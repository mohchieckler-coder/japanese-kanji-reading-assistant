(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __commonJS = (cb, mod) => function __require() {
    try {
      return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
    } catch (e) {
      throw mod = 0, e;
    }
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));

  // node_modules/kuromoji/src/viterbi/ViterbiNode.js
  var require_ViterbiNode = __commonJS({
    "node_modules/kuromoji/src/viterbi/ViterbiNode.js"(exports, module) {
      "use strict";
      function ViterbiNode(node_name, node_cost, start_pos, length, type, left_id, right_id, surface_form) {
        this.name = node_name;
        this.cost = node_cost;
        this.start_pos = start_pos;
        this.length = length;
        this.left_id = left_id;
        this.right_id = right_id;
        this.prev = null;
        this.surface_form = surface_form;
        if (type === "BOS") {
          this.shortest_cost = 0;
        } else {
          this.shortest_cost = Number.MAX_VALUE;
        }
        this.type = type;
      }
      module.exports = ViterbiNode;
    }
  });

  // node_modules/kuromoji/src/viterbi/ViterbiLattice.js
  var require_ViterbiLattice = __commonJS({
    "node_modules/kuromoji/src/viterbi/ViterbiLattice.js"(exports, module) {
      "use strict";
      var ViterbiNode = require_ViterbiNode();
      function ViterbiLattice() {
        this.nodes_end_at = [];
        this.nodes_end_at[0] = [new ViterbiNode(-1, 0, 0, 0, "BOS", 0, 0, "")];
        this.eos_pos = 1;
      }
      ViterbiLattice.prototype.append = function(node) {
        var last_pos = node.start_pos + node.length - 1;
        if (this.eos_pos < last_pos) {
          this.eos_pos = last_pos;
        }
        var prev_nodes = this.nodes_end_at[last_pos];
        if (prev_nodes == null) {
          prev_nodes = [];
        }
        prev_nodes.push(node);
        this.nodes_end_at[last_pos] = prev_nodes;
      };
      ViterbiLattice.prototype.appendEos = function() {
        var last_index = this.nodes_end_at.length;
        this.eos_pos++;
        this.nodes_end_at[last_index] = [new ViterbiNode(-1, 0, this.eos_pos, 0, "EOS", 0, 0, "")];
      };
      module.exports = ViterbiLattice;
    }
  });

  // node_modules/kuromoji/src/util/SurrogateAwareString.js
  var require_SurrogateAwareString = __commonJS({
    "node_modules/kuromoji/src/util/SurrogateAwareString.js"(exports, module) {
      "use strict";
      function SurrogateAwareString(str) {
        this.str = str;
        this.index_mapping = [];
        for (var pos = 0; pos < str.length; pos++) {
          var ch = str.charAt(pos);
          this.index_mapping.push(pos);
          if (SurrogateAwareString.isSurrogatePair(ch)) {
            pos++;
          }
        }
        this.length = this.index_mapping.length;
      }
      SurrogateAwareString.prototype.slice = function(index) {
        if (this.index_mapping.length <= index) {
          return "";
        }
        var surrogate_aware_index = this.index_mapping[index];
        return this.str.slice(surrogate_aware_index);
      };
      SurrogateAwareString.prototype.charAt = function(index) {
        if (this.str.length <= index) {
          return "";
        }
        var surrogate_aware_start_index = this.index_mapping[index];
        var surrogate_aware_end_index = this.index_mapping[index + 1];
        if (surrogate_aware_end_index == null) {
          return this.str.slice(surrogate_aware_start_index);
        }
        return this.str.slice(surrogate_aware_start_index, surrogate_aware_end_index);
      };
      SurrogateAwareString.prototype.charCodeAt = function(index) {
        if (this.index_mapping.length <= index) {
          return NaN;
        }
        var surrogate_aware_index = this.index_mapping[index];
        var upper = this.str.charCodeAt(surrogate_aware_index);
        var lower;
        if (upper >= 55296 && upper <= 56319 && surrogate_aware_index < this.str.length) {
          lower = this.str.charCodeAt(surrogate_aware_index + 1);
          if (lower >= 56320 && lower <= 57343) {
            return (upper - 55296) * 1024 + lower - 56320 + 65536;
          }
        }
        return upper;
      };
      SurrogateAwareString.prototype.toString = function() {
        return this.str;
      };
      SurrogateAwareString.isSurrogatePair = function(ch) {
        var utf16_code = ch.charCodeAt(0);
        if (utf16_code >= 55296 && utf16_code <= 56319) {
          return true;
        } else {
          return false;
        }
      };
      module.exports = SurrogateAwareString;
    }
  });

  // node_modules/kuromoji/src/viterbi/ViterbiBuilder.js
  var require_ViterbiBuilder = __commonJS({
    "node_modules/kuromoji/src/viterbi/ViterbiBuilder.js"(exports, module) {
      "use strict";
      var ViterbiNode = require_ViterbiNode();
      var ViterbiLattice = require_ViterbiLattice();
      var SurrogateAwareString = require_SurrogateAwareString();
      function ViterbiBuilder(dic) {
        this.trie = dic.trie;
        this.token_info_dictionary = dic.token_info_dictionary;
        this.unknown_dictionary = dic.unknown_dictionary;
      }
      ViterbiBuilder.prototype.build = function(sentence_str) {
        var lattice = new ViterbiLattice();
        var sentence = new SurrogateAwareString(sentence_str);
        var key, trie_id, left_id, right_id, word_cost;
        for (var pos = 0; pos < sentence.length; pos++) {
          var tail = sentence.slice(pos);
          var vocabulary = this.trie.commonPrefixSearch(tail);
          for (var n = 0; n < vocabulary.length; n++) {
            trie_id = vocabulary[n].v;
            key = vocabulary[n].k;
            var token_info_ids = this.token_info_dictionary.target_map[trie_id];
            for (var i = 0; i < token_info_ids.length; i++) {
              var token_info_id = parseInt(token_info_ids[i]);
              left_id = this.token_info_dictionary.dictionary.getShort(token_info_id);
              right_id = this.token_info_dictionary.dictionary.getShort(token_info_id + 2);
              word_cost = this.token_info_dictionary.dictionary.getShort(token_info_id + 4);
              lattice.append(new ViterbiNode(token_info_id, word_cost, pos + 1, key.length, "KNOWN", left_id, right_id, key));
            }
          }
          var surrogate_aware_tail = new SurrogateAwareString(tail);
          var head_char = new SurrogateAwareString(surrogate_aware_tail.charAt(0));
          var head_char_class = this.unknown_dictionary.lookup(head_char.toString());
          if (vocabulary == null || vocabulary.length === 0 || head_char_class.is_always_invoke === 1) {
            key = head_char;
            if (head_char_class.is_grouping === 1 && 1 < surrogate_aware_tail.length) {
              for (var k = 1; k < surrogate_aware_tail.length; k++) {
                var next_char = surrogate_aware_tail.charAt(k);
                var next_char_class = this.unknown_dictionary.lookup(next_char);
                if (head_char_class.class_name !== next_char_class.class_name) {
                  break;
                }
                key += next_char;
              }
            }
            var unk_ids = this.unknown_dictionary.target_map[head_char_class.class_id];
            for (var j = 0; j < unk_ids.length; j++) {
              var unk_id = parseInt(unk_ids[j]);
              left_id = this.unknown_dictionary.dictionary.getShort(unk_id);
              right_id = this.unknown_dictionary.dictionary.getShort(unk_id + 2);
              word_cost = this.unknown_dictionary.dictionary.getShort(unk_id + 4);
              lattice.append(new ViterbiNode(unk_id, word_cost, pos + 1, key.length, "UNKNOWN", left_id, right_id, key.toString()));
            }
          }
        }
        lattice.appendEos();
        return lattice;
      };
      module.exports = ViterbiBuilder;
    }
  });

  // node_modules/kuromoji/src/viterbi/ViterbiSearcher.js
  var require_ViterbiSearcher = __commonJS({
    "node_modules/kuromoji/src/viterbi/ViterbiSearcher.js"(exports, module) {
      "use strict";
      function ViterbiSearcher(connection_costs) {
        this.connection_costs = connection_costs;
      }
      ViterbiSearcher.prototype.search = function(lattice) {
        lattice = this.forward(lattice);
        return this.backward(lattice);
      };
      ViterbiSearcher.prototype.forward = function(lattice) {
        var i, j, k;
        for (i = 1; i <= lattice.eos_pos; i++) {
          var nodes = lattice.nodes_end_at[i];
          if (nodes == null) {
            continue;
          }
          for (j = 0; j < nodes.length; j++) {
            var node = nodes[j];
            var cost = Number.MAX_VALUE;
            var shortest_prev_node;
            var prev_nodes = lattice.nodes_end_at[node.start_pos - 1];
            if (prev_nodes == null) {
              continue;
            }
            for (k = 0; k < prev_nodes.length; k++) {
              var prev_node = prev_nodes[k];
              var edge_cost;
              if (node.left_id == null || prev_node.right_id == null) {
                console.log("Left or right is null");
                edge_cost = 0;
              } else {
                edge_cost = this.connection_costs.get(prev_node.right_id, node.left_id);
              }
              var _cost = prev_node.shortest_cost + edge_cost + node.cost;
              if (_cost < cost) {
                shortest_prev_node = prev_node;
                cost = _cost;
              }
            }
            node.prev = shortest_prev_node;
            node.shortest_cost = cost;
          }
        }
        return lattice;
      };
      ViterbiSearcher.prototype.backward = function(lattice) {
        var shortest_path = [];
        var eos = lattice.nodes_end_at[lattice.nodes_end_at.length - 1][0];
        var node_back = eos.prev;
        if (node_back == null) {
          return [];
        }
        while (node_back.type !== "BOS") {
          shortest_path.push(node_back);
          if (node_back.prev == null) {
            return [];
          }
          node_back = node_back.prev;
        }
        return shortest_path.reverse();
      };
      module.exports = ViterbiSearcher;
    }
  });

  // node_modules/kuromoji/src/util/IpadicFormatter.js
  var require_IpadicFormatter = __commonJS({
    "node_modules/kuromoji/src/util/IpadicFormatter.js"(exports, module) {
      "use strict";
      function IpadicFormatter() {
      }
      IpadicFormatter.prototype.formatEntry = function(word_id, position, type, features) {
        var token = {};
        token.word_id = word_id;
        token.word_type = type;
        token.word_position = position;
        token.surface_form = features[0];
        token.pos = features[1];
        token.pos_detail_1 = features[2];
        token.pos_detail_2 = features[3];
        token.pos_detail_3 = features[4];
        token.conjugated_type = features[5];
        token.conjugated_form = features[6];
        token.basic_form = features[7];
        token.reading = features[8];
        token.pronunciation = features[9];
        return token;
      };
      IpadicFormatter.prototype.formatUnknownEntry = function(word_id, position, type, features, surface_form) {
        var token = {};
        token.word_id = word_id;
        token.word_type = type;
        token.word_position = position;
        token.surface_form = surface_form;
        token.pos = features[1];
        token.pos_detail_1 = features[2];
        token.pos_detail_2 = features[3];
        token.pos_detail_3 = features[4];
        token.conjugated_type = features[5];
        token.conjugated_form = features[6];
        token.basic_form = features[7];
        return token;
      };
      module.exports = IpadicFormatter;
    }
  });

  // node_modules/kuromoji/src/Tokenizer.js
  var require_Tokenizer = __commonJS({
    "node_modules/kuromoji/src/Tokenizer.js"(exports, module) {
      "use strict";
      var ViterbiBuilder = require_ViterbiBuilder();
      var ViterbiSearcher = require_ViterbiSearcher();
      var IpadicFormatter = require_IpadicFormatter();
      var PUNCTUATION = /、|。/;
      function Tokenizer(dic) {
        this.token_info_dictionary = dic.token_info_dictionary;
        this.unknown_dictionary = dic.unknown_dictionary;
        this.viterbi_builder = new ViterbiBuilder(dic);
        this.viterbi_searcher = new ViterbiSearcher(dic.connection_costs);
        this.formatter = new IpadicFormatter();
      }
      Tokenizer.splitByPunctuation = function(input) {
        var sentences = [];
        var tail = input;
        while (true) {
          if (tail === "") {
            break;
          }
          var index = tail.search(PUNCTUATION);
          if (index < 0) {
            sentences.push(tail);
            break;
          }
          sentences.push(tail.substring(0, index + 1));
          tail = tail.substring(index + 1);
        }
        return sentences;
      };
      Tokenizer.prototype.tokenize = function(text) {
        var sentences = Tokenizer.splitByPunctuation(text);
        var tokens = [];
        for (var i = 0; i < sentences.length; i++) {
          var sentence = sentences[i];
          this.tokenizeForSentence(sentence, tokens);
        }
        return tokens;
      };
      Tokenizer.prototype.tokenizeForSentence = function(sentence, tokens) {
        if (tokens == null) {
          tokens = [];
        }
        var lattice = this.getLattice(sentence);
        var best_path = this.viterbi_searcher.search(lattice);
        var last_pos = 0;
        if (tokens.length > 0) {
          last_pos = tokens[tokens.length - 1].word_position;
        }
        for (var j = 0; j < best_path.length; j++) {
          var node = best_path[j];
          var token, features, features_line;
          if (node.type === "KNOWN") {
            features_line = this.token_info_dictionary.getFeatures(node.name);
            if (features_line == null) {
              features = [];
            } else {
              features = features_line.split(",");
            }
            token = this.formatter.formatEntry(node.name, last_pos + node.start_pos, node.type, features);
          } else if (node.type === "UNKNOWN") {
            features_line = this.unknown_dictionary.getFeatures(node.name);
            if (features_line == null) {
              features = [];
            } else {
              features = features_line.split(",");
            }
            token = this.formatter.formatUnknownEntry(node.name, last_pos + node.start_pos, node.type, features, node.surface_form);
          } else {
            token = this.formatter.formatEntry(node.name, last_pos + node.start_pos, node.type, []);
          }
          tokens.push(token);
        }
        return tokens;
      };
      Tokenizer.prototype.getLattice = function(text) {
        return this.viterbi_builder.build(text);
      };
      module.exports = Tokenizer;
    }
  });

  // node_modules/zlibjs/bin/gunzip.min.js
  var require_gunzip_min = __commonJS({
    "node_modules/zlibjs/bin/gunzip.min.js"(exports) {
      (function() {
        "use strict";
        function n(e) {
          throw e;
        }
        var p = void 0, aa = this;
        function t(e, b) {
          var d = e.split("."), c = aa;
          !(d[0] in c) && c.execScript && c.execScript("var " + d[0]);
          for (var a; d.length && (a = d.shift()); ) !d.length && b !== p ? c[a] = b : c = c[a] ? c[a] : c[a] = {};
        }
        ;
        var x = "undefined" !== typeof Uint8Array && "undefined" !== typeof Uint16Array && "undefined" !== typeof Uint32Array && "undefined" !== typeof DataView;
        new (x ? Uint8Array : Array)(256);
        var y;
        for (y = 0; 256 > y; ++y) for (var A = y, ba = 7, A = A >>> 1; A; A >>>= 1) --ba;
        function B(e, b, d) {
          var c, a = "number" === typeof b ? b : b = 0, f = "number" === typeof d ? d : e.length;
          c = -1;
          for (a = f & 7; a--; ++b) c = c >>> 8 ^ C[(c ^ e[b]) & 255];
          for (a = f >> 3; a--; b += 8) c = c >>> 8 ^ C[(c ^ e[b]) & 255], c = c >>> 8 ^ C[(c ^ e[b + 1]) & 255], c = c >>> 8 ^ C[(c ^ e[b + 2]) & 255], c = c >>> 8 ^ C[(c ^ e[b + 3]) & 255], c = c >>> 8 ^ C[(c ^ e[b + 4]) & 255], c = c >>> 8 ^ C[(c ^ e[b + 5]) & 255], c = c >>> 8 ^ C[(c ^ e[b + 6]) & 255], c = c >>> 8 ^ C[(c ^ e[b + 7]) & 255];
          return (c ^ 4294967295) >>> 0;
        }
        var D = [
          0,
          1996959894,
          3993919788,
          2567524794,
          124634137,
          1886057615,
          3915621685,
          2657392035,
          249268274,
          2044508324,
          3772115230,
          2547177864,
          162941995,
          2125561021,
          3887607047,
          2428444049,
          498536548,
          1789927666,
          4089016648,
          2227061214,
          450548861,
          1843258603,
          4107580753,
          2211677639,
          325883990,
          1684777152,
          4251122042,
          2321926636,
          335633487,
          1661365465,
          4195302755,
          2366115317,
          997073096,
          1281953886,
          3579855332,
          2724688242,
          1006888145,
          1258607687,
          3524101629,
          2768942443,
          901097722,
          1119000684,
          3686517206,
          2898065728,
          853044451,
          1172266101,
          3705015759,
          2882616665,
          651767980,
          1373503546,
          3369554304,
          3218104598,
          565507253,
          1454621731,
          3485111705,
          3099436303,
          671266974,
          1594198024,
          3322730930,
          2970347812,
          795835527,
          1483230225,
          3244367275,
          3060149565,
          1994146192,
          31158534,
          2563907772,
          4023717930,
          1907459465,
          112637215,
          2680153253,
          3904427059,
          2013776290,
          251722036,
          2517215374,
          3775830040,
          2137656763,
          141376813,
          2439277719,
          3865271297,
          1802195444,
          476864866,
          2238001368,
          4066508878,
          1812370925,
          453092731,
          2181625025,
          4111451223,
          1706088902,
          314042704,
          2344532202,
          4240017532,
          1658658271,
          366619977,
          2362670323,
          4224994405,
          1303535960,
          984961486,
          2747007092,
          3569037538,
          1256170817,
          1037604311,
          2765210733,
          3554079995,
          1131014506,
          879679996,
          2909243462,
          3663771856,
          1141124467,
          855842277,
          2852801631,
          3708648649,
          1342533948,
          654459306,
          3188396048,
          3373015174,
          1466479909,
          544179635,
          3110523913,
          3462522015,
          1591671054,
          702138776,
          2966460450,
          3352799412,
          1504918807,
          783551873,
          3082640443,
          3233442989,
          3988292384,
          2596254646,
          62317068,
          1957810842,
          3939845945,
          2647816111,
          81470997,
          1943803523,
          3814918930,
          2489596804,
          225274430,
          2053790376,
          3826175755,
          2466906013,
          167816743,
          2097651377,
          4027552580,
          2265490386,
          503444072,
          1762050814,
          4150417245,
          2154129355,
          426522225,
          1852507879,
          4275313526,
          2312317920,
          282753626,
          1742555852,
          4189708143,
          2394877945,
          397917763,
          1622183637,
          3604390888,
          2714866558,
          953729732,
          1340076626,
          3518719985,
          2797360999,
          1068828381,
          1219638859,
          3624741850,
          2936675148,
          906185462,
          1090812512,
          3747672003,
          2825379669,
          829329135,
          1181335161,
          3412177804,
          3160834842,
          628085408,
          1382605366,
          3423369109,
          3138078467,
          570562233,
          1426400815,
          3317316542,
          2998733608,
          733239954,
          1555261956,
          3268935591,
          3050360625,
          752459403,
          1541320221,
          2607071920,
          3965973030,
          1969922972,
          40735498,
          2617837225,
          3943577151,
          1913087877,
          83908371,
          2512341634,
          3803740692,
          2075208622,
          213261112,
          2463272603,
          3855990285,
          2094854071,
          198958881,
          2262029012,
          4057260610,
          1759359992,
          534414190,
          2176718541,
          4139329115,
          1873836001,
          414664567,
          2282248934,
          4279200368,
          1711684554,
          285281116,
          2405801727,
          4167216745,
          1634467795,
          376229701,
          2685067896,
          3608007406,
          1308918612,
          956543938,
          2808555105,
          3495958263,
          1231636301,
          1047427035,
          2932959818,
          3654703836,
          1088359270,
          936918e3,
          2847714899,
          3736837829,
          1202900863,
          817233897,
          3183342108,
          3401237130,
          1404277552,
          615818150,
          3134207493,
          3453421203,
          1423857449,
          601450431,
          3009837614,
          3294710456,
          1567103746,
          711928724,
          3020668471,
          3272380065,
          1510334235,
          755167117
        ], C = x ? new Uint32Array(D) : D;
        function E() {
        }
        E.prototype.getName = function() {
          return this.name;
        };
        E.prototype.getData = function() {
          return this.data;
        };
        E.prototype.G = function() {
          return this.H;
        };
        function G(e) {
          var b = e.length, d = 0, c = Number.POSITIVE_INFINITY, a, f, k, l, m, r, q, g, h, v;
          for (g = 0; g < b; ++g) e[g] > d && (d = e[g]), e[g] < c && (c = e[g]);
          a = 1 << d;
          f = new (x ? Uint32Array : Array)(a);
          k = 1;
          l = 0;
          for (m = 2; k <= d; ) {
            for (g = 0; g < b; ++g) if (e[g] === k) {
              r = 0;
              q = l;
              for (h = 0; h < k; ++h) r = r << 1 | q & 1, q >>= 1;
              v = k << 16 | g;
              for (h = r; h < a; h += m) f[h] = v;
              ++l;
            }
            ++k;
            l <<= 1;
            m <<= 1;
          }
          return [f, d, c];
        }
        ;
        var J = [], K;
        for (K = 0; 288 > K; K++) switch (true) {
          case 143 >= K:
            J.push([K + 48, 8]);
            break;
          case 255 >= K:
            J.push([K - 144 + 400, 9]);
            break;
          case 279 >= K:
            J.push([K - 256 + 0, 7]);
            break;
          case 287 >= K:
            J.push([K - 280 + 192, 8]);
            break;
          default:
            n("invalid literal: " + K);
        }
        var ca = (function() {
          function e(a) {
            switch (true) {
              case 3 === a:
                return [257, a - 3, 0];
              case 4 === a:
                return [258, a - 4, 0];
              case 5 === a:
                return [259, a - 5, 0];
              case 6 === a:
                return [260, a - 6, 0];
              case 7 === a:
                return [261, a - 7, 0];
              case 8 === a:
                return [262, a - 8, 0];
              case 9 === a:
                return [263, a - 9, 0];
              case 10 === a:
                return [264, a - 10, 0];
              case 12 >= a:
                return [265, a - 11, 1];
              case 14 >= a:
                return [266, a - 13, 1];
              case 16 >= a:
                return [267, a - 15, 1];
              case 18 >= a:
                return [268, a - 17, 1];
              case 22 >= a:
                return [269, a - 19, 2];
              case 26 >= a:
                return [270, a - 23, 2];
              case 30 >= a:
                return [271, a - 27, 2];
              case 34 >= a:
                return [
                  272,
                  a - 31,
                  2
                ];
              case 42 >= a:
                return [273, a - 35, 3];
              case 50 >= a:
                return [274, a - 43, 3];
              case 58 >= a:
                return [275, a - 51, 3];
              case 66 >= a:
                return [276, a - 59, 3];
              case 82 >= a:
                return [277, a - 67, 4];
              case 98 >= a:
                return [278, a - 83, 4];
              case 114 >= a:
                return [279, a - 99, 4];
              case 130 >= a:
                return [280, a - 115, 4];
              case 162 >= a:
                return [281, a - 131, 5];
              case 194 >= a:
                return [282, a - 163, 5];
              case 226 >= a:
                return [283, a - 195, 5];
              case 257 >= a:
                return [284, a - 227, 5];
              case 258 === a:
                return [285, a - 258, 0];
              default:
                n("invalid length: " + a);
            }
          }
          var b = [], d, c;
          for (d = 3; 258 >= d; d++) c = e(d), b[d] = c[2] << 24 | c[1] << 16 | c[0];
          return b;
        })();
        x && new Uint32Array(ca);
        function L(e, b) {
          this.i = [];
          this.j = 32768;
          this.d = this.f = this.c = this.n = 0;
          this.input = x ? new Uint8Array(e) : e;
          this.o = false;
          this.k = M;
          this.w = false;
          if (b || !(b = {})) b.index && (this.c = b.index), b.bufferSize && (this.j = b.bufferSize), b.bufferType && (this.k = b.bufferType), b.resize && (this.w = b.resize);
          switch (this.k) {
            case N:
              this.a = 32768;
              this.b = new (x ? Uint8Array : Array)(32768 + this.j + 258);
              break;
            case M:
              this.a = 0;
              this.b = new (x ? Uint8Array : Array)(this.j);
              this.e = this.D;
              this.q = this.A;
              this.l = this.C;
              break;
            default:
              n(Error("invalid inflate mode"));
          }
        }
        var N = 0, M = 1;
        L.prototype.g = function() {
          for (; !this.o; ) {
            var e = P(this, 3);
            e & 1 && (this.o = true);
            e >>>= 1;
            switch (e) {
              case 0:
                var b = this.input, d = this.c, c = this.b, a = this.a, f = b.length, k = p, l = p, m = c.length, r = p;
                this.d = this.f = 0;
                d + 1 >= f && n(Error("invalid uncompressed block header: LEN"));
                k = b[d++] | b[d++] << 8;
                d + 1 >= f && n(Error("invalid uncompressed block header: NLEN"));
                l = b[d++] | b[d++] << 8;
                k === ~l && n(Error("invalid uncompressed block header: length verify"));
                d + k > b.length && n(Error("input buffer is broken"));
                switch (this.k) {
                  case N:
                    for (; a + k > c.length; ) {
                      r = m - a;
                      k -= r;
                      if (x) c.set(b.subarray(d, d + r), a), a += r, d += r;
                      else for (; r--; ) c[a++] = b[d++];
                      this.a = a;
                      c = this.e();
                      a = this.a;
                    }
                    break;
                  case M:
                    for (; a + k > c.length; ) c = this.e({ t: 2 });
                    break;
                  default:
                    n(Error("invalid inflate mode"));
                }
                if (x) c.set(b.subarray(d, d + k), a), a += k, d += k;
                else for (; k--; ) c[a++] = b[d++];
                this.c = d;
                this.a = a;
                this.b = c;
                break;
              case 1:
                this.l(da, ea);
                break;
              case 2:
                for (var q = P(this, 5) + 257, g = P(this, 5) + 1, h = P(this, 4) + 4, v = new (x ? Uint8Array : Array)(Q.length), s = p, F = p, H = p, w = p, z = p, O = p, I = p, u = p, Z = p, u = 0; u < h; ++u) v[Q[u]] = P(this, 3);
                if (!x) {
                  u = h;
                  for (h = v.length; u < h; ++u) v[Q[u]] = 0;
                }
                s = G(v);
                w = new (x ? Uint8Array : Array)(q + g);
                u = 0;
                for (Z = q + g; u < Z; ) switch (z = R(this, s), z) {
                  case 16:
                    for (I = 3 + P(this, 2); I--; ) w[u++] = O;
                    break;
                  case 17:
                    for (I = 3 + P(this, 3); I--; ) w[u++] = 0;
                    O = 0;
                    break;
                  case 18:
                    for (I = 11 + P(this, 7); I--; ) w[u++] = 0;
                    O = 0;
                    break;
                  default:
                    O = w[u++] = z;
                }
                F = x ? G(w.subarray(0, q)) : G(w.slice(0, q));
                H = x ? G(w.subarray(q)) : G(w.slice(q));
                this.l(F, H);
                break;
              default:
                n(Error("unknown BTYPE: " + e));
            }
          }
          return this.q();
        };
        var S = [16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15], Q = x ? new Uint16Array(S) : S, fa = [3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27, 31, 35, 43, 51, 59, 67, 83, 99, 115, 131, 163, 195, 227, 258, 258, 258], ga = x ? new Uint16Array(fa) : fa, ha = [0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0, 0, 0], T = x ? new Uint8Array(ha) : ha, ia = [1, 2, 3, 4, 5, 7, 9, 13, 17, 25, 33, 49, 65, 97, 129, 193, 257, 385, 513, 769, 1025, 1537, 2049, 3073, 4097, 6145, 8193, 12289, 16385, 24577], ja = x ? new Uint16Array(ia) : ia, ka = [
          0,
          0,
          0,
          0,
          1,
          1,
          2,
          2,
          3,
          3,
          4,
          4,
          5,
          5,
          6,
          6,
          7,
          7,
          8,
          8,
          9,
          9,
          10,
          10,
          11,
          11,
          12,
          12,
          13,
          13
        ], U = x ? new Uint8Array(ka) : ka, V = new (x ? Uint8Array : Array)(288), W, la;
        W = 0;
        for (la = V.length; W < la; ++W) V[W] = 143 >= W ? 8 : 255 >= W ? 9 : 279 >= W ? 7 : 8;
        var da = G(V), X = new (x ? Uint8Array : Array)(30), Y, ma;
        Y = 0;
        for (ma = X.length; Y < ma; ++Y) X[Y] = 5;
        var ea = G(X);
        function P(e, b) {
          for (var d = e.f, c = e.d, a = e.input, f = e.c, k = a.length, l; c < b; ) f >= k && n(Error("input buffer is broken")), d |= a[f++] << c, c += 8;
          l = d & (1 << b) - 1;
          e.f = d >>> b;
          e.d = c - b;
          e.c = f;
          return l;
        }
        function R(e, b) {
          for (var d = e.f, c = e.d, a = e.input, f = e.c, k = a.length, l = b[0], m = b[1], r, q; c < m && !(f >= k); ) d |= a[f++] << c, c += 8;
          r = l[d & (1 << m) - 1];
          q = r >>> 16;
          q > c && n(Error("invalid code length: " + q));
          e.f = d >> q;
          e.d = c - q;
          e.c = f;
          return r & 65535;
        }
        L.prototype.l = function(e, b) {
          var d = this.b, c = this.a;
          this.r = e;
          for (var a = d.length - 258, f, k, l, m; 256 !== (f = R(this, e)); ) if (256 > f) c >= a && (this.a = c, d = this.e(), c = this.a), d[c++] = f;
          else {
            k = f - 257;
            m = ga[k];
            0 < T[k] && (m += P(this, T[k]));
            f = R(this, b);
            l = ja[f];
            0 < U[f] && (l += P(this, U[f]));
            c >= a && (this.a = c, d = this.e(), c = this.a);
            for (; m--; ) d[c] = d[c++ - l];
          }
          for (; 8 <= this.d; ) this.d -= 8, this.c--;
          this.a = c;
        };
        L.prototype.C = function(e, b) {
          var d = this.b, c = this.a;
          this.r = e;
          for (var a = d.length, f, k, l, m; 256 !== (f = R(this, e)); ) if (256 > f) c >= a && (d = this.e(), a = d.length), d[c++] = f;
          else {
            k = f - 257;
            m = ga[k];
            0 < T[k] && (m += P(this, T[k]));
            f = R(this, b);
            l = ja[f];
            0 < U[f] && (l += P(this, U[f]));
            c + m > a && (d = this.e(), a = d.length);
            for (; m--; ) d[c] = d[c++ - l];
          }
          for (; 8 <= this.d; ) this.d -= 8, this.c--;
          this.a = c;
        };
        L.prototype.e = function() {
          var e = new (x ? Uint8Array : Array)(this.a - 32768), b = this.a - 32768, d, c, a = this.b;
          if (x) e.set(a.subarray(32768, e.length));
          else {
            d = 0;
            for (c = e.length; d < c; ++d) e[d] = a[d + 32768];
          }
          this.i.push(e);
          this.n += e.length;
          if (x) a.set(a.subarray(b, b + 32768));
          else for (d = 0; 32768 > d; ++d) a[d] = a[b + d];
          this.a = 32768;
          return a;
        };
        L.prototype.D = function(e) {
          var b, d = this.input.length / this.c + 1 | 0, c, a, f, k = this.input, l = this.b;
          e && ("number" === typeof e.t && (d = e.t), "number" === typeof e.z && (d += e.z));
          2 > d ? (c = (k.length - this.c) / this.r[2], f = 258 * (c / 2) | 0, a = f < l.length ? l.length + f : l.length << 1) : a = l.length * d;
          x ? (b = new Uint8Array(a), b.set(l)) : b = l;
          return this.b = b;
        };
        L.prototype.q = function() {
          var e = 0, b = this.b, d = this.i, c, a = new (x ? Uint8Array : Array)(this.n + (this.a - 32768)), f, k, l, m;
          if (0 === d.length) return x ? this.b.subarray(32768, this.a) : this.b.slice(32768, this.a);
          f = 0;
          for (k = d.length; f < k; ++f) {
            c = d[f];
            l = 0;
            for (m = c.length; l < m; ++l) a[e++] = c[l];
          }
          f = 32768;
          for (k = this.a; f < k; ++f) a[e++] = b[f];
          this.i = [];
          return this.buffer = a;
        };
        L.prototype.A = function() {
          var e, b = this.a;
          x ? this.w ? (e = new Uint8Array(b), e.set(this.b.subarray(0, b))) : e = this.b.subarray(0, b) : (this.b.length > b && (this.b.length = b), e = this.b);
          return this.buffer = e;
        };
        function $(e) {
          this.input = e;
          this.c = 0;
          this.m = [];
          this.s = false;
        }
        $.prototype.F = function() {
          this.s || this.g();
          return this.m.slice();
        };
        $.prototype.g = function() {
          for (var e = this.input.length; this.c < e; ) {
            var b = new E(), d = p, c = p, a = p, f = p, k = p, l = p, m = p, r = p, q = p, g = this.input, h = this.c;
            b.u = g[h++];
            b.v = g[h++];
            (31 !== b.u || 139 !== b.v) && n(Error("invalid file signature:" + b.u + "," + b.v));
            b.p = g[h++];
            switch (b.p) {
              case 8:
                break;
              default:
                n(Error("unknown compression method: " + b.p));
            }
            b.h = g[h++];
            r = g[h++] | g[h++] << 8 | g[h++] << 16 | g[h++] << 24;
            b.H = new Date(1e3 * r);
            b.N = g[h++];
            b.M = g[h++];
            0 < (b.h & 4) && (b.I = g[h++] | g[h++] << 8, h += b.I);
            if (0 < (b.h & 8)) {
              m = [];
              for (l = 0; 0 < (k = g[h++]); ) m[l++] = String.fromCharCode(k);
              b.name = m.join("");
            }
            if (0 < (b.h & 16)) {
              m = [];
              for (l = 0; 0 < (k = g[h++]); ) m[l++] = String.fromCharCode(k);
              b.J = m.join("");
            }
            0 < (b.h & 2) && (b.B = B(g, 0, h) & 65535, b.B !== (g[h++] | g[h++] << 8) && n(Error("invalid header crc16")));
            d = g[g.length - 4] | g[g.length - 3] << 8 | g[g.length - 2] << 16 | g[g.length - 1] << 24;
            g.length - h - 4 - 4 < 512 * d && (f = d);
            c = new L(g, { index: h, bufferSize: f });
            b.data = a = c.g();
            h = c.c;
            b.K = q = (g[h++] | g[h++] << 8 | g[h++] << 16 | g[h++] << 24) >>> 0;
            B(a, p, p) !== q && n(Error("invalid CRC-32 checksum: 0x" + B(a, p, p).toString(16) + " / 0x" + q.toString(16)));
            b.L = d = (g[h++] | g[h++] << 8 | g[h++] << 16 | g[h++] << 24) >>> 0;
            (a.length & 4294967295) !== d && n(Error("invalid input size: " + (a.length & 4294967295) + " / " + d));
            this.m.push(b);
            this.c = h;
          }
          this.s = true;
          var v = this.m, s, F, H = 0, w = 0, z;
          s = 0;
          for (F = v.length; s < F; ++s) w += v[s].data.length;
          if (x) {
            z = new Uint8Array(w);
            for (s = 0; s < F; ++s) z.set(v[s].data, H), H += v[s].data.length;
          } else {
            z = [];
            for (s = 0; s < F; ++s) z[s] = v[s].data;
            z = Array.prototype.concat.apply([], z);
          }
          return z;
        };
        t("Zlib.Gunzip", $);
        t("Zlib.Gunzip.prototype.decompress", $.prototype.g);
        t("Zlib.Gunzip.prototype.getMembers", $.prototype.F);
        t("Zlib.GunzipMember", E);
        t("Zlib.GunzipMember.prototype.getName", E.prototype.getName);
        t("Zlib.GunzipMember.prototype.getData", E.prototype.getData);
        t("Zlib.GunzipMember.prototype.getMtime", E.prototype.G);
      }).call(exports);
    }
  });

  // src/path-shim.cjs
  var require_path_shim = __commonJS({
    "src/path-shim.cjs"(exports, module) {
      "use strict";
      module.exports = {
        join(base, ...parts) {
          const normalizedBase = String(base).replace(/[\\/]+$/, "");
          const suffix = parts.map((part) => String(part).replace(/^[\\/]+|[\\/]+$/g, "")).filter(Boolean).join("/");
          return suffix ? `${normalizedBase}/${suffix}` : normalizedBase;
        }
      };
    }
  });

  // src/async-shim.cjs
  var require_async_shim = __commonJS({
    "src/async-shim.cjs"(exports, module) {
      "use strict";
      function once(callback) {
        let called = false;
        return (...args) => {
          if (called) {
            return;
          }
          called = true;
          callback(...args);
        };
      }
      function map(items, iteratee, callback) {
        const done = once(callback);
        if (!Array.isArray(items) || items.length === 0) {
          done(null, []);
          return;
        }
        const results = new Array(items.length);
        let remaining = items.length;
        items.forEach((item, index) => {
          const completeItem = once((error, value) => {
            if (error) {
              done(error);
              return;
            }
            results[index] = value;
            remaining -= 1;
            if (remaining === 0) {
              done(null, results);
            }
          });
          try {
            iteratee(item, completeItem);
          } catch (error) {
            completeItem(error);
          }
        });
      }
      function parallel(tasks, callback) {
        map(
          tasks,
          (task, completeTask) => {
            task(completeTask);
          },
          callback
        );
      }
      module.exports = { map, parallel };
    }
  });

  // node_modules/doublearray/doublearray.js
  var require_doublearray = __commonJS({
    "node_modules/doublearray/doublearray.js"(exports, module) {
      (function() {
        "use strict";
        var TERM_CHAR = "\0", TERM_CODE = 0, ROOT_ID = 0, NOT_FOUND = -1, BASE_SIGNED = true, CHECK_SIGNED = true, BASE_BYTES = 4, CHECK_BYTES = 4, MEMORY_EXPAND_RATIO = 2;
        var newBC = function(initial_size) {
          if (initial_size == null) {
            initial_size = 1024;
          }
          var initBase = function(_base, start, end) {
            for (var i = start; i < end; i++) {
              _base[i] = -i + 1;
            }
            if (0 < check.array[check.array.length - 1]) {
              var last_used_id = check.array.length - 2;
              while (0 < check.array[last_used_id]) {
                last_used_id--;
              }
              _base[start] = -last_used_id;
            }
          };
          var initCheck = function(_check, start, end) {
            for (var i = start; i < end; i++) {
              _check[i] = -i - 1;
            }
          };
          var realloc = function(min_size) {
            var new_size = min_size * MEMORY_EXPAND_RATIO;
            var base_new_array = newArrayBuffer(base.signed, base.bytes, new_size);
            initBase(base_new_array, base.array.length, new_size);
            base_new_array.set(base.array);
            base.array = null;
            base.array = base_new_array;
            var check_new_array = newArrayBuffer(check.signed, check.bytes, new_size);
            initCheck(check_new_array, check.array.length, new_size);
            check_new_array.set(check.array);
            check.array = null;
            check.array = check_new_array;
          };
          var first_unused_node = ROOT_ID + 1;
          var base = {
            signed: BASE_SIGNED,
            bytes: BASE_BYTES,
            array: newArrayBuffer(BASE_SIGNED, BASE_BYTES, initial_size)
          };
          var check = {
            signed: CHECK_SIGNED,
            bytes: CHECK_BYTES,
            array: newArrayBuffer(CHECK_SIGNED, CHECK_BYTES, initial_size)
          };
          base.array[ROOT_ID] = 1;
          check.array[ROOT_ID] = ROOT_ID;
          initBase(base.array, ROOT_ID + 1, base.array.length);
          initCheck(check.array, ROOT_ID + 1, check.array.length);
          return {
            getBaseBuffer: function() {
              return base.array;
            },
            getCheckBuffer: function() {
              return check.array;
            },
            loadBaseBuffer: function(base_buffer) {
              base.array = base_buffer;
              return this;
            },
            loadCheckBuffer: function(check_buffer) {
              check.array = check_buffer;
              return this;
            },
            size: function() {
              return Math.max(base.array.length, check.array.length);
            },
            getBase: function(index) {
              if (base.array.length - 1 < index) {
                return -index + 1;
              }
              return base.array[index];
            },
            getCheck: function(index) {
              if (check.array.length - 1 < index) {
                return -index - 1;
              }
              return check.array[index];
            },
            setBase: function(index, base_value) {
              if (base.array.length - 1 < index) {
                realloc(index);
              }
              base.array[index] = base_value;
            },
            setCheck: function(index, check_value) {
              if (check.array.length - 1 < index) {
                realloc(index);
              }
              check.array[index] = check_value;
            },
            setFirstUnusedNode: function(index) {
              first_unused_node = index;
            },
            getFirstUnusedNode: function() {
              return first_unused_node;
            },
            shrink: function() {
              var last_index = this.size() - 1;
              while (true) {
                if (0 <= check.array[last_index]) {
                  break;
                }
                last_index--;
              }
              base.array = base.array.subarray(0, last_index + 2);
              check.array = check.array.subarray(0, last_index + 2);
            },
            calc: function() {
              var unused_count = 0;
              var size = check.array.length;
              for (var i = 0; i < size; i++) {
                if (check.array[i] < 0) {
                  unused_count++;
                }
              }
              return {
                all: size,
                unused: unused_count,
                efficiency: (size - unused_count) / size
              };
            },
            dump: function() {
              var dump_base = "";
              var dump_check = "";
              var i;
              for (i = 0; i < base.array.length; i++) {
                dump_base = dump_base + " " + this.getBase(i);
              }
              for (i = 0; i < check.array.length; i++) {
                dump_check = dump_check + " " + this.getCheck(i);
              }
              console.log("base:" + dump_base);
              console.log("chck:" + dump_check);
              return "base:" + dump_base + " chck:" + dump_check;
            }
          };
        };
        function DoubleArrayBuilder(initial_size) {
          this.bc = newBC(initial_size);
          this.keys = [];
        }
        DoubleArrayBuilder.prototype.append = function(key, record) {
          this.keys.push({ k: key, v: record });
          return this;
        };
        DoubleArrayBuilder.prototype.build = function(keys, sorted) {
          if (keys == null) {
            keys = this.keys;
          }
          if (keys == null) {
            return new DoubleArray(this.bc);
          }
          if (sorted == null) {
            sorted = false;
          }
          var buff_keys = keys.map(function(k) {
            return {
              k: stringToUtf8Bytes(k.k + TERM_CHAR),
              v: k.v
            };
          });
          if (sorted) {
            this.keys = buff_keys;
          } else {
            this.keys = buff_keys.sort(function(k1, k2) {
              var b1 = k1.k;
              var b2 = k2.k;
              var min_length = Math.min(b1.length, b2.length);
              for (var pos = 0; pos < min_length; pos++) {
                if (b1[pos] === b2[pos]) {
                  continue;
                }
                return b1[pos] - b2[pos];
              }
              return b1.length - b2.length;
            });
          }
          buff_keys = null;
          this._build(ROOT_ID, 0, 0, this.keys.length);
          return new DoubleArray(this.bc);
        };
        DoubleArrayBuilder.prototype._build = function(parent_index, position, start, length) {
          var children_info = this.getChildrenInfo(position, start, length);
          var _base = this.findAllocatableBase(children_info);
          this.setBC(parent_index, children_info, _base);
          for (var i = 0; i < children_info.length; i = i + 3) {
            var child_code = children_info[i];
            if (child_code === TERM_CODE) {
              continue;
            }
            var child_start = children_info[i + 1];
            var child_len = children_info[i + 2];
            var child_index = _base + child_code;
            this._build(child_index, position + 1, child_start, child_len);
          }
        };
        DoubleArrayBuilder.prototype.getChildrenInfo = function(position, start, length) {
          var current_char = this.keys[start].k[position];
          var i = 0;
          var children_info = new Int32Array(length * 3);
          children_info[i++] = current_char;
          children_info[i++] = start;
          var next_pos = start;
          var start_pos = start;
          for (; next_pos < start + length; next_pos++) {
            var next_char = this.keys[next_pos].k[position];
            if (current_char !== next_char) {
              children_info[i++] = next_pos - start_pos;
              children_info[i++] = next_char;
              children_info[i++] = next_pos;
              current_char = next_char;
              start_pos = next_pos;
            }
          }
          children_info[i++] = next_pos - start_pos;
          children_info = children_info.subarray(0, i);
          return children_info;
        };
        DoubleArrayBuilder.prototype.setBC = function(parent_id, children_info, _base) {
          var bc = this.bc;
          bc.setBase(parent_id, _base);
          var i;
          for (i = 0; i < children_info.length; i = i + 3) {
            var code = children_info[i];
            var child_id = _base + code;
            var prev_unused_id = -bc.getBase(child_id);
            var next_unused_id = -bc.getCheck(child_id);
            if (child_id !== bc.getFirstUnusedNode()) {
              bc.setCheck(prev_unused_id, -next_unused_id);
            } else {
              bc.setFirstUnusedNode(next_unused_id);
            }
            bc.setBase(next_unused_id, -prev_unused_id);
            var check = parent_id;
            bc.setCheck(child_id, check);
            if (code === TERM_CODE) {
              var start_pos = children_info[i + 1];
              var value = this.keys[start_pos].v;
              if (value == null) {
                value = 0;
              }
              var base = -value - 1;
              bc.setBase(child_id, base);
            }
          }
        };
        DoubleArrayBuilder.prototype.findAllocatableBase = function(children_info) {
          var bc = this.bc;
          var _base;
          var curr = bc.getFirstUnusedNode();
          while (true) {
            _base = curr - children_info[0];
            if (_base < 0) {
              curr = -bc.getCheck(curr);
              continue;
            }
            var empty_area_found = true;
            for (var i = 0; i < children_info.length; i = i + 3) {
              var code = children_info[i];
              var candidate_id = _base + code;
              if (!this.isUnusedNode(candidate_id)) {
                curr = -bc.getCheck(curr);
                empty_area_found = false;
                break;
              }
            }
            if (empty_area_found) {
              return _base;
            }
          }
        };
        DoubleArrayBuilder.prototype.isUnusedNode = function(index) {
          var bc = this.bc;
          var check = bc.getCheck(index);
          if (index === ROOT_ID) {
            return false;
          }
          if (check < 0) {
            return true;
          }
          return false;
        };
        function DoubleArray(bc) {
          this.bc = bc;
          this.bc.shrink();
        }
        DoubleArray.prototype.contain = function(key) {
          var bc = this.bc;
          key += TERM_CHAR;
          var buffer = stringToUtf8Bytes(key);
          var parent = ROOT_ID;
          var child = NOT_FOUND;
          for (var i = 0; i < buffer.length; i++) {
            var code = buffer[i];
            child = this.traverse(parent, code);
            if (child === NOT_FOUND) {
              return false;
            }
            if (bc.getBase(child) <= 0) {
              return true;
            } else {
              parent = child;
              continue;
            }
          }
          return false;
        };
        DoubleArray.prototype.lookup = function(key) {
          key += TERM_CHAR;
          var buffer = stringToUtf8Bytes(key);
          var parent = ROOT_ID;
          var child = NOT_FOUND;
          for (var i = 0; i < buffer.length; i++) {
            var code = buffer[i];
            child = this.traverse(parent, code);
            if (child === NOT_FOUND) {
              return NOT_FOUND;
            }
            parent = child;
          }
          var base = this.bc.getBase(child);
          if (base <= 0) {
            return -base - 1;
          } else {
            return NOT_FOUND;
          }
        };
        DoubleArray.prototype.commonPrefixSearch = function(key) {
          var buffer = stringToUtf8Bytes(key);
          var parent = ROOT_ID;
          var child = NOT_FOUND;
          var result = [];
          for (var i = 0; i < buffer.length; i++) {
            var code = buffer[i];
            child = this.traverse(parent, code);
            if (child !== NOT_FOUND) {
              parent = child;
              var grand_child = this.traverse(child, TERM_CODE);
              if (grand_child !== NOT_FOUND) {
                var base = this.bc.getBase(grand_child);
                var r = {};
                if (base <= 0) {
                  r.v = -base - 1;
                }
                r.k = utf8BytesToString(arrayCopy(buffer, 0, i + 1));
                result.push(r);
              }
              continue;
            } else {
              break;
            }
          }
          return result;
        };
        DoubleArray.prototype.traverse = function(parent, code) {
          var child = this.bc.getBase(parent) + code;
          if (this.bc.getCheck(child) === parent) {
            return child;
          } else {
            return NOT_FOUND;
          }
        };
        DoubleArray.prototype.size = function() {
          return this.bc.size();
        };
        DoubleArray.prototype.calc = function() {
          return this.bc.calc();
        };
        DoubleArray.prototype.dump = function() {
          return this.bc.dump();
        };
        var newArrayBuffer = function(signed, bytes, size) {
          if (signed) {
            switch (bytes) {
              case 1:
                return new Int8Array(size);
              case 2:
                return new Int16Array(size);
              case 4:
                return new Int32Array(size);
              default:
                throw new RangeError("Invalid newArray parameter element_bytes:" + bytes);
            }
          } else {
            switch (bytes) {
              case 1:
                return new Uint8Array(size);
              case 2:
                return new Uint16Array(size);
              case 4:
                return new Uint32Array(size);
              default:
                throw new RangeError("Invalid newArray parameter element_bytes:" + bytes);
            }
          }
        };
        var arrayCopy = function(src, src_offset, length) {
          var buffer = new ArrayBuffer(length);
          var dstU8 = new Uint8Array(buffer, 0, length);
          var srcU8 = src.subarray(src_offset, length);
          dstU8.set(srcU8);
          return dstU8;
        };
        var stringToUtf8Bytes = function(str) {
          var bytes = new Uint8Array(new ArrayBuffer(str.length * 4));
          var i = 0, j = 0;
          while (i < str.length) {
            var unicode_code;
            var utf16_code = str.charCodeAt(i++);
            if (utf16_code >= 55296 && utf16_code <= 56319) {
              var upper = utf16_code;
              var lower = str.charCodeAt(i++);
              if (lower >= 56320 && lower <= 57343) {
                unicode_code = (upper - 55296) * (1 << 10) + (1 << 16) + (lower - 56320);
              } else {
                return null;
              }
            } else {
              unicode_code = utf16_code;
            }
            if (unicode_code < 128) {
              bytes[j++] = unicode_code;
            } else if (unicode_code < 1 << 11) {
              bytes[j++] = unicode_code >>> 6 | 192;
              bytes[j++] = unicode_code & 63 | 128;
            } else if (unicode_code < 1 << 16) {
              bytes[j++] = unicode_code >>> 12 | 224;
              bytes[j++] = unicode_code >> 6 & 63 | 128;
              bytes[j++] = unicode_code & 63 | 128;
            } else if (unicode_code < 1 << 21) {
              bytes[j++] = unicode_code >>> 18 | 240;
              bytes[j++] = unicode_code >> 12 & 63 | 128;
              bytes[j++] = unicode_code >> 6 & 63 | 128;
              bytes[j++] = unicode_code & 63 | 128;
            } else {
            }
          }
          return bytes.subarray(0, j);
        };
        var utf8BytesToString = function(bytes) {
          var str = "";
          var code, b1, b2, b3, b4, upper, lower;
          var i = 0;
          while (i < bytes.length) {
            b1 = bytes[i++];
            if (b1 < 128) {
              code = b1;
            } else if (b1 >> 5 === 6) {
              b2 = bytes[i++];
              code = (b1 & 31) << 6 | b2 & 63;
            } else if (b1 >> 4 === 14) {
              b2 = bytes[i++];
              b3 = bytes[i++];
              code = (b1 & 15) << 12 | (b2 & 63) << 6 | b3 & 63;
            } else {
              b2 = bytes[i++];
              b3 = bytes[i++];
              b4 = bytes[i++];
              code = (b1 & 7) << 18 | (b2 & 63) << 12 | (b3 & 63) << 6 | b4 & 63;
            }
            if (code < 65536) {
              str += String.fromCharCode(code);
            } else {
              code -= 65536;
              upper = 55296 | code >> 10;
              lower = 56320 | code & 1023;
              str += String.fromCharCode(upper, lower);
            }
          }
          return str;
        };
        var doublearray = {
          builder: function(initial_size) {
            return new DoubleArrayBuilder(initial_size);
          },
          load: function(base_buffer, check_buffer) {
            var bc = newBC(0);
            bc.loadBaseBuffer(base_buffer);
            bc.loadCheckBuffer(check_buffer);
            return new DoubleArray(bc);
          }
        };
        if ("undefined" === typeof module) {
          window.doublearray = doublearray;
        } else {
          module.exports = doublearray;
        }
      })();
    }
  });

  // node_modules/kuromoji/src/util/ByteBuffer.js
  var require_ByteBuffer = __commonJS({
    "node_modules/kuromoji/src/util/ByteBuffer.js"(exports, module) {
      "use strict";
      var stringToUtf8Bytes = function(str) {
        var bytes = new Uint8Array(str.length * 4);
        var i = 0, j = 0;
        while (i < str.length) {
          var unicode_code;
          var utf16_code = str.charCodeAt(i++);
          if (utf16_code >= 55296 && utf16_code <= 56319) {
            var upper = utf16_code;
            var lower = str.charCodeAt(i++);
            if (lower >= 56320 && lower <= 57343) {
              unicode_code = (upper - 55296) * (1 << 10) + (1 << 16) + (lower - 56320);
            } else {
              return null;
            }
          } else {
            unicode_code = utf16_code;
          }
          if (unicode_code < 128) {
            bytes[j++] = unicode_code;
          } else if (unicode_code < 1 << 11) {
            bytes[j++] = unicode_code >>> 6 | 192;
            bytes[j++] = unicode_code & 63 | 128;
          } else if (unicode_code < 1 << 16) {
            bytes[j++] = unicode_code >>> 12 | 224;
            bytes[j++] = unicode_code >> 6 & 63 | 128;
            bytes[j++] = unicode_code & 63 | 128;
          } else if (unicode_code < 1 << 21) {
            bytes[j++] = unicode_code >>> 18 | 240;
            bytes[j++] = unicode_code >> 12 & 63 | 128;
            bytes[j++] = unicode_code >> 6 & 63 | 128;
            bytes[j++] = unicode_code & 63 | 128;
          } else {
          }
        }
        return bytes.subarray(0, j);
      };
      var utf8BytesToString = function(bytes) {
        var str = "";
        var code, b1, b2, b3, b4, upper, lower;
        var i = 0;
        while (i < bytes.length) {
          b1 = bytes[i++];
          if (b1 < 128) {
            code = b1;
          } else if (b1 >> 5 === 6) {
            b2 = bytes[i++];
            code = (b1 & 31) << 6 | b2 & 63;
          } else if (b1 >> 4 === 14) {
            b2 = bytes[i++];
            b3 = bytes[i++];
            code = (b1 & 15) << 12 | (b2 & 63) << 6 | b3 & 63;
          } else {
            b2 = bytes[i++];
            b3 = bytes[i++];
            b4 = bytes[i++];
            code = (b1 & 7) << 18 | (b2 & 63) << 12 | (b3 & 63) << 6 | b4 & 63;
          }
          if (code < 65536) {
            str += String.fromCharCode(code);
          } else {
            code -= 65536;
            upper = 55296 | code >> 10;
            lower = 56320 | code & 1023;
            str += String.fromCharCode(upper, lower);
          }
        }
        return str;
      };
      function ByteBuffer(arg) {
        var initial_size;
        if (arg == null) {
          initial_size = 1024 * 1024;
        } else if (typeof arg === "number") {
          initial_size = arg;
        } else if (arg instanceof Uint8Array) {
          this.buffer = arg;
          this.position = 0;
          return;
        } else {
          throw typeof arg + " is invalid parameter type for ByteBuffer constructor";
        }
        this.buffer = new Uint8Array(initial_size);
        this.position = 0;
      }
      ByteBuffer.prototype.size = function() {
        return this.buffer.length;
      };
      ByteBuffer.prototype.reallocate = function() {
        var new_array = new Uint8Array(this.buffer.length * 2);
        new_array.set(this.buffer);
        this.buffer = new_array;
      };
      ByteBuffer.prototype.shrink = function() {
        this.buffer = this.buffer.subarray(0, this.position);
        return this.buffer;
      };
      ByteBuffer.prototype.put = function(b) {
        if (this.buffer.length < this.position + 1) {
          this.reallocate();
        }
        this.buffer[this.position++] = b;
      };
      ByteBuffer.prototype.get = function(index) {
        if (index == null) {
          index = this.position;
          this.position += 1;
        }
        if (this.buffer.length < index + 1) {
          return 0;
        }
        return this.buffer[index];
      };
      ByteBuffer.prototype.putShort = function(num) {
        if (65535 < num) {
          throw num + " is over short value";
        }
        var lower = 255 & num;
        var upper = (65280 & num) >> 8;
        this.put(lower);
        this.put(upper);
      };
      ByteBuffer.prototype.getShort = function(index) {
        if (index == null) {
          index = this.position;
          this.position += 2;
        }
        if (this.buffer.length < index + 2) {
          return 0;
        }
        var lower = this.buffer[index];
        var upper = this.buffer[index + 1];
        var value = (upper << 8) + lower;
        if (value & 32768) {
          value = -(value - 1 ^ 65535);
        }
        return value;
      };
      ByteBuffer.prototype.putInt = function(num) {
        if (4294967295 < num) {
          throw num + " is over integer value";
        }
        var b0 = 255 & num;
        var b1 = (65280 & num) >> 8;
        var b2 = (16711680 & num) >> 16;
        var b3 = (4278190080 & num) >> 24;
        this.put(b0);
        this.put(b1);
        this.put(b2);
        this.put(b3);
      };
      ByteBuffer.prototype.getInt = function(index) {
        if (index == null) {
          index = this.position;
          this.position += 4;
        }
        if (this.buffer.length < index + 4) {
          return 0;
        }
        var b0 = this.buffer[index];
        var b1 = this.buffer[index + 1];
        var b2 = this.buffer[index + 2];
        var b3 = this.buffer[index + 3];
        return (b3 << 24) + (b2 << 16) + (b1 << 8) + b0;
      };
      ByteBuffer.prototype.readInt = function() {
        var pos = this.position;
        this.position += 4;
        return this.getInt(pos);
      };
      ByteBuffer.prototype.putString = function(str) {
        var bytes = stringToUtf8Bytes(str);
        for (var i = 0; i < bytes.length; i++) {
          this.put(bytes[i]);
        }
        this.put(0);
      };
      ByteBuffer.prototype.getString = function(index) {
        var buf = [], ch;
        if (index == null) {
          index = this.position;
        }
        while (true) {
          if (this.buffer.length < index + 1) {
            break;
          }
          ch = this.get(index++);
          if (ch === 0) {
            break;
          } else {
            buf.push(ch);
          }
        }
        this.position = index;
        return utf8BytesToString(buf);
      };
      module.exports = ByteBuffer;
    }
  });

  // node_modules/kuromoji/src/dict/TokenInfoDictionary.js
  var require_TokenInfoDictionary = __commonJS({
    "node_modules/kuromoji/src/dict/TokenInfoDictionary.js"(exports, module) {
      "use strict";
      var ByteBuffer = require_ByteBuffer();
      function TokenInfoDictionary() {
        this.dictionary = new ByteBuffer(10 * 1024 * 1024);
        this.target_map = {};
        this.pos_buffer = new ByteBuffer(10 * 1024 * 1024);
      }
      TokenInfoDictionary.prototype.buildDictionary = function(entries) {
        var dictionary_entries = {};
        for (var i = 0; i < entries.length; i++) {
          var entry = entries[i];
          if (entry.length < 4) {
            continue;
          }
          var surface_form = entry[0];
          var left_id = entry[1];
          var right_id = entry[2];
          var word_cost = entry[3];
          var feature = entry.slice(4).join(",");
          if (!isFinite(left_id) || !isFinite(right_id) || !isFinite(word_cost)) {
            console.log(entry);
          }
          var token_info_id = this.put(left_id, right_id, word_cost, surface_form, feature);
          dictionary_entries[token_info_id] = surface_form;
        }
        this.dictionary.shrink();
        this.pos_buffer.shrink();
        return dictionary_entries;
      };
      TokenInfoDictionary.prototype.put = function(left_id, right_id, word_cost, surface_form, feature) {
        var token_info_id = this.dictionary.position;
        var pos_id = this.pos_buffer.position;
        this.dictionary.putShort(left_id);
        this.dictionary.putShort(right_id);
        this.dictionary.putShort(word_cost);
        this.dictionary.putInt(pos_id);
        this.pos_buffer.putString(surface_form + "," + feature);
        return token_info_id;
      };
      TokenInfoDictionary.prototype.addMapping = function(source, target) {
        var mapping = this.target_map[source];
        if (mapping == null) {
          mapping = [];
        }
        mapping.push(target);
        this.target_map[source] = mapping;
      };
      TokenInfoDictionary.prototype.targetMapToBuffer = function() {
        var buffer = new ByteBuffer();
        var map_keys_size = Object.keys(this.target_map).length;
        buffer.putInt(map_keys_size);
        for (var key in this.target_map) {
          var values = this.target_map[key];
          var map_values_size = values.length;
          buffer.putInt(parseInt(key));
          buffer.putInt(map_values_size);
          for (var i = 0; i < values.length; i++) {
            buffer.putInt(values[i]);
          }
        }
        return buffer.shrink();
      };
      TokenInfoDictionary.prototype.loadDictionary = function(array_buffer) {
        this.dictionary = new ByteBuffer(array_buffer);
        return this;
      };
      TokenInfoDictionary.prototype.loadPosVector = function(array_buffer) {
        this.pos_buffer = new ByteBuffer(array_buffer);
        return this;
      };
      TokenInfoDictionary.prototype.loadTargetMap = function(array_buffer) {
        var buffer = new ByteBuffer(array_buffer);
        buffer.position = 0;
        this.target_map = {};
        buffer.readInt();
        while (true) {
          if (buffer.buffer.length < buffer.position + 1) {
            break;
          }
          var key = buffer.readInt();
          var map_values_size = buffer.readInt();
          for (var i = 0; i < map_values_size; i++) {
            var value = buffer.readInt();
            this.addMapping(key, value);
          }
        }
        return this;
      };
      TokenInfoDictionary.prototype.getFeatures = function(token_info_id_str) {
        var token_info_id = parseInt(token_info_id_str);
        if (isNaN(token_info_id)) {
          return "";
        }
        var pos_id = this.dictionary.getInt(token_info_id + 6);
        return this.pos_buffer.getString(pos_id);
      };
      module.exports = TokenInfoDictionary;
    }
  });

  // node_modules/kuromoji/src/dict/ConnectionCosts.js
  var require_ConnectionCosts = __commonJS({
    "node_modules/kuromoji/src/dict/ConnectionCosts.js"(exports, module) {
      "use strict";
      function ConnectionCosts(forward_dimension, backward_dimension) {
        this.forward_dimension = forward_dimension;
        this.backward_dimension = backward_dimension;
        this.buffer = new Int16Array(forward_dimension * backward_dimension + 2);
        this.buffer[0] = forward_dimension;
        this.buffer[1] = backward_dimension;
      }
      ConnectionCosts.prototype.put = function(forward_id, backward_id, cost) {
        var index = forward_id * this.backward_dimension + backward_id + 2;
        if (this.buffer.length < index + 1) {
          throw "ConnectionCosts buffer overflow";
        }
        this.buffer[index] = cost;
      };
      ConnectionCosts.prototype.get = function(forward_id, backward_id) {
        var index = forward_id * this.backward_dimension + backward_id + 2;
        if (this.buffer.length < index + 1) {
          throw "ConnectionCosts buffer overflow";
        }
        return this.buffer[index];
      };
      ConnectionCosts.prototype.loadConnectionCosts = function(connection_costs_buffer) {
        this.forward_dimension = connection_costs_buffer[0];
        this.backward_dimension = connection_costs_buffer[1];
        this.buffer = connection_costs_buffer;
      };
      module.exports = ConnectionCosts;
    }
  });

  // node_modules/kuromoji/src/dict/CharacterClass.js
  var require_CharacterClass = __commonJS({
    "node_modules/kuromoji/src/dict/CharacterClass.js"(exports, module) {
      "use strict";
      function CharacterClass(class_id, class_name, is_always_invoke, is_grouping, max_length) {
        this.class_id = class_id;
        this.class_name = class_name;
        this.is_always_invoke = is_always_invoke;
        this.is_grouping = is_grouping;
        this.max_length = max_length;
      }
      module.exports = CharacterClass;
    }
  });

  // node_modules/kuromoji/src/dict/InvokeDefinitionMap.js
  var require_InvokeDefinitionMap = __commonJS({
    "node_modules/kuromoji/src/dict/InvokeDefinitionMap.js"(exports, module) {
      "use strict";
      var ByteBuffer = require_ByteBuffer();
      var CharacterClass = require_CharacterClass();
      function InvokeDefinitionMap() {
        this.map = [];
        this.lookup_table = {};
      }
      InvokeDefinitionMap.load = function(invoke_def_buffer) {
        var invoke_def = new InvokeDefinitionMap();
        var character_category_definition = [];
        var buffer = new ByteBuffer(invoke_def_buffer);
        while (buffer.position + 1 < buffer.size()) {
          var class_id = character_category_definition.length;
          var is_always_invoke = buffer.get();
          var is_grouping = buffer.get();
          var max_length = buffer.getInt();
          var class_name = buffer.getString();
          character_category_definition.push(new CharacterClass(class_id, class_name, is_always_invoke, is_grouping, max_length));
        }
        invoke_def.init(character_category_definition);
        return invoke_def;
      };
      InvokeDefinitionMap.prototype.init = function(character_category_definition) {
        if (character_category_definition == null) {
          return;
        }
        for (var i = 0; i < character_category_definition.length; i++) {
          var character_class = character_category_definition[i];
          this.map[i] = character_class;
          this.lookup_table[character_class.class_name] = i;
        }
      };
      InvokeDefinitionMap.prototype.getCharacterClass = function(class_id) {
        return this.map[class_id];
      };
      InvokeDefinitionMap.prototype.lookup = function(class_name) {
        var class_id = this.lookup_table[class_name];
        if (class_id == null) {
          return null;
        }
        return class_id;
      };
      InvokeDefinitionMap.prototype.toBuffer = function() {
        var buffer = new ByteBuffer();
        for (var i = 0; i < this.map.length; i++) {
          var char_class = this.map[i];
          buffer.put(char_class.is_always_invoke);
          buffer.put(char_class.is_grouping);
          buffer.putInt(char_class.max_length);
          buffer.putString(char_class.class_name);
        }
        buffer.shrink();
        return buffer.buffer;
      };
      module.exports = InvokeDefinitionMap;
    }
  });

  // node_modules/kuromoji/src/dict/CharacterDefinition.js
  var require_CharacterDefinition = __commonJS({
    "node_modules/kuromoji/src/dict/CharacterDefinition.js"(exports, module) {
      "use strict";
      var InvokeDefinitionMap = require_InvokeDefinitionMap();
      var CharacterClass = require_CharacterClass();
      var SurrogateAwareString = require_SurrogateAwareString();
      var DEFAULT_CATEGORY = "DEFAULT";
      function CharacterDefinition() {
        this.character_category_map = new Uint8Array(65536);
        this.compatible_category_map = new Uint32Array(65536);
        this.invoke_definition_map = null;
      }
      CharacterDefinition.load = function(cat_map_buffer, compat_cat_map_buffer, invoke_def_buffer) {
        var char_def = new CharacterDefinition();
        char_def.character_category_map = cat_map_buffer;
        char_def.compatible_category_map = compat_cat_map_buffer;
        char_def.invoke_definition_map = InvokeDefinitionMap.load(invoke_def_buffer);
        return char_def;
      };
      CharacterDefinition.parseCharCategory = function(class_id, parsed_category_def) {
        var category = parsed_category_def[1];
        var invoke = parseInt(parsed_category_def[2]);
        var grouping = parseInt(parsed_category_def[3]);
        var max_length = parseInt(parsed_category_def[4]);
        if (!isFinite(invoke) || invoke !== 0 && invoke !== 1) {
          console.log("char.def parse error. INVOKE is 0 or 1 in:" + invoke);
          return null;
        }
        if (!isFinite(grouping) || grouping !== 0 && grouping !== 1) {
          console.log("char.def parse error. GROUP is 0 or 1 in:" + grouping);
          return null;
        }
        if (!isFinite(max_length) || max_length < 0) {
          console.log("char.def parse error. LENGTH is 1 to n:" + max_length);
          return null;
        }
        var is_invoke = invoke === 1;
        var is_grouping = grouping === 1;
        return new CharacterClass(class_id, category, is_invoke, is_grouping, max_length);
      };
      CharacterDefinition.parseCategoryMapping = function(parsed_category_mapping) {
        var start = parseInt(parsed_category_mapping[1]);
        var default_category = parsed_category_mapping[2];
        var compatible_category = 3 < parsed_category_mapping.length ? parsed_category_mapping.slice(3) : [];
        if (!isFinite(start) || start < 0 || start > 65535) {
          console.log("char.def parse error. CODE is invalid:" + start);
        }
        return { start, default: default_category, compatible: compatible_category };
      };
      CharacterDefinition.parseRangeCategoryMapping = function(parsed_category_mapping) {
        var start = parseInt(parsed_category_mapping[1]);
        var end = parseInt(parsed_category_mapping[2]);
        var default_category = parsed_category_mapping[3];
        var compatible_category = 4 < parsed_category_mapping.length ? parsed_category_mapping.slice(4) : [];
        if (!isFinite(start) || start < 0 || start > 65535) {
          console.log("char.def parse error. CODE is invalid:" + start);
        }
        if (!isFinite(end) || end < 0 || end > 65535) {
          console.log("char.def parse error. CODE is invalid:" + end);
        }
        return { start, end, default: default_category, compatible: compatible_category };
      };
      CharacterDefinition.prototype.initCategoryMappings = function(category_mapping) {
        var code_point;
        if (category_mapping != null) {
          for (var i = 0; i < category_mapping.length; i++) {
            var mapping = category_mapping[i];
            var end = mapping.end || mapping.start;
            for (code_point = mapping.start; code_point <= end; code_point++) {
              this.character_category_map[code_point] = this.invoke_definition_map.lookup(mapping.default);
              for (var j = 0; j < mapping.compatible.length; j++) {
                var bitset = this.compatible_category_map[code_point];
                var compatible_category = mapping.compatible[j];
                if (compatible_category == null) {
                  continue;
                }
                var class_id = this.invoke_definition_map.lookup(compatible_category);
                if (class_id == null) {
                  continue;
                }
                var class_id_bit = 1 << class_id;
                bitset = bitset | class_id_bit;
                this.compatible_category_map[code_point] = bitset;
              }
            }
          }
        }
        var default_id = this.invoke_definition_map.lookup(DEFAULT_CATEGORY);
        if (default_id == null) {
          return;
        }
        for (code_point = 0; code_point < this.character_category_map.length; code_point++) {
          if (this.character_category_map[code_point] === 0) {
            this.character_category_map[code_point] = 1 << default_id;
          }
        }
      };
      CharacterDefinition.prototype.lookupCompatibleCategory = function(ch) {
        var classes = [];
        var code = ch.charCodeAt(0);
        var integer;
        if (code < this.compatible_category_map.length) {
          integer = this.compatible_category_map[code];
        }
        if (integer == null || integer === 0) {
          return classes;
        }
        for (var bit = 0; bit < 32; bit++) {
          if (integer << 31 - bit >>> 31 === 1) {
            var character_class = this.invoke_definition_map.getCharacterClass(bit);
            if (character_class == null) {
              continue;
            }
            classes.push(character_class);
          }
        }
        return classes;
      };
      CharacterDefinition.prototype.lookup = function(ch) {
        var class_id;
        var code = ch.charCodeAt(0);
        if (SurrogateAwareString.isSurrogatePair(ch)) {
          class_id = this.invoke_definition_map.lookup(DEFAULT_CATEGORY);
        } else if (code < this.character_category_map.length) {
          class_id = this.character_category_map[code];
        }
        if (class_id == null) {
          class_id = this.invoke_definition_map.lookup(DEFAULT_CATEGORY);
        }
        return this.invoke_definition_map.getCharacterClass(class_id);
      };
      module.exports = CharacterDefinition;
    }
  });

  // node_modules/kuromoji/src/dict/UnknownDictionary.js
  var require_UnknownDictionary = __commonJS({
    "node_modules/kuromoji/src/dict/UnknownDictionary.js"(exports, module) {
      "use strict";
      var TokenInfoDictionary = require_TokenInfoDictionary();
      var CharacterDefinition = require_CharacterDefinition();
      var ByteBuffer = require_ByteBuffer();
      function UnknownDictionary() {
        this.dictionary = new ByteBuffer(10 * 1024 * 1024);
        this.target_map = {};
        this.pos_buffer = new ByteBuffer(10 * 1024 * 1024);
        this.character_definition = null;
      }
      UnknownDictionary.prototype = Object.create(TokenInfoDictionary.prototype);
      UnknownDictionary.prototype.characterDefinition = function(character_definition) {
        this.character_definition = character_definition;
        return this;
      };
      UnknownDictionary.prototype.lookup = function(ch) {
        return this.character_definition.lookup(ch);
      };
      UnknownDictionary.prototype.lookupCompatibleCategory = function(ch) {
        return this.character_definition.lookupCompatibleCategory(ch);
      };
      UnknownDictionary.prototype.loadUnknownDictionaries = function(unk_buffer, unk_pos_buffer, unk_map_buffer, cat_map_buffer, compat_cat_map_buffer, invoke_def_buffer) {
        this.loadDictionary(unk_buffer);
        this.loadPosVector(unk_pos_buffer);
        this.loadTargetMap(unk_map_buffer);
        this.character_definition = CharacterDefinition.load(cat_map_buffer, compat_cat_map_buffer, invoke_def_buffer);
      };
      module.exports = UnknownDictionary;
    }
  });

  // node_modules/kuromoji/src/dict/DynamicDictionaries.js
  var require_DynamicDictionaries = __commonJS({
    "node_modules/kuromoji/src/dict/DynamicDictionaries.js"(exports, module) {
      "use strict";
      var doublearray = require_doublearray();
      var TokenInfoDictionary = require_TokenInfoDictionary();
      var ConnectionCosts = require_ConnectionCosts();
      var UnknownDictionary = require_UnknownDictionary();
      function DynamicDictionaries(trie, token_info_dictionary, connection_costs, unknown_dictionary) {
        if (trie != null) {
          this.trie = trie;
        } else {
          this.trie = doublearray.builder(0).build([
            { k: "", v: 1 }
          ]);
        }
        if (token_info_dictionary != null) {
          this.token_info_dictionary = token_info_dictionary;
        } else {
          this.token_info_dictionary = new TokenInfoDictionary();
        }
        if (connection_costs != null) {
          this.connection_costs = connection_costs;
        } else {
          this.connection_costs = new ConnectionCosts(0, 0);
        }
        if (unknown_dictionary != null) {
          this.unknown_dictionary = unknown_dictionary;
        } else {
          this.unknown_dictionary = new UnknownDictionary();
        }
      }
      DynamicDictionaries.prototype.loadTrie = function(base_buffer, check_buffer) {
        this.trie = doublearray.load(base_buffer, check_buffer);
        return this;
      };
      DynamicDictionaries.prototype.loadTokenInfoDictionaries = function(token_info_buffer, pos_buffer, target_map_buffer) {
        this.token_info_dictionary.loadDictionary(token_info_buffer);
        this.token_info_dictionary.loadPosVector(pos_buffer);
        this.token_info_dictionary.loadTargetMap(target_map_buffer);
        return this;
      };
      DynamicDictionaries.prototype.loadConnectionCosts = function(cc_buffer) {
        this.connection_costs.loadConnectionCosts(cc_buffer);
        return this;
      };
      DynamicDictionaries.prototype.loadUnknownDictionaries = function(unk_buffer, unk_pos_buffer, unk_map_buffer, cat_map_buffer, compat_cat_map_buffer, invoke_def_buffer) {
        this.unknown_dictionary.loadUnknownDictionaries(unk_buffer, unk_pos_buffer, unk_map_buffer, cat_map_buffer, compat_cat_map_buffer, invoke_def_buffer);
        return this;
      };
      module.exports = DynamicDictionaries;
    }
  });

  // node_modules/kuromoji/src/loader/DictionaryLoader.js
  var require_DictionaryLoader = __commonJS({
    "node_modules/kuromoji/src/loader/DictionaryLoader.js"(exports, module) {
      "use strict";
      var path = require_path_shim();
      var async = require_async_shim();
      var DynamicDictionaries = require_DynamicDictionaries();
      function DictionaryLoader(dic_path) {
        this.dic = new DynamicDictionaries();
        this.dic_path = dic_path;
      }
      DictionaryLoader.prototype.loadArrayBuffer = function(file, callback) {
        throw new Error("DictionaryLoader#loadArrayBuffer should be overwrite");
      };
      DictionaryLoader.prototype.load = function(load_callback) {
        var dic = this.dic;
        var dic_path = this.dic_path;
        var loadArrayBuffer = this.loadArrayBuffer;
        async.parallel([
          // Trie
          function(callback) {
            async.map(["base.dat.gz", "check.dat.gz"], function(filename, _callback) {
              loadArrayBuffer(path.join(dic_path, filename), function(err, buffer) {
                if (err) {
                  return _callback(err);
                }
                _callback(null, buffer);
              });
            }, function(err, buffers) {
              if (err) {
                return callback(err);
              }
              var base_buffer = new Int32Array(buffers[0]);
              var check_buffer = new Int32Array(buffers[1]);
              dic.loadTrie(base_buffer, check_buffer);
              callback(null);
            });
          },
          // Token info dictionaries
          function(callback) {
            async.map(["tid.dat.gz", "tid_pos.dat.gz", "tid_map.dat.gz"], function(filename, _callback) {
              loadArrayBuffer(path.join(dic_path, filename), function(err, buffer) {
                if (err) {
                  return _callback(err);
                }
                _callback(null, buffer);
              });
            }, function(err, buffers) {
              if (err) {
                return callback(err);
              }
              var token_info_buffer = new Uint8Array(buffers[0]);
              var pos_buffer = new Uint8Array(buffers[1]);
              var target_map_buffer = new Uint8Array(buffers[2]);
              dic.loadTokenInfoDictionaries(token_info_buffer, pos_buffer, target_map_buffer);
              callback(null);
            });
          },
          // Connection cost matrix
          function(callback) {
            loadArrayBuffer(path.join(dic_path, "cc.dat.gz"), function(err, buffer) {
              if (err) {
                return callback(err);
              }
              var cc_buffer = new Int16Array(buffer);
              dic.loadConnectionCosts(cc_buffer);
              callback(null);
            });
          },
          // Unknown dictionaries
          function(callback) {
            async.map(["unk.dat.gz", "unk_pos.dat.gz", "unk_map.dat.gz", "unk_char.dat.gz", "unk_compat.dat.gz", "unk_invoke.dat.gz"], function(filename, _callback) {
              loadArrayBuffer(path.join(dic_path, filename), function(err, buffer) {
                if (err) {
                  return _callback(err);
                }
                _callback(null, buffer);
              });
            }, function(err, buffers) {
              if (err) {
                return callback(err);
              }
              var unk_buffer = new Uint8Array(buffers[0]);
              var unk_pos_buffer = new Uint8Array(buffers[1]);
              var unk_map_buffer = new Uint8Array(buffers[2]);
              var cat_map_buffer = new Uint8Array(buffers[3]);
              var compat_cat_map_buffer = new Uint32Array(buffers[4]);
              var invoke_def_buffer = new Uint8Array(buffers[5]);
              dic.loadUnknownDictionaries(unk_buffer, unk_pos_buffer, unk_map_buffer, cat_map_buffer, compat_cat_map_buffer, invoke_def_buffer);
              callback(null);
            });
          }
        ], function(err) {
          load_callback(err, dic);
        });
      };
      module.exports = DictionaryLoader;
    }
  });

  // node_modules/kuromoji/src/loader/BrowserDictionaryLoader.js
  var require_BrowserDictionaryLoader = __commonJS({
    "node_modules/kuromoji/src/loader/BrowserDictionaryLoader.js"(exports, module) {
      "use strict";
      var zlib = require_gunzip_min();
      var DictionaryLoader = require_DictionaryLoader();
      function BrowserDictionaryLoader(dic_path) {
        DictionaryLoader.apply(this, [dic_path]);
      }
      BrowserDictionaryLoader.prototype = Object.create(DictionaryLoader.prototype);
      BrowserDictionaryLoader.prototype.loadArrayBuffer = function(url, callback) {
        var xhr = new XMLHttpRequest();
        xhr.open("GET", url, true);
        xhr.responseType = "arraybuffer";
        xhr.onload = function() {
          if (this.status > 0 && this.status !== 200) {
            callback(xhr.statusText, null);
            return;
          }
          var arraybuffer = this.response;
          var gz = new zlib.Zlib.Gunzip(new Uint8Array(arraybuffer));
          var typed_array = gz.decompress();
          callback(null, typed_array.buffer);
        };
        xhr.onerror = function(err) {
          callback(err, null);
        };
        xhr.send();
      };
      module.exports = BrowserDictionaryLoader;
    }
  });

  // node_modules/kuromoji/src/TokenizerBuilder.js
  var require_TokenizerBuilder = __commonJS({
    "node_modules/kuromoji/src/TokenizerBuilder.js"(exports, module) {
      "use strict";
      var Tokenizer = require_Tokenizer();
      var DictionaryLoader = require_BrowserDictionaryLoader();
      function TokenizerBuilder(option) {
        if (option.dicPath == null) {
          this.dic_path = "dict/";
        } else {
          this.dic_path = option.dicPath;
        }
      }
      TokenizerBuilder.prototype.build = function(callback) {
        var loader = new DictionaryLoader(this.dic_path);
        loader.load(function(err, dic) {
          callback(err, new Tokenizer(dic));
        });
      };
      module.exports = TokenizerBuilder;
    }
  });

  // node_modules/kuromoji/src/dict/builder/ConnectionCostsBuilder.js
  var require_ConnectionCostsBuilder = __commonJS({
    "node_modules/kuromoji/src/dict/builder/ConnectionCostsBuilder.js"(exports, module) {
      "use strict";
      var ConnectionCosts = require_ConnectionCosts();
      function ConnectionCostsBuilder() {
        this.lines = 0;
        this.connection_cost = null;
      }
      ConnectionCostsBuilder.prototype.putLine = function(line) {
        if (this.lines === 0) {
          var dimensions = line.split(" ");
          var forward_dimension = dimensions[0];
          var backward_dimension = dimensions[1];
          if (forward_dimension < 0 || backward_dimension < 0) {
            throw "Parse error of matrix.def";
          }
          this.connection_cost = new ConnectionCosts(forward_dimension, backward_dimension);
          this.lines++;
          return this;
        }
        var costs = line.split(" ");
        if (costs.length !== 3) {
          return this;
        }
        var forward_id = parseInt(costs[0]);
        var backward_id = parseInt(costs[1]);
        var cost = parseInt(costs[2]);
        if (forward_id < 0 || backward_id < 0 || !isFinite(forward_id) || !isFinite(backward_id) || this.connection_cost.forward_dimension <= forward_id || this.connection_cost.backward_dimension <= backward_id) {
          throw "Parse error of matrix.def";
        }
        this.connection_cost.put(forward_id, backward_id, cost);
        this.lines++;
        return this;
      };
      ConnectionCostsBuilder.prototype.build = function() {
        return this.connection_cost;
      };
      module.exports = ConnectionCostsBuilder;
    }
  });

  // node_modules/kuromoji/src/dict/builder/CharacterDefinitionBuilder.js
  var require_CharacterDefinitionBuilder = __commonJS({
    "node_modules/kuromoji/src/dict/builder/CharacterDefinitionBuilder.js"(exports, module) {
      "use strict";
      var CharacterDefinition = require_CharacterDefinition();
      var InvokeDefinitionMap = require_InvokeDefinitionMap();
      var CATEGORY_DEF_PATTERN = /^(\w+)\s+(\d)\s+(\d)\s+(\d)/;
      var CATEGORY_MAPPING_PATTERN = /^(0x[0-9A-F]{4})(?:\s+([^#\s]+))(?:\s+([^#\s]+))*/;
      var RANGE_CATEGORY_MAPPING_PATTERN = /^(0x[0-9A-F]{4})\.\.(0x[0-9A-F]{4})(?:\s+([^#\s]+))(?:\s+([^#\s]+))*/;
      function CharacterDefinitionBuilder() {
        this.char_def = new CharacterDefinition();
        this.char_def.invoke_definition_map = new InvokeDefinitionMap();
        this.character_category_definition = [];
        this.category_mapping = [];
      }
      CharacterDefinitionBuilder.prototype.putLine = function(line) {
        var parsed_category_def = CATEGORY_DEF_PATTERN.exec(line);
        if (parsed_category_def != null) {
          var class_id = this.character_category_definition.length;
          var char_class = CharacterDefinition.parseCharCategory(class_id, parsed_category_def);
          if (char_class == null) {
            return;
          }
          this.character_category_definition.push(char_class);
          return;
        }
        var parsed_category_mapping = CATEGORY_MAPPING_PATTERN.exec(line);
        if (parsed_category_mapping != null) {
          var mapping = CharacterDefinition.parseCategoryMapping(parsed_category_mapping);
          this.category_mapping.push(mapping);
        }
        var parsed_range_category_mapping = RANGE_CATEGORY_MAPPING_PATTERN.exec(line);
        if (parsed_range_category_mapping != null) {
          var range_mapping = CharacterDefinition.parseRangeCategoryMapping(parsed_range_category_mapping);
          this.category_mapping.push(range_mapping);
        }
      };
      CharacterDefinitionBuilder.prototype.build = function() {
        this.char_def.invoke_definition_map.init(this.character_category_definition);
        this.char_def.initCategoryMappings(this.category_mapping);
        return this.char_def;
      };
      module.exports = CharacterDefinitionBuilder;
    }
  });

  // node_modules/kuromoji/src/dict/builder/DictionaryBuilder.js
  var require_DictionaryBuilder = __commonJS({
    "node_modules/kuromoji/src/dict/builder/DictionaryBuilder.js"(exports, module) {
      "use strict";
      var doublearray = require_doublearray();
      var DynamicDictionaries = require_DynamicDictionaries();
      var TokenInfoDictionary = require_TokenInfoDictionary();
      var ConnectionCostsBuilder = require_ConnectionCostsBuilder();
      var CharacterDefinitionBuilder = require_CharacterDefinitionBuilder();
      var UnknownDictionary = require_UnknownDictionary();
      function DictionaryBuilder() {
        this.tid_entries = [];
        this.unk_entries = [];
        this.cc_builder = new ConnectionCostsBuilder();
        this.cd_builder = new CharacterDefinitionBuilder();
      }
      DictionaryBuilder.prototype.addTokenInfoDictionary = function(line) {
        var new_entry = line.split(",");
        this.tid_entries.push(new_entry);
        return this;
      };
      DictionaryBuilder.prototype.putCostMatrixLine = function(line) {
        this.cc_builder.putLine(line);
        return this;
      };
      DictionaryBuilder.prototype.putCharDefLine = function(line) {
        this.cd_builder.putLine(line);
        return this;
      };
      DictionaryBuilder.prototype.putUnkDefLine = function(line) {
        this.unk_entries.push(line.split(","));
        return this;
      };
      DictionaryBuilder.prototype.build = function() {
        var dictionaries = this.buildTokenInfoDictionary();
        var unknown_dictionary = this.buildUnknownDictionary();
        return new DynamicDictionaries(dictionaries.trie, dictionaries.token_info_dictionary, this.cc_builder.build(), unknown_dictionary);
      };
      DictionaryBuilder.prototype.buildTokenInfoDictionary = function() {
        var token_info_dictionary = new TokenInfoDictionary();
        var dictionary_entries = token_info_dictionary.buildDictionary(this.tid_entries);
        var trie = this.buildDoubleArray();
        for (var token_info_id in dictionary_entries) {
          var surface_form = dictionary_entries[token_info_id];
          var trie_id = trie.lookup(surface_form);
          token_info_dictionary.addMapping(trie_id, token_info_id);
        }
        return {
          trie,
          token_info_dictionary
        };
      };
      DictionaryBuilder.prototype.buildUnknownDictionary = function() {
        var unk_dictionary = new UnknownDictionary();
        var dictionary_entries = unk_dictionary.buildDictionary(this.unk_entries);
        var char_def = this.cd_builder.build();
        unk_dictionary.characterDefinition(char_def);
        for (var token_info_id in dictionary_entries) {
          var class_name = dictionary_entries[token_info_id];
          var class_id = char_def.invoke_definition_map.lookup(class_name);
          unk_dictionary.addMapping(class_id, token_info_id);
        }
        return unk_dictionary;
      };
      DictionaryBuilder.prototype.buildDoubleArray = function() {
        var trie_id = 0;
        var words = this.tid_entries.map(function(entry) {
          var surface_form = entry[0];
          return { k: surface_form, v: trie_id++ };
        });
        var builder = doublearray.builder(1024 * 1024);
        return builder.build(words);
      };
      module.exports = DictionaryBuilder;
    }
  });

  // node_modules/kuromoji/src/kuromoji.js
  var require_kuromoji = __commonJS({
    "node_modules/kuromoji/src/kuromoji.js"(exports, module) {
      "use strict";
      var TokenizerBuilder = require_TokenizerBuilder();
      var DictionaryBuilder = require_DictionaryBuilder();
      var kuromoji2 = {
        builder: function(option) {
          return new TokenizerBuilder(option);
        },
        dictionaryBuilder: function() {
          return new DictionaryBuilder();
        }
      };
      module.exports = kuromoji2;
    }
  });

  // src/content.js
  var import_kuromoji = __toESM(require_kuromoji(), 1);

  // src/person-name-readings.mjs
  var VERIFIED_AT = "2026-08-20";
  var PERSON_NAME_SOURCES = Object.freeze({
    "mofa-heads-2026-08-20": Object.freeze({
      url: "https://www.mofa.go.jp/mofaj/ms/po/page22_001297.html",
      note: "Japanese Ministry of Foreign Affairs list of current heads of state and ministers"
    }),
    "mofa-north-korea-2022-04-21": Object.freeze({
      url: "https://www.mofa.go.jp/mofaj/area/n_korea/data.html",
      note: "Japanese Ministry of Foreign Affairs North Korea country data"
    }),
    "mofa-vietnam-country-data": Object.freeze({
      url: "https://www.mofa.go.jp/mofaj/area/vietnam/data.html",
      note: "Japanese Ministry of Foreign Affairs Vietnam country data and official katakana spellings"
    }),
    "mofa-korea-official-pages": Object.freeze({
      url: "https://www.mofa.go.jp/mofaj/a_o/na/kr/pageit_000001_02236.html",
      note: "Japanese Ministry of Foreign Affairs Korean leader spellings"
    })
  });
  var PERSON_COUNTRY_HINTS = Object.freeze({
    china: Object.freeze(["\u4E2D\u56FD", "\u4E2D\u83EF\u4EBA\u6C11\u5171\u548C\u56FD", "\u4E2D\u56FD\u5171\u7523\u515A", "\u5317\u4EAC"]),
    korea: Object.freeze(["\u97D3\u56FD", "\u5927\u97D3\u6C11\u56FD", "\u30BD\u30A6\u30EB"]),
    northKorea: Object.freeze(["\u5317\u671D\u9BAE", "\u671D\u9BAE\u6C11\u4E3B\u4E3B\u7FA9\u4EBA\u6C11\u5171\u548C\u56FD", "\u671D\u9BAE\u52B4\u50CD\u515A", "\u5E73\u58CC"]),
    vietnam: Object.freeze([
      "\u30D9\u30C8\u30CA\u30E0\u793E\u4F1A\u4E3B\u7FA9\u5171\u548C\u56FD",
      "\u30D9\u30C8\u30CA\u30E0\u5171\u7523\u515A",
      "\u30D9\u30C8\u30CA\u30E0",
      "\u8D8A\u5357",
      "\u30CF\u30CE\u30A4"
    ])
  });
  var PERSON_ROLE_HINTS = Object.freeze([
    "\u6C0F",
    "\u3055\u3093",
    "\u5927\u7D71\u9818",
    "\u56FD\u5BB6\u4E3B\u5E2D",
    "\u4E3B\u5E2D",
    "\u9996\u76F8",
    "\u7DCF\u7406",
    "\u5916\u76F8",
    "\u5916\u52D9\u5927\u81E3",
    "\u5916\u4EA4\u90E8\u9577",
    "\u7DCF\u66F8\u8A18",
    "\u66F8\u8A18\u9577",
    "\u56FD\u52D9\u59D4\u54E1\u9577",
    "\u6700\u9AD8\u6307\u5C0E\u8005",
    "\u526F\u9996\u76F8",
    "\u9577\u5B98",
    "\u5143\u66F8\u8A18\u9577",
    "\u5143\u56FD\u5BB6\u4E3B\u5E2D",
    "\u5143\u5927\u7D71\u9818",
    "\u5143\u9996\u76F8",
    "\u524D\u5927\u7D71\u9818",
    "\u524D\u9996\u76F8",
    "\u524D\u4E3B\u5E2D",
    "\u524D\u5916\u76F8",
    "\u8B70\u9577",
    "\u8B70\u54E1",
    "\u5019\u88DC",
    "\u4EE3\u8868",
    "\u4F1A\u9577",
    "\u76E3\u7763",
    "\u9078\u624B",
    "\u6559\u6388",
    "\u535A\u58EB",
    "\u653F\u6A29"
  ]);
  function defineName(definition) {
    const {
      surfaces,
      components: rawComponents,
      blockedSuffixes = [],
      roleHints = [],
      ...metadata
    } = definition;
    const components = rawComponents.map((component) => Object.freeze({ ...component }));
    const componentReading = components.map((component) => component.reading).join("");
    if (componentReading !== definition.reading) {
      throw new Error(`Foreign person name components do not reconstruct ${definition.id}`);
    }
    return Object.freeze({
      verifiedAt: VERIFIED_AT,
      confidence: "unique",
      ...metadata,
      surfaces: Object.freeze([...surfaces]),
      components: Object.freeze(components),
      blockedSuffixes: Object.freeze([...blockedSuffixes]),
      roleHints: Object.freeze([...roleHints])
    });
  }
  var FOREIGN_PERSON_NAMES = Object.freeze([
    defineName({
      id: "xi-jinping",
      country: "china",
      locale: "zh-CN",
      surfaces: ["\u7FD2\u8FD1\u5E73", "\u4E60\u8FD1\u5E73"],
      reading: "\u30B7\u30FC\u30B8\u30F3\u30D4\u30F3",
      components: [{ length: 1, reading: "\u30B7\u30FC" }, { length: 1, reading: "\u30B8\u30F3" }, { length: 1, reading: "\u30D4\u30F3" }],
      sourceId: "mofa-heads-2026-08-20"
    }),
    defineName({
      id: "li-qiang",
      country: "china",
      locale: "zh-CN",
      confidence: "contextual",
      surfaces: ["\u674E\u5F37", "\u674E\u5F3A"],
      reading: "\u30EA\u30FC\u30FB\u30C1\u30A2\u30F3",
      components: [{ length: 1, reading: "\u30EA\u30FC\u30FB" }, { length: 1, reading: "\u30C1\u30A2\u30F3" }],
      roleHints: ["\u9996\u76F8", "\u7DCF\u7406", "\u56FD\u52D9\u9662\u7DCF\u7406"],
      sourceId: "mofa-heads-2026-08-20"
    }),
    defineName({
      id: "wang-yi",
      country: "china",
      locale: "zh-CN",
      confidence: "contextual",
      surfaces: ["\u738B\u6BC5"],
      reading: "\u30EF\u30F3\u30FB\u30A4\u30FC",
      components: [{ length: 1, reading: "\u30EF\u30F3\u30FB" }, { length: 1, reading: "\u30A4\u30FC" }],
      roleHints: ["\u5916\u76F8", "\u5916\u52D9\u5927\u81E3", "\u5916\u4EA4\u90E8\u9577", "\u653F\u6CBB\u5C40\u54E1"],
      sourceId: "mofa-heads-2026-08-20"
    }),
    defineName({
      id: "kim-jong-un",
      country: "northKorea",
      locale: "ko-KP",
      surfaces: ["\u91D1\u6B63\u6069"],
      reading: "\u30AD\u30E0\u30FB\u30B8\u30E7\u30F3\u30A6\u30F3",
      components: [{ length: 1, reading: "\u30AD\u30E0\u30FB" }, { length: 1, reading: "\u30B8\u30E7\u30F3" }, { length: 1, reading: "\u30A6\u30F3" }],
      sourceId: "mofa-north-korea-2022-04-21"
    }),
    defineName({
      id: "kim-yo-jong",
      country: "northKorea",
      locale: "ko-KP",
      surfaces: ["\u91D1\u4E0E\u6B63", "\u91D1\u8207\u6B63"],
      reading: "\u30AD\u30E0\u30FB\u30E8\u30B8\u30E7\u30F3",
      components: [{ length: 1, reading: "\u30AD\u30E0\u30FB" }, { length: 1, reading: "\u30E8" }, { length: 1, reading: "\u30B8\u30E7\u30F3" }],
      sourceId: "mofa-north-korea-2022-04-21"
    }),
    defineName({
      id: "kim-il-sung",
      country: "northKorea",
      locale: "ko-KP",
      surfaces: ["\u91D1\u65E5\u6210"],
      reading: "\u30AD\u30E0\u30FB\u30A4\u30EB\u30BD\u30F3",
      components: [{ length: 1, reading: "\u30AD\u30E0\u30FB" }, { length: 1, reading: "\u30A4\u30EB" }, { length: 1, reading: "\u30BD\u30F3" }],
      sourceId: "mofa-north-korea-2022-04-21"
    }),
    defineName({
      id: "kim-jong-il",
      country: "northKorea",
      locale: "ko-KP",
      surfaces: ["\u91D1\u6B63\u65E5"],
      reading: "\u30AD\u30E0\u30FB\u30B8\u30E7\u30F3\u30A4\u30EB",
      components: [{ length: 1, reading: "\u30AD\u30E0\u30FB" }, { length: 1, reading: "\u30B8\u30E7\u30F3" }, { length: 1, reading: "\u30A4\u30EB" }],
      sourceId: "mofa-north-korea-2022-04-21"
    }),
    defineName({
      id: "choe-ryong-hae",
      country: "northKorea",
      locale: "ko-KP",
      surfaces: ["\u5D14\u7ADC\u6D77", "\u5D14\u9F8D\u6D77"],
      reading: "\u30C1\u30A7\u30FB\u30EA\u30E7\u30F3\u30D8",
      components: [{ length: 1, reading: "\u30C1\u30A7\u30FB" }, { length: 1, reading: "\u30EA\u30E7\u30F3" }, { length: 1, reading: "\u30D8" }],
      sourceId: "mofa-north-korea-2022-04-21"
    }),
    defineName({
      id: "jo-yong-won",
      country: "northKorea",
      locale: "ko-KP",
      surfaces: ["\u8D99\u752C\u5143"],
      reading: "\u30C1\u30E7\u30FB\u30E8\u30F3\u30A6\u30A9\u30F3",
      components: [{ length: 1, reading: "\u30C1\u30E7\u30FB" }, { length: 1, reading: "\u30E8\u30F3" }, { length: 1, reading: "\u30A6\u30A9\u30F3" }],
      sourceId: "mofa-north-korea-2022-04-21"
    }),
    defineName({
      id: "pak-jong-chon",
      country: "northKorea",
      locale: "ko-KP",
      surfaces: ["\u6734\u6B63\u5929"],
      reading: "\u30D1\u30AF\u30FB\u30B8\u30E7\u30F3\u30C1\u30E7\u30F3",
      components: [{ length: 1, reading: "\u30D1\u30AF\u30FB" }, { length: 1, reading: "\u30B8\u30E7\u30F3" }, { length: 1, reading: "\u30C1\u30E7\u30F3" }],
      sourceId: "mofa-north-korea-2022-04-21"
    }),
    defineName({
      id: "kim-tok-hun",
      country: "northKorea",
      locale: "ko-KP",
      surfaces: ["\u91D1\u5FB3\u8A13"],
      reading: "\u30AD\u30E0\u30FB\u30C9\u30C3\u30AF\u30F3",
      components: [{ length: 1, reading: "\u30AD\u30E0\u30FB" }, { length: 1, reading: "\u30C9\u30C3" }, { length: 1, reading: "\u30AF\u30F3" }],
      sourceId: "mofa-north-korea-2022-04-21"
    }),
    defineName({
      id: "ri-son-gwon",
      country: "northKorea",
      locale: "ko-KP",
      surfaces: ["\u674E\u5584\u6A29", "\u674E\u5584\u6B0A"],
      reading: "\u30EA\u30FB\u30BD\u30F3\u30B0\u30A9\u30F3",
      components: [{ length: 1, reading: "\u30EA\u30FB" }, { length: 1, reading: "\u30BD\u30F3" }, { length: 1, reading: "\u30B0\u30A9\u30F3" }],
      sourceId: "mofa-north-korea-2022-04-21"
    }),
    defineName({
      id: "lee-jae-myung",
      country: "korea",
      locale: "ko-KR",
      surfaces: ["\u674E\u5728\u660E"],
      reading: "\u30A4\u30FB\u30B8\u30A7\u30DF\u30E7\u30F3",
      components: [{ length: 1, reading: "\u30A4\u30FB" }, { length: 1, reading: "\u30B8\u30A7" }, { length: 1, reading: "\u30DF\u30E7\u30F3" }],
      sourceId: "mofa-heads-2026-08-20"
    }),
    defineName({
      id: "yoon-suk-yeol",
      country: "korea",
      locale: "ko-KR",
      surfaces: ["\u5C39\u932B\u60A6"],
      reading: "\u30E6\u30F3\u30FB\u30BD\u30F3\u30CB\u30E7\u30EB",
      components: [{ length: 1, reading: "\u30E6\u30F3\u30FB" }, { length: 1, reading: "\u30BD\u30F3" }, { length: 1, reading: "\u30CB\u30E7\u30EB" }],
      sourceId: "mofa-korea-official-pages"
    }),
    defineName({
      id: "moon-jae-in",
      country: "korea",
      locale: "ko-KR",
      surfaces: ["\u6587\u5728\u5BC5"],
      reading: "\u30E0\u30F3\u30FB\u30B8\u30A7\u30A4\u30F3",
      components: [{ length: 1, reading: "\u30E0\u30F3\u30FB" }, { length: 1, reading: "\u30B8\u30A7" }, { length: 1, reading: "\u30A4\u30F3" }],
      sourceId: "mofa-korea-official-pages"
    }),
    defineName({
      id: "park-geun-hye",
      country: "korea",
      locale: "ko-KR",
      surfaces: ["\u6734\u69FF\u6075", "\u6734\u69FF\u60E0"],
      reading: "\u30D1\u30AF\u30FB\u30AF\u30CD",
      components: [{ length: 1, reading: "\u30D1\u30AF\u30FB" }, { length: 1, reading: "\u30AF" }, { length: 1, reading: "\u30CD" }],
      sourceId: "mofa-korea-official-pages"
    }),
    defineName({
      id: "lee-myung-bak",
      country: "korea",
      locale: "ko-KR",
      surfaces: ["\u674E\u660E\u535A"],
      reading: "\u30A4\u30FB\u30DF\u30E7\u30F3\u30D0\u30AF",
      components: [{ length: 1, reading: "\u30A4\u30FB" }, { length: 1, reading: "\u30DF\u30E7\u30F3" }, { length: 1, reading: "\u30D0\u30AF" }],
      sourceId: "mofa-korea-official-pages"
    }),
    defineName({
      id: "roh-moo-hyun",
      country: "korea",
      locale: "ko-KR",
      surfaces: ["\u76E7\u6B66\u9249"],
      reading: "\u30CE\u30FB\u30E0\u30D2\u30E7\u30F3",
      components: [{ length: 1, reading: "\u30CE\u30FB" }, { length: 1, reading: "\u30E0" }, { length: 1, reading: "\u30D2\u30E7\u30F3" }],
      sourceId: "mofa-korea-official-pages"
    }),
    defineName({
      id: "kim-dae-jung",
      country: "korea",
      locale: "ko-KR",
      surfaces: ["\u91D1\u5927\u4E2D"],
      reading: "\u30AD\u30E0\u30FB\u30C7\u30B8\u30E5\u30F3",
      components: [{ length: 1, reading: "\u30AD\u30E0\u30FB" }, { length: 1, reading: "\u30C7" }, { length: 1, reading: "\u30B8\u30E5\u30F3" }],
      sourceId: "mofa-korea-official-pages"
    }),
    defineName({
      id: "kim-young-sam",
      country: "korea",
      locale: "ko-KR",
      surfaces: ["\u91D1\u6CF3\u4E09"],
      reading: "\u30AD\u30E0\u30FB\u30E8\u30F3\u30B5\u30E0",
      components: [{ length: 1, reading: "\u30AD\u30E0\u30FB" }, { length: 1, reading: "\u30E8\u30F3" }, { length: 1, reading: "\u30B5\u30E0" }],
      sourceId: "mofa-korea-official-pages"
    }),
    defineName({
      id: "chun-doo-hwan",
      country: "korea",
      locale: "ko-KR",
      surfaces: ["\u5168\u6597\u7165"],
      reading: "\u30C1\u30E7\u30F3\u30FB\u30C9\u30A5\u30D5\u30A1\u30F3",
      components: [{ length: 1, reading: "\u30C1\u30E7\u30F3\u30FB" }, { length: 1, reading: "\u30C9\u30A5" }, { length: 1, reading: "\u30D5\u30A1\u30F3" }],
      sourceId: "mofa-korea-official-pages"
    }),
    defineName({
      id: "nguyen-phu-trong",
      country: "vietnam",
      locale: "vi",
      surfaces: ["\u962E\u5BCC\u4EF2"],
      reading: "\u30B0\u30A8\u30F3\u30FB\u30D5\u30FC\u30FB\u30C1\u30E7\u30F3",
      components: [{ length: 1, reading: "\u30B0\u30A8\u30F3\u30FB" }, { length: 1, reading: "\u30D5\u30FC\u30FB" }, { length: 1, reading: "\u30C1\u30E7\u30F3" }],
      sourceId: "mofa-vietnam-country-data"
    }),
    defineName({
      id: "nguyen-xuan-phuc",
      country: "vietnam",
      locale: "vi",
      surfaces: ["\u962E\u6625\u798F"],
      reading: "\u30B0\u30A8\u30F3\u30FB\u30B9\u30A2\u30F3\u30FB\u30D5\u30C3\u30AF",
      components: [{ length: 1, reading: "\u30B0\u30A8\u30F3\u30FB" }, { length: 1, reading: "\u30B9\u30A2\u30F3\u30FB" }, { length: 1, reading: "\u30D5\u30C3\u30AF" }],
      sourceId: "mofa-vietnam-country-data"
    }),
    defineName({
      id: "vo-nguyen-giap",
      country: "vietnam",
      locale: "vi",
      surfaces: ["\u6B66\u5143\u7532"],
      reading: "\u30F4\u30A9\u30FC\u30FB\u30B0\u30A8\u30F3\u30FB\u30B6\u30C3\u30D7",
      components: [{ length: 1, reading: "\u30F4\u30A9\u30FC\u30FB" }, { length: 1, reading: "\u30B0\u30A8\u30F3\u30FB" }, { length: 1, reading: "\u30B6\u30C3\u30D7" }],
      sourceId: "mofa-vietnam-country-data"
    }),
    defineName({
      id: "vo-van-thuong",
      country: "vietnam",
      locale: "vi",
      surfaces: ["\u6B66\u6587\u8CDE"],
      reading: "\u30F4\u30A9\u30FC\u30FB\u30F4\u30A1\u30F3\u30FB\u30C8\u30A5\u30AA\u30F3",
      components: [{ length: 1, reading: "\u30F4\u30A9\u30FC\u30FB" }, { length: 1, reading: "\u30F4\u30A1\u30F3\u30FB" }, { length: 1, reading: "\u30C8\u30A5\u30AA\u30F3" }],
      sourceId: "mofa-vietnam-country-data"
    }),
    defineName({
      id: "to-lam",
      country: "vietnam",
      locale: "vi",
      confidence: "contextual",
      surfaces: ["\u8607\u6797"],
      reading: "\u30C8\u30FC\u30FB\u30E9\u30E0",
      components: [{ length: 1, reading: "\u30C8\u30FC\u30FB" }, { length: 1, reading: "\u30E9\u30E0" }],
      roleHints: ["\u66F8\u8A18\u9577", "\u7DCF\u66F8\u8A18", "\u56FD\u5BB6\u4E3B\u5E2D", "\u4E3B\u5E2D"],
      sourceId: "mofa-vietnam-country-data"
    }),
    defineName({
      id: "luong-cuong",
      country: "vietnam",
      locale: "vi",
      confidence: "contextual",
      surfaces: ["\u6881\u5F37", "\u6881\u5F3A"],
      reading: "\u30EB\u30AA\u30F3\u30FB\u30AF\u30AA\u30F3",
      components: [{ length: 1, reading: "\u30EB\u30AA\u30F3\u30FB" }, { length: 1, reading: "\u30AF\u30AA\u30F3" }],
      roleHints: ["\u56FD\u5BB6\u4E3B\u5E2D", "\u4E3B\u5E2D"],
      sourceId: "mofa-heads-2026-08-20"
    }),
    defineName({
      id: "pham-minh-chinh",
      country: "vietnam",
      locale: "vi",
      confidence: "contextual",
      surfaces: ["\u8303\u660E\u653F"],
      reading: "\u30D5\u30A1\u30E0\u30FB\u30DF\u30F3\u30FB\u30C1\u30F3",
      components: [{ length: 1, reading: "\u30D5\u30A1\u30E0\u30FB" }, { length: 1, reading: "\u30DF\u30F3\u30FB" }, { length: 1, reading: "\u30C1\u30F3" }],
      roleHints: ["\u9996\u76F8"],
      sourceId: "mofa-heads-2026-08-20"
    }),
    defineName({
      id: "bui-thanh-son",
      country: "vietnam",
      locale: "vi",
      confidence: "contextual",
      surfaces: ["\u88F4\u9752\u5C71"],
      reading: "\u30D6\u30A4\u30FB\u30BF\u30A4\u30F3\u30FB\u30BD\u30F3",
      components: [{ length: 1, reading: "\u30D6\u30A4\u30FB" }, { length: 1, reading: "\u30BF\u30A4\u30F3\u30FB" }, { length: 1, reading: "\u30BD\u30F3" }],
      roleHints: ["\u5916\u76F8", "\u5916\u52D9\u5927\u81E3", "\u526F\u9996\u76F8"],
      sourceId: "mofa-heads-2026-08-20"
    }),
    defineName({
      id: "tran-thanh-man",
      country: "vietnam",
      locale: "vi",
      surfaces: ["\u9673\u9752\u654F"],
      reading: "\u30C1\u30E3\u30F3\u30FB\u30BF\u30A4\u30F3\u30FB\u30DE\u30F3",
      components: [{ length: 1, reading: "\u30C1\u30E3\u30F3\u30FB" }, { length: 1, reading: "\u30BF\u30A4\u30F3\u30FB" }, { length: 1, reading: "\u30DE\u30F3" }],
      sourceId: "mofa-vietnam-country-data"
    }),
    defineName({
      id: "ho-chi-minh",
      country: "vietnam",
      locale: "vi",
      confidence: "contextual",
      surfaces: ["\u80E1\u5FD7\u660E"],
      reading: "\u30DB\u30FC\u30FB\u30C1\u30FB\u30DF\u30F3",
      components: [{ length: 1, reading: "\u30DB\u30FC\u30FB" }, { length: 1, reading: "\u30C1\u30FB" }, { length: 1, reading: "\u30DF\u30F3" }],
      roleHints: ["\u4E3B\u5E2D", "\u9769\u547D\u5BB6", "\u5EFA\u56FD\u306E\u7236"],
      blockedSuffixes: ["\u5E02", "\u7A7A\u6E2F", "\u99C5", "\u5E02\u5185", "\u901A\u308A", "\u5EDF"],
      sourceId: "mofa-vietnam-country-data"
    })
  ]);
  function getForeignPersonNameParts(entry, surface) {
    const parts = [];
    let start = 0;
    for (let first = 0; first < entry.components.length; first += 1) {
      let length = 0;
      let reading = "";
      for (let last = first; last < entry.components.length; last += 1) {
        length += entry.components[last].length;
        reading += entry.components[last].reading;
        parts.push(Object.freeze({
          surface: surface.slice(start, start + length),
          start,
          reading: reading.replace(/・$/u, "")
        }));
      }
      start += entry.components[first].length;
    }
    return parts;
  }

  // src/katakana-reading-overrides.mjs
  var KATAKANA_READING_DEFINITIONS = Object.freeze([
    Object.freeze({
      surfaces: Object.freeze([
        "\u9EBB\u8FA3\u6E6F",
        // Standard Japanese spelling.
        "\u9EBB\u8FA3\u70EB",
        // Simplified Chinese spelling reported by a user.
        "\u9EBB\u8FA3\u71D9"
        // Traditional Chinese spelling of the same dish name.
      ]),
      reading: "\u30DE\u30FC\u30E9\u30FC\u30BF\u30F3",
      source: "https://kotobank.jp/word/%E9%BA%BB%E8%BE%A3%E6%B9%AF-3257872"
    })
  ]);
  var KATAKANA_READING_OVERRIDES = Object.freeze(
    KATAKANA_READING_DEFINITIONS.flatMap(({ surfaces, reading }) => surfaces.map(
      (surface) => Object.freeze([surface, reading])
    )).sort(([left], [right]) => right.length - left.length)
  );

  // src/core.mjs
  var KANJI_PATTERN = /[\p{Script=Han}々〆ヶ]/u;
  var SINGLE_KANJI_PATTERN = /^[\p{Script=Han}々〆ヶ]$/u;
  var KANJI_RUN_PATTERN = /^[\p{Script=Han}々〆ヶ]+$/u;
  var KANA_PATTERN = /[\p{Script=Hiragana}\p{Script=Katakana}ー]/u;
  var JAPANESE_WRITING_RUN_PATTERN = /[\p{Script=Han}々〆ヶ]+|[\p{Script=Hiragana}\p{Script=Katakana}ー]+/gu;
  var HORIZONTAL_SPACE = "[\\p{Zs}\\t]*";
  var WEEKDAY_ABBREVIATION_READINGS = Object.freeze({
    \u65E5: "\u306B\u3061",
    \u6708: "\u3052\u3064",
    \u706B: "\u304B",
    \u6C34: "\u3059\u3044",
    \u6728: "\u3082\u304F",
    \u91D1: "\u304D\u3093",
    \u571F: "\u3069"
  });
  var CLOSING_PARENTHESIS = Object.freeze({
    "(": ")",
    "\uFF08": "\uFF09"
  });
  var SPECIAL_DAY_READINGS = Object.freeze({
    1: "\u3064\u3044\u305F\u3061",
    2: "\u3075\u3064\u304B",
    3: "\u307F\u3063\u304B",
    4: "\u3088\u3063\u304B",
    5: "\u3044\u3064\u304B",
    6: "\u3080\u3044\u304B",
    7: "\u306A\u306E\u304B",
    8: "\u3088\u3046\u304B",
    9: "\u3053\u3053\u306E\u304B",
    10: "\u3068\u304A\u304B",
    14: "\u3058\u3085\u3046\u3088\u3063\u304B",
    20: "\u306F\u3064\u304B",
    24: "\u306B\u3058\u3085\u3046\u3088\u3063\u304B"
  });
  var PEOPLE_COUNTER_READINGS = Object.freeze({
    "1": "\u3072\u3068\u308A",
    "\uFF11": "\u3072\u3068\u308A",
    \u4E00: "\u3072\u3068\u308A",
    "2": "\u3075\u305F\u308A",
    "\uFF12": "\u3075\u305F\u308A",
    \u4E8C: "\u3075\u305F\u308A"
  });
  var EXACT_PHRASE_READINGS = Object.freeze([
    ["\u598A\u5A20\u9AD8\u8840\u5727\u814E\u75C7", "\u306B\u3093\u3057\u3093\u3053\u3046\u3051\u3064\u3042\u3064\u3058\u3093\u3057\u3087\u3046"],
    ["\u535A\u58EB\u8AB2\u7A0B", "\u306F\u304F\u3057\u304B\u3066\u3044"],
    ["\u65E5\u672C\u7814\u7A76", "\u306B\u307B\u3093\u3051\u3093\u304D\u3085\u3046"],
    ["\u65E5\u672C\u521D", "\u306B\u307B\u3093\u306F\u3064"],
    ["\u982D\u9838\u90E8", "\u3068\u3046\u3051\u3044\u3076"],
    ["\u5E79\u7D30\u80DE", "\u304B\u3093\u3055\u3044\u307C\u3046"],
    ["\u6D78\u900F\u5727", "\u3057\u3093\u3068\u3046\u3042\u3064"],
    ["\u30C8\u30D4\u4E3B\u69D8", "\u3068\u3074\u306C\u3057\u3055\u307E"],
    ["\u30B9\u30EC\u4E3B\u69D8", "\u3059\u308C\u306C\u3057\u3055\u307E"],
    ["\u30C8\u30D4\u7ACB\u3066", "\u3068\u3074\u305F\u3066"],
    ["\u30B9\u30EC\u7ACB\u3066", "\u3059\u308C\u305F\u3066"],
    ["\u30C8\u30D4\u4E3B", "\u3068\u3074\u306C\u3057"],
    ["\u30B9\u30EC\u4E3B", "\u3059\u308C\u306C\u3057"],
    ["\u76F8\u8EE2\u79FB", "\u305D\u3046\u3066\u3093\u3044"],
    ["\u5E73\u5747\u5834", "\u3078\u3044\u304D\u3093\u3070"],
    ["\u9AA8\u9AC4", "\u3053\u3064\u305A\u3044"],
    ["\u5354\u50CD", "\u304D\u3087\u3046\u3069\u3046"],
    ["\u81EA\u6CBB\u53A8", "\u3058\u3061\u3061\u3085\u3046"],
    ["\u65E2\u8AAD", "\u304D\u3069\u304F"],
    ["\u516C\u9332", "\u3053\u3046\u308D\u304F"],
    ["\u58F2\u308A\u6642", "\u3046\u308A\u3069\u304D"],
    ["\u6628\u590F", "\u3055\u3063\u304B"],
    ["\u4E00\u4EBA\u4E00\u4EBA", "\u3072\u3068\u308A\u3072\u3068\u308A"],
    ["\u4E8C\u4EBA\u7D44", "\u3075\u305F\u308A\u3050\u307F"],
    ["\u81B5", "\u3059\u3044"]
  ].sort(([left], [right]) => right.length - left.length));
  var EXACT_READING_OVERRIDES = Object.freeze([
    ...KATAKANA_READING_OVERRIDES,
    ...EXACT_PHRASE_READINGS
  ].sort(([left], [right]) => right.length - left.length));
  var ROUND_COUNTER_READINGS = Object.freeze({
    \u4E00: "\u3044\u3063\u304B\u3044",
    \u516D: "\u308D\u3063\u304B\u3044",
    \u516B: "\u306F\u3063\u304B\u3044",
    \u5341: "\u3058\u3085\u3063\u304B\u3044",
    \u767E: "\u3072\u3083\u3063\u304B\u3044"
  });
  var SPLIT_COMPOUND_READINGS = Object.freeze([
    {
      surface: "\u598A\u5A20\u9AD8\u8840\u5727\u814E\u75C7",
      parts: [
        ["\u598A", 0, "\u306B\u3093"],
        ["\u5A20", 1, "\u3057\u3093"],
        ["\u9AD8", 2, "\u3053\u3046"],
        ["\u8840", 3, "\u3051\u3064"],
        ["\u5727", 4, "\u3042\u3064"],
        ["\u814E", 5, "\u3058\u3093"],
        ["\u75C7", 6, "\u3057\u3087\u3046"],
        ["\u598A\u5A20", 0, "\u306B\u3093\u3057\u3093"],
        ["\u8840\u5727", 3, "\u3051\u3064\u3042\u3064"],
        ["\u814E\u75C7", 5, "\u3058\u3093\u3057\u3087\u3046"]
      ]
    },
    {
      surface: "\u535A\u58EB\u8AB2\u7A0B",
      parts: [
        ["\u535A", 0, "\u306F\u304F"],
        ["\u58EB", 1, "\u3057"],
        ["\u8AB2", 2, "\u304B"],
        ["\u7A0B", 3, "\u3066\u3044"],
        ["\u535A\u58EB", 0, "\u306F\u304F\u3057"],
        ["\u8AB2\u7A0B", 2, "\u304B\u3066\u3044"]
      ]
    },
    {
      surface: "\u65E5\u672C\u7814\u7A76",
      parts: [
        ["\u65E5", 0, "\u306B"],
        ["\u672C", 1, "\u307B\u3093"],
        ["\u7814", 2, "\u3051\u3093"],
        ["\u7A76", 3, "\u304D\u3085\u3046"],
        ["\u65E5\u672C", 0, "\u306B\u307B\u3093"],
        ["\u7814\u7A76", 2, "\u3051\u3093\u304D\u3085\u3046"]
      ]
    },
    {
      surface: "\u5E79\u7D30\u80DE",
      parts: [
        ["\u5E79", 0, "\u304B\u3093"],
        ["\u7D30", 1, "\u3055\u3044"],
        ["\u80DE", 2, "\u307C\u3046"],
        ["\u7D30\u80DE", 1, "\u3055\u3044\u307C\u3046"]
      ]
    },
    {
      surface: "\u982D\u9838\u90E8",
      parts: [["\u982D", 0, "\u3068\u3046"], ["\u9838", 1, "\u3051\u3044"], ["\u90E8", 2, "\u3076"]]
    },
    {
      surface: "\u6D78\u900F\u5727",
      parts: [
        ["\u6D78", 0, "\u3057\u3093"],
        ["\u900F", 1, "\u3068\u3046"],
        ["\u5727", 2, "\u3042\u3064"],
        ["\u6D78\u900F", 0, "\u3057\u3093\u3068\u3046"]
      ]
    },
    {
      surface: "\u65E5\u672C\u521D",
      parts: [
        ["\u65E5", 0, "\u306B"],
        ["\u672C", 1, "\u307B\u3093"],
        ["\u521D", 2, "\u306F\u3064"],
        ["\u65E5\u672C", 0, "\u306B\u307B\u3093"],
        ["\u672C\u521D", 1, "\u307B\u3093\u306F\u3064"]
      ]
    },
    {
      surface: "\u76F8\u8EE2\u79FB",
      parts: [
        ["\u76F8", 0, "\u305D\u3046"],
        ["\u8EE2", 1, "\u3066\u3093"],
        ["\u79FB", 2, "\u3044"],
        ["\u8EE2\u79FB", 1, "\u3066\u3093\u3044"]
      ]
    },
    {
      surface: "\u5E73\u5747\u5834",
      parts: [
        ["\u5E73", 0, "\u3078\u3044"],
        ["\u5747", 1, "\u304D\u3093"],
        ["\u5834", 2, "\u3070"],
        ["\u5E73\u5747", 0, "\u3078\u3044\u304D\u3093"]
      ]
    },
    {
      surface: "\u81EA\u6CBB\u53A8",
      parts: [
        ["\u81EA", 0, "\u3058"],
        ["\u6CBB", 1, "\u3061"],
        ["\u53A8", 2, "\u3061\u3085\u3046"],
        ["\u81EA\u6CBB", 0, "\u3058\u3061"]
      ]
    },
    {
      surface: "\u58F2\u308A\u6642",
      parts: [["\u58F2\u308A", 0, "\u3046\u308A"], ["\u6642", 2, "\u3069\u304D"]]
    },
    {
      surface: "\u9AA8\u9AC4",
      parts: [["\u9AA8", 0, "\u3053\u3064"], ["\u9AC4", 1, "\u305A\u3044"]]
    },
    {
      surface: "\u5354\u50CD",
      parts: [["\u5354", 0, "\u304D\u3087\u3046"], ["\u50CD", 1, "\u3069\u3046"]]
    },
    {
      surface: "\u65E2\u8AAD",
      parts: [["\u65E2", 0, "\u304D"], ["\u8AAD", 1, "\u3069\u304F"]]
    },
    {
      surface: "\u516C\u9332",
      parts: [["\u516C", 0, "\u3053\u3046"], ["\u9332", 1, "\u308D\u304F"]]
    },
    {
      surface: "\u6628\u590F",
      parts: [["\u6628", 0, "\u3055\u3063"], ["\u590F", 1, "\u304B"]]
    },
    {
      surface: "\u4E2D\u65E5",
      parts: [["\u4E2D", 0, "\u3061\u3085\u3046"], ["\u65E5", 1, "\u306B\u3061"]]
    },
    {
      surface: "\u5DE8\u4EBA",
      parts: [["\u5DE8", 0, "\u304D\u3087"], ["\u4EBA", 1, "\u3058\u3093"]]
    },
    {
      surface: "\u975E\u5E38",
      parts: [["\u975E", 0, "\u3072"], ["\u5E38", 1, "\u3058\u3087\u3046"]]
    }
  ]);
  var FOREIGN_PERSON_SURFACES = Object.freeze(FOREIGN_PERSON_NAMES.flatMap(
    (entry) => entry.surfaces.map((surface) => Object.freeze({
      entry,
      surface,
      parts: Object.freeze(getForeignPersonNameParts(entry, surface))
    }))
  ).sort((left, right) => right.surface.length - left.surface.length));
  var ALL_PERSON_COUNTRY_HINTS = Object.freeze(Object.values(PERSON_COUNTRY_HINTS).flat());
  var PROVIDED_READING_PATTERN = /^([\p{Script=Han}々〆ヶ]{2,6})[\p{Zs}\t]*([\(（])[\p{Zs}\t]*([\p{Script=Hiragana}\p{Script=Katakana}ー・･\p{Zs}\t]{2,48})[\p{Zs}\t]*([\)）])/u;
  function containsKanji(value) {
    return KANJI_PATTERN.test(value);
  }
  function katakanaToHiragana(value) {
    return Array.from(value, (character) => {
      const codePoint = character.codePointAt(0);
      if (codePoint >= 12449 && codePoint <= 12534) {
        return String.fromCodePoint(codePoint - 96);
      }
      return character;
    }).join("");
  }
  function splitKanjiReadingFromOkurigana(surface, reading) {
    if (!reading || !containsKanji(surface) || !KANA_PATTERN.test(surface)) {
      return [{ text: surface, reading }];
    }
    const writingRuns = surface.match(JAPANESE_WRITING_RUN_PATTERN) || [];
    if (writingRuns.join("") !== surface) {
      return [{ text: surface, reading: null }];
    }
    const normalizedReading = katakanaToHiragana(reading);
    const memo = /* @__PURE__ */ new Map();
    const align = (runIndex, readingIndex) => {
      const memoKey = `${runIndex}:${readingIndex}`;
      if (memo.has(memoKey)) {
        return memo.get(memoKey);
      }
      if (runIndex === writingRuns.length) {
        const result = readingIndex === normalizedReading.length ? [] : null;
        memo.set(memoKey, result);
        return result;
      }
      const run = writingRuns[runIndex];
      if (!KANJI_RUN_PATTERN.test(run)) {
        const normalizedKana = katakanaToHiragana(run);
        if (!normalizedReading.startsWith(normalizedKana, readingIndex)) {
          memo.set(memoKey, null);
          return null;
        }
        const tail = align(runIndex + 1, readingIndex + normalizedKana.length);
        const result = tail ? [{ text: run, reading: null }, ...tail] : null;
        memo.set(memoKey, result);
        return result;
      }
      for (let readingEnd = readingIndex + 1; readingEnd <= normalizedReading.length; readingEnd += 1) {
        const tail = align(runIndex + 1, readingEnd);
        if (tail) {
          const result = [{
            text: run,
            reading: reading.slice(readingIndex, readingEnd)
          }, ...tail];
          memo.set(memoKey, result);
          return result;
        }
      }
      memo.set(memoKey, null);
      return null;
    };
    return align(0, 0) || [{ text: surface, reading: null }];
  }
  function appendRubyReadySegments(segments, surface, reading) {
    segments.push(...splitKanjiReadingFromOkurigana(surface, reading));
  }
  function parseJapaneseNumber(value) {
    return Number(value.replace(
      /[０-９]/g,
      (digit) => String.fromCodePoint(digit.codePointAt(0) - 65248)
    ));
  }
  function normalizeContext(context) {
    return {
      prefix: typeof context?.prefix === "string" ? context.prefix : "",
      suffix: typeof context?.suffix === "string" ? context.suffix : ""
    };
  }
  function startsWithAny(value, candidates) {
    return candidates.some((candidate) => value.startsWith(candidate));
  }
  function endsWithAny(value, candidates) {
    return candidates.some((candidate) => value.endsWith(candidate));
  }
  function normalizeProvidedReading(value) {
    return value.trim().replace(/[\p{Zs}\t]+/gu, "\u30FB").replaceAll("\uFF65", "\u30FB");
  }
  function personRoleImmediatelyFollows(textAfter, roleHints = PERSON_ROLE_HINTS) {
    const withoutHorizontalSpace = textAfter.replace(/^[\p{Zs}\t]+/u, "");
    return startsWithAny(withoutHorizontalSpace, roleHints);
  }
  function personRoleImmediatelyPrecedes(textBefore, roleHints = PERSON_ROLE_HINTS) {
    const withoutHorizontalSpace = textBefore.replace(/[\p{Zs}\t]+$/u, "");
    return roleHints.some(
      (role) => withoutHorizontalSpace.endsWith(role) || withoutHorizontalSpace.endsWith(`${role}\u306E`)
    );
  }
  var COUNTRY_AFFILIATION_PATTERN = /^[\p{Zs}\t]*(?:(?:の|・|、|政府(?:の)?|共産党(?:の)?|国家(?:主席)?(?:の)?|政権(?:の)?|代表(?:の)?|首脳(?:の)?|大統領府(?:の)?)[\p{Zs}\t]*)?$/u;
  function hasCountryHint(entry, contextualText, start, end) {
    const hints = entry ? PERSON_COUNTRY_HINTS[entry.country] : ALL_PERSON_COUNTRY_HINTS;
    const before = contextualText.slice(Math.max(0, start - 36), start);
    const after = contextualText.slice(end, Math.min(contextualText.length, end + 36));
    const lastBoundary = Math.max(
      before.lastIndexOf("\u3002"),
      before.lastIndexOf("\uFF01"),
      before.lastIndexOf("\uFF1F"),
      before.lastIndexOf("!"),
      before.lastIndexOf("?"),
      before.lastIndexOf("\uFF1B"),
      before.lastIndexOf(";"),
      before.lastIndexOf("\n"),
      before.lastIndexOf("\r")
    );
    const sameSentenceBefore = before.slice(lastBoundary + 1);
    const afterBoundary = after.search(/[。！？!?；;\r\n]/u);
    const sameSentenceAfter = afterBoundary === -1 ? after : after.slice(0, afterBoundary);
    return hints.some((hint) => {
      const hintStart = sameSentenceBefore.lastIndexOf(hint);
      if (hintStart !== -1) {
        const between = sameSentenceBefore.slice(hintStart + hint.length);
        if (COUNTRY_AFFILIATION_PATTERN.test(between)) {
          return true;
        }
      }
      const afterName = sameSentenceAfter.replace(/^[\p{Zs}\t、・]+/u, "");
      if (!afterName.startsWith(hint)) {
        return false;
      }
      return personRoleImmediatelyFollows(
        afterName.slice(hint.length),
        entry?.roleHints || PERSON_ROLE_HINTS
      );
    });
  }
  function hasRequiredPersonContext(entry, contextualText, start, end) {
    if (entry.confidence !== "contextual") {
      return true;
    }
    const textBefore = contextualText.slice(0, start);
    const textAfter = contextualText.slice(end);
    return hasCountryHint(entry, contextualText, start, end) || personRoleImmediatelyFollows(textAfter, entry.roleHints) || personRoleImmediatelyPrecedes(textBefore, entry.roleHints);
  }
  function hasPersonNameBoundary(contextualText, start, end, entry = null) {
    const textBefore = contextualText.slice(0, start);
    const textAfter = contextualText.slice(end);
    const boundaryAfter = textAfter.replace(/^[\p{Zs}\t]+/u, "");
    if (entry && startsWithAny(boundaryAfter, entry.blockedSuffixes)) {
      return false;
    }
    const previousCharacter = Array.from(textBefore).at(-1) || "";
    if (SINGLE_KANJI_PATTERN.test(previousCharacter)) {
      const countryHints = entry ? PERSON_COUNTRY_HINTS[entry.country] : ALL_PERSON_COUNTRY_HINTS;
      if (!endsWithAny(textBefore, countryHints)) {
        return false;
      }
    }
    const nextCharacter = Array.from(boundaryAfter)[0] || "";
    if (SINGLE_KANJI_PATTERN.test(nextCharacter)) {
      const allowedSuffixes = entry ? [...PERSON_ROLE_HINTS, ...entry.roleHints] : PERSON_ROLE_HINTS;
      if (!startsWithAny(boundaryAfter, allowedSuffixes)) {
        return false;
      }
    }
    return true;
  }
  function findForeignPersonSurface(surface) {
    return FOREIGN_PERSON_SURFACES.find((candidate) => candidate.surface === surface) || null;
  }
  function findPageProvidedPersonName(text, start, contextualText, contextualOffset) {
    const match = text.slice(start).match(PROVIDED_READING_PATTERN);
    if (!match || CLOSING_PARENTHESIS[match[2]] !== match[4]) {
      return null;
    }
    const surface = match[1];
    const reading = normalizeProvidedReading(match[3]);
    if (!/[\p{Script=Hiragana}\p{Script=Katakana}]/u.test(reading)) {
      return null;
    }
    const known = findForeignPersonSurface(surface);
    const contextualStart = contextualOffset + start;
    const contextualEnd = contextualStart + surface.length;
    if (!hasPersonNameBoundary(contextualText, contextualStart, contextualEnd, known?.entry || null)) {
      return null;
    }
    if (!known) {
      const parentheticalEnd = contextualOffset + start + match[0].length;
      const afterParenthetical = contextualText.slice(parentheticalEnd);
      if (!hasCountryHint(null, contextualText, contextualStart, contextualEnd) || !personRoleImmediatelyFollows(afterParenthetical)) {
        return null;
      }
    }
    return {
      start,
      end: start + surface.length,
      surface,
      reading,
      priority: 3,
      source: "page"
    };
  }
  function findKnownPersonName(text, start, contextualText, contextualOffset) {
    for (const candidate of FOREIGN_PERSON_SURFACES) {
      if (!text.startsWith(candidate.surface, start)) {
        continue;
      }
      const contextualStart = contextualOffset + start;
      const contextualEnd = contextualStart + candidate.surface.length;
      if (hasPersonNameBoundary(contextualText, contextualStart, contextualEnd, candidate.entry) && hasRequiredPersonContext(candidate.entry, contextualText, contextualStart, contextualEnd)) {
        return {
          start,
          end: start + candidate.surface.length,
          surface: candidate.surface,
          reading: candidate.entry.reading,
          priority: 2,
          source: candidate.entry.id
        };
      }
    }
    return null;
  }
  function findCrossBoundaryPersonParts(text, contextualText, contextualOffset) {
    const currentStart = contextualOffset;
    const currentEnd = contextualOffset + text.length;
    const matches = [];
    for (const candidate of FOREIGN_PERSON_SURFACES) {
      let nameStart = contextualText.indexOf(
        candidate.surface,
        Math.max(0, currentStart - candidate.surface.length + 1)
      );
      while (nameStart !== -1 && nameStart < currentEnd) {
        const nameEnd = nameStart + candidate.surface.length;
        const crossesBoundary = nameStart < currentStart || nameEnd > currentEnd;
        if (crossesBoundary && nameEnd > currentStart && hasPersonNameBoundary(contextualText, nameStart, nameEnd, candidate.entry) && hasRequiredPersonContext(candidate.entry, contextualText, nameStart, nameEnd)) {
          const overlapStart = Math.max(nameStart, currentStart);
          const overlapEnd = Math.min(nameEnd, currentEnd);
          const relativeStart = overlapStart - nameStart;
          const overlapSurface = contextualText.slice(overlapStart, overlapEnd);
          const part = candidate.parts.find(
            (item) => item.start === relativeStart && item.surface === overlapSurface
          );
          if (part) {
            matches.push({
              start: overlapStart - currentStart,
              end: overlapEnd - currentStart,
              surface: overlapSurface,
              reading: part.reading,
              priority: 1,
              source: candidate.entry.id
            });
          }
        }
        nameStart = contextualText.indexOf(candidate.surface, nameStart + 1);
      }
    }
    return matches;
  }
  function findForeignPersonNameMatches(text, context) {
    const normalizedContext = normalizeContext(context);
    const contextualText = `${normalizedContext.prefix}${text}${normalizedContext.suffix}`;
    const contextualOffset = normalizedContext.prefix.length;
    const candidates = [];
    for (let start = 0; start < text.length; start += 1) {
      const pageProvided = findPageProvidedPersonName(text, start, contextualText, contextualOffset);
      const known = findKnownPersonName(text, start, contextualText, contextualOffset);
      if (pageProvided) {
        candidates.push(pageProvided);
      } else if (known) {
        candidates.push(known);
      }
    }
    candidates.push(...findCrossBoundaryPersonParts(text, contextualText, contextualOffset));
    candidates.sort(
      (left, right) => left.start - right.start || right.priority - left.priority || right.end - right.start - (left.end - left.start)
    );
    const matches = [];
    let consumedUntil = 0;
    for (const candidate of candidates) {
      if (candidate.start < consumedUntil) {
        continue;
      }
      matches.push(candidate);
      consumedUntil = candidate.end;
    }
    return matches;
  }
  function getSplitCompoundReading(contextualText, contextualStart, surface, currentTextStart, currentTextEnd) {
    const tokenEnd = contextualStart + surface.length;
    for (const compound of SPLIT_COMPOUND_READINGS) {
      let compoundStart = contextualText.indexOf(
        compound.surface,
        Math.max(0, contextualStart - compound.surface.length + 1)
      );
      while (compoundStart !== -1 && compoundStart <= contextualStart) {
        const compoundEnd = compoundStart + compound.surface.length;
        if (tokenEnd <= compoundEnd) {
          const crossesTextBoundary = compoundStart < currentTextStart || compoundEnd > currentTextEnd;
          if (crossesTextBoundary) {
            const relativeStart = contextualStart - compoundStart;
            const matchingPart = compound.parts.find(
              ([partSurface, partStart]) => partStart === relativeStart && partSurface === surface
            );
            if (matchingPart) {
              return matchingPart[2];
            }
          }
        }
        compoundStart = contextualText.indexOf(compound.surface, compoundStart + 1);
      }
    }
    return null;
  }
  function getPairedWeekdayContext(textBefore, textAfter) {
    const closingMatch = textAfter.match(new RegExp(`^${HORIZONTAL_SPACE}([\\)\uFF09])`, "u"));
    if (!closingMatch) {
      return null;
    }
    const japaneseDateMatch = textBefore.match(new RegExp(
      `(?:^|[^0-9\uFF10-\uFF19])([0-9\uFF10-\uFF19]{1,2})\u65E5${HORIZONTAL_SPACE}([\\(\uFF08])${HORIZONTAL_SPACE}$`,
      "u"
    ));
    if (japaneseDateMatch) {
      const dayNumber2 = parseJapaneseNumber(japaneseDateMatch[1]);
      if (dayNumber2 >= 1 && dayNumber2 <= 31 && CLOSING_PARENTHESIS[japaneseDateMatch[2]] === closingMatch[1]) {
        return true;
      }
    }
    const bareDayMatch = textBefore.match(new RegExp(
      `(?:^|[^\\p{Letter}\\p{Number}.\uFF0E/\uFF0F-])([0-9\uFF10-\uFF19]{1,2})${HORIZONTAL_SPACE}([\\(\uFF08])${HORIZONTAL_SPACE}$`,
      "u"
    ));
    if (bareDayMatch) {
      const dayNumber2 = parseJapaneseNumber(bareDayMatch[1]);
      if (dayNumber2 >= 1 && dayNumber2 <= 31 && CLOSING_PARENTHESIS[bareDayMatch[2]] === closingMatch[1]) {
        return true;
      }
    }
    const dottedDateMatch = textBefore.match(new RegExp(
      `(?:^|[^0-9\uFF10-\uFF19])([0-9\uFF10-\uFF19]{1,2})[.\uFF0E/\uFF0F-]([0-9\uFF10-\uFF19]{1,2})${HORIZONTAL_SPACE}([\\(\uFF08])${HORIZONTAL_SPACE}$`,
      "u"
    ));
    if (!dottedDateMatch) {
      return null;
    }
    const monthNumber = parseJapaneseNumber(dottedDateMatch[1]);
    const dayNumber = parseJapaneseNumber(dottedDateMatch[2]);
    return monthNumber >= 1 && monthNumber <= 12 && dayNumber >= 1 && dayNumber <= 31 && CLOSING_PARENTHESIS[dottedDateMatch[3]] === closingMatch[1];
  }
  function getContextualReading(text, tokenStart, surface, context = {}) {
    const normalizedContext = normalizeContext(context);
    const contextualText = `${normalizedContext.prefix}${text}${normalizedContext.suffix}`;
    const contextualStart = normalizedContext.prefix.length + tokenStart;
    const textBefore = contextualText.slice(0, contextualStart);
    const textAfter = contextualText.slice(contextualStart + surface.length);
    const splitCompoundReading = getSplitCompoundReading(
      contextualText,
      contextualStart,
      surface,
      normalizedContext.prefix.length,
      normalizedContext.prefix.length + text.length
    );
    if (splitCompoundReading) {
      return splitCompoundReading;
    }
    if (surface === "\u96E8") {
      const followsHardBoundary = /(?:^|[/／:：|｜、，,（(【「『])[\p{Zs}\t]*$/u.test(textBefore);
      const startsWeatherPair = /^[\p{Zs}\t]*・/u.test(textAfter);
      if (followsHardBoundary && startsWeatherPair) {
        return "\u3042\u3081";
      }
    }
    if (surface === "\u6708") {
      const monthMatch = textBefore.match(/(?:^|[^0-9０-９])([0-9０-９]{1,2})$/u);
      if (monthMatch) {
        const monthNumber = parseJapaneseNumber(monthMatch[1]);
        if (monthNumber >= 1 && monthNumber <= 12) {
          return "\u304C\u3064";
        }
      }
    }
    if (surface === "\u7B11" || surface === "\u6CE3") {
      const openingMatch = textBefore.match(/([\(（])[\p{Zs}\t]*$/u);
      const closingMatch = textAfter.match(/^[\p{Zs}\t]*([\)）])/u);
      if (openingMatch && closingMatch && CLOSING_PARENTHESIS[openingMatch[1]] === closingMatch[1]) {
        return surface === "\u7B11" ? "\u308F\u3089\u3044" : "\u306A\u304D";
      }
    }
    if (surface === "\u8F9B\u3044" && /^[\p{Zs}\t]*(?:焼きそば|料理|食べ物|食品|ラーメン|カレー|味)/u.test(textAfter)) {
      return "\u304B\u3089\u3044";
    }
    if (surface === "\u5F8C" && /^から/u.test(textAfter) && /(?:^|[。．.!！?？、，,（(【「『])[\p{Zs}\t]*$/u.test(textBefore)) {
      return "\u3042\u3068";
    }
    if (surface === "\u7ACB\u3066" && /(?:トピ|スレ)$/u.test(textBefore)) {
      return "\u305F\u3066";
    }
    if (surface === "\u4E3B" && /(?:トピ|スレ)$/u.test(textBefore) && /^(?:さん|様)/u.test(textAfter)) {
      return "\u306C\u3057";
    }
    const weekdayReading = WEEKDAY_ABBREVIATION_READINGS[surface];
    if (!weekdayReading || surface.length !== 1) {
      return null;
    }
    return getPairedWeekdayContext(textBefore, textAfter) ? weekdayReading : null;
  }
  function createTokenEntries(tokens) {
    let start = 0;
    return tokens.map((token) => {
      const entry = {
        token,
        start,
        end: start + token.surface_form.length
      };
      start = entry.end;
      return entry;
    });
  }
  function findExactPhrase(text, start, tokenIndexByStart) {
    for (const [surface, reading] of EXACT_READING_OVERRIDES) {
      if (!text.startsWith(surface, start)) {
        continue;
      }
      const nextTokenIndex = tokenIndexByStart.get(start + surface.length);
      if (nextTokenIndex !== void 0) {
        return { surface, reading, nextTokenIndex };
      }
    }
    return null;
  }
  function followsValidCalendarMonth(textBefore) {
    const match = textBefore.match(/(?:^|[^0-9０-９])([0-9０-９]{1,2})月[\p{Zs}\t]*$/u);
    if (!match) {
      return false;
    }
    const monthNumber = parseJapaneseNumber(match[1]);
    return monthNumber >= 1 && monthNumber <= 12;
  }
  function startsPairedWeekday(textAfter) {
    const match = textAfter.match(/^[\p{Zs}\t]*([\(（])[\p{Zs}\t]*[日月火水木金土][\p{Zs}\t]*([\)）])/u);
    return Boolean(match && CLOSING_PARENTHESIS[match[1]] === match[2]);
  }
  function findSpecialDay(text, start, tokenIndexByStart, context) {
    const match = text.slice(start).match(/^([0-9０-９]{1,2})日(間)?/u);
    if (!match) {
      return null;
    }
    const dayNumber = parseJapaneseNumber(match[1]);
    const ordinaryReading = SPECIAL_DAY_READINGS[dayNumber];
    if (!ordinaryReading) {
      return null;
    }
    const surface = match[0];
    const nextTokenIndex = tokenIndexByStart.get(start + surface.length);
    if (nextTokenIndex === void 0) {
      return null;
    }
    const normalizedContext = normalizeContext(context);
    const textBefore = `${normalizedContext.prefix}${text.slice(0, start)}`;
    const textAfter = `${text.slice(start + surface.length)}${normalizedContext.suffix}`;
    if (!match[2] && textAfter.startsWith("\u672C")) {
      return null;
    }
    if (match[2]) {
      const dayReading = dayNumber === 1 ? "\u3044\u3061\u306B\u3061" : ordinaryReading;
      return { surface, reading: `${dayReading}\u304B\u3093`, nextTokenIndex };
    }
    if (dayNumber === 1) {
      if (followsValidCalendarMonth(textBefore) || startsPairedWeekday(textAfter)) {
        return { surface, reading: ordinaryReading, nextTokenIndex };
      }
      if (/^(?:目|後|前|以内|以上|以下|未満|程度)/u.test(textAfter)) {
        return { surface, reading: "\u3044\u3061\u306B\u3061", nextTokenIndex };
      }
      return null;
    }
    return { surface, reading: ordinaryReading, nextTokenIndex };
  }
  function findPeopleCounter(text, start, tokenIndexByStart, context) {
    const match = text.slice(start).match(/^([12１２一二])人/u);
    if (!match) {
      return null;
    }
    const surface = match[0];
    const nextTokenIndex = tokenIndexByStart.get(start + surface.length);
    if (nextTokenIndex === void 0) {
      return null;
    }
    const normalizedContext = normalizeContext(context);
    const textAfter = `${text.slice(start + surface.length)}${normalizedContext.suffix}`;
    if (/^[称前月日年者物]/u.test(textAfter)) {
      return null;
    }
    return {
      surface,
      reading: PEOPLE_COUNTER_READINGS[match[1]],
      nextTokenIndex
    };
  }
  function findRoundCounter(text, start, tokenIndexByStart, context) {
    const match = text.slice(start).match(/^([一六八十百])回/u);
    if (!match) {
      return null;
    }
    const normalizedContext = normalizeContext(context);
    const previousCharacter = Array.from(`${normalizedContext.prefix}${text.slice(0, start)}`).at(-1) ?? "";
    if (/[一二三四五六七八九十百千万兆]/u.test(previousCharacter)) {
      return null;
    }
    const surface = match[0];
    const nextTokenIndex = tokenIndexByStart.get(start + surface.length);
    if (nextTokenIndex === void 0) {
      return null;
    }
    return {
      surface,
      reading: ROUND_COUNTER_READINGS[match[1]],
      nextTokenIndex
    };
  }
  function buildBaseAnnotationSegments(text, tokenizer, context = {}) {
    if (!containsKanji(text)) {
      return [{ text, reading: null }];
    }
    const tokens = tokenizer.tokenize(text);
    if (tokens.map((token) => token.surface_form).join("") !== text) {
      return [{ text, reading: null }];
    }
    const entries = createTokenEntries(tokens);
    const tokenIndexByStart = new Map(entries.map((entry, index2) => [entry.start, index2]));
    tokenIndexByStart.set(text.length, entries.length);
    const segments = [];
    let index = 0;
    while (index < entries.length) {
      const entry = entries[index];
      const phrase = findExactPhrase(text, entry.start, tokenIndexByStart) ?? findSpecialDay(text, entry.start, tokenIndexByStart, context) ?? findPeopleCounter(text, entry.start, tokenIndexByStart, context) ?? findRoundCounter(text, entry.start, tokenIndexByStart, context);
      if (phrase) {
        appendRubyReadySegments(segments, phrase.surface, phrase.reading);
        index = phrase.nextTokenIndex;
        continue;
      }
      const dictionaryReading = entry.token.reading && entry.token.reading !== "*" ? katakanaToHiragana(entry.token.reading) : null;
      const reading = getContextualReading(text, entry.start, entry.token.surface_form, context) ?? dictionaryReading;
      appendRubyReadySegments(
        segments,
        entry.token.surface_form,
        containsKanji(entry.token.surface_form) ? reading : null
      );
      index += 1;
    }
    return segments;
  }
  function buildAnnotationSegments(text, tokenizer, context = {}) {
    if (!containsKanji(text)) {
      return [{ text, reading: null }];
    }
    const matches = findForeignPersonNameMatches(text, context);
    if (matches.length === 0) {
      return buildBaseAnnotationSegments(text, tokenizer, context);
    }
    const normalizedContext = normalizeContext(context);
    const segments = [];
    let cursor = 0;
    for (const match of matches) {
      if (match.start > cursor) {
        segments.push(...buildBaseAnnotationSegments(
          text.slice(cursor, match.start),
          tokenizer,
          {
            prefix: `${normalizedContext.prefix}${text.slice(0, cursor)}`,
            suffix: `${text.slice(match.start)}${normalizedContext.suffix}`
          }
        ));
      }
      appendRubyReadySegments(segments, match.surface, match.reading);
      cursor = match.end;
    }
    if (cursor < text.length) {
      segments.push(...buildBaseAnnotationSegments(
        text.slice(cursor),
        tokenizer,
        {
          prefix: `${normalizedContext.prefix}${text.slice(0, cursor)}`,
          suffix: normalizedContext.suffix
        }
      ));
    }
    return segments;
  }

  // src/data/loanword-origins-jmdict.mjs
  var JMDICT_LOANWORD_ORIGIN_METADATA = Object.freeze({ "dictionaryDate": "2026-08-17", "sourceVersion": "3.6.2+20260817122448", "sourceUrl": "https://github.com/scriptin/jmdict-simplified/releases/tag/3.6.2%2B20260817122448", "sourceSha256": "445073563CCCDB85C47D1E014385BEEF858C3EFC3FDD2F75019DB33699A07DE6", "entryCount": 2989, "ambiguousSurfacesOmitted": 84, "license": "CC BY-SA 4.0 / EDRDG General Dictionary Licence" });
  var JMDICT_LOANWORD_ORIGINS = Object.freeze([
    Object.freeze(["\u30A2\u30A4\u30AA\u30EA", "fre", "a\xEFoli"]),
    Object.freeze(["\u30A2\u30A4\u30AA\u30EA\u30BD\u30FC\u30B9", "eng", "aioli sauce"]),
    Object.freeze(["\u30A2\u30A4\u30AA\u30EA\u30FB\u30BD\u30FC\u30B9", "eng", "aioli sauce"]),
    Object.freeze(["\u30A2\u30A4\u30B4\u30FC", "kor", "aigo"]),
    Object.freeze(["\u30A2\u30A4\u30B9\u30CF\u30FC\u30B1\u30F3", "ger", "Eishaken"]),
    Object.freeze(["\u30A2\u30A4\u30B9\u30D0\u30A4\u30F3", "ger", "Eisbein"]),
    Object.freeze(["\u30A2\u30A4\u30B9\u30D0\u30FC\u30F3", "ger", "Eisbahn"]),
    Object.freeze(["\u30A2\u30A4\u30B9\u30D6\u30EC\u30A4\u30AD\u30F3\u30B0", "eng", "ice-breaking"]),
    Object.freeze(["\u30A2\u30A4\u30B9\u30D6\u30EC\u30FC\u30AD\u30F3\u30B0", "eng", "ice-breaking"]),
    Object.freeze(["\u30A2\u30A4\u30BC\u30F3", "ger", "Eisen"]),
    Object.freeze(["\u30A2\u30A4\u30E9\u30B0", "mon", "airag"]),
    Object.freeze(["\u30A2\u30A6\u30BF\u30EB\u30AD\u30FC", "ger", "Autarkie"]),
    Object.freeze(["\u30A2\u30A6\u30C8\u30AB\u30A6\u30F3\u30C8", "eng", "out count"]),
    Object.freeze(["\u30A2\u30A6\u30C8\u30D0\u30FC\u30F3", "ger", "Autobahn"]),
    Object.freeze(["\u30A2\u30A6\u30C8\u30FB\u30AB\u30A6\u30F3\u30C8", "eng", "out count"]),
    Object.freeze(["\u30A2\u30A6\u30D5\u30BF\u30AF\u30C8", "ger", "Auftakt"]),
    Object.freeze(["\u30A2\u30A6\u30D5\u30D8\u30FC\u30D9\u30F3", "ger", "aufheben"]),
    Object.freeze(["\u30A2\u30AA\u30B6\u30A4", "vie", "\xE1o d\xE0i"]),
    Object.freeze(["\u30A2\u30AB\u30B7\u30E3", "san", "\u0101k\u0101\u015Ba"]),
    Object.freeze(["\u30A2\u30AC\u30DA\u30FC", "gre", "agap\u0113"]),
    Object.freeze(["\u30A2\u30AF\u30B5\u30F3\u30B0\u30E9\u30FC\u30D6", "fre", "accent grave"]),
    Object.freeze(["\u30A2\u30AF\u30B5\u30F3\u30B0\u30E9\u30FC\u30F4", "fre", "accent grave"]),
    Object.freeze(["\u30A2\u30AF\u30B5\u30F3\u30B7\u30EB\u30B3\u30F3\u30D5\u30EC\u30C3\u30AF\u30B9", "fre", "accent circonflexe"]),
    Object.freeze(["\u30A2\u30AF\u30B5\u30F3\u30C6\u30AE\u30E5", "fre", "accent aigu"]),
    Object.freeze(["\u30A2\u30AF\u30B5\u30F3\u30FB\u30B0\u30E9\u30FC\u30D6", "fre", "accent grave"]),
    Object.freeze(["\u30A2\u30AF\u30B5\u30F3\u30FB\u30B0\u30E9\u30FC\u30F4", "fre", "accent grave"]),
    Object.freeze(["\u30A2\u30AF\u30B5\u30F3\u30FB\u30B7\u30EB\u30B3\u30F3\u30D5\u30EC\u30C3\u30AF\u30B9", "fre", "accent circonflexe"]),
    Object.freeze(["\u30A2\u30AF\u30B7\u30E7\u30F3\u30D1\u30BA\u30EB", "eng", "action puzzle"]),
    Object.freeze(["\u30A2\u30AF\u30B7\u30E7\u30F3\u30FB\u30D1\u30BA\u30EB", "eng", "action puzzle"]),
    Object.freeze(["\u30A2\u30AF\u30BB\u30B9\u30AB\u30A6\u30F3\u30BF", "eng", "access counter"]),
    Object.freeze(["\u30A2\u30AF\u30BB\u30B9\u30AB\u30A6\u30F3\u30BF\u30FC", "eng", "access counter"]),
    Object.freeze(["\u30A2\u30AF\u30BB\u30B9\u30E9\u30F3\u30AD\u30F3\u30B0", "eng", "access ranking"]),
    Object.freeze(["\u30A2\u30AF\u30BB\u30B9\u30FB\u30AB\u30A6\u30F3\u30BF", "eng", "access counter"]),
    Object.freeze(["\u30A2\u30AF\u30BB\u30B9\u30FB\u30AB\u30A6\u30F3\u30BF\u30FC", "eng", "access counter"]),
    Object.freeze(["\u30A2\u30AF\u30BB\u30B9\u30FB\u30E9\u30F3\u30AD\u30F3\u30B0", "eng", "access ranking"]),
    Object.freeze(["\u30A2\u30AF\u30BB\u30BD\u30EF\u30EA\u30B9\u30C8", "fre", "accessoiriste"]),
    Object.freeze(["\u30A2\u30AF\u30BB\u30EB", "eng", "accel(erator)"]),
    Object.freeze(["\u30A2\u30AF\u30E1", "fre", "acm\xE9"]),
    Object.freeze(["\u30A2\u30AF\u30EA\u30EB", "ger", "Acryl"]),
    Object.freeze(["\u30A2\u30B0\u30EC\u30AC\u30B7\u30AA\u30F3", "fre", "agr\xE9gation"]),
    Object.freeze(["\u30A2\u30B2\u30A3\u30F3\u30B9\u30C8", "eng", "against"]),
    Object.freeze(["\u30A2\u30B2\u30A4\u30F3", "eng", "again"]),
    Object.freeze(["\u30A2\u30B2\u30A4\u30F3\u30B9\u30C8", "eng", "against"]),
    Object.freeze(["\u30A2\u30B2\u30F3", "eng", "again"]),
    Object.freeze(["\u30A2\u30B2\u30F3\u30B9\u30C8", "eng", "against"]),
    Object.freeze(["\u30A2\u30B2\u30FC\u30F3", "eng", "again"]),
    Object.freeze(["\u30A2\u30B7\u30B9\u30C8", "eng", "assist"]),
    Object.freeze(["\u30A2\u30B8\u30E3\u30BF", "eng", "A(ll) Ja(pan) Ta(maire Association)"]),
    Object.freeze(["\u30A2\u30B8\u30FC\u30EB", "ger", "Asyl"]),
    Object.freeze(["\u30A2\u30B9\u30C6\u30AB", "spa", "Azteca"]),
    Object.freeze(["\u30A2\u30B9\u30C8\u30ED\u30CE\u30FC\u30BF\u30B9", "lat", "Astronotus"]),
    Object.freeze(["\u30A2\u30B9\u30D4\u30EA\u30F3", "ger", "Aspirin"]),
    Object.freeze(["\u30A2\u30B9\u30D4\u30FC\u30C6", "ger", "Aspite"]),
    Object.freeze(["\u30A2\u30B9\u30D9\u30B9\u30C8", "dut", "asbest"]),
    Object.freeze(["\u30A2\u30C3\u30D7\u30B6\u30A4\u30EC\u30F3", "ger", "Abseilen"]),
    Object.freeze(["\u30A2\u30C3\u30D7\u30B7\u30E7\u30C3\u30C8", "eng", "up shot"]),
    Object.freeze(["\u30A2\u30C3\u30D7\u30FB\u30B7\u30E7\u30C3\u30C8", "eng", "up shot"]),
    Object.freeze(["\u30A2\u30C6\u30CA\u30A4", "lat", "Athenae"]),
    Object.freeze(["\u30A2\u30C6\u30CD", "lat", "Athenae"]),
    Object.freeze(["\u30A2\u30C6\u30ED\u30FC\u30E0", "ger", "Atherom"]),
    Object.freeze(["\u30A2\u30C7\u30A3\u30AA\u30B9", "spa", "adi\xF3s"]),
    Object.freeze(["\u30A2\u30C8\u30CB\u30FC", "ger", "Atonie"]),
    Object.freeze(["\u30A2\u30C8\u30E9\u30F3\u30C6\u30B9", "gre", "atlantes"]),
    Object.freeze(["\u30A2\u30CA\u30B9\u30C1\u30B0\u30DE\u30FC\u30C8", "ger", "Anastigmat"]),
    Object.freeze(["\u30A2\u30CA\u30D5\u30A3\u30E9\u30AD\u30B7", "ger", "Anaphylaxie"]),
    Object.freeze(["\u30A2\u30CA\u30D5\u30A3\u30E9\u30AD\u30B7\u30FC", "ger", "Anaphylaxie"]),
    Object.freeze(["\u30A2\u30CB\u30E1\u30A4\u30C8", "eng", "animate"]),
    Object.freeze(["\u30A2\u30CB\u30E1\u30FC\u30C8", "eng", "animate"]),
    Object.freeze(["\u30A2\u30CB\u30E7\u30CF\u30BB\u30E8", "kor", "annyeonghaseyo"]),
    Object.freeze(["\u30A2\u30CD\u30A2\u30ED\u30D3\u30AF\u30B9", "eng", "anaerobics"]),
    Object.freeze(["\u30A2\u30D0\u30A6\u30C8", "eng", "about"]),
    Object.freeze(["\u30A2\u30D0\u30F3", "fre", "avant"]),
    Object.freeze(["\u30A2\u30D0\u30F3\u30B2\u30FC\u30EB", "fre", "avant-guerre"]),
    Object.freeze(["\u30A2\u30D0\u30F3\u30C1\u30E5\u30FC\u30EB", "fre", "aventure"]),
    Object.freeze(["\u30A2\u30D1\u30C3\u30B7\u30E5", "fre", "apache"]),
    Object.freeze(["\u30A2\u30D1\u30EB\u30C8\u30DE\u30F3", "fre", "appartement"]),
    Object.freeze(["\u30A2\u30D2\u30E0\u30B5\u30FC", "san", "ahi\u1E43s\u0101"]),
    Object.freeze(["\u30A2\u30D2\u30F3\u30B5\u30FC", "san", "ahi\u1E43s\u0101"]),
    Object.freeze(["\u30A2\u30D2\u30FC\u30B8\u30E7", "spa", "ajillo"]),
    Object.freeze(["\u30A2\u30D3\u30E9\u30A6\u30F3\u30B1\u30F3", "san", "a vi ra h\u016B\u1E43 kha\u1E43"]),
    Object.freeze(["\u30A2\u30D3\u30E9\u30A6\u30F3\u30B1\u30F3\u30BD\u30EF\u30AB", "san", "a vi ra h\u016B\u1E43 kha\u1E43 sv\u0101h\u0101"]),
    Object.freeze(["\u30A2\u30D5\u30BF\u30FC\u30C0\u30FC\u30AF", "eng", "after dark"]),
    Object.freeze(["\u30A2\u30D5\u30BF\u30FC\u30FB\u30C0\u30FC\u30AF", "eng", "after dark"]),
    Object.freeze(["\u30A2\u30D5\u30ED\u30D8\u30A2", "eng", "Afro hair"]),
    Object.freeze(["\u30A2\u30D5\u30ED\u30D8\u30A2\u30FC", "eng", "Afro hair"]),
    Object.freeze(["\u30A2\u30D5\u30ED\u30FB\u30D8\u30A2", "eng", "Afro hair"]),
    Object.freeze(["\u30A2\u30D5\u30ED\u30FB\u30D8\u30A2\u30FC", "eng", "Afro hair"]),
    Object.freeze(["\u30A2\u30D6\u30BD\u30EB\u30D0\u30F3", "fre", "absorbant"]),
    Object.freeze(["\u30A2\u30D7\u30B6\u30A4\u30EC\u30F3", "ger", "Abseilen"]),
    Object.freeze(["\u30A2\u30D7\u30B9\u30C8\u30EC\u30FC", "fre", "abstrait"]),
    Object.freeze(["\u30A2\u30D7\u30BD\u30EB\u30D0\u30F3", "fre", "absorbant"]),
    Object.freeze(["\u30A2\u30D7\u30D5\u30A7\u30EB\u30B7\u30E5\u30C8\u30A5\u30EB\u30FC\u30C7\u30EB", "ger", "Apfelstrudel"]),
    Object.freeze(["\u30A2\u30D7\u30D5\u30A7\u30EB\u30B7\u30E5\u30C8\u30E5\u30EB\u30FC\u30C7\u30EB", "ger", "Apfelstrudel"]),
    Object.freeze(["\u30A2\u30D7\u30D5\u30A7\u30EB\u30B7\u30E5\u30C8\u30EB\u30FC\u30C7\u30EB", "ger", "Apfelstrudel"]),
    Object.freeze(["\u30A2\u30D7\u30EC\u30B2\u30FC\u30EB", "fre", "apr\xE8s-guerre"]),
    Object.freeze(["\u30A2\u30D7\u30EC\u30FB\u30B2\u30FC\u30EB", "fre", "apr\xE8s-guerre"]),
    Object.freeze(["\u30A2\u30D9\u30C3\u30AF", "fre", "avec"]),
    Object.freeze(["\u30A2\u30DA\u30E9\u30B7\u30AA\u30F3\u30C9\u30EA\u30B8\u30FC\u30CC\u30B3\u30F3\u30C8\u30ED\u30FC\u30EC", "fre", "Appellation d'origine contr\xF4l\xE9e"]),
    Object.freeze(["\u30A2\u30DA\u30E9\u30B7\u30AA\u30F3\u30FB\u30C9\u30EA\u30B8\u30FC\u30CC\u30FB\u30B3\u30F3\u30C8\u30ED\u30EC", "fre", "Appellation d'origine contr\xF4l\xE9e"]),
    Object.freeze(["\u30A2\u30DA\u30EA\u30C1\u30D5", "fre", "ap\xE9ritif"]),
    Object.freeze(["\u30A2\u30DA\u30EA\u30C6\u30A3\u30D5", "fre", "ap\xE9ritif"]),
    Object.freeze(["\u30A2\u30DC\u30B8", "kor", "abeoji"]),
    Object.freeze(["\u30A2\u30DD\u30AF\u30ED\u30DE\u30FC\u30C8", "ger", "Apochromat"]),
    Object.freeze(["\u30A2\u30DD\u30B9\u30C8\u30ED", "por", "apostolo"]),
    Object.freeze(["\u30A2\u30DD\u30D5\u30A3\u30FC\u30BC", "ger", "Apophyse"]),
    Object.freeze(["\u30A2\u30DD\u30ED\u30F3", "gre", "Apoll\u014Dn"]),
    Object.freeze(["\u30A2\u30DD\u30ED\u30FC\u30F3", "gre", "Apoll\u014Dn"]),
    Object.freeze(["\u30A2\u30DE", "por", "ama"]),
    Object.freeze(["\u30A2\u30DE\u30F3", "fre", "amant, amante"]),
    Object.freeze(["\u30A2\u30DE\u30F3\u30C9", "fre", "amande"]),
    Object.freeze(["\u30A2\u30DF", "fre", "ami, amie"]),
    Object.freeze(["\u30A2\u30DF\u30A2", "lat", "Amia"]),
    Object.freeze(["\u30A2\u30DF\u30B4", "spa", "amigo"]),
    Object.freeze(["\u30A2\u30DF\u30E9\u30FC\u30BC", "ger", "Amylase"]),
    Object.freeze(["\u30A2\u30DF\u30FC\u30B4", "spa", "amigo"]),
    Object.freeze(["\u30A2\u30E0\u30FC\u30EB", "fre", "amour"]),
    Object.freeze(["\u30A2\u30E1\u30EA\u30AB\u30CA\u30A4\u30BA", "eng", "Americanize"]),
    Object.freeze(["\u30A2\u30E2\u30FC\u30EC", "ita", "amore"]),
    Object.freeze(["\u30A2\u30E9\u30B6\u30F3", "fre", "argent"]),
    Object.freeze(["\u30A2\u30E9\u30E2\u30FC\u30C9", "fre", "\xE0 la mode"]),
    Object.freeze(["\u30A2\u30EB", "chi", "\xE8r"]),
    Object.freeze(["\u30A2\u30EB\u30AB\u30A4\u30B9\u30E0", "fre", "archa\xEFsme"]),
    Object.freeze(["\u30A2\u30EB\u30AB\u30A4\u30BA\u30E0", "fre", "archa\xEFsme"]),
    Object.freeze(["\u30A2\u30EB\u30AB\u30A4\u30C3\u30AF", "fre", "archa\xEFque"]),
    Object.freeze(["\u30A2\u30EB\u30B3\u30FC\u30C9", "chi", "\xE8rgu\u014Dt\xF3u"]),
    Object.freeze(["\u30A2\u30EB\u30B4\u30B9", "gre", "\xC1rgos"]),
    Object.freeze(["\u30A2\u30EB\u30B8\u30A7", "fre", "Alger"]),
    Object.freeze(["\u30A2\u30EB\u30B9", "lat", "ars"]),
    Object.freeze(["\u30A2\u30EB\u30C6\u30DF\u30A2", "lat", "artemia"]),
    Object.freeze(["\u30A2\u30EB\u30D0\u30A4\u30BF\u30FC", "ger", "Arbeiter"]),
    Object.freeze(["\u30A2\u30EB\u30D0\u30A4\u30C8", "ger", "Arbeit"]),
    Object.freeze(["\u30A2\u30EB\u30DA\u30F3\u30B9\u30AD\u30FC", "ger", "Alpenski"]),
    Object.freeze(["\u30A2\u30EB\u30EB\u30AB\u30F3", "fre", "arlequin"]),
    Object.freeze(["\u30A2\u30EB\u30EC\u30C3\u30AD\u30FC\u30CE", "ita", "arlecchino"]),
    Object.freeze(["\u30A2\u30EC\u30EB\u30AE\u30FC", "ger", "Allergie"]),
    Object.freeze(["\u30A2\u30EC\u30F3\u30B8", "eng", "arrange"]),
    Object.freeze(["\u30A2\u30ED\u30A8", "dut", "alo\xEB"]),
    Object.freeze(["\u30A2\u30ED\u30B5", "lat", "Alosa"]),
    Object.freeze(["\u30A2\u30ED\u30BC", "fre", "arroser"]),
    Object.freeze(["\u30A2\u30ED\u30DE\u30C6\u30E9\u30D4\u30FC", "fre", "aromath\xE9rapie"]),
    Object.freeze(["\u30A2\u30F3\u30AB\u30F3", "chi", "\xE0ng\xE0ng"]),
    Object.freeze(["\u30A2\u30F3\u30AC\u30FC\u30B8\u30E5\u30DE\u30F3", "fre", "engagement"]),
    Object.freeze(["\u30A2\u30F3\u30AF\u30EB", "fre", "ancre"]),
    Object.freeze(["\u30A2\u30F3\u30B1\u30FC\u30C8", "fre", "enqu\xEAte"]),
    Object.freeze(["\u30A2\u30F3\u30B2\u30EA\u30A2", "lat", "Anglia"]),
    Object.freeze(["\u30A2\u30F3\u30B3", "chi", "\xE0n k\xE8"]),
    Object.freeze(["\u30A2\u30F3\u30B3\u30F3", "eng", "uncon(structed)"]),
    Object.freeze(["\u30A2\u30F3\u30B3\u30FC", "chi", "\xE0n k\xE8"]),
    Object.freeze(["\u30A2\u30F3\u30B3\u30FC\u30C4", "chi", "\xE0n k\xE8 zi"]),
    Object.freeze(["\u30A2\u30F3\u30B6\u30A4\u30EC\u30F3", "ger", "Anseilen"]),
    Object.freeze(["\u30A2\u30F3\u30B8\u30E3\u30D9\u30EB", "dut", "anjelier"]),
    Object.freeze(["\u30A2\u30F3\u30B8\u30E7", "por", "anjo"]),
    Object.freeze(["\u30A2\u30F3\u30C1\u30C6\u30A2\u30C8\u30EB", "fre", "anti-th\xE9\xE2tre"]),
    Object.freeze(["\u30A2\u30F3\u30C1\u30C6\u30FC\u30BC", "ger", "Antithese"]),
    Object.freeze(["\u30A2\u30F3\u30C1\u30CE\u30DF\u30FC", "ger", "Antinomie"]),
    Object.freeze(["\u30A2\u30F3\u30C1\u30E2\u30F3", "ger", "Antimon"]),
    Object.freeze(["\u30A2\u30F3\u30C7\u30D1\u30F3\u30C0\u30F3", "fre", "Ind\xE9pendants"]),
    Object.freeze(["\u30A2\u30F3\u30C8\u30ED\u30DD\u30ED\u30AE\u30FC", "ger", "Anthropologie"]),
    Object.freeze(["\u30A2\u30F3\u30C8\u30ED\u30DD\u30ED\u30B8\u30FC", "fre", "anthropologie"]),
    Object.freeze(["\u30A2\u30F3\u30C9\u30A5\u30C8\u30ED\u30EF", "fre", "un, deux, trois"]),
    Object.freeze(["\u30A2\u30F3\u30C9\u30A6\u30C8\u30E9\u30EF", "fre", "un, deux, trois"]),
    Object.freeze(["\u30A2\u30F3\u30CB\u30E7\u30F3", "kor", "annyeong"]),
    Object.freeze(["\u30A2\u30F3\u30CB\u30E7\u30F3\u30CF\u30B7\u30E0\u30CB\u30AB", "kor", "annyeong hashimnikka"]),
    Object.freeze(["\u30A2\u30F3\u30CB\u30E7\u30F3\u30CF\u30BB\u30E8", "kor", "annyeonghaseyo"]),
    Object.freeze(["\u30A2\u30F3\u30D5\u30A1\u30F3", "fre", "enfant"]),
    Object.freeze(["\u30A2\u30F3\u30D7\u30EC\u30B7\u30E7\u30CB\u30B9\u30E0", "fre", "impressionnisme"]),
    Object.freeze(["\u30A2\u30F3\u30D7\u30EC\u30C3\u30B7\u30E7\u30CB\u30B9\u30E0", "fre", "impressionnisme"]),
    Object.freeze(["\u30A2\u30F3\u30DA\u30E9", "may", "ampela"]),
    Object.freeze(["\u30A2\u30F3\u30E2\u30E9\u30EB", "eng", "unmoral"]),
    Object.freeze(["\u30A2\u30F3\u30FB\u30C9\u30A5\u30FB\u30C8\u30ED\u30EF", "fre", "un, deux, trois"]),
    Object.freeze(["\u30A2\u30F4\u30A1\u30F3", "fre", "avant"]),
    Object.freeze(["\u30A2\u30F4\u30A1\u30F3\u30B2\u30FC\u30EB", "fre", "avant-guerre"]),
    Object.freeze(["\u30A2\u30F4\u30A1\u30F3\u30C1\u30E5\u30FC\u30EB", "fre", "aventure"]),
    Object.freeze(["\u30A2\u30F4\u30A7\u30C3\u30AF", "fre", "avec"]),
    Object.freeze(["\u30A2\u30FB\u30E9\u30FB\u30E2\u30FC\u30C9", "fre", "\xE0 la mode"]),
    Object.freeze(["\u30A2\u30FC", "chi", "\xE8r"]),
    Object.freeze(["\u30A2\u30FC\u30AB\u30FC\u30B7\u30E3", "san", "\u0101k\u0101\u015Ba"]),
    Object.freeze(["\u30A2\u30FC\u30B1\u30A4\u30BA\u30E0", "fre", "archa\xEFsme"]),
    Object.freeze(["\u30A2\u30FC\u30C8\u30DE\u30F3", "san", "\u0101tman"]),
    Object.freeze(["\u30A2\u30FC\u30D9\u30F3\u30C8", "ger", "Abend"]),
    Object.freeze(["\u30A2\u30FC\u30DE\u30FC\u30C9\u30D7\u30EC\u30B3", "eng", "armored pleco"]),
    Object.freeze(["\u30A2\u30FC\u30DE\u30FC\u30C9\u30FB\u30D7\u30EC\u30B3", "eng", "armored pleco"]),
    Object.freeze(["\u30A2\u30FC\u30E2\u30F3\u30C9\u30D7\u30FC\u30C9\u30EB", "fre", "poudre"]),
    Object.freeze(["\u30A2\u30FC\u30E2\u30F3\u30C9\u30FB\u30D7\u30FC\u30C9\u30EB", "fre", "poudre"]),
    Object.freeze(["\u30A2\u30FC\u30EA\u30AA\u30AA\u30FC\u30EA\u30AA", "ita", "aglio olio"]),
    Object.freeze(["\u30A2\u30FC\u30EA\u30AA\u30FB\u30AA\u30FC\u30EA\u30AA", "ita", "aglio olio"]),
    Object.freeze(["\u30A2\u30FC\u30EB", "chi", "\xE8r"]),
    Object.freeze(["\u30A2\u30FC\u30EB\u30C7\u30B3", "fre", "art d\xE9co"]),
    Object.freeze(["\u30A2\u30FC\u30EB\u30FB\u30C7\u30B3", "fre", "art d\xE9co"]),
    Object.freeze(["\u30A2\u30FC\u30EC", "ger", "Ar"]),
    Object.freeze(["\u30A4\u30A4\u30B9\u30B9", "gre", "I\u0113so\xFBs"]),
    Object.freeze(["\u30A4\u30A7\u30CB\u30C1\u30A7\u30EA", "tur", "Yeni\xE7eri"]),
    Object.freeze(["\u30A4\u30A7\u30F3\u30C4\u30FC\u30E6\u30A4", "chi", "y\u0101nzhiy\xFA"]),
    Object.freeze(["\u30A4\u30A8\u30B9", "lat", "Iesus"]),
    Object.freeze(["\u30A4\u30A8\u30CB\u30C1\u30A7\u30EA", "tur", "Yeni\xE7eri"]),
    Object.freeze(["\u30A4\u30A8\u30ED\u30FC\u30AD\u30E3\u30D6", "eng", "yellow cab"]),
    Object.freeze(["\u30A4\u30A8\u30ED\u30FC\u30FB\u30AD\u30E3\u30D6", "eng", "yellow cab"]),
    Object.freeze(["\u30A4\u30A8\u30FC\u30B9\u30FC\u30B9", "lat", "Iesus"]),
    Object.freeze(["\u30A4\u30AA\u30F3", "ger", "Ion"]),
    Object.freeze(["\u30A4\u30AE\u30EA\u30B9", "por", "ingl\xEAs"]),
    Object.freeze(["\u30A4\u30AF\u30E9", "rus", "ikra"]),
    Object.freeze(["\u30A4\u30B1\u30FC\u30EB", "fre", "\xE9querre"]),
    Object.freeze(["\u30A4\u30B3\u30CE\u30AF\u30E9\u30B9\u30E0", "fre", "iconoclasme"]),
    Object.freeze(["\u30A4\u30B3\u30F3", "ger", "Ikon"]),
    Object.freeze(["\u30A4\u30B9", "por", "es(padas)"]),
    Object.freeze(["\u30A4\u30B9\u30D1\u30CB\u30A2", "spa", "Espa\xF1a"]),
    Object.freeze(["\u30A4\u30B9\u30D1\u30CE\u30A2\u30E1\u30EA\u30AB", "spa", "Hispanoam\xE9rica"]),
    Object.freeze(["\u30A4\u30B9\u30D1\u30FC\u30CB\u30E3", "spa", "Espa\xF1a"]),
    Object.freeze(["\u30A4\u30BD\u30ED\u30A4\u30B7\u30F3", "ger", "Isoleucin"]),
    Object.freeze(["\u30A4\u30BF\u30EA\u30A2", "ita", "Italia"]),
    Object.freeze(["\u30A4\u30BF\u30EA\u30E4", "ita", "Italia"]),
    Object.freeze(["\u30A4\u30C3\u30D2", "ger", "ich"]),
    Object.freeze(["\u30A4\u30C3\u30D2\u30ED\u30DE\u30F3", "ger", "Ich-Roman"]),
    Object.freeze(["\u30A4\u30C7\u30AA\u30ED\u30AE", "ger", "Ideologie"]),
    Object.freeze(["\u30A4\u30C7\u30AA\u30ED\u30AE\u30C3\u30B7\u30E5", "ger", "ideologisch"]),
    Object.freeze(["\u30A4\u30C7\u30AA\u30ED\u30AE\u30FC", "ger", "Ideologie"]),
    Object.freeze(["\u30A4\u30C7\u30AA\u30ED\u30FC\u30B0", "fre", "id\xE9ologue"]),
    Object.freeze(["\u30A4\u30C7\u30FC", "ger", "Idee"]),
    Object.freeze(["\u30A4\u30C9\u30E9", "lat", "idola"]),
    Object.freeze(["\u30A4\u30CC\u30EA\u30F3", "ger", "Inulin"]),
    Object.freeze(["\u30A4\u30CE\u30F3\u30C9", "spa", "eneldo"]),
    Object.freeze(["\u30A4\u30DA", "por", "ip\xEA"]),
    Object.freeze(["\u30A4\u30DA\u30EA\u30C3\u30C8", "fre", "yp\xE9rite"]),
    Object.freeze(["\u30A4\u30EB\u30DC\u30F3", "kor", "ilbon"]),
    Object.freeze(["\u30A4\u30EB\u30DE\u30F3", "por", "irm\xE3o"]),
    Object.freeze(["\u30A4\u30EB\u30DF\u30CD\u30FC\u30C8", "eng", "illuminate"]),
    Object.freeze(["\u30A4\u30F3\u30AD", "dut", "inkt"]),
    Object.freeze(["\u30A4\u30F3\u30B0\u30EA\u30C3\u30B7\u30E5\u30CD\u30FC\u30E0", "eng", "English name"]),
    Object.freeze(["\u30A4\u30F3\u30B0\u30EA\u30C3\u30B7\u30E5\u30FB\u30CD\u30FC\u30E0", "eng", "English name"]),
    Object.freeze(["\u30A4\u30F3\u30B9\u30BF\u30F3\u30C8\u30B3\u30B3\u30A2", "eng", "instant cocoa"]),
    Object.freeze(["\u30A4\u30F3\u30B9\u30BF\u30F3\u30C8\u30FB\u30B3\u30B3\u30A2", "eng", "instant cocoa"]),
    Object.freeze(["\u30A4\u30F3\u30BF\u30D5\u30A9\u30F3", "eng", "interphone"]),
    Object.freeze(["\u30A4\u30F3\u30BF\u30DB\u30F3", "eng", "interphone"]),
    Object.freeze(["\u30A4\u30F3\u30BF\u30DB\u30FC\u30F3", "eng", "interphone"]),
    Object.freeze(["\u30A4\u30F3\u30BF\u30FC\u30AB\u30EC\u30C3\u30B8", "eng", "intercollege"]),
    Object.freeze(["\u30A4\u30F3\u30BF\u30FC\u30CD\u30C3\u30C8\u30D7\u30ED\u30D0\u30A4\u30C0", "eng", "Internet provider"]),
    Object.freeze(["\u30A4\u30F3\u30BF\u30FC\u30CD\u30C3\u30C8\u30D7\u30ED\u30D0\u30A4\u30C0\u30FC", "eng", "Internet provider"]),
    Object.freeze(["\u30A4\u30F3\u30BF\u30FC\u30CD\u30C3\u30C8\u30FB\u30D7\u30ED\u30D0\u30A4\u30C0", "eng", "Internet provider"]),
    Object.freeze(["\u30A4\u30F3\u30BF\u30FC\u30CD\u30C3\u30C8\u30FB\u30D7\u30ED\u30D0\u30A4\u30C0\u30FC", "eng", "Internet provider"]),
    Object.freeze(["\u30A4\u30F3\u30BF\u30FC\u30D5\u30A9\u30F3", "eng", "interphone"]),
    Object.freeze(["\u30A4\u30F3\u30BF\u30FC\u30DB\u30F3", "eng", "interphone"]),
    Object.freeze(["\u30A4\u30F3\u30BF\u30FC\u30DB\u30FC\u30F3", "eng", "interphone"]),
    Object.freeze(["\u30A4\u30F3\u30C6\u30EA\u30B2\u30F3\u30C1\u30A2", "rus", "intelligentsiya"]),
    Object.freeze(["\u30A4\u30F3\u30C6\u30EA\u30B2\u30F3\u30C1\u30E3", "rus", "intelligentsiya"]),
    Object.freeze(["\u30A4\u30F3\u30C6\u30EA\u30B2\u30F3\u30C4\u30A3\u30A2", "rus", "intelligentsiya"]),
    Object.freeze(["\u30A4\u30F3\u30C6\u30EB", "eng", "inter(line)"]),
    Object.freeze(["\u30A4\u30F3\u30C7\u30A3\u30D8\u30CA", "spa", "ind\xEDgena"]),
    Object.freeze(["\u30A4\u30F3\u30C7\u30A3\u30FC\u30BA", "eng", "indies"]),
    Object.freeze(["\u30A4\u30F3\u30D7\u30EC\u30BE\u30F3\u30D3", "eng", "impre(ssion) zombie"]),
    Object.freeze(["\u30A4\u30F3\u30D9\u30EB\u30BF\u30FC\u30BC", "ger", "Invertase"]),
    Object.freeze(["\u30A4\u30F3\u30DD\u30C6\u30F3\u30B9", "ger", "Impotenz"]),
    Object.freeze(["\u30A4\u30F3\u30DD\u30C6\u30F3\u30C4", "ger", "Impotenz"]),
    Object.freeze(["\u30A4\u30FC", "chi", "y\u012B"]),
    Object.freeze(["\u30A4\u30FC\u30B7\u30E3\u30F3\u30C6\u30F3", "chi", "y\u012B xi\xE0ng t\u012Bng"]),
    Object.freeze(["\u30A4\u30FC\u30C1\u30E3\u30F3", "chi", "y\u012Bzhu\u0101ng"]),
    Object.freeze(["\u30A4\u30FC\u30DA\u30FC", "chi", "y\u012B b\u0113i"]),
    Object.freeze(["\u30A4\u30FC\u30DA\u30FC\u30B3\u30FC", "chi", "y\u012B b\u0113i k\u01D2u"]),
    Object.freeze(["\u30A6\u30A3", "fre", "oui"]),
    Object.freeze(["\u30A6\u30A3\u30F3\u30AB", "eng", "winker"]),
    Object.freeze(["\u30A6\u30A3\u30F3\u30AB\u30FC", "eng", "winker"]),
    Object.freeze(["\u30A6\u30A3\u30F3\u30AF\u30AD\u30E9\u30FC", "eng", "wink killer"]),
    Object.freeze(["\u30A6\u30A3\u30F3\u30AF\u30FB\u30AD\u30E9\u30FC", "eng", "wink killer"]),
    Object.freeze(["\u30A6\u30A3\u30F3\u30C9\u30E4\u30C3\u30B1", "ger", "Windjacke"]),
    Object.freeze(["\u30A6\u30A3\u30F3\u30CA", "ger", "Wiener"]),
    Object.freeze(["\u30A6\u30A3\u30F3\u30CA\u30FC", "ger", "Wiener"]),
    Object.freeze(["\u30A6\u30A3\u30FC\u30F3", "ger", "Wien"]),
    Object.freeze(["\u30A6\u30A4", "fre", "oui"]),
    Object.freeze(["\u30A6\u30A4\u30F3\u30AB", "eng", "winker"]),
    Object.freeze(["\u30A6\u30A4\u30F3\u30AB\u30FC", "eng", "winker"]),
    Object.freeze(["\u30A6\u30A4\u30F3\u30AF\u30AD\u30E9\u30FC", "eng", "wink killer"]),
    Object.freeze(["\u30A6\u30A4\u30F3\u30AF\u30FB\u30AD\u30E9\u30FC", "eng", "wink killer"]),
    Object.freeze(["\u30A6\u30A4\u30F3\u30C9\u30E4\u30C3\u30B1", "ger", "Windjacke"]),
    Object.freeze(["\u30A6\u30A4\u30F3\u30CA", "ger", "Wiener"]),
    Object.freeze(["\u30A6\u30A4\u30F3\u30CA\u30FC", "ger", "Wiener"]),
    Object.freeze(["\u30A6\u30A5\u30EB\u30AB\u30FC\u30CC\u30B9", "lat", "Vulcanus"]),
    Object.freeze(["\u30A6\u30A7\u30A4\u30C6\u30A3\u30F3\u30B0", "eng", "waiting"]),
    Object.freeze(["\u30A6\u30A7\u30B9", "eng", "waste"]),
    Object.freeze(["\u30A6\u30A7\u30B9\u30C8\u30DD\u30FC\u30C1", "eng", "waist pouch"]),
    Object.freeze(["\u30A6\u30A7\u30B9\u30C8\u30FB\u30DD\u30FC\u30C1", "eng", "waist pouch"]),
    Object.freeze(["\u30A6\u30A7\u30BB\u30AF", "kor", "waesaeg"]),
    Object.freeze(["\u30A6\u30A7\u30C3\u30B8\u30AB\u30C3\u30C8", "eng", "wedge cut"]),
    Object.freeze(["\u30A6\u30A7\u30C3\u30B8\u30FB\u30AB\u30C3\u30C8", "eng", "wedge cut"]),
    Object.freeze(["\u30A6\u30A7\u30C7\u30A3\u30F3\u30B0\u30B9\u30FC\u30C4", "eng", "wedding suit"]),
    Object.freeze(["\u30A6\u30A7\u30C7\u30A3\u30F3\u30B0\u30FB\u30B9\u30FC\u30C4", "eng", "wedding suit"]),
    Object.freeze(["\u30A6\u30A7\u30CF\u30FC\u30B9", "eng", "wafers"]),
    Object.freeze(["\u30A6\u30A7\u30D6\u30B7\u30E7\u30C3\u30D7", "eng", "web shop"]),
    Object.freeze(["\u30A6\u30A7\u30D6\u30B9\u30C8\u30A2", "eng", "web store"]),
    Object.freeze(["\u30A6\u30A7\u30D6\u30FB\u30B7\u30E7\u30C3\u30D7", "eng", "web shop"]),
    Object.freeze(["\u30A6\u30A7\u30D6\u30FB\u30B9\u30C8\u30A2", "eng", "web store"]),
    Object.freeze(["\u30A6\u30A7\u30FC\u30C6\u30A3\u30F3\u30B0", "eng", "waiting"]),
    Object.freeze(["\u30A6\u30A7\u30FC\u30C7\u30EB\u30F3", "ger", "Wedeln"]),
    Object.freeze(["\u30A6\u30A8\u30A4\u30C6\u30A3\u30F3\u30B0", "eng", "waiting"]),
    Object.freeze(["\u30A6\u30A8\u30B9", "eng", "waste"]),
    Object.freeze(["\u30A6\u30A8\u30B9\u30C8\u30DD\u30FC\u30C1", "eng", "waist pouch"]),
    Object.freeze(["\u30A6\u30A8\u30B9\u30C8\u30FB\u30DD\u30FC\u30C1", "eng", "waist pouch"]),
    Object.freeze(["\u30A6\u30A8\u30CF\u30FC\u30B9", "eng", "wafers"]),
    Object.freeze(["\u30A6\u30A8\u30D6\u30B7\u30E7\u30C3\u30D7", "eng", "web shop"]),
    Object.freeze(["\u30A6\u30A8\u30FC\u30C6\u30A3\u30F3\u30B0", "eng", "waiting"]),
    Object.freeze(["\u30A6\u30A8\u30FC\u30C7\u30EB\u30F3", "ger", "Wedeln"]),
    Object.freeze(["\u30A6\u30A9\u30EB\u30D5\u30E9\u30E0", "ger", "Wolfram"]),
    Object.freeze(["\u30A6\u30A9\u30FC\u30AD\u30F3\u30B0\u30DE\u30B7\u30F3", "eng", "walking machine"]),
    Object.freeze(["\u30A6\u30A9\u30FC\u30AD\u30F3\u30B0\u30DE\u30B7\u30FC\u30F3", "eng", "walking machine"]),
    Object.freeze(["\u30A6\u30A9\u30FC\u30AD\u30F3\u30B0\u30FB\u30DE\u30B7\u30F3", "eng", "walking machine"]),
    Object.freeze(["\u30A6\u30A9\u30FC\u30AD\u30F3\u30B0\u30FB\u30DE\u30B7\u30FC\u30F3", "eng", "walking machine"]),
    Object.freeze(["\u30A6\u30CB\u30B3\u30FC\u30EB", "por", "unicorne"]),
    Object.freeze(["\u30A6\u30CB\u30B3\u30FC\u30F3", "por", "unicorne"]),
    Object.freeze(["\u30A6\u30D0\u30FC\u30EC", "ger", "Uvale"]),
    Object.freeze(["\u30A6\u30D1\u30CB\u30B7\u30E3\u30C3\u30C9", "san", "Upanisad"]),
    Object.freeze(["\u30A6\u30E9\u30F3", "ger", "Uran"]),
    Object.freeze(["\u30A6\u30E9\u30FC", "rus", "ura"]),
    Object.freeze(["\u30A6\u30EA", "kor", "uli"]),
    Object.freeze(["\u30A6\u30EA\u30CA\u30E9", "kor", "uli nala"]),
    Object.freeze(["\u30A6\u30EA\u30CA\u30E9\u30DE\u30F3\u30BB\u30FC", "kor", "ulinala manse"]),
    Object.freeze(["\u30A6\u30EA\u30CF\u30C3\u30AD\u30E7", "kor", "uri hakgyo"]),
    Object.freeze(["\u30A6\u30EA\u30FB\u30CF\u30C3\u30AD\u30E7", "kor", "uri hakgyo"]),
    Object.freeze(["\u30A6\u30EB\u30AB\u30CC\u30B9", "lat", "Vulcanus"]),
    Object.freeze(["\u30A6\u30EB\u30AC\u30BF", "lat", "vulgata"]),
    Object.freeze(["\u30A6\u30EB\u30AC\u30FC\u30BF", "lat", "vulgata"]),
    Object.freeze(["\u30A6\u30EC\u30BF\u30F3", "ger", "Urethan"]),
    Object.freeze(["\u30A6\u30F3\u30B7\u30E3\u30F3", "ger", "unsch\xF6n"]),
    Object.freeze(["\u30A6\u30F3\u30D1\u30A4\u30ED\u30FC", "chi", "y\xFAn b\xE1i r\xF2u"]),
    Object.freeze(["\u30A6\u30F3\u30E0\u30F3", "kor", "eonmun"]),
    Object.freeze(["\u30A6\u30FC", "chi", "w\u01D4"]),
    Object.freeze(["\u30A6\u30FC\u30B7\u30E3\u30F3\u30D5\u30A7\u30F3", "chi", "w\u01D4xi\u0101ngf\u011Bn"]),
    Object.freeze(["\u30A6\u30FC\u30B7\u30E3\u30F3\u30D5\u30F3", "chi", "w\u01D4xi\u0101ngf\u011Bn"]),
    Object.freeze(["\u30A6\u30FC\u30ED\u30F3", "chi", "w\u016Bl\xF3ng"]),
    Object.freeze(["\u30A8\u30A4\u30C9\u30B9", "gre", "eidos"]),
    Object.freeze(["\u30A8\u30AA\u30A2\u30F3\u30C8\u30ED\u30D7\u30B9", "lat", "Eoanthropus"]),
    Object.freeze(["\u30A8\u30AF\u30E1\u30FC\u30CD", "gre", "Oekumene"]),
    Object.freeze(["\u30A8\u30AF\u30E9\u30F3", "fre", "\xE9cran"]),
    Object.freeze(["\u30A8\u30AF\u30EA\u30C1\u30E5\u30FC\u30EB", "fre", "\xE9criture"]),
    Object.freeze(["\u30A8\u30B0\u30B8\u30B9\u30BF\u30F3\u30B7\u30A2\u30EA\u30B9\u30E0", "fre", "existentialisme"]),
    Object.freeze(["\u30A8\u30B1\u30EC\u30B8\u30E4", "por", "ecclesia"]),
    Object.freeze(["\u30A8\u30B2\u30EC\u30B9", "dut", "Engelsch"]),
    Object.freeze(["\u30A8\u30B3\u30FC", "gre", "\u0112kh\u014D"]),
    Object.freeze(["\u30A8\u30B3\u30FC\u30EB", "fre", "\xE9cole"]),
    Object.freeze(["\u30A8\u30B4\u30C1\u30B9\u30E0", "fre", "\xE9gotisme"]),
    Object.freeze(["\u30A8\u30B4\u30C6\u30A3\u30B9\u30E0", "fre", "\xE9gotisme"]),
    Object.freeze(["\u30A8\u30B7\u30E3\u30ED\u30C3\u30C8", "fre", "\xE9chalote"]),
    Object.freeze(["\u30A8\u30B9", "lat", "Iesus"]),
    Object.freeze(["\u30A8\u30B9\u30AB\u30D9\u30FC\u30B7\u30E5", "fre", "escab\xE8che"]),
    Object.freeze(["\u30A8\u30B9\u30AB\u30EB\u30B4", "fre", "escargot"]),
    Object.freeze(["\u30A8\u30B9\u30AD\u30B9", "fre", "esquisse"]),
    Object.freeze(["\u30A8\u30B9\u30AD\u30FC\u30B9", "fre", "esquisse"]),
    Object.freeze(["\u30A8\u30B9\u30C6\u30B7\u30E3\u30F3", "fre", "esth\xE9ticien"]),
    Object.freeze(["\u30A8\u30B9\u30C6\u30C6\u30A3\u30AF", "fre", "esth\xE9tique"]),
    Object.freeze(["\u30A8\u30B9\u30C6\u30C6\u30A3\u30B7\u30E3\u30F3", "fre", "esth\xE9ticien"]),
    Object.freeze(["\u30A8\u30B9\u30C6\u30C6\u30A3\u30C3\u30AF", "fre", "esth\xE9tique"]),
    Object.freeze(["\u30A8\u30B9\u30C6\u30C6\u30A3\u30FC\u30AF", "fre", "esth\xE9tique"]),
    Object.freeze(["\u30A8\u30B9\u30C8\u30E9\u30B4\u30F3", "fre", "estragon"]),
    Object.freeze(["\u30A8\u30B9\u30D1\u30CB\u30A2", "spa", "Espa\xF1a"]),
    Object.freeze(["\u30A8\u30B9\u30D1\u30FC\u30CB\u30E3", "spa", "Espa\xF1a"]),
    Object.freeze(["\u30A8\u30B9\u30D7\u30E2\u30FC\u30BD", "spa", "espumoso"]),
    Object.freeze(["\u30A8\u30B9\u30D7\u30EA", "fre", "esprit"]),
    Object.freeze(["\u30A8\u30B9\u30DA\u30E9\u30F3\u30B5", "por", "esperan\xE7a"]),
    Object.freeze(["\u30A8\u30B9\u30DD\u30EF\u30FC\u30EB", "fre", "espoir"]),
    Object.freeze(["\u30A8\u30BF\u30CE\u30FC\u30EB", "ger", "\xC4thanol"]),
    Object.freeze(["\u30A8\u30BF\u30F3", "ger", "\xC4than"]),
    Object.freeze(["\u30A8\u30C1\u30B1\u30C3\u30C8", "fre", "\xE9tiquette"]),
    Object.freeze(["\u30A8\u30C1\u30E5\u30FC\u30C9", "fre", "\xE9tude"]),
    Object.freeze(["\u30A8\u30C1\u30EB", "ger", "\xC4thyl"]),
    Object.freeze(["\u30A8\u30C1\u30EB\u30A2\u30EB\u30B3\u30FC\u30EB", "ger", "\xC4thylalkohol"]),
    Object.freeze(["\u30A8\u30C1\u30EB\u30FB\u30A2\u30EB\u30B3\u30FC\u30EB", "ger", "\xC4thylalkohol"]),
    Object.freeze(["\u30A8\u30C3\u30AF\u30B9\u30B9\u30DD\u30FC\u30C4", "eng", "x sports"]),
    Object.freeze(["\u30A8\u30C3\u30BB\u30F3", "ger", "Essen"]),
    Object.freeze(["\u30A8\u30C8\u30E9\u30F3\u30BC", "fre", "\xE9tranger"]),
    Object.freeze(["\u30A8\u30C8\u30EF\u30B9", "ger", "etwas"]),
    Object.freeze(["\u30A8\u30C8\u30EF\u30FC\u30EB", "fre", "\xE9toile"]),
    Object.freeze(["\u30A8\u30CD\u30EB\u30AE", "ger", "Energie"]),
    Object.freeze(["\u30A8\u30CD\u30EB\u30AE\u30C3\u30B7\u30E5", "ger", "energisch"]),
    Object.freeze(["\u30A8\u30CD\u30EB\u30AE\u30FC", "ger", "Energie"]),
    Object.freeze(["\u30A8\u30D0\u30FC\u30BD\u30D5\u30C8", "eng", "Eversoft(TM)"]),
    Object.freeze(["\u30A8\u30D4\u30B4\u30FC\u30CD\u30F3", "ger", "Epigonen"]),
    Object.freeze(["\u30A8\u30DD\u30EC\u30C3\u30C8", "fre", "\xE9paulette"]),
    Object.freeze(["\u30A8\u30EA\u30A8\u30EA\u30EC\u30DE\u30B5\u30D0\u30AF\u30BF\u30CB", "gre", "\u0113li \u0113li lem\u0101 sabachthani"]),
    Object.freeze(["\u30A8\u30EA\u30C6\u30DE\u30C8\u30FC\u30C7\u30B9", "ger", "Erythematodes"]),
    Object.freeze(["\u30A8\u30EA\u30E5\u30B7\u30AA\u30F3", "gre", "\u0112lusion"]),
    Object.freeze(["\u30A8\u30EA\u30FB\u30A8\u30EA\u30FB\u30EC\u30DE\u30FB\u30B5\u30D0\u30AF\u30BF\u30CB", "gre", "\u0113li \u0113li lem\u0101 sabachthani"]),
    Object.freeze(["\u30A8\u30EA\u30FC\u30C8", "fre", "\xE9lite"]),
    Object.freeze(["\u30A8\u30EB\u30DF\u30F3", "fre", "hermine"]),
    Object.freeze(["\u30A8\u30EC\u30AD\u30C6\u30EB", "dut", "elektriciteit"]),
    Object.freeze(["\u30A8\u30EC\u30AF\u30C8", "eng", "erect"]),
    Object.freeze(["\u30A8\u30F3\u30B8\u30F3\u30D6\u30EC\u30FC\u30AD", "eng", "engine brake"]),
    Object.freeze(["\u30A8\u30F3\u30B8\u30F3\u30FB\u30D6\u30EC\u30FC\u30AD", "eng", "engine brake"]),
    Object.freeze(["\u30A8\u30F3\u30BF\u30A4\u30C8\u30EB", "eng", "entitle"]),
    Object.freeze(["\u30A8\u30F3\u30C1\u30FC\u30E0", "ger", "Enzym"]),
    Object.freeze(["\u30A8\u30F3\u30C6\u30EC\u30B1\u30A4\u30A2", "gre", "entelecheia"]),
    Object.freeze(["\u30A8\u30FC\u30B8\u30B7\u30E5\u30FC\u30C8", "eng", "age shoot"]),
    Object.freeze(["\u30A8\u30FC\u30B8\u30FB\u30B7\u30E5\u30FC\u30C8", "eng", "age shoot"]),
    Object.freeze(["\u30AA\u30A4\u30AD\u30E0\u30C1", "kor", "oi kimch'i"]),
    Object.freeze(["\u30AA\u30A4\u30BF\u30CA\u30B7\u30FC", "ger", "Euthanasie"]),
    Object.freeze(["\u30AA\u30A4\u30BF\u30CA\u30B8\u30FC", "ger", "Euthanasie"]),
    Object.freeze(["\u30AA\u30A4\u30EA\u30E5\u30C8\u30DF\u30FC", "ger", "Eurythmie"]),
    Object.freeze(["\u30AA\u30A6\u30EB", "por", "ouros"]),
    Object.freeze(["\u30AA\u30A6\u30ED", "por", "ouros"]),
    Object.freeze(["\u30AA\u30AD\u30B7\u30B2\u30CA\u30FC\u30BC", "ger", "Oxygenase"]),
    Object.freeze(["\u30AA\u30AD\u30B7\u30C9\u30FC\u30EB", "ger", "Oxydol"]),
    Object.freeze(["\u30AA\u30B9\u30C1\u30E4", "lat", "hostia"]),
    Object.freeze(["\u30AA\u30BF\u30EA\u30A2", "lat", "Otaria"]),
    Object.freeze(["\u30AA\u30C8\u30B7\u30F3\u30AF\u30EB\u30B9", "lat", "Otocinclus"]),
    Object.freeze(["\u30AA\u30CA\u30CB", "ger", "Onanie"]),
    Object.freeze(["\u30AA\u30CA\u30CB\u30FC", "ger", "Onanie"]),
    Object.freeze(["\u30AA\u30CD\u30C8\u30FC\u30E0", "fre", "honn\xEAte homme"]),
    Object.freeze(["\u30AA\u30CE\u30DE\u30C8\u30DA", "fre", "onomatop\xE9e"]),
    Object.freeze(["\u30AA\u30CE\u30DE\u30C8\u30DA\u30FC", "fre", "onomatop\xE9e"]),
    Object.freeze(["\u30AA\u30D5\u30E9\u30A4\u30F3\u30DF\u30FC\u30C6\u30A3\u30F3\u30B0", "eng", "offline meeting"]),
    Object.freeze(["\u30AA\u30D5\u30E9\u30A4\u30F3\u30FB\u30DF\u30FC\u30C6\u30A3\u30F3\u30B0", "eng", "offline meeting"]),
    Object.freeze(["\u30AA\u30D6\u30EA\u30AC\u30FC\u30C0", "por", "obrigada"]),
    Object.freeze(["\u30AA\u30D6\u30EA\u30AC\u30FC\u30C9", "por", "obrigado"]),
    Object.freeze(["\u30AA\u30D9\u30EA\u30B9\u30AF", "fre", "ob\xE9lisque"]),
    Object.freeze(["\u30AA\u30DE\u30FC\u30B8\u30E5", "fre", "hommage"]),
    Object.freeze(["\u30AA\u30DE\u30FC\u30EB", "fre", "homard"]),
    Object.freeze(["\u30AA\u30E0", "fre", "homme"]),
    Object.freeze(["\u30AA\u30E0\u30EC\u30C3\u30C8", "fre", "omelette"]),
    Object.freeze(["\u30AA\u30E2\u30CB", "kor", "eomeoni"]),
    Object.freeze(["\u30AA\u30E9\u30B7\u30E7", "lat", "oratio"]),
    Object.freeze(["\u30AA\u30E9\u30F3\u30C0", "por", "Holanda"]),
    Object.freeze(["\u30AA\u30EA\u30AC\u30EB\u30D2", "rus", "oligarkhi"]),
    Object.freeze(["\u30AA\u30EA\u30F3\u30D4\u30C3\u30AF", "eng", "Olympic"]),
    Object.freeze(["\u30AA\u30EB\u30AC\u30B9\u30E0\u30B9", "ger", "Orgasmus"]),
    Object.freeze(["\u30AA\u30EB\u30AC\u30CD\u30E9", "lat", "organella"]),
    Object.freeze(["\u30AA\u30EB\u30AC\u30F3", "por", "\xF3rg\xE3o"]),
    Object.freeze(["\u30AA\u30EB\u30B4\u30FC\u30EB", "dut", "orgel"]),
    Object.freeze(["\u30AA\u30EB\u30D5\u30E9\u30E0", "ger", "Wolfram"]),
    Object.freeze(["\u30AA\u30EB\u30E1\u30AB", "spa", "olmeca"]),
    Object.freeze(["\u30AA\u30F3\u30BF\u30FC\u30C7", "por", "vontade"]),
    Object.freeze(["\u30AA\u30F3\u30C8\u30ED\u30AE\u30FC", "ger", "Ontologie"]),
    Object.freeze(["\u30AA\u30F3\u30E2\u30F3", "kor", "eonmun"]),
    Object.freeze(["\u30AA\u30FC\u30A8\u30B9", "fre", "oh hisse"]),
    Object.freeze(["\u30AA\u30FC\u30AB\u30FC", "fre", "ocre"]),
    Object.freeze(["\u30AA\u30FC\u30AF\u30EB", "fre", "ocre"]),
    Object.freeze(["\u30AA\u30FC\u30B8\u30FC\u30D3\u30FC\u30D5", "eng", "Aussie beef"]),
    Object.freeze(["\u30AA\u30FC\u30B8\u30FC\u30FB\u30D3\u30FC\u30D5", "eng", "Aussie beef"]),
    Object.freeze(["\u30AA\u30FC\u30BF\u30E0\u30CA\u30EB", "eng", "autumnal"]),
    Object.freeze(["\u30AA\u30FC\u30C8\u30A8\u30A2\u30B3\u30F3", "eng", "auto air-con"]),
    Object.freeze(["\u30AA\u30FC\u30C8\u30DE\u30C1\u30B9\u30E0", "fre", "automatisme"]),
    Object.freeze(["\u30AA\u30FC\u30C8\u30DE\u30C6\u30A3\u30B9\u30E0", "fre", "automatisme"]),
    Object.freeze(["\u30AA\u30FC\u30C8\u30FB\u30A8\u30A2\u30B3\u30F3", "eng", "auto air-con"]),
    Object.freeze(["\u30AA\u30FC\u30C9\u30D3", "fre", "eau de vie"]),
    Object.freeze(["\u30AA\u30FC\u30C9\u30D6\u30EB", "fre", "hors-d'\u0153uvre"]),
    Object.freeze(["\u30AA\u30FC\u30C9\u30FC\u30D6\u30EB", "fre", "hors-d'\u0153uvre"]),
    Object.freeze(["\u30AA\u30FC\u30D0\u30FC\u30A2\u30AF\u30B7\u30E7\u30F3", "eng", "overaction"]),
    Object.freeze(["\u30AA\u30FC\u30D0\u30FC\u30E9\u30C3\u30D4\u30F3\u30B0", "eng", "overlapping"]),
    Object.freeze(["\u30AA\u30FC\u30D0\u30FC\u30FB\u30A2\u30AF\u30B7\u30E7\u30F3", "eng", "overaction"]),
    Object.freeze(["\u30AA\u30FC\u30D3\u30B9", "lat", "orbis"]),
    Object.freeze(["\u30AA\u30FC\u30D7\u30F3\u30B1\u30FC\u30B9", "eng", "open case"]),
    Object.freeze(["\u30AA\u30FC\u30D7\u30F3\u30D5\u30A1\u30FC\u30E0", "eng", "open farm"]),
    Object.freeze(["\u30AA\u30FC\u30D7\u30F3\u30FB\u30B1\u30FC\u30B9", "eng", "open case"]),
    Object.freeze(["\u30AA\u30FC\u30D7\u30F3\u30FB\u30D5\u30A1\u30FC\u30E0", "eng", "open farm"]),
    Object.freeze(["\u30AA\u30FC\u30EB\u30BB\u30FC\u30D5", "eng", "all safe"]),
    Object.freeze(["\u30AA\u30FC\u30EB\u30FB\u30BB\u30FC\u30D5", "eng", "all safe"]),
    Object.freeze(["\u30AB\u30A4\u30AB\u30A4\u30C7", "chi", "ku\xE0i ku\xE0i de"]),
    Object.freeze(["\u30AB\u30A4\u30AB\u30A4\u30C7\u30FC", "chi", "ku\xE0i ku\xE0i de"]),
    Object.freeze(["\u30AB\u30A4\u30B6\u30FC", "ger", "Kaiser"]),
    Object.freeze(["\u30AB\u30A4\u30BC\u30EB", "ger", "Kaiser"]),
    Object.freeze(["\u30AB\u30A4\u30C8\u30B0\u30E9\u30D5\u30A3\u30FC", "eng", "kiteography"]),
    Object.freeze(["\u30AB\u30A6\u30F3\u30BF\u30FC\u30C1\u30A7\u30A2", "eng", "counter chair"]),
    Object.freeze(["\u30AB\u30A6\u30F3\u30BF\u30FC\u30FB\u30C1\u30A7\u30A2", "eng", "counter chair"]),
    Object.freeze(["\u30AB\u30A6\u30F3\u30C8\u30A2\u30A6\u30C8", "eng", "count out"]),
    Object.freeze(["\u30AB\u30A6\u30F3\u30C8\u30FB\u30A2\u30A6\u30C8", "eng", "count out"]),
    Object.freeze(["\u30AB\u30AA\u30B9", "gre", "khaos"]),
    Object.freeze(["\u30AB\u30AA\u30DE\u30F3\u30AC\u30A4", "tha", "khao man kai"]),
    Object.freeze(["\u30AB\u30AA\u30E4\u30FC\u30C4", "chi", "k\u01CEoy\u0101"]),
    Object.freeze(["\u30AB\u30AA\u30EA\u30E3\u30F3", "chi", "g\u0101oliang"]),
    Object.freeze(["\u30AB\u30AB\u30AA", "spa", "cacao"]),
    Object.freeze(["\u30AB\u30AB\u30AA\u30DD\u30EA\u30D5\u30A7\u30CE\u30FC\u30EB", "eng", "cacao polyphenol"]),
    Object.freeze(["\u30AB\u30AB\u30AA\u30FB\u30DD\u30EA\u30D5\u30A7\u30CE\u30FC\u30EB", "eng", "cacao polyphenol"]),
    Object.freeze(["\u30AB\u30AF\u30C6\u30AD", "kor", "kkakdugi"]),
    Object.freeze(["\u30AB\u30B6\u30FC\u30AF", "rus", "kazak"]),
    Object.freeze(["\u30AB\u30B7\u30B9", "fre", "cassis"]),
    Object.freeze(["\u30AB\u30B7\u30E5\u30AF\u30FC\u30EB", "fre", "cache-c\u0153ur"]),
    Object.freeze(["\u30AB\u30B9\u30AF", "fre", "casque"]),
    Object.freeze(["\u30AB\u30B9\u30AF\u30FC\u30C8", "fre", "casse-cro\xFBte"]),
    Object.freeze(["\u30AB\u30B9\u30B1\u30C3\u30C8", "fre", "casquette"]),
    Object.freeze(["\u30AB\u30B9\u30C6\u30E9", "por", "p\xE3o de Castella"]),
    Object.freeze(["\u30AB\u30B9\u30C6\u30F3", "ger", "Kasten"]),
    Object.freeze(["\u30AB\u30B9\u30C6\u30FC\u30E9", "por", "p\xE3o de Castella"]),
    Object.freeze(["\u30AB\u30B9\u30C8", "por", "casta"]),
    Object.freeze(["\u30AB\u30BA\u30E9", "lat", "casula"]),
    Object.freeze(["\u30AB\u30BB\u30C9\u30E9\u30EB", "fre", "cath\xE9drale"]),
    Object.freeze(["\u30AB\u30BC\u30A4\u30F3", "ger", "Kasein"]),
    Object.freeze(["\u30AB\u30BF\u30B3\u30F3\u30D6", "fre", "catacombes"]),
    Object.freeze(["\u30AB\u30BF\u30C8\u30CB\u30FC", "ger", "Katatonie"]),
    Object.freeze(["\u30AB\u30BF\u30E9\u30FC\u30BC", "ger", "Katalase"]),
    Object.freeze(["\u30AB\u30BF\u30EB\u30B7\u30B9", "gre", "katharsis"]),
    Object.freeze(["\u30AB\u30BF\u30EB\u30CB\u30E3", "spa", "Catalu\xF1a"]),
    Object.freeze(["\u30AB\u30BF\u30EB\u30FC\u30CB\u30E3", "spa", "Catalu\xF1a"]),
    Object.freeze(["\u30AB\u30C1\u30E5\u30FC\u30B7\u30E3", "rus", "Katyusha"]),
    Object.freeze(["\u30AB\u30C3\u30C6\u30A3\u30F3\u30B0\u30B7\u30FC\u30C8", "eng", "cutting sheet"]),
    Object.freeze(["\u30AB\u30C3\u30C6\u30A3\u30F3\u30B0\u30FB\u30B7\u30FC\u30C8", "eng", "cutting sheet"]),
    Object.freeze(["\u30AB\u30C3\u30C8\u30D0\u30F3", "eng", "cut + ban(dage)"]),
    Object.freeze(["\u30AB\u30C3\u30D1", "por", "capa"]),
    Object.freeze(["\u30AB\u30C3\u30DA", "ger", "Kappe"]),
    Object.freeze(["\u30AB\u30C6\u30B4\u30EA", "ger", "Kategorie"]),
    Object.freeze(["\u30AB\u30C6\u30B4\u30EA\u30A3", "ger", "Kategorie"]),
    Object.freeze(["\u30AB\u30C6\u30B4\u30EA\u30FC", "ger", "Kategorie"]),
    Object.freeze(["\u30AB\u30C6\u30C9\u30E9\u30EB", "fre", "cath\xE9drale"]),
    Object.freeze(["\u30AB\u30C7\u30F3\u30C4", "ger", "Kadenz"]),
    Object.freeze(["\u30AB\u30C8\u30EA\u30C3\u30AF", "dut", "katholiek"]),
    Object.freeze(["\u30AB\u30C8\u30EB\u30AB\u30FC\u30EB", "fre", "quatre-quarts"]),
    Object.freeze(["\u30AB\u30C8\u30EB\u30FB\u30AB\u30FC\u30EB", "fre", "quatre-quarts"]),
    Object.freeze(["\u30AB\u30CA\u30AD\u30F3", "por", "canequim"]),
    Object.freeze(["\u30AB\u30CA\u30EA\u30A2", "spa", "canaria"]),
    Object.freeze(["\u30AB\u30CA\u30EA\u30E4", "spa", "canaria"]),
    Object.freeze(["\u30AB\u30CB\u30E5\u30FC\u30EC", "ger", "Kan\xFCle"]),
    Object.freeze(["\u30AB\u30CD\u30AD\u30F3", "por", "canequim"]),
    Object.freeze(["\u30AB\u30CE\u30C1\u30A8", "fre", "canotier"]),
    Object.freeze(["\u30AB\u30CE\u30C6\u30A3\u30A8", "fre", "canotier"]),
    Object.freeze(["\u30AB\u30CE\u30F3", "dut", "kanon"]),
    Object.freeze(["\u30AB\u30D0\u30D6", "tur", "kebap"]),
    Object.freeze(["\u30AB\u30D4\u30BF\u30F3", "por", "capit\xE3o"]),
    Object.freeze(["\u30AB\u30D5\u30A7\u30A2\u30E9\u30AF\u30EC\u30FC\u30E0", "fre", "caf\xE9 \xE0 la cr\xE8me"]),
    Object.freeze(["\u30AB\u30D5\u30A7\u30A4\u30F3", "ger", "Kaffein"]),
    Object.freeze(["\u30AB\u30D5\u30A7\u30A8\u30B9\u30D7\u30EC\u30C3\u30BD", "ita", "caff\xE8 espresso"]),
    Object.freeze(["\u30AB\u30D5\u30A7\u30CA\u30DD\u30EA\u30BF\u30FC\u30CE", "ita", "caffe napolitano"]),
    Object.freeze(["\u30AB\u30D5\u30A7\u30CE\u30EF\u30FC\u30EB", "fre", "caf\xE9 noir"]),
    Object.freeze(["\u30AB\u30D5\u30A7\u30FB\u30A2\u30FB\u30E9\u30FB\u30AF\u30EC\u30FC\u30E0", "fre", "caf\xE9 \xE0 la cr\xE8me"]),
    Object.freeze(["\u30AB\u30D5\u30A7\u30FB\u30A8\u30B9\u30D7\u30EC\u30C3\u30BD", "ita", "caff\xE8 espresso"]),
    Object.freeze(["\u30AB\u30D5\u30A7\u30FB\u30CA\u30DD\u30EA\u30BF\u30FC\u30CE", "ita", "caffe napolitano"]),
    Object.freeze(["\u30AB\u30D5\u30A7\u30FB\u30CE\u30EF\u30FC\u30EB", "fre", "caf\xE9 noir"]),
    Object.freeze(["\u30AB\u30D7\u30BB\u30EB", "ger", "Kapsel"]),
    Object.freeze(["\u30AB\u30DA\u30A4\u30AB", "rus", "kopeyka"]),
    Object.freeze(["\u30AB\u30DA\u30C3\u30EA\u30C0\u30F3\u30B8\u30A7\u30ED", "ita", "capelli d'angelo"]),
    Object.freeze(["\u30AB\u30DA\u30C3\u30EA\u30FB\u30C0\u30F3\u30B8\u30A7\u30ED", "ita", "capelli d'angelo"]),
    Object.freeze(["\u30AB\u30DC\u30C1\u30E3", "por", "Cambodia ab\xF3bora"]),
    Object.freeze(["\u30AB\u30DD", "ita", "capo(tasto)"]),
    Object.freeze(["\u30AB\u30DD\u30BF\u30B9\u30C8", "ita", "capotasto"]),
    Object.freeze(["\u30AB\u30DF\u30C4\u30EC", "dut", "kamille"]),
    Object.freeze(["\u30AB\u30DF\u30EB\u30EC", "dut", "kamille"]),
    Object.freeze(["\u30AB\u30DF\u30F3", "ger", "Kamin"]),
    Object.freeze(["\u30AB\u30E0\u30A2\u30A6\u30C8", "eng", "come out"]),
    Object.freeze(["\u30AB\u30E0\u30B5\u30CF\u30E0\u30CB\u30C0", "kor", "gamsahamnida"]),
    Object.freeze(["\u30AB\u30E0\u30EB\u30C1\u30A4", "kor", "kamultchi"]),
    Object.freeze(["\u30AB\u30E0\u30EB\u30C1\u30FC", "kor", "kamultchi"]),
    Object.freeze(["\u30AB\u30E0\u30EF\u30EB\u30C4", "ger", "Kammwalze"]),
    Object.freeze(["\u30AB\u30E0\u30FB\u30A2\u30A6\u30C8", "eng", "come out"]),
    Object.freeze(["\u30AB\u30E9\u30CA\u30DE\u30AF", "hin", "k\u0101l\u0101 namak"]),
    Object.freeze(["\u30AB\u30E9\u30CA\u30DE\u30C3\u30AF", "hin", "k\u0101l\u0101 namak"]),
    Object.freeze(["\u30AB\u30E9\u30D3\u30CA", "ger", "Karabiner"]),
    Object.freeze(["\u30AB\u30E9\u30F3", "dut", "kraan"]),
    Object.freeze(["\u30AB\u30EA", "dut", "kali"]),
    Object.freeze(["\u30AB\u30EA\u30A6\u30E0", "ger", "Kalium"]),
    Object.freeze(["\u30AB\u30EA\u30A8\u30B9", "ger", "Karies"]),
    Object.freeze(["\u30AB\u30EA\u30B9\u30DE", "ger", "Charisma"]),
    Object.freeze(["\u30AB\u30EA\u30C0\u30FC\u30C7", "por", "caridade"]),
    Object.freeze(["\u30AB\u30EB\u30B5\u30F3", "por", "cal\xE7\xE3o"]),
    Object.freeze(["\u30AB\u30EB\u30B9\u30C8", "ger", "Karst"]),
    Object.freeze(["\u30AB\u30EB\u30BD\u30F3", "fre", "cale\xE7on"]),
    Object.freeze(["\u30AB\u30EB\u30BF", "por", "carta"]),
    Object.freeze(["\u30AB\u30EB\u30C1\u30E7", "ita", "calcio"]),
    Object.freeze(["\u30AB\u30EB\u30C6", "ger", "Karte"]),
    Object.freeze(["\u30AB\u30EB\u30C6\u30C3\u30C8", "ita", "quartetto"]),
    Object.freeze(["\u30AB\u30EB\u30C6\u30EB", "ger", "Kartell"]),
    Object.freeze(["\u30AB\u30EB\u30C8\u30F3", "fre", "carton"]),
    Object.freeze(["\u30AB\u30EB\u30D1", "spa", "carpa"]),
    Object.freeze(["\u30AB\u30EB\u30DF\u30F3", "dut", "karmijn"]),
    Object.freeze(["\u30AB\u30EB\u30E1\u30E9", "por", "caramelo"]),
    Object.freeze(["\u30AB\u30EB\u30E1\u30EB", "por", "caramelo"]),
    Object.freeze(["\u30AB\u30EC\u30FC\u30B7\u30C1\u30E5\u30FC", "eng", "curry stew"]),
    Object.freeze(["\u30AB\u30EC\u30FC\u30FB\u30B7\u30C1\u30E5\u30FC", "eng", "curry stew"]),
    Object.freeze(["\u30AB\u30F3\u30AB\u30F3", "fre", "cancan"]),
    Object.freeze(["\u30AB\u30F3\u30BF\u30EA\u30B9", "lat", "cantharis"]),
    Object.freeze(["\u30AB\u30F3\u30C4", "chi", "g\xE0ng zi"]),
    Object.freeze(["\u30AB\u30F3\u30C6", "ger", "Kante"]),
    Object.freeze(["\u30AB\u30F3\u30C6\u30E9", "dut", "kandelaar"]),
    Object.freeze(["\u30AB\u30F3\u30C8\u30EA\u30FC\u30A8\u30EC\u30D9\u30FC\u30BF\u30FC", "eng", "country elevator"]),
    Object.freeze(["\u30AB\u30F3\u30C8\u30EA\u30FC\u30FB\u30A8\u30EC\u30D9\u30FC\u30BF\u30FC", "eng", "country elevator"]),
    Object.freeze(["\u30AB\u30F3\u30CB\u30F3\u30B0", "eng", "cunning"]),
    Object.freeze(["\u30AB\u30F3\u30D1\u30CB\u30A2", "rus", "kampanya"]),
    Object.freeze(["\u30AB\u30F3\u30D5\u30EB", "dut", "kamfer"]),
    Object.freeze(["\u30AB\u30F3\u30D5\u30FC", "chi", "g\u014Dngfu"]),
    Object.freeze(["\u30AB\u30FC\u30B5", "spa", "casa"]),
    Object.freeze(["\u30AB\u30FC\u30B9\u30C8", "por", "casta"]),
    Object.freeze(["\u30AB\u30FC\u30C9\u30EB", "fre", "cadre"]),
    Object.freeze(["\u30AB\u30FC\u30D6", "fre", "cave"]),
    Object.freeze(["\u30AB\u30FC\u30DF\u30F3", "dut", "karmijn"]),
    Object.freeze(["\u30AB\u30FC\u30EB", "ger", "Kar"]),
    Object.freeze(["\u30AB\u30FC\u30EC\u30FC\u30BF\u30FC", "eng", "car+(esca)lator"]),
    Object.freeze(["\u30AC\u30A4\u30B9\u30C8", "ger", "Geist"]),
    Object.freeze(["\u30AC\u30A4\u30E4\u30EB\u30C9", "fre", "gaillarde"]),
    Object.freeze(["\u30AC\u30B9\u30AC\u30F3", "eng", "gas gun"]),
    Object.freeze(["\u30AC\u30B9\u30C8\u30A2\u30EB\u30D0\u30A4\u30BF\u30FC", "ger", "Gastarbeiter"]),
    Object.freeze(["\u30AC\u30B9\u30D5\u30A1\u30F3\u30D2\u30FC\u30BF\u30FC", "eng", "gas fan heater"]),
    Object.freeze(["\u30AC\u30B9\u30DC\u30F3\u30D9", "ger", "Gasbombe"]),
    Object.freeze(["\u30AC\u30B9\u30FB\u30AC\u30F3", "eng", "gas gun"]),
    Object.freeze(["\u30AC\u30B9\u30FB\u30D5\u30A1\u30F3\u30FB\u30D2\u30FC\u30BF\u30FC", "eng", "gas fan heater"]),
    Object.freeze(["\u30AC\u30BD\u30EA\u30F3\u30AB\u30FC", "eng", "gasoline car"]),
    Object.freeze(["\u30AC\u30BD\u30EA\u30F3\u30FB\u30AB\u30FC", "eng", "gasoline car"]),
    Object.freeze(["\u30AC\u30C8\u30FC", "fre", "g\xE2teau"]),
    Object.freeze(["\u30AC\u30C8\u30FC\u30B7\u30E7\u30B3\u30E9", "fre", "g\xE2teau (au) chocolat"]),
    Object.freeze(["\u30AC\u30C8\u30FC\u30BB\u30C3\u30AF", "fre", "g\xE2teaux secs"]),
    Object.freeze(["\u30AC\u30C8\u30FC\u30FB\u30B7\u30E7\u30B3\u30E9", "fre", "g\xE2teau (au) chocolat"]),
    Object.freeze(["\u30AC\u30C8\u30FC\u30FB\u30BB\u30C3\u30AF", "fre", "g\xE2teaux secs"]),
    Object.freeze(["\u30AC\u30D3\u30A2\u30EB", "fre", "gavial"]),
    Object.freeze(["\u30AC\u30E9\u30B5", "por", "gra\xE7a"]),
    Object.freeze(["\u30AC\u30E9\u30B9", "dut", "glas"]),
    Object.freeze(["\u30AC\u30EA\u30A2", "lat", "Gallia"]),
    Object.freeze(["\u30AC\u30EA\u30F3\u30DA\u30A4\u30ED", "por", "garimpeiro"]),
    Object.freeze(["\u30AC\u30EB\u30BD\u30F3", "fre", "gar\xE7on"]),
    Object.freeze(["\u30AC\u30EB\u30BD\u30F3\u30CC", "fre", "gar\xE7onne"]),
    Object.freeze(["\u30AC\u30EB\u30D0\u30F3\u30BD", "spa", "garbanzo"]),
    Object.freeze(["\u30AC\u30EB\u30D0\u30F3\u30BE", "spa", "garbanzo"]),
    Object.freeze(["\u30AC\u30FC\u30BC", "ger", "Gaze"]),
    Object.freeze(["\u30AC\u30FC\u30C9", "eng", "girder"]),
    Object.freeze(["\u30AC\u30FC\u30EB\u30BA\u30C8\u30FC\u30AF", "eng", "girls' talk"]),
    Object.freeze(["\u30AC\u30FC\u30EB\u30BA\u30FB\u30C8\u30FC\u30AF", "eng", "girls' talk"]),
    Object.freeze(["\u30AD\u30A8\u30C6\u30A3\u30B9\u30E0", "fre", "qui\xE9tisme"]),
    Object.freeze(["\u30AD\u30AF\u30ED\u30D7\u30B9", "gre", "K\xFAkl\u014Dps"]),
    Object.freeze(["\u30AD\u30C3\u30AF\u30D9\u30FC\u30B9\u30DC\u30FC\u30EB", "eng", "kick baseball"]),
    Object.freeze(["\u30AD\u30C3\u30AF\u30FB\u30D9\u30FC\u30B9\u30DC\u30FC\u30EB", "eng", "kick baseball"]),
    Object.freeze(["\u30AD\u30C3\u30BA\u30B9\u30DA\u30FC\u30B9", "eng", "kids space"]),
    Object.freeze(["\u30AD\u30C3\u30BA\u30FB\u30B9\u30DA\u30FC\u30B9", "eng", "kids space"]),
    Object.freeze(["\u30AD\u30C3\u30C1\u30E5", "ger", "Kitsch"]),
    Object.freeze(["\u30AD\u30CA", "dut", "kina"]),
    Object.freeze(["\u30AD\u30CB\u30FC\u30CD", "dut", "kinine"]),
    Object.freeze(["\u30AD\u30CD\u30DE\u30C8\u30B0\u30E9\u30D5", "eng", "kinematograph"]),
    Object.freeze(["\u30AD\u30D7\u30ED\u30B9", "gre", "K\xFDpros"]),
    Object.freeze(["\u30AD\u30DE\u30A4\u30E9", "gre", "Khimaira"]),
    Object.freeze(["\u30AD\u30E3\u30B9\u30B1\u30C3\u30C8", "fre", "casquette"]),
    Object.freeze(["\u30AD\u30E3\u30C3\u30B7\u30F3\u30B0", "eng", "cashing"]),
    Object.freeze(["\u30AD\u30E3\u30C3\u30C1\u30E3\u30FC\u30DC\u30FC\u30C8", "eng", "catcher boat"]),
    Object.freeze(["\u30AD\u30E3\u30C3\u30C1\u30E3\u30FC\u30FB\u30DC\u30FC\u30C8", "eng", "catcher boat"]),
    Object.freeze(["\u30AD\u30E3\u30C3\u30D7", "eng", "cap(tain)"]),
    Object.freeze(["\u30AD\u30E3\u30CE\u30C1\u30A7", "fre", "canotier"]),
    Object.freeze(["\u30AD\u30E3\u30CE\u30C1\u30A8", "fre", "canotier"]),
    Object.freeze(["\u30AD\u30E3\u30D3\u30CD", "fre", "cabin\xE9"]),
    Object.freeze(["\u30AD\u30E3\u30E9\u30E1\u30EA\u30BC", "fre", "caram\xE9liser"]),
    Object.freeze(["\u30AD\u30E3\u30ED\u30C3\u30C8\u30E9\u30DA", "fre", "carrote r\xE2p\xE9e"]),
    Object.freeze(["\u30AD\u30E3\u30ED\u30C3\u30C8\u30FB\u30E9\u30DA", "fre", "carrote r\xE2p\xE9e"]),
    Object.freeze(["\u30AD\u30E3\u30F3\u30BB\u30EB", "eng", "cancel"]),
    Object.freeze(["\u30AD\u30E5\u30AF\u30ED\u30D7\u30B9", "gre", "K\xFAkl\u014Dps"]),
    Object.freeze(["\u30AD\u30E5\u30AF\u30ED\u30FC\u30D7\u30B9", "gre", "K\xFAkl\u014Dps"]),
    Object.freeze(["\u30AD\u30E5\u30D3\u30B9\u30C8", "fre", "Cubiste"]),
    Object.freeze(["\u30AD\u30E5\u30D3\u30B9\u30E0", "fre", "Cubisme"]),
    Object.freeze(["\u30AD\u30E5\u30D3\u30BA\u30E0", "fre", "Cubisme"]),
    Object.freeze(["\u30AD\u30E5\u30E9\u30BD\u30FC", "fre", "cura\xE7ao"]),
    Object.freeze(["\u30AD\u30E5\u30F3\u30E1\u30EB", "ger", "K\xFCmmel"]),
    Object.freeze(["\u30AD\u30E5\u30FC\u30D3\u30BA\u30E0", "fre", "Cubisme"]),
    Object.freeze(["\u30AD\u30E7\u30D5\u30C6", "tur", "k\xF6fte"]),
    Object.freeze(["\u30AD\u30E7\u30F3\u30B7\u30FC", "chi", "goeng-si"]),
    Object.freeze(["\u30AD\u30E9\u30FC\u30C1\u30E5\u30FC\u30F3", "eng", "killer tune"]),
    Object.freeze(["\u30AD\u30E9\u30FC\u30FB\u30C1\u30E5\u30FC\u30F3", "eng", "killer tune"]),
    Object.freeze(["\u30AD\u30EA\u30B7\u30BF\u30F3", "por", "crist\xE3o"]),
    Object.freeze(["\u30AD\u30EA\u30B7\u30BF\u30F3\u30D1\u30C6\u30EC\u30F3", "por", "cristao padre"]),
    Object.freeze(["\u30AD\u30EA\u30B7\u30BF\u30F3\u30FB\u30D1\u30C6\u30EC\u30F3", "por", "cristao padre"]),
    Object.freeze(["\u30AD\u30EA\u30B9\u30C8", "por", "Cristo"]),
    Object.freeze(["\u30AD\u30EB\u30AF", "dut", "kurk"]),
    Object.freeze(["\u30AD\u30EB\u30B7\u30E5", "ger", "Kirsch"]),
    Object.freeze(["\u30AD\u30EB\u30B7\u30E5\u30EF\u30C3\u30B5\u30FC", "ger", "Kirschwasser"]),
    Object.freeze(["\u30AD\u30EB\u30D3\u30E1\u30FC\u30BF\u30FC", "fre", "curvim\xE8tre"]),
    Object.freeze(["\u30AD\u30ED\u30E1\u30FC\u30BF\u30FC", "fre", "kilom\xE8tre"]),
    Object.freeze(["\u30AD\u30ED\u30E1\u30FC\u30C8\u30EB", "fre", "kilom\xE8tre"]),
    Object.freeze(["\u30AD\u30ED\u30FB\u30E1\u30FC\u30C8\u30EB", "fre", "kilom\xE8tre"]),
    Object.freeze(["\u30AD\u30F3\u30B5\u30A4", "chi", "q\xEDnc\xE0i"]),
    Object.freeze(["\u30AD\u30F3\u30C0\u30FC\u30AC\u30FC\u30C6\u30F3", "ger", "Kindergarten"]),
    Object.freeze(["\u30AD\u30F3\u30C0\u30FC\u30AC\u30FC\u30C7\u30F3", "ger", "Kindergarten"]),
    Object.freeze(["\u30AD\u30F3\u30C4\u30A1\u30A4", "chi", "q\xEDnc\xE0i"]),
    Object.freeze(["\u30AD\u30FC\u30B5\u30F3", "kor", "gisaeng"]),
    Object.freeze(["\u30AD\u30FC\u30BB\u30F3", "kor", "gisaeng"]),
    Object.freeze(["\u30AD\u30FC\u30C4\u30FC\u30EB", "eng", "key tool"]),
    Object.freeze(["\u30AD\u30FC\u30D1\u30FC\u30C1\u30E3\u30FC\u30B8", "eng", "keeper charge"]),
    Object.freeze(["\u30AD\u30FC\u30D1\u30FC\u30FB\u30C1\u30E3\u30FC\u30B8", "eng", "keeper charge"]),
    Object.freeze(["\u30AD\u30FC\u30D7\u30C7\u30A3\u30B9\u30BF\u30F3\u30B9", "eng", "keep distance"]),
    Object.freeze(["\u30AD\u30FC\u30D7\u30FB\u30C7\u30A3\u30B9\u30BF\u30F3\u30B9", "eng", "keep distance"]),
    Object.freeze(["\u30AD\u30FC\u30FB\u30C4\u30FC\u30EB", "eng", "key tool"]),
    Object.freeze(["\u30AE\u30AC\u30FC\u30B9", "gre", "gig\xE2s"]),
    Object.freeze(["\u30AE\u30CB\u30E7\u30EB", "fre", "guignol"]),
    Object.freeze(["\u30AE\u30CB\u30E7\u30FC\u30EB", "fre", "guignol"]),
    Object.freeze(["\u30AE\u30D6\u30B9", "ger", "Gips"]),
    Object.freeze(["\u30AE\u30D7\u30B9", "ger", "Gips"]),
    Object.freeze(["\u30AE\u30E2\u30FC\u30D6", "fre", "guimauve"]),
    Object.freeze(["\u30AE\u30E2\u30FC\u30F4", "fre", "guimauve"]),
    Object.freeze(["\u30AE\u30E3\u30EB", "eng", "gal"]),
    Object.freeze(["\u30AE\u30E3\u30EB\u30BD\u30F3", "fre", "gar\xE7on"]),
    Object.freeze(["\u30AE\u30E3\u30EB\u30BD\u30F3\u30CC", "fre", "gar\xE7onne"]),
    Object.freeze(["\u30AE\u30E4\u30DE\u30F3", "dut", "diamant"]),
    Object.freeze(["\u30AE\u30E7\u30A6\u30B6", "chi", "ji\u01CEozi"]),
    Object.freeze(["\u30AE\u30E7\u30FC\u30B6", "chi", "ji\u01CEozi"]),
    Object.freeze(["\u30AE\u30EA\u30B7\u30A2", "por", "Gr\xE9cia"]),
    Object.freeze(["\u30AE\u30EA\u30B7\u30E3", "por", "Gr\xE9cia"]),
    Object.freeze(["\u30AE\u30EA\u30B7\u30E4", "por", "Gr\xE9cia"]),
    Object.freeze(["\u30AF\u30A1\u30EB\u30C6\u30C3\u30C8", "ita", "quartetto"]),
    Object.freeze(["\u30AF\u30A2\u30C8\u30ED", "ita", "quatro"]),
    Object.freeze(["\u30AF\u30A2\u30CF\u30A6\u30B9", "ger", "Kurhaus"]),
    Object.freeze(["\u30AF\u30A3\u30A8\u30C6\u30A3\u30B9\u30E0", "fre", "qui\xE9tisme"]),
    Object.freeze(["\u30AF\u30A3\u30F3\u30C6\u30C3\u30C8", "ita", "quintetto"]),
    Object.freeze(["\u30AF\u30A4\u30C3\u30AF\u30B7\u30E5\u30FC", "eng", "quick shoe"]),
    Object.freeze(["\u30AF\u30A4\u30C3\u30AF\u30FB\u30B7\u30E5\u30FC", "eng", "quick shoe"]),
    Object.freeze(["\u30AF\u30A4\u30F3\u30C6\u30C3\u30C8", "ita", "quintetto"]),
    Object.freeze(["\u30AF\u30A6\u30CB\u30E3\u30F3", "chi", "g\u016Bniang"]),
    Object.freeze(["\u30AF\u30A9\u30FC\u30BF\u30D3\u30E5\u30FC", "eng", "quarter view"]),
    Object.freeze(["\u30AF\u30A9\u30FC\u30BF\u30FC\u30D3\u30E5\u30FC", "eng", "quarter view"]),
    Object.freeze(["\u30AF\u30A9\u30FC\u30BF\u30FC\u30FB\u30D3\u30E5\u30FC", "eng", "quarter view"]),
    Object.freeze(["\u30AF\u30AA\u30C3\u30AF\u30B0\u30FC", "vie", "qu\u1ED1c ng\u1EEF"]),
    Object.freeze(["\u30AF\u30AA\u30C3\u30AF\u30FB\u30B0\u30FC", "vie", "qu\u1ED1c ng\u1EEF"]),
    Object.freeze(["\u30AF\u30AA\u30FC\u30BF\u30D3\u30E5\u30FC", "eng", "quarter view"]),
    Object.freeze(["\u30AF\u30AA\u30FC\u30BF\u30FC\u30D3\u30E5\u30FC", "eng", "quarter view"]),
    Object.freeze(["\u30AF\u30AA\u30FC\u30BF\u30FC\u30FB\u30D3\u30E5\u30FC", "eng", "quarter view"]),
    Object.freeze(["\u30AF\u30B7\u30E3\u30C8\u30EA\u30E4", "san", "k\u1E63atriya"]),
    Object.freeze(["\u30AF\u30C1\u30AF\u30E9", "lat", "cuticula"]),
    Object.freeze(["\u30AF\u30C1\u30E5\u30EA\u30A8\u30FC\u30EB", "fre", "couturi\xE8re"]),
    Object.freeze(["\u30AF\u30C6\u30CE\u30DD\u30DE", "lat", "Ctenopoma"]),
    Object.freeze(["\u30AF\u30E9\u30A4\u30F3\u30AC\u30EB\u30C6\u30F3", "ger", "Kleingarten"]),
    Object.freeze(["\u30AF\u30E9\u30A6\u30C1\u30F3\u30B0\u30B9\u30BF\u30A4\u30EB", "eng", "crouching style"]),
    Object.freeze(["\u30AF\u30E9\u30A6\u30C1\u30F3\u30B0\u30B9\u30BF\u30FC\u30C8", "eng", "crouching start"]),
    Object.freeze(["\u30AF\u30E9\u30A6\u30C1\u30F3\u30B0\u30FB\u30B9\u30BF\u30A4\u30EB", "eng", "crouching style"]),
    Object.freeze(["\u30AF\u30E9\u30A6\u30C1\u30F3\u30B0\u30FB\u30B9\u30BF\u30FC\u30C8", "eng", "crouching start"]),
    Object.freeze(["\u30AF\u30E9\u30D0\u30C3\u30C8", "fre", "cravate"]),
    Object.freeze(["\u30AF\u30E9\u30D3\u30C1\u30A7\u30F3\u30D0\u30ED", "ita", "clavicembalo"]),
    Object.freeze(["\u30AF\u30E9\u30D6\u30B5\u30F3", "fre", "clavecin"]),
    Object.freeze(["\u30AF\u30E9\u30F3\u30B1", "ger", "Kranke"]),
    Object.freeze(["\u30AF\u30E9\u30F4\u30A1\u30C3\u30C8", "fre", "cravate"]),
    Object.freeze(["\u30AF\u30E9\u30F4\u30A3\u30C1\u30A7\u30F3\u30D0\u30ED", "ita", "clavicembalo"]),
    Object.freeze(["\u30AF\u30E9\u30F4\u30B5\u30F3", "fre", "clavecin"]),
    Object.freeze(["\u30AF\u30EA\u30B9\u30C1\u30E3\u30CB\u30A2", "ger", "Kristiania"]),
    Object.freeze(["\u30AF\u30EA\u30B9\u30C8", "por", "Cristo"]),
    Object.freeze(["\u30AF\u30EA\u30EB\u30BF\u30A4", "mon", "khuruldai"]),
    Object.freeze(["\u30AF\u30EA\u30FC", "chi", "k\u01D4l\xEC"]),
    Object.freeze(["\u30AF\u30EA\u30FC\u30AF", "eng", "cleek"]),
    Object.freeze(["\u30AF\u30EB\u30B9", "por", "cruz"]),
    Object.freeze(["\u30AF\u30EB\u30C3\u30D7", "ger", "Krupp"]),
    Object.freeze(["\u30AF\u30EB\u30E0\u30DB\u30EB\u30F3", "ger", "Krummhorn"]),
    Object.freeze(["\u30AF\u30EB\u30F3\u30C6\u30D7", "tha", "Krung Thep"]),
    Object.freeze(["\u30AF\u30EB\u30F3\u30C6\u30FC\u30D7", "tha", "Krung Thep"]),
    Object.freeze(["\u30AF\u30EB\u30F3\u30FB\u30C6\u30FC\u30D7", "tha", "Krung Thep"]),
    Object.freeze(["\u30AF\u30EC\u30A2\u30C8\u30A5\u30FC\u30EB", "fre", "cr\xE9ateur"]),
    Object.freeze(["\u30AF\u30EC\u30AA\u30FC\u30EB", "fre", "cr\xE9ole"]),
    Object.freeze(["\u30AF\u30EC\u30BD\u30F3", "fre", "cresson"]),
    Object.freeze(["\u30AF\u30EC\u30BE\u30FC\u30EB", "ger", "Kresol"]),
    Object.freeze(["\u30AF\u30EC\u30C3\u30B7\u30E5", "fre", "cr\xE8che"]),
    Object.freeze(["\u30AF\u30EC\u30F3\u30E1", "ger", "Klemme"]),
    Object.freeze(["\u30AF\u30ED\u30B9\u30D0\u30A4\u30AF", "eng", "cross bike"]),
    Object.freeze(["\u30AF\u30ED\u30B9\u30FB\u30D0\u30A4\u30AF", "eng", "cross bike"]),
    Object.freeze(["\u30AF\u30ED\u30C3\u30AD\u30FC", "fre", "croquis"]),
    Object.freeze(["\u30AF\u30ED\u30EB", "ger", "Chlor"]),
    Object.freeze(["\u30AF\u30ED\u30FC\u30EB", "ger", "Chlor"]),
    Object.freeze(["\u30AF\u30ED\u30FC\u30EB\u30AB\u30EB\u30AD", "ger", "Chlorkalk"]),
    Object.freeze(["\u30AF\u30EF\u30B9", "rus", "kvas"]),
    Object.freeze(["\u30AF\u30EF\u30C8\u30ED", "ita", "quatro"]),
    Object.freeze(["\u30AF\u30EF\u30EB\u30C6\u30C3\u30C8", "ita", "quartetto"]),
    Object.freeze(["\u30AF\u30F3\u30B9\u30C8", "ger", "Kunst"]),
    Object.freeze(["\u30AF\u30F3\u30D5\u30FC", "chi", "g\u014Dngfu"]),
    Object.freeze(["\u30AF\u30FC\u30CB\u30E3\u30F3", "chi", "g\u016Bniang"]),
    Object.freeze(["\u30AF\u30FC\u30CF\u30F3", "fre", "couffin"]),
    Object.freeze(["\u30AF\u30FC\u30D5\u30A1\u30F3", "fre", "couffin"]),
    Object.freeze(["\u30AF\u30FC\u30D8\u30F3", "ger", "Kuchen"]),
    Object.freeze(["\u30AF\u30FC\u30EA\u30FC", "chi", "k\u01D4l\xEC"]),
    Object.freeze(["\u30B0\u30E4\u30FC\u30B7\u30E5", "hun", "guly\xE1s"]),
    Object.freeze(["\u30B0\u30E9\u30B7", "fre", "glacis"]),
    Object.freeze(["\u30B0\u30E9\u30B7\u30A2\u30B9", "spa", "gracias"]),
    Object.freeze(["\u30B0\u30E9\u30B9\u30CE\u30B9\u30C1", "rus", "glasnost'"]),
    Object.freeze(["\u30B0\u30E9\u30B9\u30D5\u30A1\u30A4\u30D0\u30FC\u30DD\u30FC\u30EB", "eng", "glass fiber pole"]),
    Object.freeze(["\u30B0\u30E9\u30B9\u30FB\u30D5\u30A1\u30A4\u30D0\u30FC\u30FB\u30DD\u30FC\u30EB", "eng", "glass fiber pole"]),
    Object.freeze(["\u30B0\u30E9\u30C1\u30A7", "ita", "grazie"]),
    Object.freeze(["\u30B0\u30E9\u30C1\u30A8", "ita", "grazie"]),
    Object.freeze(["\u30B0\u30E9\u30C3\u30B7", "fre", "glacis"]),
    Object.freeze(["\u30B0\u30E9\u30C3\u30C1\u30A7", "ita", "grazie"]),
    Object.freeze(["\u30B0\u30E9\u30C3\u30C4\u30A3\u30A8", "ita", "grazie"]),
    Object.freeze(["\u30B0\u30E9\u30C3\u30C4\u30A7", "ita", "grazie"]),
    Object.freeze(["\u30B0\u30E9\u30C3\u30C4\u30A8", "ita", "grazie"]),
    Object.freeze(["\u30B0\u30E9\u30C4\u30A3\u30A8", "ita", "grazie"]),
    Object.freeze(["\u30B0\u30E9\u30D5\u30A3\u30C3\u30AF\u30DC\u30FC\u30C9", "eng", "graphic board"]),
    Object.freeze(["\u30B0\u30E9\u30D5\u30A3\u30C3\u30AF\u30FB\u30DC\u30FC\u30C9", "eng", "graphic board"]),
    Object.freeze(["\u30B0\u30E9\u30F3", "fre", "grand"]),
    Object.freeze(["\u30B0\u30E9\u30F3\u30C7", "ita", "grande"]),
    Object.freeze(["\u30B0\u30E9\u30FC\u30C4\u30A3\u30A8", "ita", "grazie"]),
    Object.freeze(["\u30B0\u30E9\u30FC\u30C8", "ger", "Grat"]),
    Object.freeze(["\u30B0\u30EA\u30A8", "fre", "grill\xE9"]),
    Object.freeze(["\u30B0\u30EA\u30D6\u30CA", "rus", "gr\xEDvna"]),
    Object.freeze(["\u30B0\u30EA\u30E5\u30FC\u30D0\u30A4\u30F3", "ger", "Gl\xFChwein"]),
    Object.freeze(["\u30B0\u30EA\u30E5\u30FC\u30EF\u30A4\u30F3", "ger", "Gl\xFChwein"]),
    Object.freeze(["\u30B0\u30EA\u30E5\u30FC\u30F4\u30A1\u30A4\u30F3", "ger", "Gl\xFChwein"]),
    Object.freeze(["\u30B0\u30EA\u30F4\u30CA", "rus", "gr\xEDvna"]),
    Object.freeze(["\u30B0\u30EB\u30B8\u30A2", "rus", "Gruziya"]),
    Object.freeze(["\u30B0\u30EB\u30C6\u30F3", "ger", "Gluten"]),
    Object.freeze(["\u30B0\u30EB\u30CB\u30A8", "fre", "grenier"]),
    Object.freeze(["\u30B0\u30EB\u30E1", "fre", "gourmet"]),
    Object.freeze(["\u30B0\u30ED\u30B0\u30E9\u30F3", "fre", "gros-grain"]),
    Object.freeze(["\u30B0\u30ED\u30C3\u30B1", "ger", "Glocke"]),
    Object.freeze(["\u30B0\u30ED\u30FC\u30AB\u30EB", "eng", "global + local"]),
    Object.freeze(["\u30B0\u30FC", "eng", "good"]),
    Object.freeze(["\u30B0\u30FC\u30C6\u30F3\u30BF\u30FC\u30AF", "ger", "Guten Tag"]),
    Object.freeze(["\u30B0\u30FC\u30C6\u30F3\u30E2\u30EB\u30B2\u30F3", "ger", "Guten Morgen"]),
    Object.freeze(["\u30B0\u30FC\u30C6\u30F3\u30FB\u30BF\u30FC\u30AF", "ger", "Guten Tag"]),
    Object.freeze(["\u30B0\u30FC\u30C6\u30F3\u30FB\u30E2\u30EB\u30B2\u30F3", "ger", "Guten Morgen"]),
    Object.freeze(["\u30B1\u30A4\u30B7\u30E3\u30FC\u30C0", "por", "queixada"]),
    Object.freeze(["\u30B1\u30D0\u30D6", "tur", "kebap"]),
    Object.freeze(["\u30B1\u30D5\u30A1\u30EA\u30F3", "ger", "Kephalin"]),
    Object.freeze(["\u30B1\u30D9\u30C3\u30AF", "fre", "Qu\xE9bec"]),
    Object.freeze(["\u30B1\u30DF", "kor", "kemi"]),
    Object.freeze(["\u30B1\u30E9\u30C1\u30F3", "ger", "Keratin"]),
    Object.freeze(["\u30B1\u30EA\u30E5\u30B0\u30DE", "gre", "k\u0113rygma"]),
    Object.freeze(["\u30B1\u30EB\u30D9\u30ED\u30B9", "gre", "Kerberos"]),
    Object.freeze(["\u30B1\u30EB\u30F3", "ger", "K\xF6ln"]),
    Object.freeze(["\u30B1\u30F3\u30BF\u30A6\u30EB", "gre", "Kentauros"]),
    Object.freeze(["\u30B1\u30F3\u30BF\u30A6\u30EB\u30B9", "gre", "Kentauros"]),
    Object.freeze(["\u30B1\u30F3\u30BF\u30A6\u30ED\u30B9", "gre", "Kentauros"]),
    Object.freeze(["\u30B2\u30AA\u30DD\u30EA\u30C6\u30A3\u30FC\u30AF", "ger", "Geopolitik"]),
    Object.freeze(["\u30B2\u30B9\u30C8\u30DC\u30FC\u30AB\u30EB", "eng", "guest vocal"]),
    Object.freeze(["\u30B2\u30B9\u30C8\u30F4\u30A9\u30FC\u30AB\u30EB", "eng", "guest vocal"]),
    Object.freeze(["\u30B2\u30B9\u30C8\u30FB\u30DC\u30FC\u30AB\u30EB", "eng", "guest vocal"]),
    Object.freeze(["\u30B2\u30B9\u30C8\u30FB\u30F4\u30A9\u30FC\u30AB\u30EB", "eng", "guest vocal"]),
    Object.freeze(["\u30B2\u30C3\u30C8\u30A2\u30A6\u30C8", "eng", "get out"]),
    Object.freeze(["\u30B2\u30C3\u30C8\u30FB\u30A2\u30A6\u30C8", "eng", "get out"]),
    Object.freeze(["\u30B2\u30CD\u30D7\u30ED", "ger", "Generalprobe"]),
    Object.freeze(["\u30B2\u30CE\u30E0", "ger", "Genom"]),
    Object.freeze(["\u30B2\u30D0\u30EB\u30C8", "ger", "Gewalt"]),
    Object.freeze(["\u30B2\u30E9\u30F3\u30C7", "ger", "Gel\xE4nde"]),
    Object.freeze(["\u30B2\u30EB\u30C8", "ger", "Geld"]),
    Object.freeze(["\u30B2\u30EB\u30DE\u30F3", "ger", "Germane"]),
    Object.freeze(["\u30B2\u30EC\u30F3\u30C7", "ger", "Gel\xE4nde"]),
    Object.freeze(["\u30B2\u30EC\u30F3\u30C7\u30B7\u30E5\u30D7\u30EB\u30F3\u30B0", "ger", "Gel\xE4ndesprung"]),
    Object.freeze(["\u30B2\u30F3", "ger", "Gen"]),
    Object.freeze(["\u30B2\u30F3\u30C1\u30A2\u30CA", "lat", "gentiana"]),
    Object.freeze(["\u30B2\u30FC\u30C8\u30EB", "fre", "gu\xEAtre"]),
    Object.freeze(["\u30B2\u30FC\u30E0\u30A8\u30DF\u30E5\u30EC\u30FC\u30BF", "eng", "game emulator"]),
    Object.freeze(["\u30B2\u30FC\u30E0\u30A8\u30DF\u30E5\u30EC\u30FC\u30BF\u30FC", "eng", "game emulator"]),
    Object.freeze(["\u30B2\u30FC\u30E0\u30B7\u30B9\u30C6\u30E0", "eng", "game system"]),
    Object.freeze(["\u30B2\u30FC\u30E0\u30D7\u30E9\u30F3\u30CA\u30FC", "eng", "game planner"]),
    Object.freeze(["\u30B2\u30FC\u30E0\u30E1\u30A4\u30AB\u30FC", "eng", "game maker"]),
    Object.freeze(["\u30B2\u30FC\u30E0\u30E1\u30FC\u30AB", "eng", "game maker"]),
    Object.freeze(["\u30B2\u30FC\u30E0\u30E1\u30FC\u30AB\u30FC", "eng", "game maker"]),
    Object.freeze(["\u30B2\u30FC\u30E0\u30FB\u30A8\u30DF\u30E5\u30EC\u30FC\u30BF", "eng", "game emulator"]),
    Object.freeze(["\u30B2\u30FC\u30E0\u30FB\u30A8\u30DF\u30E5\u30EC\u30FC\u30BF\u30FC", "eng", "game emulator"]),
    Object.freeze(["\u30B2\u30FC\u30E0\u30FB\u30B7\u30B9\u30C6\u30E0", "eng", "game system"]),
    Object.freeze(["\u30B2\u30FC\u30E0\u30FB\u30D7\u30E9\u30F3\u30CA\u30FC", "eng", "game planner"]),
    Object.freeze(["\u30B2\u30FC\u30E0\u30FB\u30E1\u30FC\u30AB\u30FC", "eng", "game maker"]),
    Object.freeze(["\u30B3\u30A2\u30F3\u30C1\u30E7\u30A6", "chi", "Gu\u01CEngzh\u014Du"]),
    Object.freeze(["\u30B3\u30A8\u30F3\u30C9\u30ED", "por", "coentro"]),
    Object.freeze(["\u30B3\u30AD\u30E5", "fre", "cocu"]),
    Object.freeze(["\u30B3\u30AD\u30E5\u30FC", "fre", "cocu"]),
    Object.freeze(["\u30B3\u30AD\u30FC\u30E6", "fre", "coquille"]),
    Object.freeze(["\u30B3\u30AD\u30FC\u30EB", "fre", "coquille"]),
    Object.freeze(["\u30B3\u30AF\u30B9", "ger", "Koks"]),
    Object.freeze(["\u30B3\u30B1\u30C3\u30C8\u30EA\u30FC", "fre", "coquetterie"]),
    Object.freeze(["\u30B3\u30B3\u30EC\u30C3\u30C1", "tur", "kokore\xE7"]),
    Object.freeze(["\u30B3\u30B9\u30E1\u30D5\u30EA\u30FC\u30AF", "eng", "cosme(tics) freak"]),
    Object.freeze(["\u30B3\u30B9\u30E1\u30FB\u30D5\u30EA\u30FC\u30AF", "eng", "cosme(tics) freak"]),
    Object.freeze(["\u30B3\u30B9\u30E2\u30CE\u30FC\u30C8", "rus", "kosmonavt"]),
    Object.freeze(["\u30B3\u30C3\u30AF", "dut", "kok"]),
    Object.freeze(["\u30B3\u30C3\u30C1\u30E7\u30EA", "kor", "geotjeori"]),
    Object.freeze(["\u30B3\u30C3\u30D2\u30A7\u30EB", "ger", "Kocher"]),
    Object.freeze(["\u30B3\u30C3\u30D5\u30A7\u30EB", "ger", "Kocher"]),
    Object.freeze(["\u30B3\u30C3\u30D7\u30F3\u30AB\u30FC", "tha", "khob khun ka"]),
    Object.freeze(["\u30B3\u30C3\u30D8\u30EB", "ger", "Kocher"]),
    Object.freeze(["\u30B3\u30C8\u30EC\u30C3\u30C8", "fre", "c\xF4telette"]),
    Object.freeze(["\u30B3\u30CA\u30DF\u30B3\u30DE\u30F3\u30C9", "eng", "Konami command"]),
    Object.freeze(["\u30B3\u30CA\u30DF\u30FB\u30B3\u30DE\u30F3\u30C9", "eng", "Konami command"]),
    Object.freeze(["\u30B3\u30CB\u30FC\u30C7", "ger", "Konide"]),
    Object.freeze(["\u30B3\u30D0\u30B9\u30C6\u30C3\u30C1", "eng", "cover stitch"]),
    Object.freeze(["\u30B3\u30D2\u30B5\u30F3", "por", "confiss\xE3o"]),
    Object.freeze(["\u30B3\u30D2\u30FC\u30EC\u30F3\u30B7", "eng", "coherency"]),
    Object.freeze(["\u30B3\u30D2\u30FC\u30EC\u30F3\u30B7\u30FC", "eng", "coherency"]),
    Object.freeze(["\u30B3\u30D4\u30FC\u30AC\u30FC\u30C9", "eng", "copy guard"]),
    Object.freeze(["\u30B3\u30D4\u30FC\u30FB\u30AC\u30FC\u30C9", "eng", "copy guard"]),
    Object.freeze(["\u30B3\u30D5\u30C6", "tur", "k\xF6fte"]),
    Object.freeze(["\u30B3\u30D5\u30EC", "fre", "coffret"]),
    Object.freeze(["\u30B3\u30D7\u30C1\u30E3\u30F3", "kor", "gobchang"]),
    Object.freeze(["\u30B3\u30DA\u30A4\u30AB", "rus", "kopeyka"]),
    Object.freeze(["\u30B3\u30DA\u30E9", "lat", "Copella"]),
    Object.freeze(["\u30B3\u30DA\u30EB\u30C8", "ita", "cop\xE8rto"]),
    Object.freeze(["\u30B3\u30DC\u30EB\u30C8", "ger", "Kobolt"]),
    Object.freeze(["\u30B3\u30DC\u30EB\u30C9", "ger", "Kobolt"]),
    Object.freeze(["\u30B3\u30DE\u30F3\u30BF\u30EC\u30D6\u30FC", "fre", "comment allez-vous?"]),
    Object.freeze(["\u30B3\u30DE\u30FC\u30B7\u30E3\u30EB\u30A2\u30C3\u30C8", "eng", "commercial at"]),
    Object.freeze(["\u30B3\u30DE\u30FC\u30B7\u30E3\u30EB\u30FB\u30A2\u30C3\u30C8", "eng", "commercial at"]),
    Object.freeze(["\u30B3\u30DF\u30B5\u30EA\u30FC", "eng", "commissary"]),
    Object.freeze(["\u30B3\u30DF\u30F3\u30C6\u30EB\u30F3", "rus", "Komintern"]),
    Object.freeze(["\u30B3\u30E9\u30FC\u30B2\u30F3", "ger", "Kollagen"]),
    Object.freeze(["\u30B3\u30EA\u30A2\u30F3\u30BF\u30A6\u30F3", "eng", "Korean town"]),
    Object.freeze(["\u30B3\u30EA\u30A2\u30F3\u30FB\u30BF\u30A6\u30F3", "eng", "Korean town"]),
    Object.freeze(["\u30B3\u30EB\u30AF", "dut", "kurk"]),
    Object.freeze(["\u30B3\u30EB\u30CD", "fre", "cornet"]),
    Object.freeze(["\u30B3\u30EB\u30CD\u30C3\u30C8", "ita", "cornetto"]),
    Object.freeze(["\u30B3\u30EB\u30D2\u30C1\u30F3", "ger", "Kolchizin"]),
    Object.freeze(["\u30B3\u30EC\u30AF\u30B7\u30E7\u30F3\u30D3\u30EB", "eng", "collection bill"]),
    Object.freeze(["\u30B3\u30EC\u30AF\u30B7\u30E7\u30F3\u30FB\u30D3\u30EB", "eng", "collection bill"]),
    Object.freeze(["\u30B3\u30EC\u30B8\u30AA", "por", "collegio"]),
    Object.freeze(["\u30B3\u30EC\u30B8\u30E8", "por", "collegio"]),
    Object.freeze(["\u30B3\u30ED\u30B9", "gre", "choros"]),
    Object.freeze(["\u30B3\u30ED\u30BD\u30DE", "lat", "Colossoma"]),
    Object.freeze(["\u30B3\u30ED\u30C3\u30BB\u30AA", "ita", "Colosseo"]),
    Object.freeze(["\u30B3\u30ED\u30C3\u30D7", "dut", "prop"]),
    Object.freeze(["\u30B3\u30ED\u30CB\u30A2", "por", "col\xF4nia"]),
    Object.freeze(["\u30B3\u30ED\u30CD", "fre", "cornet"]),
    Object.freeze(["\u30B3\u30ED\u30EA\u30B9\u30C8", "fre", "coloriste"]),
    Object.freeze(["\u30B3\u30ED\u30F3", "fre", "colon"]),
    Object.freeze(["\u30B3\u30ED\u30F3\u30D0\u30F3", "fre", "colombin"]),
    Object.freeze(["\u30B3\u30EF\u30F3\u30C1\u30E7\u30A6", "chi", "Gu\u01CEngzh\u014Du"]),
    Object.freeze(["\u30B3\u30F3\u30AF\u30FC\u30EB", "fre", "concours"]),
    Object.freeze(["\u30B3\u30F3\u30B3\u30EB\u30C0\u30FC\u30C8", "ger", "Konkordat"]),
    Object.freeze(["\u30B3\u30F3\u30B8\u30ED\u30FC\u30E0", "ger", "Kondylom"]),
    Object.freeze(["\u30B3\u30F3\u30B9", "chi", "g\u014Dngs\u012B"]),
    Object.freeze(["\u30B3\u30F3\u30BB\u30A4\u30A8", "fre", "conseiller"]),
    Object.freeze(["\u30B3\u30F3\u30BF\u30B9", "por", "contas"]),
    Object.freeze(["\u30B3\u30F3\u30BF\u30C4", "por", "contas"]),
    Object.freeze(["\u30B3\u30F3\u30C1\u30EA\u30B5\u30F3", "por", "contri\xE7\xE3o"]),
    Object.freeze(["\u30B3\u30F3\u30C4\u30A7\u30EB\u30C8", "ger", "Konzert"]),
    Object.freeze(["\u30B3\u30F3\u30C4\u30A7\u30EB\u30F3", "ger", "Konzern"]),
    Object.freeze(["\u30B3\u30F3\u30C8\u30E9\u30D0\u30B9", "ger", "Kontrabass"]),
    Object.freeze(["\u30B3\u30F3\u30C8\u30E9\u30D5\u30A1\u30B4\u30C3\u30C8", "ita", "controfagotto"]),
    Object.freeze(["\u30B3\u30F3\u30C8\u30E9\u30D7\u30F3\u30AF\u30C8", "ger", "Kontrapunkt"]),
    Object.freeze(["\u30B3\u30F3\u30C8\u30ED\u30FC\u30EB\u30D1\u30C3\u30C8", "eng", "control pad"]),
    Object.freeze(["\u30B3\u30F3\u30C8\u30ED\u30FC\u30EB\u30D1\u30C3\u30C9", "eng", "control pad"]),
    Object.freeze(["\u30B3\u30F3\u30C8\u30ED\u30FC\u30EB\u30FB\u30D1\u30C3\u30C9", "eng", "control pad"]),
    Object.freeze(["\u30B3\u30F3\u30D1\u30B9", "dut", "kompas"]),
    Object.freeze(["\u30B3\u30F3\u30D1\u30CB\u30A2", "por", "companhia"]),
    Object.freeze(["\u30B3\u30F3\u30D1\u30CB\u30E4", "por", "companhia"]),
    Object.freeze(["\u30B3\u30F3\u30D2\u30B5\u30F3", "por", "confiss\xE3o"]),
    Object.freeze(["\u30B3\u30F3\u30D3\u30CA\u30FC\u30C8", "rus", "kombinat"]),
    Object.freeze(["\u30B3\u30F3\u30D3\u30CD\u30FC\u30B7\u30E7\u30F3\u30D7\u30E9\u30A4\u30E4\u30FC", "eng", "combination plier"]),
    Object.freeze(["\u30B3\u30F3\u30D3\u30CD\u30FC\u30B7\u30E7\u30F3\u30FB\u30D7\u30E9\u30A4\u30E4\u30FC", "eng", "combination plier"]),
    Object.freeze(["\u30B3\u30F3\u30D4\u30E5\u30FC\u30BF\u30A2\u30EC\u30EB\u30AE\u30FC", "eng", "computer allergy"]),
    Object.freeze(["\u30B3\u30F3\u30D4\u30E5\u30FC\u30BF\u30FB\u30A2\u30EC\u30EB\u30AE\u30FC", "eng", "computer allergy"]),
    Object.freeze(["\u30B3\u30F3\u30D4\u30E5\u30FC\u30BF\u30FC\u30A2\u30EC\u30EB\u30AE\u30FC", "eng", "computer allergy"]),
    Object.freeze(["\u30B3\u30F3\u30D4\u30E5\u30FC\u30BF\u30FC\u30FB\u30A2\u30EC\u30EB\u30AE\u30FC", "eng", "computer allergy"]),
    Object.freeze(["\u30B3\u30F3\u30DA\u30A4\u30C8\u30FC", "por", "confeito"]),
    Object.freeze(["\u30B3\u30F3\u30DA\u30FC\u30C8\u30FC", "por", "confeito"]),
    Object.freeze(["\u30B3\u30F3\u30DD\u30B8\u30C3\u30C8\u30D1\u30CD\u30EB", "eng", "composite panel"]),
    Object.freeze(["\u30B3\u30F3\u30DD\u30B8\u30C3\u30C8\u30FB\u30D1\u30CD\u30EB", "eng", "composite panel"]),
    Object.freeze(["\u30B3\u30F3\u30E1\u30F3\u30BF\u30FC\u30EB", "ger", "Kommentar"]),
    Object.freeze(["\u30B3\u30FC\u30AF\u30B9", "ger", "Koks"]),
    Object.freeze(["\u30B3\u30FC\u30C4", "chi", "k\xE8 zi"]),
    Object.freeze(["\u30B3\u30FC\u30C8\u30CF\u30F3\u30AC\u30FC", "eng", "coat hanger"]),
    Object.freeze(["\u30B3\u30FC\u30C8\u30EC\u30C3\u30C8", "fre", "c\xF4telette"]),
    Object.freeze(["\u30B3\u30FC\u30C8\u30FB\u30CF\u30F3\u30AC\u30FC", "eng", "coat hanger"]),
    Object.freeze(["\u30B3\u30FC\u30D2\u30FC\u30B5\u30A4\u30D5\u30A9\u30F3", "eng", "coffee siphon"]),
    Object.freeze(["\u30B3\u30FC\u30D2\u30FC\u30B5\u30A4\u30DB\u30F3", "eng", "coffee siphon"]),
    Object.freeze(["\u30B3\u30FC\u30D2\u30FC\u30FB\u30B5\u30A4\u30D5\u30A9\u30F3", "eng", "coffee siphon"]),
    Object.freeze(["\u30B3\u30FC\u30DC\u30EB\u30C8", "ger", "Kobolt"]),
    Object.freeze(["\u30B3\u30FC\u30EA\u30E3\u30F3", "chi", "g\u0101oliang"]),
    Object.freeze(["\u30B3\u30FC\u30EB\u30E6\u30FC\u30D6\u30F3\u30B2\u30F3", "ger", "Chor\xFCbungen"]),
    Object.freeze(["\u30B4\u30C3\u30C8\u30CF\u30F3\u30C9", "eng", "God's hands"]),
    Object.freeze(["\u30B4\u30C3\u30C8\u30FB\u30CF\u30F3\u30C9", "eng", "God's hands"]),
    Object.freeze(["\u30B4\u30C3\u30C9\u30CF\u30F3\u30C9", "eng", "God's hands"]),
    Object.freeze(["\u30B4\u30C3\u30C9\u30FB\u30CF\u30F3\u30C9", "eng", "God's hands"]),
    Object.freeze(["\u30B4\u30E0", "dut", "gom"]),
    Object.freeze(["\u30B4\u30F3\u30BA\u30A4", "lat", "Plotosus"]),
    Object.freeze(["\u30B4\u30F3\u30D0\u30AA\u30B8\u30FC\u30C7\u30A3\u30F3", "chi", "g\u014Dngb\u01CEo j\u012Bd\u012Bng"]),
    Object.freeze(["\u30B4\u30FC\u30A4\u30F3\u30B0\u30DE\u30A4\u30A6\u30A7\u30A4", "eng", "going my way"]),
    Object.freeze(["\u30B4\u30FC\u30A4\u30F3\u30B0\u30DE\u30A4\u30A6\u30A8\u30A4", "eng", "going my way"]),
    Object.freeze(["\u30B4\u30FC\u30A4\u30F3\u30B0\u30DE\u30A4\u30A6\u30A8\u30FC", "eng", "going my way"]),
    Object.freeze(["\u30B4\u30FC\u30A4\u30F3\u30B0\u30FB\u30DE\u30A4\u30FB\u30A6\u30A7\u30A4", "eng", "going my way"]),
    Object.freeze(["\u30B4\u30FC\u30A4\u30F3\u30B0\u30FB\u30DE\u30A4\u30FB\u30A6\u30A8\u30A4", "eng", "going my way"]),
    Object.freeze(["\u30B4\u30FC\u30A4\u30F3\u30B0\u30FB\u30DE\u30A4\u30FB\u30A6\u30A8\u30FC", "eng", "going my way"]),
    Object.freeze(["\u30B4\u30FC\u30D5\u30EB", "fre", "gaufre"]),
    Object.freeze(["\u30B4\u30FC\u30D5\u30EC\u30C3\u30C8", "fre", "gaufrette"]),
    Object.freeze(["\u30B5\u30A4\u30AF\u30EA\u30F3\u30B0\u30B3\u30FC\u30B9", "eng", "cycling course"]),
    Object.freeze(["\u30B5\u30A4\u30AF\u30EA\u30F3\u30B0\u30FB\u30B3\u30FC\u30B9", "eng", "cycling course"]),
    Object.freeze(["\u30B5\u30A4\u30AF\u30EB\u30AD\u30E3\u30C3\u30D7", "eng", "cycle cap"]),
    Object.freeze(["\u30B5\u30A4\u30AF\u30EB\u30FB\u30AD\u30E3\u30C3\u30D7", "eng", "cycle cap"]),
    Object.freeze(["\u30B5\u30A4\u30B4\u30F3", "vie", "S\xE0i G\xF2n"]),
    Object.freeze(["\u30B5\u30A4\u30C0\u30FC", "eng", "cider"]),
    Object.freeze(["\u30B5\u30A4\u30C8", "eng", "sight"]),
    Object.freeze(["\u30B5\u30A4\u30C9\u30DF\u30E9\u30FC", "eng", "side mirror"]),
    Object.freeze(["\u30B5\u30A4\u30C9\u30FB\u30DF\u30E9\u30FC", "eng", "side mirror"]),
    Object.freeze(["\u30B5\u30A4\u30D0\u30FC\u30C6\u30ED", "eng", "cyber terror"]),
    Object.freeze(["\u30B5\u30A6\u30F3\u30C9\u30DC\u30C7\u30A3\u30FC", "eng", "sound body"]),
    Object.freeze(["\u30B5\u30A6\u30F3\u30C9\u30FB\u30DC\u30C7\u30A3\u30FC", "eng", "sound body"]),
    Object.freeze(["\u30B5\u30A8\u30E9", "fre", "\xE7\xE0 et l\xE0"]),
    Object.freeze(["\u30B5\u30B3\u30C3\u30B7\u30E5", "fre", "sacoche"]),
    Object.freeze(["\u30B5\u30C3\u30AB\u30E9\u30FC\u30BC", "ger", "Saccharase"]),
    Object.freeze(["\u30B5\u30C3\u30AB\u30FC", "eng", "sucker"]),
    Object.freeze(["\u30B5\u30C3\u30AF", "eng", "sack"]),
    Object.freeze(["\u30B5\u30C3\u30C4", "ger", "Satz"]),
    Object.freeze(["\u30B5\u30C6\u30A3\u30A2\u30F3", "san", "satyam"]),
    Object.freeze(["\u30B5\u30C6\u30A3\u30F3", "dut", "satijn"]),
    Object.freeze(["\u30B5\u30C6\u30E5\u30ED\u30B9", "gre", "s\xE1tyros"]),
    Object.freeze(["\u30B5\u30C6\u30F3", "dut", "satijn"]),
    Object.freeze(["\u30B5\u30C8\u30A5\u30EB\u30CC\u30B9", "lat", "Saturnus"]),
    Object.freeze(["\u30B5\u30D0\u30C8", "por", "s\xE1bado"]),
    Object.freeze(["\u30B5\u30D5\u30E9\u30F3", "dut", "saffraan"]),
    Object.freeze(["\u30B5\u30DC\u30BF\u30FC\u30B8", "fre", "sabotage"]),
    Object.freeze(["\u30B5\u30DC\u30BF\u30FC\u30B8\u30E5", "fre", "sabotage"]),
    Object.freeze(["\u30B5\u30DC\u30F3", "fre", "savon"]),
    Object.freeze(["\u30B5\u30DF\u30BA\u30C0\u30FC\u30C8", "rus", "samizdat"]),
    Object.freeze(["\u30B5\u30E9\u30B5", "por", "sara\xE7a"]),
    Object.freeze(["\u30B5\u30E9\u30F3\u30D8\u30E8", "kor", "saranghaeyo"]),
    Object.freeze(["\u30B5\u30EB\u30DF\u30A2\u30C3\u30AD", "fin", "salmiakki"]),
    Object.freeze(["\u30B5\u30ED\u30DA\u30C3\u30C8", "fre", "salopette"]),
    Object.freeze(["\u30B5\u30F3\u30A2\u30F3\u30B3\u30FC", "chi", "s\u0101n \xE0n k\xE8"]),
    Object.freeze(["\u30B5\u30F3\u30AB\u30F3\u30C4", "chi", "s\u0101n g\xE0ng zi"]),
    Object.freeze(["\u30B5\u30F3\u30AD\u30E5\u30FC\u30CF\u30B6\u30FC\u30C9", "eng", "thank you hazard"]),
    Object.freeze(["\u30B5\u30F3\u30AD\u30E5\u30FC\u30FB\u30CF\u30B6\u30FC\u30C9", "eng", "thank you hazard"]),
    Object.freeze(["\u30B5\u30F3\u30AF\u30AC\u30FC\u30C7\u30F3", "eng", "sunk garden"]),
    Object.freeze(["\u30B5\u30F3\u30AF\u30C1\u30E5\u30FC\u30EB", "fre", "sans couture"]),
    Object.freeze(["\u30B5\u30F3\u30AF\u30FB\u30AC\u30FC\u30C7\u30F3", "eng", "sunk garden"]),
    Object.freeze(["\u30B5\u30F3\u30B0\u30EA\u30A2", "spa", "sangr\xEDa"]),
    Object.freeze(["\u30B5\u30F3\u30B8\u30AB\u30EA\u30B9\u30C8", "fre", "syndicaliste"]),
    Object.freeze(["\u30B5\u30F3\u30B8\u30AB\u30EA\u30B9\u30E0", "fre", "syndicalisme"]),
    Object.freeze(["\u30B5\u30F3\u30B8\u30AB\u30EA\u30BA\u30E0", "fre", "syndicalisme"]),
    Object.freeze(["\u30B5\u30F3\u30B8\u30AB\u30EB\u30B9\u30C8", "fre", "syndicaliste"]),
    Object.freeze(["\u30B5\u30F3\u30BF\u30DE\u30EA\u30A2", "por", "Santa Maria"]),
    Object.freeze(["\u30B5\u30F3\u30BF\u30FB\u30DE\u30EA\u30A2", "por", "Santa Maria"]),
    Object.freeze(["\u30B5\u30F3\u30C1\u30E3", "chi", "san jia"]),
    Object.freeze(["\u30B5\u30F3\u30C1\u30E5", "kor", "sangchu"]),
    Object.freeze(["\u30B5\u30F3\u30C1\u30E5\u30FC\u30EB", "fre", "ceinture"]),
    Object.freeze(["\u30B5\u30F3\u30C6\u30C6\u30A3\u30B9\u30E0", "fre", "synth\xE9tisme"]),
    Object.freeze(["\u30B5\u30F3\u30C7\u30A3\u30AB\u30EA\u30B9\u30C8", "fre", "syndicaliste"]),
    Object.freeze(["\u30B5\u30F3\u30C7\u30A3\u30AB\u30EA\u30B9\u30E0", "fre", "syndicalisme"]),
    Object.freeze(["\u30B5\u30F3\u30C7\u30A3\u30AB\u30EA\u30BA\u30E0", "fre", "syndicalisme"]),
    Object.freeze(["\u30B5\u30F3\u30C8", "lat", "sancto"]),
    Object.freeze(["\u30B5\u30F3\u30C8\u30B9", "por", "santos"]),
    Object.freeze(["\u30B5\u30F3\u30C9\u30D0\u30C3\u30AF", "eng", "sandbag"]),
    Object.freeze(["\u30B5\u30F3\u30C9\u30D0\u30C3\u30B0", "eng", "sandbag"]),
    Object.freeze(["\u30B5\u30F3\u30C9\u30FB\u30D0\u30C3\u30AF", "eng", "sandbag"]),
    Object.freeze(["\u30B5\u30F3\u30C9\u30FB\u30D0\u30C3\u30B0", "eng", "sandbag"]),
    Object.freeze(["\u30B5\u30F3\u30D0\u30C9\u30ED\u30FC\u30E0", "por", "samb\u014Ddromo"]),
    Object.freeze(["\u30B5\u30F3\u30DC\u30EA\u30B9\u30C8", "fre", "symboliste"]),
    Object.freeze(["\u30B5\u30F3\u30DC\u30EA\u30B9\u30E0", "fre", "symbolisme"]),
    Object.freeze(["\u30B5\u30F3\u30DC\u30EA\u30BA\u30E0", "fre", "symbolisme"]),
    Object.freeze(["\u30B5\u30F3\u30DC\u30FC\u30C9\u30ED\u30E2", "por", "samb\u014Ddromo"]),
    Object.freeze(["\u30B5\u30F3\u30E6\u30A2\u30F3\u30D1\u30A4", "chi", "s\u0101n yu\xE1n p\xE1i"]),
    Object.freeze(["\u30B5\u30F3\u30E9\u30FC\u30BF\u30F3", "chi", "su\u0101n l\xE0 t\u0101ng"]),
    Object.freeze(["\u30B5\u30F3\u30FB\u30AF\u30C1\u30E5\u30FC\u30EB", "fre", "sans couture"]),
    Object.freeze(["\u30B5\u30FB\u30A8\u30FB\u30E9", "fre", "\xE7\xE0 et l\xE0"]),
    Object.freeze(["\u30B5\u30FC\u30C8\u30A5\u30EB\u30CC\u30B9", "lat", "Saturnus"]),
    Object.freeze(["\u30B5\u30FC\u30D0\u30FC\u30C0\u30A6\u30F3", "eng", "server down"]),
    Object.freeze(["\u30B5\u30FC\u30D0\u30FC\u30FB\u30C0\u30A6\u30F3", "eng", "server down"]),
    Object.freeze(["\u30B5\u30FC\u30D3\u30B9\u30A8\u30FC\u30B9", "eng", "service ace"]),
    Object.freeze(["\u30B5\u30FC\u30D3\u30B9\u30AB\u30A6\u30F3\u30BF\u30FC", "eng", "service counter"]),
    Object.freeze(["\u30B5\u30FC\u30D3\u30B9\u30D0\u30EB\u30B3\u30CB\u30FC", "eng", "service balcony"]),
    Object.freeze(["\u30B5\u30FC\u30D3\u30B9\u30D7\u30ED\u30D0\u30A4\u30C0", "eng", "service provider"]),
    Object.freeze(["\u30B5\u30FC\u30D3\u30B9\u30D7\u30ED\u30D0\u30A4\u30C0\u30FC", "eng", "service provider"]),
    Object.freeze(["\u30B5\u30FC\u30D3\u30B9\u30FB\u30A8\u30FC\u30B9", "eng", "service ace"]),
    Object.freeze(["\u30B5\u30FC\u30D3\u30B9\u30FB\u30AB\u30A6\u30F3\u30BF\u30FC", "eng", "service counter"]),
    Object.freeze(["\u30B5\u30FC\u30D3\u30B9\u30FB\u30D0\u30EB\u30B3\u30CB\u30FC", "eng", "service balcony"]),
    Object.freeze(["\u30B5\u30FC\u30D3\u30B9\u30FB\u30D7\u30ED\u30D0\u30A4\u30C0", "eng", "service provider"]),
    Object.freeze(["\u30B5\u30FC\u30D3\u30B9\u30FB\u30D7\u30ED\u30D0\u30A4\u30C0\u30FC", "eng", "service provider"]),
    Object.freeze(["\u30B5\u30FC\u30D9\u30EB", "dut", "sabel"]),
    Object.freeze(["\u30B6\u30A4\u30EB", "ger", "Seil"]),
    Object.freeze(["\u30B6\u30A4\u30F3", "ger", "Sein"]),
    Object.freeze(["\u30B6\u30AB\u30D5\u30AB\u30B9", "rus", "Zakavkazye"]),
    Object.freeze(["\u30B6\u30AF\u30B9\u30AB", "rus", "zakuska"]),
    Object.freeze(["\u30B6\u30AF\u30FC\u30B9\u30AB", "rus", "zakuska"]),
    Object.freeze(["\u30B6\u30C3\u30AF", "ger", "Sack"]),
    Object.freeze(["\u30B6\u30C3\u30C4", "ger", "Satz"]),
    Object.freeze(["\u30B6\u30DC\u30F3", "por", "zamboa"]),
    Object.freeze(["\u30B6\u30FC", "chi", "zh\xE1"]),
    Object.freeze(["\u30B6\u30FC\u30B5\u30A4", "chi", "zh\xE0c\xE0i"]),
    Object.freeze(["\u30B6\u30FC\u30C4\u30A1\u30A4", "chi", "zh\xE0c\xE0i"]),
    Object.freeze(["\u30B6\u30FC\u30C5\u30FC\u30C1\u30FC", "chi", "zhaziji"]),
    Object.freeze(["\u30B6\u30FC\u30E1\u30F3", "ger", "Samen"]),
    Object.freeze(["\u30B7\u30A2\u30CA\u30DF\u30C9", "ger", "Cyanamid"]),
    Object.freeze(["\u30B7\u30A6\u30DE\u30A4", "chi", "sh\u0101om\xE0i"]),
    Object.freeze(["\u30B7\u30A7\u30A4\u30B7\u30A7\u30A4", "chi", "xi\xE8xie"]),
    Object.freeze(["\u30B7\u30A7\u30B7\u30A7", "chi", "xi\xE8xie"]),
    Object.freeze(["\u30B7\u30A7\u30E9\u30D5", "ger", "Schlafsack"]),
    Object.freeze(["\u30B7\u30A7\u30F3\u30B8\u30A7\u30F3\u30DE\u30F3\u30C8\u30FC", "chi", "sh\u0113ngji\u0101n m\xE1ntou"]),
    Object.freeze(["\u30B7\u30A7\u30F3\u30C8\u30A6\u30B8\u30E3\u30F3", "chi", "xi\xE1n d\xF2uji\u0101ng"]),
    Object.freeze(["\u30B7\u30A7\u30FC\u30D6\u30EB", "fre", "ch\xE8vre"]),
    Object.freeze(["\u30B7\u30A7\u30FC\u30DE", "ger", "Schema"]),
    Object.freeze(["\u30B7\u30A8\u30B7\u30A8", "chi", "xi\xE8xie"]),
    Object.freeze(["\u30B7\u30A8\u30EB", "fre", "ciel"]),
    Object.freeze(["\u30B7\u30B7\u30AB\u30D0\u30D6", "tur", "\u015Fi\u015F kebap"]),
    Object.freeze(["\u30B7\u30B7\u30B1\u30D0\u30D6", "tur", "\u015Fi\u015F kebap"]),
    Object.freeze(["\u30B7\u30B7\u30FB\u30AB\u30D0\u30D6", "tur", "\u015Fi\u015F kebap"]),
    Object.freeze(["\u30B7\u30B7\u30FB\u30B1\u30D0\u30D6", "tur", "\u015Fi\u015F kebap"]),
    Object.freeze(["\u30B7\u30B9\u30C6\u30E0\u30C8\u30EC\u30FC\u30C9", "eng", "system trade"]),
    Object.freeze(["\u30B7\u30B9\u30C6\u30E0\u30FB\u30C8\u30EC\u30FC\u30C9", "eng", "system trade"]),
    Object.freeze(["\u30B7\u30C3\u30AF", "eng", "thick"]),
    Object.freeze(["\u30B7\u30C3\u30AF\u30CF\u30A6\u30B9", "eng", "sick house"]),
    Object.freeze(["\u30B7\u30C3\u30AF\u30FB\u30CF\u30A6\u30B9", "eng", "sick house"]),
    Object.freeze(["\u30B7\u30C8\u30AF\u30ED\u30E0", "ger", "Cytochrom"]),
    Object.freeze(["\u30B7\u30CB\u30B9\u30E0", "fre", "cynisme"]),
    Object.freeze(["\u30B7\u30CD\u30DE", "fre", "cin\xE9ma"]),
    Object.freeze(["\u30B7\u30CD\u30DE\u30C6\u30FC\u30AF", "fre", "cin\xE9math\xE8que"]),
    Object.freeze(["\u30B7\u30CD\u30DE\u30C8\u30B0\u30E9\u30D5", "fre", "cin\xE9matographe"]),
    Object.freeze(["\u30B7\u30CE\u30C9\u30F3\u30C6\u30A3\u30B9", "lat", "Synodontis"]),
    Object.freeze(["\u30B7\u30CE\u30ED\u30B8\u30FC", "fre", "sinologie"]),
    Object.freeze(["\u30B7\u30D3\u30E5\u30E9", "gre", "sibylla"]),
    Object.freeze(["\u30B7\u30D6\u30B9\u30C8", "fre", "chiboust"]),
    Object.freeze(["\u30B7\u30D6\u30EC\u30C3\u30C8", "fre", "ciboulette"]),
    Object.freeze(["\u30B7\u30D6\u30FC\u30B9\u30C8", "fre", "chiboust"]),
    Object.freeze(["\u30B7\u30DF\u30E5\u30EB\u30BF\u30CD\u30A4\u30B9\u30E0", "fre", "simultan\xE9isme"]),
    Object.freeze(["\u30B7\u30E3\u30A4\u30C4", "chi", "sh\u01CEizi"]),
    Object.freeze(["\u30B7\u30E3\u30A6\u30AB\u30B9\u30C6\u30F3", "ger", "Schaukasten"]),
    Object.freeze(["\u30B7\u30E3\u30AA\u30B7\u30F3\u30C1\u30E5\u30A6", "chi", "sh\xE0ox\u012Bngji\u01D4"]),
    Object.freeze(["\u30B7\u30E3\u30AA\u30B7\u30F3\u30C1\u30E5\u30FC", "chi", "sh\xE0ox\u012Bngji\u01D4"]),
    Object.freeze(["\u30B7\u30E3\u30AA\u30B9\u30FC\u30B7\u30FC", "chi", "xi\u01CEo s\xEC x\u01D0"]),
    Object.freeze(["\u30B7\u30E3\u30AA\u30C1\u30FC", "chi", "xi\u01CEoch\u012B"]),
    Object.freeze(["\u30B7\u30E3\u30AA\u30EA\u30FC\u30D9\u30F3", "chi", "xi\u01CEo r\xECb\u011Bn"]),
    Object.freeze(["\u30B7\u30E3\u30AA\u30ED\u30F3\u30D1", "chi", "xi\u01CEol\xF3ngb\u0101o"]),
    Object.freeze(["\u30B7\u30E3\u30C3\u30DD", "fre", "chapeau"]),
    Object.freeze(["\u30B7\u30E3\u30DA\u30ED\u30F3", "fre", "chaperon"]),
    Object.freeze(["\u30B7\u30E3\u30DC\u30F3", "por", "sab\xE3o"]),
    Object.freeze(["\u30B7\u30E3\u30DD\u30FC", "fre", "chapeau"]),
    Object.freeze(["\u30B7\u30E3\u30EB\u30DE\u30F3", "fre", "charmant"]),
    Object.freeze(["\u30B7\u30E3\u30EB\u30E0", "fre", "charme"]),
    Object.freeze(["\u30B7\u30E3\u30F3", "ger", "sch\xF6n"]),
    Object.freeze(["\u30B7\u30E3\u30F3\u30BF\u30F3", "chi", "sh\xE0ngt\u0101ng"]),
    Object.freeze(["\u30B7\u30E3\u30F3\u30C1\u30FC", "chi", "xi\xE0ngq\xED"]),
    Object.freeze(["\u30B7\u30E3\u30F3\u30C4\u30A7", "ger", "Schanze"]),
    Object.freeze(["\u30B7\u30E3\u30F3\u30E4\u30F3\u30ED\u30FC", "chi", "shu\xE0ny\xE1ngr\xF2u"]),
    Object.freeze(["\u30B7\u30E3\u30FC", "chi", "x\u012B"]),
    Object.freeze(["\u30B7\u30E3\u30FC\u30EC", "ger", "Schale"]),
    Object.freeze(["\u30B7\u30E4\u30F3", "ger", "sch\xF6n"]),
    Object.freeze(["\u30B7\u30E5\u30A6\u30D1\u30A4", "chi", "sh\xF9 p\xE1i"]),
    Object.freeze(["\u30B7\u30E5\u30A6\u30DE\u30A4", "chi", "sh\u0101om\xE0i"]),
    Object.freeze(["\u30B7\u30E5\u30B7\u30E5", "fre", "chouchou"]),
    Object.freeze(["\u30B7\u30E5\u30BF\u30A4\u30AF\u30A2\u30A4\u30BC\u30F3", "ger", "Steigeisen"]),
    Object.freeze(["\u30B7\u30E5\u30C0\u30E9", "san", "\u015B\u016Bdra"]),
    Object.freeze(["\u30B7\u30E5\u30C6\u30E0\u30AF\u30EA\u30B9\u30C1\u30E3\u30CB\u30A2", "ger", "Stemmkristiania"]),
    Object.freeze(["\u30B7\u30E5\u30C6\u30E0\u30DC\u30FC\u30B2\u30F3", "ger", "Stemmbogen"]),
    Object.freeze(["\u30B7\u30E5\u30C6\u30EB\u30D9\u30F3", "ger", "Sterben"]),
    Object.freeze(["\u30B7\u30E5\u30C8\u30A5\u30EB\u30FC\u30C7\u30EB", "ger", "Strudel"]),
    Object.freeze(["\u30B7\u30E5\u30C8\u30C3\u30AF", "ger", "Stock"]),
    Object.freeze(["\u30B7\u30E5\u30C8\u30EB\u30FC\u30C7\u30EB", "ger", "Strudel"]),
    Object.freeze(["\u30B7\u30E5\u30C8\u30EC\u30F3", "ger", "Stollen"]),
    Object.freeze(["\u30B7\u30E5\u30C8\u30FC\u30EC\u30F3", "ger", "Stollen"]),
    Object.freeze(["\u30B7\u30E5\u30CA\u30A6\u30B6\u30FC", "ger", "Schnauzer"]),
    Object.freeze(["\u30B7\u30E5\u30CA\u30A6\u30C4\u30A1\u30FC", "ger", "Schnauzer"]),
    Object.freeze(["\u30B7\u30E5\u30CA\u30C3\u30D7\u30B9", "ger", "Schnaps"]),
    Object.freeze(["\u30B7\u30E5\u30CB\u30C3\u30C4\u30A7\u30EB", "ger", "Schnitzel"]),
    Object.freeze(["\u30B7\u30E5\u30CE\u30FC\u30B1\u30EB", "ger", "Schnorchel"]),
    Object.freeze(["\u30B7\u30E5\u30CF\u30B9\u30B3", "por", "churrasco"]),
    Object.freeze(["\u30B7\u30E5\u30D7\u30EC\u30C3\u30D2\u30B3\u30FC\u30EB", "ger", "Sprechchor"]),
    Object.freeze(["\u30B7\u30E5\u30D7\u30EC\u30D2\u30B3\u30FC\u30EB", "ger", "Sprechchor"]),
    Object.freeze(["\u30B7\u30E5\u30D7\u30EC\u30DE\u30C6\u30A3\u30B9\u30E0", "fre", "supr\xE9matisme"]),
    Object.freeze(["\u30B7\u30E5\u30D7\u30EC\u30DE\u30C6\u30A3\u30BA\u30E0", "fre", "supr\xE9matisme"]),
    Object.freeze(["\u30B7\u30E5\u30D7\u30FC\u30EB", "ger", "Spur"]),
    Object.freeze(["\u30B7\u30E5\u30DF\u30CD", "fre", "chemin\xE9e"]),
    Object.freeze(["\u30B7\u30E5\u30E9\u30B9\u30B3", "por", "churrasco"]),
    Object.freeze(["\u30B7\u30E5\u30E9\u30D5", "ger", "Schlafsack"]),
    Object.freeze(["\u30B7\u30E5\u30E9\u30D5\u30B6\u30C3\u30AF", "ger", "Schlafsack"]),
    Object.freeze(["\u30B7\u30E5\u30E9\u30FC\u30D5", "ger", "Schlafsack"]),
    Object.freeze(["\u30B7\u30E5\u30E9\u30FC\u30D5\u30B6\u30C3\u30AF", "ger", "Schlafsack"]),
    Object.freeze(["\u30B7\u30E5\u30EA\u30F3\u30B2", "ger", "Schlinge"]),
    Object.freeze(["\u30B7\u30E5\u30EB\u30EC\u30A2\u30EA\u30B9\u30E0", "fre", "surr\xE9alisme"]),
    Object.freeze(["\u30B7\u30E5\u30EC\u30A2\u30EA\u30B9\u30E0", "fre", "surr\xE9alisme"]),
    Object.freeze(["\u30B7\u30E5\u30EF\u30F3\u30E4\u30F3\u30ED\u30A6", "chi", "shu\xE0ny\xE1ngr\xF2u"]),
    Object.freeze(["\u30B7\u30E5\u30F3\u30C4", "chi", "sh\xF9nzi"]),
    Object.freeze(["\u30B7\u30E5\u30FC\u30AF\u30EA\u30FC\u30E0", "fre", "chou \xE0 la cr\xE8me"]),
    Object.freeze(["\u30B7\u30E5\u30FC\u30C9\u30E9", "san", "\u015B\u016Bdra"]),
    Object.freeze(["\u30B7\u30E5\u30FC\u30D1\u30A4", "chi", "sh\xF9 p\xE1i"]),
    Object.freeze(["\u30B7\u30E5\u30FC\u30DE\u30A4", "chi", "sh\u0101om\xE0i"]),
    Object.freeze(["\u30B7\u30E5\u30FC\u30EB\u30EA\u30A2\u30EA\u30BA\u30E0", "fre", "surr\xE9alisme"]),
    Object.freeze(["\u30B7\u30E5\u30FC\u30EB\u30EC\u30A2\u30EA\u30B9\u30E0", "fre", "surr\xE9alisme"]),
    Object.freeze(["\u30B7\u30E5\u30FC\u30EB\u30EC\u30A2\u30EA\u30BA\u30E0", "fre", "surr\xE9alisme"]),
    Object.freeze(["\u30B7\u30E5\u30FC\u30EB\u30FC\u30B8\u30E5", "fre", "chou rouge"]),
    Object.freeze(["\u30B7\u30E5\u30FC\u30FB\u30AF\u30EA\u30FC\u30E0", "fre", "chou \xE0 la cr\xE8me"]),
    Object.freeze(["\u30B7\u30E5\u30FC\u30FB\u30EB\u30FC\u30B8\u30E5", "fre", "chou rouge"]),
    Object.freeze(["\u30B7\u30E7\u30A6\u30ED\u30F3\u30DD\u30A6", "chi", "xi\u01CEol\xF3ngb\u0101o"]),
    Object.freeze(["\u30B7\u30E7\u30B3\u30E9", "fre", "chocolat"]),
    Object.freeze(["\u30B7\u30E7\u30B3\u30E9\u30B7\u30E7\u30A6", "fre", "chocolat chaud"]),
    Object.freeze(["\u30B7\u30E7\u30B3\u30E9\u30B7\u30E7\u30FC", "fre", "chocolat chaud"]),
    Object.freeze(["\u30B7\u30E7\u30B3\u30E9\u30FB\u30B7\u30E7\u30A6", "fre", "chocolat chaud"]),
    Object.freeze(["\u30B7\u30E7\u30B3\u30E9\u30FB\u30B7\u30E7\u30FC", "fre", "chocolat chaud"]),
    Object.freeze(["\u30B7\u30E7\u30F3\u30B8\u30A8\u30F3\u30D0\u30AA", "chi", "sh\u0113ngji\u0101nb\u0101o"]),
    Object.freeze(["\u30B7\u30E7\u30F3\u30C1\u30A7\u30F3\u30D1\u30AA", "chi", "sh\u0113ngji\u0101nb\u0101o"]),
    Object.freeze(["\u30B7\u30E7\u30FC\u30B9", "fre", "chausses"]),
    Object.freeze(["\u30B7\u30E7\u30FC\u30C8\u30D1\u30F3\u30C4", "eng", "short pants"]),
    Object.freeze(["\u30B7\u30E7\u30FC\u30C8\u30E1\u30C3\u30BB\u30FC\u30B8", "eng", "short message"]),
    Object.freeze(["\u30B7\u30E7\u30FC\u30C8\u30FB\u30D1\u30F3\u30C4", "eng", "short pants"]),
    Object.freeze(["\u30B7\u30E7\u30FC\u30C8\u30FB\u30E1\u30C3\u30BB\u30FC\u30B8", "eng", "short message"]),
    Object.freeze(["\u30B7\u30E7\u30FC\u30D3\u30CB\u30B9\u30E0", "fre", "chauvinisme"]),
    Object.freeze(["\u30B7\u30E7\u30FC\u30D3\u30CB\u30BA\u30E0", "fre", "chauvinisme"]),
    Object.freeze(["\u30B7\u30E7\u30FC\u30E2\u30C7\u30EB", "eng", "show model"]),
    Object.freeze(["\u30B7\u30E7\u30FC\u30ED\u30F3\u30DD\u30FC", "chi", "xi\u01CEol\xF3ngb\u0101o"]),
    Object.freeze(["\u30B7\u30E7\u30FC\u30F4\u30A3\u30CB\u30B9\u30E0", "fre", "chauvinisme"]),
    Object.freeze(["\u30B7\u30E7\u30FC\u30FB\u30E2\u30C7\u30EB", "eng", "show model"]),
    Object.freeze(["\u30B7\u30EA\u30F3\u30B0", "ger", "Schilling"]),
    Object.freeze(["\u30B7\u30EB\u30D6\u30D7\u30EC", "fre", "s'il vous pla\xEEt"]),
    Object.freeze(["\u30B7\u30EB\u30DF\u30F3", "ger", "Silumin"]),
    Object.freeze(["\u30B7\u30EB\u30F4\u30D7\u30EC", "fre", "s'il vous pla\xEEt"]),
    Object.freeze(["\u30B7\u30EB\u30FB\u30D6\u30FB\u30D7\u30EC", "fre", "s'il vous pla\xEEt"]),
    Object.freeze(["\u30B7\u30EB\u30FB\u30F4\u30FB\u30D7\u30EC", "fre", "s'il vous pla\xEEt"]),
    Object.freeze(["\u30B7\u30ED\u30C3\u30B3", "ita", "scirocco"]),
    Object.freeze(["\u30B7\u30ED\u30C3\u30D7", "dut", "siroop"]),
    Object.freeze(["\u30B7\u30FC", "chi", "sh\xED"]),
    Object.freeze(["\u30B7\u30FC\u30B5\u30F3", "chi", "xi\u0101nsh\u0113ng"]),
    Object.freeze(["\u30B7\u30FC\u30B7\u30C3\u30AF", "eng", "seasick"]),
    Object.freeze(["\u30B7\u30FC\u30C1\u30AD\u30F3", "eng", "Sea Chicken"]),
    Object.freeze(["\u30B7\u30FC\u30C9\u30EB", "fre", "cidre"]),
    Object.freeze(["\u30B7\u30FC\u30CB\u30E5", "fre", "signe"]),
    Object.freeze(["\u30B7\u30FC\u30CD", "ger", "Schiene"]),
    Object.freeze(["\u30B7\u30FC\u30CF\u30A4\u30EB", "ger", "Ski Heil"]),
    Object.freeze(["\u30B7\u30FC\u30D1\u30A4", "chi", "x\u01D0 p\xE1i"]),
    Object.freeze(["\u30B7\u30FC\u30FB\u30C1\u30AD\u30F3", "eng", "Sea Chicken"]),
    Object.freeze(["\u30B7\u30FC\u30FB\u30CF\u30A4\u30EB", "ger", "Ski Heil"]),
    Object.freeze(["\u30B8\u30A2\u30B9\u30BF\u30FC\u30BC", "ger", "Diastase"]),
    Object.freeze(["\u30B8\u30A2\u30BB\u30C1\u30EB\u30E2\u30EB\u30D2\u30CD", "ger", "Diacetylmorphin"]),
    Object.freeze(["\u30B8\u30AA\u30D7\u30BF", "ger", "Dioptrie"]),
    Object.freeze(["\u30B8\u30AA\u30D7\u30C8\u30EA\u30FC", "ger", "Dioptrie"]),
    Object.freeze(["\u30B8\u30C3\u30D8\u30EB", "ger", "Sicherung"]),
    Object.freeze(["\u30B8\u30D0\u30F3", "por", "gib\xE3o"]),
    Object.freeze(["\u30B8\u30D3\u30A8", "fre", "gibier"]),
    Object.freeze(["\u30B8\u30D5\u30A3\u30EA\u30B9", "ger", "Syphilis"]),
    Object.freeze(["\u30B8\u30D9\u30EB", "ger", "D\xFCbel"]),
    Object.freeze(["\u30B8\u30E0\u30CA\u30FC\u30AB\u30B9", "lat", "Gymnarchus"]),
    Object.freeze(["\u30B8\u30E2\u30C6\u30A3\u30AD", "gre", "dimotiki"]),
    Object.freeze(["\u30B8\u30E3\u30AC\u30BF\u30E9", "dut", "Jacatra"]),
    Object.freeze(["\u30B8\u30E3\u30DD\u30CD\u30B9\u30AF", "fre", "japonesque"]),
    Object.freeze(["\u30B8\u30E3\u30DD\u30F3", "fre", "Japon"]),
    Object.freeze(["\u30B8\u30E3\u30E8\u30A6", "chi", "ji\u0101y\xF3u"]),
    Object.freeze(["\u30B8\u30E3\u30F3\u30BB\u30CB\u30B9\u30E0", "fre", "Jans\xE9nisme"]),
    Object.freeze(["\u30B8\u30E3\u30F3\u30BB\u30CB\u30BA\u30E0", "fre", "Jans\xE9nisme"]),
    Object.freeze(["\u30B8\u30E3\u30FC\u30AF", "eng", "jerk"]),
    Object.freeze(["\u30B8\u30E3\u30FC\u30BF\u30AB", "san", "j\u0101taka"]),
    Object.freeze(["\u30B8\u30E3\u30FC\u30E1\u30F3", "chi", "zh\xE1mi\xE0n"]),
    Object.freeze(["\u30B8\u30E3\u30FC\u30E6\u30FC", "chi", "ji\u0101y\xF3u"]),
    Object.freeze(["\u30B8\u30E3\u30FC\u30E8\u30A6", "chi", "ji\u0101y\xF3u"]),
    Object.freeze(["\u30B8\u30E5\u30C6\u30FC\u30E0", "fre", "je t'aime"]),
    Object.freeze(["\u30B8\u30E5\u30CD\u30FC\u30D6", "fre", "Gen\xE8ve"]),
    Object.freeze(["\u30B8\u30E5\u30CD\u30FC\u30F4", "fre", "Gen\xE8ve"]),
    Object.freeze(["\u30B8\u30E5\u30D0\u30F3", "por", "gib\xE3o"]),
    Object.freeze(["\u30B8\u30E5\u30EC", "fre", "gel\xE9e"]),
    Object.freeze(["\u30B8\u30E5\u30F3\u30C1\u30E3\u30F3\u30BF\u30A4\u30E4\u30AA\u30C1\u30E5\u30A6", "chi", "ch\xFAn qu\xE1n d\xE0i y\u0101o ji\u01D4"]),
    Object.freeze(["\u30B8\u30E5\u30FB\u30C6\u30FC\u30E0", "fre", "je t'aime"]),
    Object.freeze(["\u30B8\u30E7\u30A6\u30ED", "por", "jorro"]),
    Object.freeze(["\u30B8\u30E7\u30C3\u30AD", "eng", "jug"]),
    Object.freeze(["\u30B8\u30E7\u30FC\u30BA", "eng", "jaws"]),
    Object.freeze(["\u30B8\u30EB", "tur", "zil"]),
    Object.freeze(["\u30B8\u30EB\u30B3\u30F3", "ger", "Zirkon"]),
    Object.freeze(["\u30B8\u30ED", "por", "jil\xF3"]),
    Object.freeze(["\u30B8\u30ED\u30FC\u30EB", "fre", "girolle"]),
    Object.freeze(["\u30B8\u30F3\u30B2\u30EB", "ger", "Singer"]),
    Object.freeze(["\u30B8\u30F3\u30BB\u30F3", "chi", "jenshen"]),
    Object.freeze(["\u30B8\u30F3\u30C6\u30FC\u30BC", "ger", "Synthese"]),
    Object.freeze(["\u30B8\u30FC\u30DE\u30FC\u30B8\u30E3\u30F3", "chi", "zh\u012Bmaji\xE0ng"]),
    Object.freeze(["\u30B9\u30A2\u30F3\u30E9\u30FC\u30BF\u30F3", "chi", "su\u0101n l\xE0 t\u0101ng"]),
    Object.freeze(["\u30B9\u30A4\u30B9", "fre", "Suisse"]),
    Object.freeze(["\u30B9\u30A4\u30FC\u30C8\u30DB\u30FC\u30E0", "eng", "sweet home"]),
    Object.freeze(["\u30B9\u30A4\u30FC\u30C8\u30FB\u30DB\u30FC\u30E0", "eng", "sweet home"]),
    Object.freeze(["\u30B9\u30A6\u30A3\u30FC\u30C8\u30DB\u30FC\u30E0", "eng", "sweet home"]),
    Object.freeze(["\u30B9\u30A6\u30A3\u30FC\u30C8\u30FB\u30DB\u30FC\u30E0", "eng", "sweet home"]),
    Object.freeze(["\u30B9\u30A6\u30A7\u30FC\u30C9", "fre", "su\xE8de"]),
    Object.freeze(["\u30B9\u30A8\u30FC\u30C9", "fre", "su\xE8de"]),
    Object.freeze(["\u30B9\u30AA\u30DF", "fin", "Suomi"]),
    Object.freeze(["\u30B9\u30AB\u30E9\u30D9", "fre", "scarab\xE9e"]),
    Object.freeze(["\u30B9\u30AD\u30BE", "eng", "schizo"]),
    Object.freeze(["\u30B9\u30AD\u30C3\u30C8\u30EB", "eng", "skittle"]),
    Object.freeze(["\u30B9\u30AD\u30EB\u30A2\u30C3\u30D7", "eng", "skill up"]),
    Object.freeze(["\u30B9\u30AD\u30EB\u30FB\u30A2\u30C3\u30D7", "eng", "skill up"]),
    Object.freeze(["\u30B9\u30AD\u30F3\u30D8\u30C3\u30C8", "eng", "skinhead"]),
    Object.freeze(["\u30B9\u30AD\u30F3\u30D8\u30C3\u30C9", "eng", "skinhead"]),
    Object.freeze(["\u30B9\u30B3\u30C3\u30C1\u30C6\u30EA\u30A2", "eng", "Scotch terrier"]),
    Object.freeze(["\u30B9\u30B3\u30C3\u30C1\u30FB\u30C6\u30EA\u30A2", "eng", "Scotch terrier"]),
    Object.freeze(["\u30B9\u30B3\u30C3\u30D7", "dut", "schop"]),
    Object.freeze(["\u30B9\u30B3\u30E9", "lat", "schola"]),
    Object.freeze(["\u30B9\u30B3\u30FC\u30E9", "lat", "schola"]),
    Object.freeze(["\u30B9\u30B3\u30FC\u30EB", "dan", "sk\xE5l"]),
    Object.freeze(["\u30B9\u30BF\u30A4\u30DF\u30FC", "eng", "stymie"]),
    Object.freeze(["\u30B9\u30BF\u30C3\u30AF", "eng", "stuck"]),
    Object.freeze(["\u30B9\u30BF\u30F3\u30C9\u30AB\u30E9\u30FC", "eng", "stand collar"]),
    Object.freeze(["\u30B9\u30BF\u30F3\u30C9\u30FB\u30AB\u30E9\u30FC", "eng", "stand collar"]),
    Object.freeze(["\u30B9\u30BF\u30FC\u30C8\u30D7\u30EC\u30A4\u30E4\u30FC", "eng", "start player"]),
    Object.freeze(["\u30B9\u30BF\u30FC\u30C8\u30FB\u30D7\u30EC\u30A4\u30E4\u30FC", "eng", "start player"]),
    Object.freeze(["\u30B9\u30C0\u30E9", "san", "\u015B\u016Bdra"]),
    Object.freeze(["\u30B9\u30C1\u30B3\u30F3", "eng", "sty(rol) con(denser)"]),
    Object.freeze(["\u30B9\u30C1\u30FC\u30DE\u30FC", "eng", "steamer"]),
    Object.freeze(["\u30B9\u30C6\u30A4\u30DB\u30FC\u30E0", "eng", "stay home"]),
    Object.freeze(["\u30B9\u30C6\u30A4\u30FB\u30DB\u30FC\u30E0", "eng", "stay home"]),
    Object.freeze(["\u30B9\u30C6\u30C3\u30D7\u30EB", "eng", "staple"]),
    Object.freeze(["\u30B9\u30C6\u30EB\u30D9\u30F3", "ger", "Sterben"]),
    Object.freeze(["\u30B9\u30C8\u30C3\u30AB\u30FC", "eng", "stocker"]),
    Object.freeze(["\u30B9\u30C8\u30C3\u30AF", "ger", "Stock"]),
    Object.freeze(["\u30B9\u30C8\u30EC\u30EA\u30C1\u30A2", "lat", "Strelitzia"]),
    Object.freeze(["\u30B9\u30CE\u30FC\u30C9\u30FC\u30E0", "eng", "snow dome"]),
    Object.freeze(["\u30B9\u30CE\u30FC\u30FB\u30C9\u30FC\u30E0", "eng", "snow dome"]),
    Object.freeze(["\u30B9\u30D1\u30B7\u30FC\u30D0", "rus", "spasibo"]),
    Object.freeze(["\u30B9\u30D1\u30B7\u30FC\u30DC", "rus", "spasibo"]),
    Object.freeze(["\u30B9\u30D1\u30C1\u30E5\u30FC\u30EB", "fre", "spatule"]),
    Object.freeze(["\u30B9\u30D1\u30C6\u30EB", "ger", "Spatel"]),
    Object.freeze(["\u30B9\u30D1\u30EA\u30BE\u30FC\u30C8", "eng", "spa resort"]),
    Object.freeze(["\u30B9\u30D1\u30EB\u30BF\u30AD\u30A2\u30FC\u30C9", "rus", "spartakiada"]),
    Object.freeze(["\u30B9\u30D1\u30FB\u30EA\u30BE\u30FC\u30C8", "eng", "spa resort"]),
    Object.freeze(["\u30B9\u30D1\u30FC\u30C6\u30EB", "ger", "Spatel"]),
    Object.freeze(["\u30B9\u30D4\u30C3\u30C4", "ger", "Spitz"]),
    Object.freeze(["\u30B9\u30D4\u30ED\u30D8\u30FC\u30BF", "lat", "Spirochaeta"]),
    Object.freeze(["\u30B9\u30D4\u30FC\u30C9\u30E9\u30F3\u30CA\u30FC", "eng", "speed runner"]),
    Object.freeze(["\u30B9\u30D4\u30FC\u30C9\u30FB\u30E9\u30F3\u30CA\u30FC", "eng", "speed runner"]),
    Object.freeze(["\u30B9\u30D7\u30E9\u30C3\u30B7\u30E3\u30FC", "eng", "splasher"]),
    Object.freeze(["\u30B9\u30D7\u30E9\u30F3\u30AF\u30CB\u30BE\u30DE\u30A4", "gre", "splagchnizomai"]),
    Object.freeze(["\u30B9\u30D9\u30BF", "por", "espada"]),
    Object.freeze(["\u30B9\u30DA\u30AF\u30C8\u30EB", "fre", "spectre"]),
    Object.freeze(["\u30B9\u30DA\u30B7\u30E3\u30EB\u30BB\u30FC\u30EB", "eng", "special sale"]),
    Object.freeze(["\u30B9\u30DA\u30B7\u30E3\u30EB\u30D7\u30E9\u30A4\u30B9", "eng", "special price"]),
    Object.freeze(["\u30B9\u30DA\u30B7\u30E3\u30EB\u30FB\u30BB\u30FC\u30EB", "eng", "special sale"]),
    Object.freeze(["\u30B9\u30DA\u30B7\u30E3\u30EB\u30FB\u30D7\u30E9\u30A4\u30B9", "eng", "special price"]),
    Object.freeze(["\u30B9\u30DA\u30C4\u30CA\u30BA", "rus", "spetsnaz"]),
    Object.freeze(["\u30B9\u30DA\u30E9\u30F3\u30B5", "por", "esperan\xE7a"]),
    Object.freeze(["\u30B9\u30DD\u30A4\u30C8", "dut", "spuit"]),
    Object.freeze(["\u30B9\u30DD\u30A4\u30C9", "dut", "spuit"]),
    Object.freeze(["\u30B9\u30DD\u30C3\u30C8\u30A2\u30CA\u30A6\u30F3\u30B9", "eng", "spot announce"]),
    Object.freeze(["\u30B9\u30DD\u30C3\u30C8\u30FB\u30A2\u30CA\u30A6\u30F3\u30B9", "eng", "spot announce"]),
    Object.freeze(["\u30B9\u30DD\u30FC\u30C4\u30AF\u30E9\u30D6", "eng", "sports club"]),
    Object.freeze(["\u30B9\u30DD\u30FC\u30C4\u30FB\u30AF\u30E9\u30D6", "eng", "sports club"]),
    Object.freeze(["\u30B9\u30E0\u30FC\u30B8\u30F3\u30B0\u30AA\u30DA\u30EC\u30FC\u30B7\u30E7\u30F3", "eng", "smoothing operation"]),
    Object.freeze(["\u30B9\u30E0\u30FC\u30B8\u30F3\u30B0\u30FB\u30AA\u30DA\u30EC\u30FC\u30B7\u30E7\u30F3", "eng", "smoothing operation"]),
    Object.freeze(["\u30B9\u30E2\u30AC\u30B9\u30DC\u30FC\u30C9", "swe", "sm\xF6rg\xE5sbord"]),
    Object.freeze(["\u30B9\u30E2\u30FC\u30AC\u30B9\u30DC\u30FC\u30C9", "swe", "sm\xF6rg\xE5sbord"]),
    Object.freeze(["\u30B9\u30E2\u30FC\u30D6\u30ED\u30FC", "dan", "sm\xF8rrebr\xF8d"]),
    Object.freeze(["\u30B9\u30E9\u30ED\u30FC\u30E0", "nor", "slal\xE5m"]),
    Object.freeze(["\u30B9\u30EA\u30AB\u30BF", "lat", "suricata"]),
    Object.freeze(["\u30B9\u30EA\u30AB\u30FC\u30BF", "lat", "suricata"]),
    Object.freeze(["\u30B9\u30EB\u30FC", "eng", "through"]),
    Object.freeze(["\u30B9\u30EC\u30AA\u30CB\u30F3", "ger", "Threonin"]),
    Object.freeze(["\u30B9\u30FC", "chi", "s\xEC"]),
    Object.freeze(["\u30B9\u30FC\u30A2\u30F3\u30B3\u30FC", "chi", "s\xEC \xE0n k\xE8"]),
    Object.freeze(["\u30B9\u30FC\u30AB\u30F3\u30C4", "chi", "s\xEC g\xE0ng zi"]),
    Object.freeze(["\u30B9\u30FC\u30BD\u30FC\u30D1\u30A4", "chi", "s\xEC s\xE8 p\xE1i"]),
    Object.freeze(["\u30B9\u30FC\u30C9\u30E9", "san", "\u015B\u016Bdra"]),
    Object.freeze(["\u30B9\u30FC\u30D1\u30FC\u30A4\u30F3\u30DD\u30FC\u30BA", "eng", "superimpose"]),
    Object.freeze(["\u30B9\u30FC\u30D1\u30FC\u30DC\u30FC\u30EB", "eng", "Super Ball"]),
    Object.freeze(["\u30B9\u30FC\u30D1\u30FC\u30FB\u30DC\u30FC\u30EB", "eng", "Super Ball"]),
    Object.freeze(["\u30B9\u30FC\u30DB\u30F3\u30D1\u30A4", "chi", "s\xEC f\u0113ng p\xE1i"]),
    Object.freeze(["\u30B9\u30FC\u30E9\u30FC\u30BF\u30F3", "chi", "su\u0101n l\xE0 t\u0101ng"]),
    Object.freeze(["\u30BA\u30C3\u30AF", "dut", "doek"]),
    Object.freeze(["\u30BA\u30DC\u30F3", "fre", "jupon"]),
    Object.freeze(["\u30BA\u30EB\u30C1\u30F3", "ger", "Dulzin"]),
    Object.freeze(["\u30BB\u30A4\u30A6\u30C1", "rus", "sivuch"]),
    Object.freeze(["\u30BB\u30A4\u30DF", "dut", "chemie"]),
    Object.freeze(["\u30BB\u30A4\u30EC\u30F3", "gre", "seiren"]),
    Object.freeze(["\u30BB\u30A4\u30EC\u30FC\u30F3", "gre", "seiren"]),
    Object.freeze(["\u30BB\u30AB\u30F3\u30C9\u30E9\u30A4\u30D5", "eng", "second life"]),
    Object.freeze(["\u30BB\u30AB\u30F3\u30C9\u30FB\u30E9\u30A4\u30D5", "eng", "second life"]),
    Object.freeze(["\u30BB\u30AD\u30E5\u30EA\u30C6\u30A3\u30FC\u30B3\u30FC\u30C9", "eng", "security code"]),
    Object.freeze(["\u30BB\u30AD\u30E5\u30EA\u30C6\u30A3\u30FC\u30FB\u30B3\u30FC\u30C9", "eng", "security code"]),
    Object.freeze(["\u30BB\u30AF\u30A8\u30F3\u30C4\u30A3\u30A2", "lat", "sequentia"]),
    Object.freeze(["\u30BB\u30B3\u30A4\u30A2\u30C7\u30F3\u30C9\u30ED\u30F3", "lat", "Sequoiadendron"]),
    Object.freeze(["\u30BB\u30BE\u30F3", "fre", "saison"]),
    Object.freeze(["\u30BB\u30C7\u30A3\u30FC\u30E6", "fre", "c\xE9dille"]),
    Object.freeze(["\u30BB\u30D7\u30C8\u30A5\u30A2\u30AE\u30F3\u30BF", "lat", "Septuaginta"]),
    Object.freeze(["\u30BB\u30DF\u30CA\u30EA\u30AA", "por", "semin\xE1rio"]),
    Object.freeze(["\u30BB\u30DF\u30CA\u30EA\u30E8", "por", "semin\xE1rio"]),
    Object.freeze(["\u30BB\u30EA\u30FC", "fre", "s\xE9rie"]),
    Object.freeze(["\u30BB\u30EB\u30AB", "kor", "selka"]),
    Object.freeze(["\u30BB\u30EB\u30AF\u30EB", "fre", "cercle"]),
    Object.freeze(["\u30BB\u30EB\u30D5\u30A3\u30FC\u30E6", "fre", "cerfeuil"]),
    Object.freeze(["\u30BB\u30EB\u30D5\u30D7\u30EC\u30B8\u30E3\u30FC", "eng", "self-pleasure"]),
    Object.freeze(["\u30BB\u30EB\u30D5\u30FB\u30D7\u30EC\u30B8\u30E3\u30FC", "eng", "self-pleasure"]),
    Object.freeze(["\u30BB\u30EC\u30F3", "ger", "Selen"]),
    Object.freeze(["\u30BB\u30ED\u30C6\u30FC\u30D7", "eng", "cellotape"]),
    Object.freeze(["\u30BB\u30F3\u30B9\u30D5\u30EB", "eng", "sense + full"]),
    Object.freeze(["\u30BB\u30F3\u30C1\u30E1\u30FC\u30BF\u30FC", "fre", "centim\xE8tre"]),
    Object.freeze(["\u30BB\u30F3\u30C1\u30E1\u30FC\u30C8\u30EB", "fre", "centim\xE8tre"]),
    Object.freeze(["\u30BB\u30F3\u30C1\u30E2", "spa", "c\xE9ntino"]),
    Object.freeze(["\u30BB\u30F3\u30C6\u30A3\u30E2", "spa", "c\xE9ntino"]),
    Object.freeze(["\u30BB\u30FC\u30CF", "spa", "ceja"]),
    Object.freeze(["\u30BB\u30FC\u30D7", "dut", "zeep"]),
    Object.freeze(["\u30BB\u30FC\u30DF", "dut", "chemie"]),
    Object.freeze(["\u30BC\u30C3\u30B1\u30F3", "ger", "Decke(n)"]),
    Object.freeze(["\u30BC\u30C4\u30A7\u30B7\u30AA\u30F3", "ger", "Sezession"]),
    Object.freeze(["\u30BC\u30C4\u30A7\u30C3\u30B7\u30E7\u30F3", "ger", "Sezession"]),
    Object.freeze(["\u30BC\u30CD\u30B3\u30F3", "eng", "gene(ral) con(tractor)"]),
    Object.freeze(["\u30BC\u30D5\u30A3\u30EB\u30B9", "lat", "Zephyrus"]),
    Object.freeze(["\u30BC\u30EA\u30FC\u30D5\u30E9\u30A4", "eng", "jelly fry"]),
    Object.freeze(["\u30BC\u30EA\u30FC\u30FB\u30D5\u30E9\u30A4", "eng", "jelly fry"]),
    Object.freeze(["\u30BC\u30F3\u30C1\u30E7", "por", "gentio"]),
    Object.freeze(["\u30BD\u30A2\u30E9\u30FC", "eng", "soarer"]),
    Object.freeze(["\u30BD\u30A6\u30BA", "chi", "su\u01D2 zi"]),
    Object.freeze(["\u30BD\u30B8\u30A6\u30E0", "ger", "Natrium"]),
    Object.freeze(["\u30BD\u30C3\u30D7", "dut", "soep"]),
    Object.freeze(["\u30BD\u30C6\u30FC", "fre", "saut\xE9"]),
    Object.freeze(["\u30BD\u30CA\u30C1\u30CD", "ita", "sonatine"]),
    Object.freeze(["\u30BD\u30D0\u30FC\u30B8\u30E5", "fre", "sauvage"]),
    Object.freeze(["\u30BD\u30D3\u30A8\u30C8", "rus", "sovet"]),
    Object.freeze(["\u30BD\u30D5\u30C8\u30A2\u30A4\u30B9\u30AF\u30EA\u30FC\u30E0", "eng", "soft ice cream"]),
    Object.freeze(["\u30BD\u30D5\u30C8\u30FB\u30A2\u30A4\u30B9\u30AF\u30EA\u30FC\u30E0", "eng", "soft ice cream"]),
    Object.freeze(["\u30BD\u30EA\u30B9\u30C8", "fre", "soliste"]),
    Object.freeze(["\u30BD\u30EB\u30D3\u30C3\u30C8", "ger", "Sorbit"]),
    Object.freeze(["\u30BD\u30EC\u30A4\u30E6", "fre", "soleil"]),
    Object.freeze(["\u30BD\u30ED\u30AD\u30E3\u30F3\u30D7", "eng", "solo camp"]),
    Object.freeze(["\u30BD\u30ED\u30FB\u30AD\u30E3\u30F3\u30D7", "eng", "solo camp"]),
    Object.freeze(["\u30BD\u30EF\u30AB", "san", "sv\u0101h\u0101"]),
    Object.freeze(["\u30BD\u30EF\u30CB\u30A8", "fre", "soigner"]),
    Object.freeze(["\u30BD\u30F3\u30AF\u30E9\u30FC\u30F3", "tha", "songkran"]),
    Object.freeze(["\u30BD\u30F3\u30E0\u30EB", "kor", "seonmul"]),
    Object.freeze(["\u30BD\u30F4\u30A1\u30FC\u30B8\u30E5", "fre", "sauvage"]),
    Object.freeze(["\u30BD\u30F4\u30A3\u30A8\u30C8", "rus", "sovet"]),
    Object.freeze(["\u30BD\u30FC\u30BA", "chi", "su\u01D2 zi"]),
    Object.freeze(["\u30BE\u30EB", "ger", "Sol"]),
    Object.freeze(["\u30BE\u30F3\u30C7", "ger", "Sonde"]),
    Object.freeze(["\u30BF\u30A4\u30A2\u30C3\u30D7", "eng", "tie-up"]),
    Object.freeze(["\u30BF\u30A4\u30AC", "rus", "tayga"]),
    Object.freeze(["\u30BF\u30A4\u30BF\u30A4", "chi", "t\xE0itai"]),
    Object.freeze(["\u30BF\u30A4\u30C9\u30A2\u30C3\u30D7", "eng", "tied up"]),
    Object.freeze(["\u30BF\u30A4\u30C9\u30FB\u30A2\u30C3\u30D7", "eng", "tied up"]),
    Object.freeze(["\u30BF\u30A4\u30D4\u30F3\u30A8\u30F3", "chi", "t\xE0ip\xEDngy\xE0n"]),
    Object.freeze(["\u30BF\u30A4\u30D4\u30FC\u30A8\u30F3", "chi", "t\xE0ip\xEDngy\xE0n"]),
    Object.freeze(["\u30BF\u30A4\u30D7\u30A4\u30F3", "eng", "type in"]),
    Object.freeze(["\u30BF\u30A4\u30D7\u30FB\u30A4\u30F3", "eng", "type in"]),
    Object.freeze(["\u30BF\u30AA", "chi", "d\xE0o"]),
    Object.freeze(["\u30BF\u30AF\u30D1\u30EB", "kor", "dakbal"]),
    Object.freeze(["\u30BF\u30B3\u30B9", "spa", "tacos"]),
    Object.freeze(["\u30BF\u30BF\u30DF\u30BC", "fre", "tatamiser"]),
    Object.freeze(["\u30BF\u30C1\u30E3", "chi", "t\u0101 ji\u0101"]),
    Object.freeze(["\u30BF\u30C3\u30AB\u30F3\u30DE\u30EA", "kor", "dak hanmari"]),
    Object.freeze(["\u30BF\u30C3\u30AF\u30B1\u30FC\u30B9", "eng", "tuck case"]),
    Object.freeze(["\u30BF\u30C3\u30AF\u30FB\u30B1\u30FC\u30B9", "eng", "tuck case"]),
    Object.freeze(["\u30BF\u30C3\u30D1\u30EB", "kor", "dakbal"]),
    Object.freeze(["\u30BF\u30D0\u30B3", "por", "tabaco"]),
    Object.freeze(["\u30BF\u30DE\u30EC", "spa", "tamal"]),
    Object.freeze(["\u30BF\u30DE\u30EC\u30B9", "spa", "tamal"]),
    Object.freeze(["\u30BF\u30DE\u30FC\u30EC", "spa", "tamal"]),
    Object.freeze(["\u30BF\u30DE\u30FC\u30EC\u30B9", "spa", "tamal"]),
    Object.freeze(["\u30BF\u30E1\u30F3\u30C1\u30E3\u30F3", "chi", "du\u014Dmi\xE0n zh\u0101ng"]),
    Object.freeze(["\u30BF\u30E9\u30C3\u30D7", "dut", "trap"]),
    Object.freeze(["\u30BF\u30E9\u30F3\u30C8", "gre", "talanton"]),
    Object.freeze(["\u30BF\u30EA\u30AA", "lat", "talio"]),
    Object.freeze(["\u30BF\u30EB\u30C8\u30EC\u30C3\u30C8", "fre", "tartelette"]),
    Object.freeze(["\u30BF\u30EC\u30F3\u30C8", "eng", "talent"]),
    Object.freeze(["\u30BF\u30EF\u30EA\u30B7\u30C1", "rus", "tovarishch"]),
    Object.freeze(["\u30BF\u30EF\u30FC\u30EA\u30B7\u30C1", "rus", "tovarishch"]),
    Object.freeze(["\u30BF\u30F3\u30A8\u30F3", "chi", "tu\xE1nyu\xE1n"]),
    Object.freeze(["\u30BF\u30F3\u30BF\u30EB", "ger", "Tantal"]),
    Object.freeze(["\u30BF\u30F3\u30BF\u30F3\u30E1\u30F3", "chi", "d\xE0nd\xE0nmi\xE0n"]),
    Object.freeze(["\u30BF\u30F3\u30D6\u30EA\u30F3", "ger", "Tamburin"]),
    Object.freeze(["\u30BF\u30F3\u30DD\u30F3", "ger", "Tampon"]),
    Object.freeze(["\u30BF\u30F3\u30E1\u30F3", "chi", "t\u0101ngmi\xE0n"]),
    Object.freeze(["\u30BF\u30F3\u30E4\u30AA\u30C1\u30E5\u30FC", "chi", "du\xE0n y\u0101o ji\u01D4"]),
    Object.freeze(["\u30BF\u30F3\u30E6\u30A7\u30F3", "chi", "tu\xE1nyu\xE1n"]),
    Object.freeze(["\u30BF\u30F3\u30E6\u30A8\u30F3", "chi", "tu\xE1nyu\xE1n"]),
    Object.freeze(["\u30BF\u30FC\u30B9\u30FC\u30B7\u30FC", "chi", "d\xE0 s\xEC x\u01D0"]),
    Object.freeze(["\u30BF\u30FC\u30C1\u30E3", "chi", "t\u0101 ji\u0101"]),
    Object.freeze(["\u30BF\u30FC\u30C4", "chi", "t\u01CE zi"]),
    Object.freeze(["\u30BF\u30FC\u30D1\u30A4", "chi", "du\u014D p\xE1i"]),
    Object.freeze(["\u30BF\u30FC\u30D5\u30EB", "dut", "tafel"]),
    Object.freeze(["\u30BF\u30FC\u30EC\u30C3\u30C8\u30C8\u30E9\u30C3\u30AF", "eng", "turret truck"]),
    Object.freeze(["\u30BF\u30FC\u30EC\u30C3\u30C8\u30FB\u30C8\u30E9\u30C3\u30AF", "eng", "turret truck"]),
    Object.freeze(["\u30C0\u30A4\u30A2", "eng", "dia(gram)"]),
    Object.freeze(["\u30C0\u30A4\u30A6\u30B9", "lat", "Deus"]),
    Object.freeze(["\u30C0\u30A4\u30CA\u30DE\u30A4\u30C8\u30D0\u30C7\u30A3", "eng", "dynamite body"]),
    Object.freeze(["\u30C0\u30A4\u30CA\u30DE\u30A4\u30C8\u30D0\u30C7\u30A3\u30FC", "eng", "dynamite body"]),
    Object.freeze(["\u30C0\u30A4\u30CA\u30DE\u30A4\u30C8\u30DC\u30C7\u30A3", "eng", "dynamite body"]),
    Object.freeze(["\u30C0\u30A4\u30CA\u30DE\u30A4\u30C8\u30DC\u30C7\u30A3\u30FC", "eng", "dynamite body"]),
    Object.freeze(["\u30C0\u30A4\u30CA\u30DE\u30A4\u30C8\u30FB\u30D0\u30C7\u30A3", "eng", "dynamite body"]),
    Object.freeze(["\u30C0\u30A4\u30CA\u30DE\u30A4\u30C8\u30FB\u30D0\u30C7\u30A3\u30FC", "eng", "dynamite body"]),
    Object.freeze(["\u30C0\u30A4\u30CA\u30DE\u30A4\u30C8\u30FB\u30DC\u30C7\u30A3", "eng", "dynamite body"]),
    Object.freeze(["\u30C0\u30A4\u30CA\u30DE\u30A4\u30C8\u30FB\u30DC\u30C7\u30A3\u30FC", "eng", "dynamite body"]),
    Object.freeze(["\u30C0\u30A4\u30DF\u30F3\u30AB\u30F3", "chi", "d\xE0 m\xEDng g\xE0ng"]),
    Object.freeze(["\u30C0\u30A4\u30E4", "eng", "dia(gram)"]),
    Object.freeze(["\u30C0\u30C0\u30A4\u30B9\u30E0", "fre", "dada\xEFsme"]),
    Object.freeze(["\u30C0\u30C0\u30A4\u30BA\u30E0", "fre", "dada\xEFsme"]),
    Object.freeze(["\u30C0\u30C3\u30AF\u30B9\u30D5\u30F3\u30C8", "ger", "Dachshund"]),
    Object.freeze(["\u30C0\u30C3\u30AF\u30B9\u30D5\u30F3\u30C9", "ger", "Dachshund"]),
    Object.freeze(["\u30C0\u30C3\u30C1\u30EF\u30A4\u30D5", "eng", "Dutch wife"]),
    Object.freeze(["\u30C0\u30C3\u30C1\u30FB\u30EF\u30A4\u30D5", "eng", "Dutch wife"]),
    Object.freeze(["\u30C0\u30E9\u30A4\u30D0\u30F3", "dut", "draaibank"]),
    Object.freeze(["\u30C0\u30EB", "hin", "d\u0101l"]),
    Object.freeze(["\u30C0\u30F3", "eng", "down"]),
    Object.freeze(["\u30C0\u30F3\u30CA", "san", "d\u0101na"]),
    Object.freeze(["\u30C0\u30F3\u30D6\u30EB", "eng", "down below"]),
    Object.freeze(["\u30C0\u30FC\u30B9", "eng", "doz(en)"]),
    Object.freeze(["\u30C0\u30FC\u30E9\u30D8\u30B9\u30C8", "swe", "dalah\xE4st"]),
    Object.freeze(["\u30C0\u30FC\u30EB", "hin", "d\u0101l"]),
    Object.freeze(["\u30C1\u30A2\u30B8\u30F3", "ger", "Thiazin"]),
    Object.freeze(["\u30C1\u30A2\u30CE\u30FC\u30BC", "ger", "Zyanose"]),
    Object.freeze(["\u30C1\u30A7\u30AD", "eng", "check it"]),
    Object.freeze(["\u30C1\u30A7\u30C1\u30A7\u30F3", "rus", "\u010De\u010Den"]),
    Object.freeze(["\u30C1\u30A7\u30F3\u30D0\u30ED", "ita", "cembalo"]),
    Object.freeze(["\u30C1\u30AD\u30F3\u30E0", "kor", "chikinmu"]),
    Object.freeze(["\u30C1\u30AF\u30EB\u30B9", "ger", "Zyklus"]),
    Object.freeze(["\u30C1\u30B2", "kor", "jjigae"]),
    Object.freeze(["\u30C1\u30B8\u30DF", "kor", "jijim"]),
    Object.freeze(["\u30C1\u30BF\u30F3", "ger", "Titan"]),
    Object.freeze(["\u30C1\u30C2\u30DF", "kor", "jijim"]),
    Object.freeze(["\u30C1\u30C3\u30AD", "eng", "check"]),
    Object.freeze(["\u30C1\u30C8\u30AF\u30ED\u30E0", "ger", "Cytochrom"]),
    Object.freeze(["\u30C1\u30D5\u30B9", "ger", "Typhus"]),
    Object.freeze(["\u30C1\u30D6\u30B9", "ger", "Typhus"]),
    Object.freeze(["\u30C1\u30D7\u30B9", "ger", "Typhus"]),
    Object.freeze(["\u30C1\u30DE\u30FC\u30BC", "ger", "Zymase"]),
    Object.freeze(["\u30C1\u30E0", "kor", "jjim"]),
    Object.freeze(["\u30C1\u30E3\u30AA\u30BA", "chi", "ji\u01CEozi"]),
    Object.freeze(["\u30C1\u30E3\u30C1\u30E3\u30C1\u30E3", "spa", "cha cha cha"]),
    Object.freeze(["\u30C1\u30E3\u30C4\u30CD", "hin", "ca\u1E6Dn\u012B"]),
    Object.freeze(["\u30C1\u30E3\u30C8\u30CB", "hin", "ca\u1E6Dn\u012B"]),
    Object.freeze(["\u30C1\u30E3\u30D1\u30C6\u30A3", "hin", "capati"]),
    Object.freeze(["\u30C1\u30E3\u30D1\u30FC\u30C6\u30A3\u30FC", "hin", "capati"]),
    Object.freeze(["\u30C1\u30E3\u30EB\u30E1\u30E9", "por", "charamela"]),
    Object.freeze(["\u30C1\u30E3\u30EB\u30E1\u30EB", "por", "charamela"]),
    Object.freeze(["\u30C1\u30E3\u30EC\u30F3\u30B8\u30C9", "eng", "challenged"]),
    Object.freeze(["\u30C1\u30E3\u30F3", "chi", "zhu\u0101ng"]),
    Object.freeze(["\u30C1\u30E3\u30F3\u30AB\u30F3", "chi", "qi\u0101ng g\xE0ng"]),
    Object.freeze(["\u30C1\u30E3\u30F3\u30B3\u30ED", "chi", "zh\u014Dnggu\xF3r\xE9n"]),
    Object.freeze(["\u30C1\u30E3\u30F3\u30D5\u30A9\u30F3\u30D1\u30A4", "chi", "qu\u0101n f\u0113ng p\xE1i"]),
    Object.freeze(["\u30C1\u30E3\u30FC\u30B7\u30E5\u30FC", "chi", "ch\u0101sh\u0101o"]),
    Object.freeze(["\u30C1\u30E3\u30FC\u30B7\u30E5\u30FC\u30D0\u30AA", "chi", "ch\u0101sh\u0101o b\u0101o"]),
    Object.freeze(["\u30C1\u30E3\u30FC\u30B7\u30E5\u30FC\u30E1\u30F3", "chi", "ch\u0101sh\u0101o mi\xE0n"]),
    Object.freeze(["\u30C1\u30E3\u30FC\u30CF\u30F3", "chi", "ch\u01CEof\xE0n"]),
    Object.freeze(["\u30C1\u30E5\u30A6\u30C1\u30E3\u30F3\u30D1\u30A4", "chi", "zh\u014Dng zh\u0101ng p\xE1i"]),
    Object.freeze(["\u30C1\u30E5\u30CE\u30E0", "vie", "ch\u1EEF n\xF4m"]),
    Object.freeze(["\u30C1\u30E5\u30E9\u30B9\u30B3", "por", "churrasco"]),
    Object.freeze(["\u30C1\u30E5\u30ED\u30B9", "spa", "churros"]),
    Object.freeze(["\u30C1\u30E5\u30F3\u30C1\u30E3\u30F3\u30D1\u30A4", "chi", "zh\u014Dng zh\u0101ng p\xE1i"]),
    Object.freeze(["\u30C1\u30E5\u30FC", "chi", "ji\u01D4"]),
    Object.freeze(["\u30C1\u30E5\u30FC\u30CE\u30E0", "vie", "ch\u1EEF n\xF4m"]),
    Object.freeze(["\u30C1\u30E5\u30FC\u30EC\u30F3\u30D1\u30AA\u30C8\u30A6", "chi", "ji\u01D4li\xE1nb\u01CEod\u0113ng"]),
    Object.freeze(["\u30C1\u30E5\u30FC\u30EC\u30F3\u30DD\u30A6\u30C8\u30A6", "chi", "ji\u01D4li\xE1nb\u01CEod\u0113ng"]),
    Object.freeze(["\u30C1\u30E5\u30FC\u30EC\u30F3\u30DD\u30FC\u30C8\u30FC", "chi", "ji\u01D4li\xE1nb\u01CEod\u0113ng"]),
    Object.freeze(["\u30C1\u30E5\u30FC\u30ED\u30B9", "spa", "churros"]),
    Object.freeze(["\u30C1\u30E7\u30A6\u30C9\u30A6\u30D5", "chi", "ch\xF2ud\xF2ufu"]),
    Object.freeze(["\u30C1\u30E7\u30B3\u30C1\u30C3\u30D7", "eng", "choco chip"]),
    Object.freeze(["\u30C1\u30E7\u30B3\u30C1\u30C3\u30D7\u30AF\u30C3\u30AD\u30FC", "eng", "choco chip cookie"]),
    Object.freeze(["\u30C1\u30E7\u30B3\u30FB\u30C1\u30C3\u30D7", "eng", "choco chip"]),
    Object.freeze(["\u30C1\u30E7\u30B3\u30FB\u30C1\u30C3\u30D7\u30FB\u30AF\u30C3\u30AD\u30FC", "eng", "choco chip cookie"]),
    Object.freeze(["\u30C1\u30E7\u30BD\u30F3\u30AF\u30EB", "kor", "choson'gul"]),
    Object.freeze(["\u30C1\u30E7\u30BD\u30F3\u30B0\u30EB", "kor", "choson'gul"]),
    Object.freeze(["\u30C1\u30E7\u30C3\u30D1\u30EA", "kor", "jjokbari"]),
    Object.freeze(["\u30C1\u30E7\u30F3\u30AC\u30FC", "kor", "ch'onggak"]),
    Object.freeze(["\u30C1\u30E7\u30F3\u30ED\u30F3", "chi", "zh\u0113ngl\xF3ng"]),
    Object.freeze(["\u30C1\u30E7\u30FC\u30AD\u30F3\u30B0", "eng", "choking"]),
    Object.freeze(["\u30C1\u30F3\u30A4\u30FC\u30BD\u30FC", "chi", "q\u012Bng y\u012B s\xE8"]),
    Object.freeze(["\u30C1\u30F3\u30B2\u30F3\u30B5\u30A4", "chi", "q\u012Bngg\u011Bngc\xE0i"]),
    Object.freeze(["\u30C1\u30F3\u30B8\u30E3\u30AA\u30ED\u30A6\u30B9\u30FC", "chi", "q\u012Bngji\u0101o r\xF2us\u012B"]),
    Object.freeze(["\u30C1\u30F3\u30B8\u30E3\u30AA\u30ED\u30FC\u30B9", "chi", "q\u012Bngji\u0101o r\xF2us\u012B"]),
    Object.freeze(["\u30C1\u30F3\u30B8\u30E3\u30AA\u30ED\u30FC\u30B9\u30FC", "chi", "q\u012Bngji\u0101o r\xF2us\u012B"]),
    Object.freeze(["\u30C1\u30F3\u30BF", "por", "(vinho) tinto"]),
    Object.freeze(["\u30C1\u30F3\u30CD", "ger", "Zinne"]),
    Object.freeze(["\u30C1\u30F3\u30E9\u30AA\u30C8\u30A6", "chi", "q\u012Bng l\u01CEo t\xF3u"]),
    Object.freeze(["\u30C1\u30FC\u30B0\u30AA\u30B8\u30FC", "chi", "q\xECgu\u014Dj\u012B"]),
    Object.freeze(["\u30C1\u30FC\u30B3\u30FC\u30B8\u30FC", "chi", "q\xECgu\u014Dj\u012B"]),
    Object.freeze(["\u30C1\u30FC\u30BA\u30C9\u30C3\u30B0", "eng", "cheese dog"]),
    Object.freeze(["\u30C1\u30FC\u30C1\u30E3", "chi", "q\u01D0 ji\u0101"]),
    Object.freeze(["\u30C1\u30FC\u30C8\u30A4\u30C4", "chi", "q\u012B du\xEC zi"]),
    Object.freeze(["\u30C1\u30FC\u30CF", "chi", "z\xEChu\xE1"]),
    Object.freeze(["\u30C1\u30FC\u30CF\u30FC", "chi", "z\xEChu\xE1"]),
    Object.freeze(["\u30C1\u30FC\u30D1\u30AA", "chi", "q\xEDp\xE1o"]),
    Object.freeze(["\u30C1\u30FC\u30D1\u30FC", "chi", "z\xEChu\xE1"]),
    Object.freeze(["\u30C1\u30FC\u30DB\u30FC", "chi", "d\xEC h\xFA"]),
    Object.freeze(["\u30C1\u30FC\u30DE\u30FC\u30B8\u30E3\u30F3", "chi", "zh\u012Bmaji\xE0ng"]),
    Object.freeze(["\u30C1\u30FC\u30E6", "chi", "j\u012B y\xF3u"]),
    Object.freeze(["\u30C4\u30A1\u30A4\u30C1\u30A7\u30F3", "chi", "z\xE0iji\xE0n"]),
    Object.freeze(["\u30C4\u30A1\u30A4\u30C1\u30A8\u30F3", "chi", "z\xE0iji\xE0n"]),
    Object.freeze(["\u30C4\u30A1\u30A4\u30C8\u30AC\u30A4\u30B9\u30C8", "ger", "Zeitgeist"]),
    Object.freeze(["\u30C4\u30A1\u30FC", "rus", "tsar'"]),
    Object.freeze(["\u30C4\u30A1\u30FC\u30EA", "rus", "tsar'"]),
    Object.freeze(["\u30C4\u30A1\u30FC\u30EB", "rus", "tsar'"]),
    Object.freeze(["\u30C4\u30A3\u30AF\u30EB\u30B9", "ger", "Zyklus"]),
    Object.freeze(["\u30C4\u30A7\u30EB\u30C8\u30B6\u30C3\u30AF", "ger", "Zeltsack"]),
    Object.freeze(["\u30C4\u30A9\u30F3\u30E6\u30FC\u30D4\u30F3", "chi", "c\u014Dngy\xF3ub\u01D0ng"]),
    Object.freeze(["\u30C4\u30C3\u30AB", "ger", "Zucker"]),
    Object.freeze(["\u30C4\u30C3\u30AB\u30FC", "ger", "Zucker"]),
    Object.freeze(["\u30C4\u30D1\u30A4", "may", "tupai"]),
    Object.freeze(["\u30C4\u30D9\u30EB\u30AF\u30EA\u30F3", "ger", "Tuberkulin"]),
    Object.freeze(["\u30C4\u30E2", "chi", "z\xECm\u014D"]),
    Object.freeze(["\u30C4\u30F4\u30A1\u30A4\u30CF\u30F3\u30C0\u30FC", "ger", "Zweih\xE4nder"]),
    Object.freeze(["\u30C4\u30F4\u30A1\u30A4\u30D8\u30F3\u30C0\u30FC", "ger", "Zweih\xE4nder"]),
    Object.freeze(["\u30C4\u30FC\u30A4\u30FC\u30BD\u30FC", "chi", "z\xEC y\u012B s\xE8"]),
    Object.freeze(["\u30C4\u30FC\u30D1\u30A4", "chi", "z\xEC p\xE1i"]),
    Object.freeze(["\u30C4\u30FC\u30D6\u30ED\u30C3\u30AF", "eng", "two-block"]),
    Object.freeze(["\u30C4\u30FC\u30E2\u30FC", "chi", "z\xECm\u014D"]),
    Object.freeze(["\u30C4\u30FC\u30FB\u30D6\u30ED\u30C3\u30AF", "eng", "two-block"]),
    Object.freeze(["\u30C6\u30A2\u30C8\u30EB", "fre", "th\xE9\xE2tre"]),
    Object.freeze(["\u30C6\u30A2\u30C8\u30ED", "ita", "teatro"]),
    Object.freeze(["\u30C6\u30A3\u30F3\u30D1\u30CB", "ita", "timpani"]),
    Object.freeze(["\u30C6\u30A3\u30F3\u30D1\u30CB\u30FC", "ita", "timpani"]),
    Object.freeze(["\u30C6\u30AA\u30EA\u30A2", "gre", "the\u014Dria"]),
    Object.freeze(["\u30C6\u30AF\u30CB\u30C3\u30AF", "eng", "technic"]),
    Object.freeze(["\u30C6\u30AF\u30CE\u30DF\u30B9\u30C8", "eng", "techno(logy) (econo)mist"]),
    Object.freeze(["\u30C6\u30B8\u30A7\u30F4\u30A7", "fre", "train \xE0 grande vitesse"]),
    Object.freeze(["\u30C6\u30B9\u30BF\u30FC", "eng", "tester"]),
    Object.freeze(["\u30C6\u30C3\u30AF\u30B9", "eng", "tex(ture)"]),
    Object.freeze(["\u30C6\u30C3\u30C1\u30E3\u30F3", "kor", "daechang"]),
    Object.freeze(["\u30C6\u30C8", "vie", "t\u1EBFt"]),
    Object.freeze(["\u30C6\u30CF\u30F3\u30DF\u30F3\u30B0\u30AF", "kor", "daehan minguk"]),
    Object.freeze(["\u30C6\u30DE", "ger", "Thema"]),
    Object.freeze(["\u30C6\u30EA\u30A2\u30AB", "lat", "theriaca"]),
    Object.freeze(["\u30C6\u30EB\u30DA\u30F3", "ger", "Terpen"]),
    Object.freeze(["\u30C6\u30EB\u30DF\u30C3\u30C8", "ger", "Thermit"]),
    Object.freeze(["\u30C6\u30EB\u30EB", "ger", "Tellur"]),
    Object.freeze(["\u30C6\u30EC\u30D5\u30A9\u30F3\u30BB\u30C3\u30AF\u30B9", "eng", "telephone sex"]),
    Object.freeze(["\u30C6\u30EC\u30D5\u30A9\u30F3\u30FB\u30BB\u30C3\u30AF\u30B9", "eng", "telephone sex"]),
    Object.freeze(["\u30C6\u30EC\u30DB\u30F3\u30BB\u30C3\u30AF\u30B9", "eng", "telephone sex"]),
    Object.freeze(["\u30C6\u30EC\u30DB\u30F3\u30FB\u30BB\u30C3\u30AF\u30B9", "eng", "telephone sex"]),
    Object.freeze(["\u30C6\u30ED\u30C3\u30D7", "eng", "Telop"]),
    Object.freeze(["\u30C6\u30ED\u30EB", "ger", "Terror"]),
    Object.freeze(["\u30C6\u30F3\u30B8\u30E3\u30F3", "kor", "doenjang"]),
    Object.freeze(["\u30C6\u30F3\u30BF\u30B5\u30F3", "por", "tenta\xE7\xE3o"]),
    Object.freeze(["\u30C6\u30F3\u30D1\u30A4", "chi", "t\u012Bngp\xE1i"]),
    Object.freeze(["\u30C6\u30F3\u30D7\u30E9", "por", "tempero"]),
    Object.freeze(["\u30C6\u30F3\u30DB\u30FC", "chi", "ti\u0101n h\xFA"]),
    Object.freeze(["\u30C6\u30F3\u30E1\u30F3\u30B8\u30E3\u30F3", "chi", "ti\xE1nmi\xE0nji\xE0ng"]),
    Object.freeze(["\u30C6\u30FB\u30B8\u30A7\u30FB\u30F4\u30A7", "fre", "train \xE0 grande vitesse"]),
    Object.freeze(["\u30C6\u30FC\u30BC", "ger", "These"]),
    Object.freeze(["\u30C6\u30FC\u30DE", "ger", "Thema"]),
    Object.freeze(["\u30C7\u30A3\u30A2\u30D6\u30ED", "ita", "diavolo"]),
    Object.freeze(["\u30C7\u30A3\u30A2\u30DC\u30ED", "ita", "diavolo"]),
    Object.freeze(["\u30C7\u30A3\u30A2\u30EC\u30AF\u30C6\u30A3\u30FC\u30AF", "ger", "Dialektik"]),
    Object.freeze(["\u30C7\u30A3\u30B9\u30AF\u30AB\u30C3\u30BF\u30FC", "eng", "disc cutter"]),
    Object.freeze(["\u30C7\u30A3\u30B9\u30AF\u30FB\u30AB\u30C3\u30BF\u30FC", "eng", "disc cutter"]),
    Object.freeze(["\u30C7\u30A3\u30B9\u30AF\u30FC\u30EB", "fre", "discours"]),
    Object.freeze(["\u30C7\u30A3\u30B9\u30B3\u30C6\u30FC\u30AF", "fre", "discoth\xE8que"]),
    Object.freeze(["\u30C7\u30A3\u30B9\u30DD\u30FC\u30B6\u30FC", "eng", "disposer"]),
    Object.freeze(["\u30C7\u30A3\u30D5\u30A9\u30EB\u30E1", "fre", "d\xE9former"]),
    Object.freeze(["\u30C7\u30A3\u30FC\u30BC\u30EB\u30AB\u30FC", "eng", "diesel car"]),
    Object.freeze(["\u30C7\u30A3\u30FC\u30BC\u30EB\u30FB\u30AB\u30FC", "eng", "diesel car"]),
    Object.freeze(["\u30C7\u30A6\u30B9", "lat", "Deus"]),
    Object.freeze(["\u30C7\u30AB", "fre", "d\xE9ca"]),
    Object.freeze(["\u30C7\u30AB\u30A2\u30FC\u30EB", "fre", "d\xE9care"]),
    Object.freeze(["\u30C7\u30AB\u30C0\u30F3", "fre", "d\xE9cadent"]),
    Object.freeze(["\u30C7\u30AB\u30C0\u30F3\u30B9", "fre", "d\xE9cadence"]),
    Object.freeze(["\u30C7\u30AB\u30D6\u30EA\u30B9\u30C8", "rus", "Dekabrist"]),
    Object.freeze(["\u30C7\u30AB\u30E1\u30FC\u30C8\u30EB", "fre", "d\xE9cam\xE8tre"]),
    Object.freeze(["\u30C7\u30AB\u30EB\u30B3\u30DE\u30CB\u30FC", "fre", "d\xE9calcomanie"]),
    Object.freeze(["\u30C7\u30AB\u30F3\u30BF\u30FC\u30B8\u30E5", "fre", "d\xE9cantage"]),
    Object.freeze(["\u30C7\u30AB\u30FC\u30EB", "fre", "d\xE9care"]),
    Object.freeze(["\u30C7\u30AD\u30E3\u30F3\u30BF\u30FC\u30B8\u30E5", "fre", "d\xE9cantage"]),
    Object.freeze(["\u30C7\u30AF\u30E9\u30C3\u30BB", "fre", "d\xE9class\xE9"]),
    Object.freeze(["\u30C7\u30B0\u30EC\u30FC\u30C9", "eng", "degrade"]),
    Object.freeze(["\u30C7\u30B7\u30B0\u30E9\u30E0", "fre", "d\xE9cigramme"]),
    Object.freeze(["\u30C7\u30B7\u30CD", "fre", "dessiner"]),
    Object.freeze(["\u30C7\u30B7\u30E1\u30FC\u30C8\u30EB", "fre", "d\xE9cim\xE8tre"]),
    Object.freeze(["\u30C7\u30B7\u30EA\u30C3\u30C8\u30EB", "fre", "d\xE9cilitre"]),
    Object.freeze(["\u30C7\u30BF\u30F3\u30C8", "fre", "d\xE9tente"]),
    Object.freeze(["\u30C7\u30C3\u30B5\u30F3", "fre", "dessin"]),
    Object.freeze(["\u30C7\u30C3\u30C9\u30DC\u30FC\u30EB", "eng", "dead ball"]),
    Object.freeze(["\u30C7\u30C3\u30C9\u30FB\u30DC\u30FC\u30EB", "eng", "dead ball"]),
    Object.freeze(["\u30C7\u30D3\u30E5\u30A6", "fre", "d\xE9but"]),
    Object.freeze(["\u30C7\u30D3\u30E5\u30BF\u30F3\u30C8", "fre", "d\xE9butante"]),
    Object.freeze(["\u30C7\u30D3\u30E5\u30FC", "fre", "d\xE9but"]),
    Object.freeze(["\u30C7\u30D5\u30A9\u30EB\u30E1", "fre", "d\xE9former"]),
    Object.freeze(["\u30C7\u30D5\u30E9\u30B0\u30C4\u30FC\u30EB", "eng", "defrag tool"]),
    Object.freeze(["\u30C7\u30D6\u30EA", "fre", "d\xE9bris"]),
    Object.freeze(["\u30C7\u30DD", "fre", "d\xE9p\xF4t"]),
    Object.freeze(["\u30C7\u30DD\u30FC", "fre", "d\xE9p\xF4t"]),
    Object.freeze(["\u30C7\u30DE\u30B4\u30AE\u30FC", "ger", "Demagogie"]),
    Object.freeze(["\u30C7\u30DE\u30B4\u30FC\u30B0", "ger", "Demagog"]),
    Object.freeze(["\u30C7\u30DF\u30A6\u30EB\u30B4\u30B9", "gre", "demiourgos"]),
    Object.freeze(["\u30C7\u30DF\u30BF\u30B9", "fre", "demi-tasse"]),
    Object.freeze(["\u30C7\u30E2\u30C6\u30A3\u30AD", "gre", "dimotiki"]),
    Object.freeze(["\u30C7\u30E2\u30FC\u30CB\u30C3\u30B7\u30E5", "ger", "d\xE4monisch"]),
    Object.freeze(["\u30C7\u30E5\u30A2\u30EB\u30BF\u30A4\u30E0\u30EC\u30FC\u30B9", "eng", "dual time race"]),
    Object.freeze(["\u30C7\u30E5\u30A2\u30EB\u30FB\u30BF\u30A4\u30E0\u30FB\u30EC\u30FC\u30B9", "eng", "dual time race"]),
    Object.freeze(["\u30C7\u30E5\u30CA\u30FC\u30DF\u30AF", "ger", "Dynamik"]),
    Object.freeze(["\u30C7\u30E9\u30B7\u30CD", "fre", "d\xE9racin\xE9"]),
    Object.freeze(["\u30C7\u30EA\u30AB\u30C6\u30C3\u30BB\u30F3", "ger", "Delikatessen"]),
    Object.freeze(["\u30C7\u30F3\u30C9\u30ED\u30D3\u30A6\u30E0", "lat", "dendrobium"]),
    Object.freeze(["\u30C7\u30FC\u30BF\u30C1\u30A7\u30C3\u30AF", "eng", "data check"]),
    Object.freeze(["\u30C7\u30FC\u30BF\u30FB\u30C1\u30A7\u30C3\u30AF", "eng", "data check"]),
    Object.freeze(["\u30C7\u30FC\u30BF\u30FC\u30C1\u30A7\u30C3\u30AF", "eng", "data check"]),
    Object.freeze(["\u30C7\u30FC\u30C8\u30AF\u30E9\u30D6", "eng", "date club"]),
    Object.freeze(["\u30C7\u30FC\u30C8\u30FB\u30AF\u30E9\u30D6", "eng", "date club"]),
    Object.freeze(["\u30C8\u30A4\u30C4", "chi", "du\xEC zi"]),
    Object.freeze(["\u30C8\u30A4\u30C8\u30A4\u30DB\u30FC", "chi", "du\xEC dui h\xFA"]),
    Object.freeze(["\u30C8\u30A4\u30E1\u30F3", "chi", "du\xECmi\xE0n"]),
    Object.freeze(["\u30C8\u30A5\u30F3\u30AB\u30ED\u30F3", "kor", "ttungkalong"]),
    Object.freeze(["\u30C8\u30A6\u30C1", "chi", "d\xF2uch\u01D0"]),
    Object.freeze(["\u30C8\u30A6\u30C1\u30B8\u30E3\u30F3", "chi", "d\xF2uch\u01D0ji\xE0ng"]),
    Object.freeze(["\u30C8\u30A6\u30C1\u30FC", "chi", "d\xF2uch\u01D0"]),
    Object.freeze(["\u30C8\u30A6\u30C1\u30FC\u30B8\u30E3\u30F3", "chi", "d\xF2uch\u01D0ji\xE0ng"]),
    Object.freeze(["\u30C8\u30A6\u30D5\u30A1", "chi", "d\xF2uhu\u0101"]),
    Object.freeze(["\u30C8\u30A6\u30D5\u30CA\u30AA", "chi", "d\xF2ufun\u01CEo"]),
    Object.freeze(["\u30C8\u30AD\u30B7\u30F3", "ger", "Toxin"]),
    Object.freeze(["\u30C8\u30BF\u30F3", "por", "tutanaga"]),
    Object.freeze(["\u30C8\u30C3\u30D7\u30DA\u30FC\u30B8", "eng", "top page"]),
    Object.freeze(["\u30C8\u30C3\u30D7\u30E1\u30CB\u30E5\u30FC", "eng", "top menu"]),
    Object.freeze(["\u30C8\u30C3\u30D7\u30E1\u30FC\u30AB", "eng", "top maker"]),
    Object.freeze(["\u30C8\u30C3\u30D7\u30E1\u30FC\u30AB\u30FC", "eng", "top maker"]),
    Object.freeze(["\u30C8\u30C3\u30D7\u30FB\u30DA\u30FC\u30B8", "eng", "top page"]),
    Object.freeze(["\u30C8\u30C3\u30D7\u30FB\u30E1\u30CB\u30E5\u30FC", "eng", "top menu"]),
    Object.freeze(["\u30C8\u30C3\u30D7\u30FB\u30E1\u30FC\u30AB\u30FC", "eng", "top maker"]),
    Object.freeze(["\u30C8\u30C8\u30AB\u30EB\u30C1\u30E7", "ita", "totocalcio"]),
    Object.freeze(["\u30C8\u30E9\u30D0\u30FC\u30E6", "fre", "travail"]),
    Object.freeze(["\u30C8\u30E9\u30E0\u30D7", "eng", "trump"]),
    Object.freeze(["\u30C8\u30E9\u30F3\u30AF\u30EB\u30FC\u30E0", "eng", "trunk room"]),
    Object.freeze(["\u30C8\u30E9\u30F3\u30AF\u30FB\u30EB\u30FC\u30E0", "eng", "trunk room"]),
    Object.freeze(["\u30C8\u30E9\u30F3\u30B9", "eng", "trans(former)"]),
    Object.freeze(["\u30C8\u30E9\u30F3\u30D7", "eng", "trump"]),
    Object.freeze(["\u30C8\u30E9\u30F3\u30D7\u30AB\u30FC\u30C9", "eng", "trump card"]),
    Object.freeze(["\u30C8\u30E9\u30F3\u30D7\u30B2\u30FC\u30E0", "eng", "trump game"]),
    Object.freeze(["\u30C8\u30E9\u30F3\u30D7\u30FB\u30AB\u30FC\u30C9", "eng", "trump card"]),
    Object.freeze(["\u30C8\u30E9\u30F3\u30D7\u30FB\u30B2\u30FC\u30E0", "eng", "trump game"]),
    Object.freeze(["\u30C8\u30EA\u30A6\u30E0", "ger", "Thorium"]),
    Object.freeze(["\u30C8\u30EA\u30B3\u30ED\u30FC\u30EB", "fre", "tricolore"]),
    Object.freeze(["\u30C8\u30EA\u30C3\u30D1", "ita", "trippa"]),
    Object.freeze(["\u30C8\u30EA\u30C3\u30DA\u30EB", "ger", "Tripper"]),
    Object.freeze(["\u30C8\u30EA\u30C8\u30DE", "lat", "tritoma"]),
    Object.freeze(["\u30C8\u30EA\u30D1\u30CE\u30BD\u30FC\u30DE", "lat", "Trypanosoma"]),
    Object.freeze(["\u30C8\u30EA\u30D1\u30CE\u30BE\u30FC\u30DE", "lat", "Trypanosoma"]),
    Object.freeze(["\u30C8\u30EA\u30E5\u30D5", "fre", "truffe"]),
    Object.freeze(["\u30C8\u30EB\u30B3", "por", "Turco"]),
    Object.freeze(["\u30C8\u30EC\u30AA\u30CB\u30F3", "ger", "Threonin"]),
    Object.freeze(["\u30C8\u30EC\u30D3\u30A2\u30F3", "fre", "tr\xE8s bien"]),
    Object.freeze(["\u30C8\u30EC\u30D3\u30B9", "fre", "tr\xE9vise"]),
    Object.freeze(["\u30C8\u30EC\u30DE", "fre", "tr\xE9ma"]),
    Object.freeze(["\u30C8\u30EC\u30F4\u30A3\u30A2\u30F3", "fre", "tr\xE8s bien"]),
    Object.freeze(["\u30C8\u30EC\u30F4\u30A3\u30B9", "fre", "tr\xE9vise"]),
    Object.freeze(["\u30C8\u30EC\u30FB\u30D3\u30A2\u30F3", "fre", "tr\xE8s bien"]),
    Object.freeze(["\u30C8\u30EC\u30FB\u30F4\u30A3\u30A2\u30F3", "fre", "tr\xE8s bien"]),
    Object.freeze(["\u30C8\u30ED\u30A4\u30AB", "rus", "troyka"]),
    Object.freeze(["\u30C8\u30ED\u30A4\u30C7", "ger", "Tholoide"]),
    Object.freeze(["\u30C8\u30ED\u30C3\u30B3", "eng", "truck"]),
    Object.freeze(["\u30C8\u30EF\u30A8\u30E2\u30A2", "fre", "toi et moi"]),
    Object.freeze(["\u30C8\u30EF\u30FB\u30A8\u30FB\u30E2\u30A2", "fre", "toi et moi"]),
    Object.freeze(["\u30C8\u30F3", "chi", "d\u014Dng"]),
    Object.freeze(["\u30C8\u30F3\u30B9\u30EB", "kor", "ttongsul"]),
    Object.freeze(["\u30C8\u30F3\u30C1\u30E3\u30F3", "kor", "ttongjang"]),
    Object.freeze(["\u30C8\u30F3\u30D8", "kor", "donghae"]),
    Object.freeze(["\u30C8\u30F3\u30DD\u30FC\u30ED\u30A6", "chi", "d\u014Dngp\u014Dr\xF2u"]),
    Object.freeze(["\u30C8\u30F3\u30DD\u30FC\u30ED\u30FC", "chi", "d\u014Dngp\u014Dr\xF2u"]),
    Object.freeze(["\u30C8\u30FC\u30AB\u30D6\u30EB", "eng", "talkable"]),
    Object.freeze(["\u30C8\u30FC\u30C1\u30AB", "rus", "tochka"]),
    Object.freeze(["\u30C8\u30FC\u30C1\u30FC", "chi", "d\xF2uch\u01D0"]),
    Object.freeze(["\u30C8\u30FC\u30D0\u30F3\u30B8\u30E3\u30F3", "chi", "d\xF2ub\xE0nji\xE0ng"]),
    Object.freeze(["\u30C8\u30FC\u30F3\u30C0\u30A6\u30F3", "eng", "tone down"]),
    Object.freeze(["\u30C8\u30FC\u30F3\u30FB\u30C0\u30A6\u30F3", "eng", "tone down"]),
    Object.freeze(["\u30C9\u30A2\u30DC\u30FC\u30A4", "eng", "door boy"]),
    Object.freeze(["\u30C9\u30A2\u30DF\u30E9\u30FC", "eng", "door mirror"]),
    Object.freeze(["\u30C9\u30A2\u30FB\u30DC\u30FC\u30A4", "eng", "door boy"]),
    Object.freeze(["\u30C9\u30A2\u30FB\u30DF\u30E9\u30FC", "eng", "door mirror"]),
    Object.freeze(["\u30C9\u30A4\u30C1\u30E5\u30E9\u30F3\u30C8", "ger", "Deutschland"]),
    Object.freeze(["\u30C9\u30A4\u30C1\u30E5\u30E9\u30F3\u30C9", "ger", "Deutschland"]),
    Object.freeze(["\u30C9\u30A4\u30C4", "dut", "Duits"]),
    Object.freeze(["\u30C9\u30A4\u30E2\u30A4", "vie", "\u0110\u1ED5i M\u1EDBi"]),
    Object.freeze(["\u30C9\u30A5\u30AA\u30E2", "ita", "duomo"]),
    Object.freeze(["\u30C9\u30A6\u30C1", "chi", "d\xF2uch\u01D0"]),
    Object.freeze(["\u30C9\u30A6\u30C1\u30FC", "chi", "d\xF2uch\u01D0"]),
    Object.freeze(["\u30C9\u30A6\u30D5\u30CA\u30AA", "chi", "d\xF2ufun\u01CEo"]),
    Object.freeze(["\u30C9\u30A6\u30DB\u30EF", "chi", "d\xF2uhu\u0101"]),
    Object.freeze(["\u30C9\u30C3\u30B0\u30A4\u30E4\u30FC", "eng", "dog year"]),
    Object.freeze(["\u30C9\u30C3\u30B0\u30FB\u30A4\u30E4\u30FC", "eng", "dog year"]),
    Object.freeze(["\u30C9\u30C3\u30DA\u30EB\u30B2\u30F3\u30AC\u30FC", "ger", "Doppelg\xE4nger"]),
    Object.freeze(["\u30C9\u30CD\u30EB\u30B1\u30D0\u30D6", "tur", "d\xF6ner kebap"]),
    Object.freeze(["\u30C9\u30CD\u30EB\u30FB\u30B1\u30D0\u30D6", "tur", "d\xF6ner kebap"]),
    Object.freeze(["\u30C9\u30DF\u30BF\u30B9", "fre", "demi-tasse"]),
    Object.freeze(["\u30C9\u30DF\u30CB\u30AB", "lat", "dominica"]),
    Object.freeze(["\u30C9\u30DF\u30F3\u30B4", "por", "domingo"]),
    Object.freeze(["\u30C9\u30E9\u30DE\u30C4\u30EB\u30AE\u30FC", "ger", "Dramaturgie"]),
    Object.freeze(["\u30C9\u30EA\u30A2", "ita", "Doria"]),
    Object.freeze(["\u30C9\u30EA\u30CD", "ger", "Doline"]),
    Object.freeze(["\u30C9\u30EA\u30E5\u30A2\u30B9", "gre", "dry\xE1s"]),
    Object.freeze(["\u30C9\u30EA\u30FC\u30CD", "ger", "Doline"]),
    Object.freeze(["\u30C9\u30EB\u30B7\u30E7\u30C3\u30AF", "eng", "dollar shock"]),
    Object.freeze(["\u30C9\u30EB\u30C1\u30A7", "ita", "dolce"]),
    Object.freeze(["\u30C9\u30EB\u30FB\u30B7\u30E7\u30C3\u30AF", "eng", "dollar shock"]),
    Object.freeze(["\u30C9\u30EC\u30B9\u30A2\u30C3\u30D7", "eng", "dress up"]),
    Object.freeze(["\u30C9\u30EC\u30B9\u30FB\u30A2\u30C3\u30D7", "eng", "dress up"]),
    Object.freeze(["\u30C9\u30EC\u30C3\u30B8", "eng", "dredge"]),
    Object.freeze(["\u30C9\u30ED\u30F3\u30B1\u30F3", "dut", "dronken"]),
    Object.freeze(["\u30C9\u30F3", "vie", "\u0111\u1ED3ng"]),
    Object.freeze(["\u30C9\u30F3\u30BF\u30AF", "dut", "zondag"]),
    Object.freeze(["\u30C9\u30F3\u30DD\u30FC\u30ED\u30A6", "chi", "d\u014Dngp\u014Dr\xF2u"]),
    Object.freeze(["\u30C9\u30F3\u30DD\u30FC\u30ED\u30FC", "chi", "d\u014Dngp\u014Dr\xF2u"]),
    Object.freeze(["\u30C9\u30F3\u30DE\u30A4", "eng", "don't mind"]),
    Object.freeze(["\u30C9\u30FC\u30AF", "eng", "dawk (dove + hawk)"]),
    Object.freeze(["\u30C9\u30FC\u30EA\u30A2", "ita", "Doria"]),
    Object.freeze(["\u30CA\u30A4\u30A2\u30B9", "gre", "Naias"]),
    Object.freeze(["\u30CA\u30A4\u30F3", "ger", "nein"]),
    Object.freeze(["\u30CA\u30A4\u30FC\u30D6", "eng", "naive"]),
    Object.freeze(["\u30CA\u30A4\u30FC\u30F4", "eng", "naive"]),
    Object.freeze(["\u30CA\u30B6\u30EB\u30DC\u30F3\u30B8\u30E5", "tur", "nazar boncu\u011Fu"]),
    Object.freeze(["\u30CA\u30B6\u30EB\u30DC\u30F3\u30B8\u30E5\u30A6", "tur", "nazar boncu\u011Fu"]),
    Object.freeze(["\u30CA\u30B6\u30EB\u30FB\u30DC\u30F3\u30B8\u30E5", "tur", "nazar boncu\u011Fu"]),
    Object.freeze(["\u30CA\u30B6\u30EB\u30FB\u30DC\u30F3\u30B8\u30E5\u30A6", "tur", "nazar boncu\u011Fu"]),
    Object.freeze(["\u30CA\u30B6\u30FC\u30EB\u30DC\u30F3\u30B8\u30E5", "tur", "nazar boncu\u011Fu"]),
    Object.freeze(["\u30CA\u30B6\u30FC\u30EB\u30DC\u30F3\u30B8\u30E5\u30A6", "tur", "nazar boncu\u011Fu"]),
    Object.freeze(["\u30CA\u30B6\u30FC\u30EB\u30DC\u30F3\u30B8\u30E5\u30FC", "tur", "nazar boncu\u011Fu"]),
    Object.freeze(["\u30CA\u30B6\u30FC\u30EB\u30FB\u30DC\u30F3\u30B8\u30E5", "tur", "nazar boncu\u011Fu"]),
    Object.freeze(["\u30CA\u30B6\u30FC\u30EB\u30FB\u30DC\u30F3\u30B8\u30E5\u30A6", "tur", "nazar boncu\u011Fu"]),
    Object.freeze(["\u30CA\u30B6\u30FC\u30EB\u30FB\u30DC\u30F3\u30B8\u30E5\u30FC", "tur", "nazar boncu\u011Fu"]),
    Object.freeze(["\u30CA\u30BF\u30A6", "por", "Natal"]),
    Object.freeze(["\u30CA\u30BF\u30EB", "por", "Natal"]),
    Object.freeze(["\u30CA\u30C1\u30B9", "ger", "Nazis"]),
    Object.freeze(["\u30CA\u30C1\u30E5\u30E9\u30EB\u30E1\u30A4\u30AD\u30E3\u30C3\u30D7", "eng", "natural makeup"]),
    Object.freeze(["\u30CA\u30C1\u30E5\u30E9\u30EB\u30E1\u30A4\u30AF\u30A2\u30C3\u30D7", "eng", "natural makeup"]),
    Object.freeze(["\u30CA\u30C1\u30E5\u30E9\u30EB\u30E1\u30FC\u30AD\u30E3\u30C3\u30D7", "eng", "natural makeup"]),
    Object.freeze(["\u30CA\u30C1\u30E5\u30E9\u30EB\u30E1\u30FC\u30AF\u30A2\u30C3\u30D7", "eng", "natural makeup"]),
    Object.freeze(["\u30CA\u30C1\u30E5\u30E9\u30EB\u30FB\u30E1\u30A4\u30AD\u30E3\u30C3\u30D7", "eng", "natural makeup"]),
    Object.freeze(["\u30CA\u30C1\u30E5\u30E9\u30EB\u30FB\u30E1\u30A4\u30AF\u30A2\u30C3\u30D7", "eng", "natural makeup"]),
    Object.freeze(["\u30CA\u30C1\u30E5\u30E9\u30EB\u30FB\u30E1\u30FC\u30AD\u30E3\u30C3\u30D7", "eng", "natural makeup"]),
    Object.freeze(["\u30CA\u30C1\u30E5\u30E9\u30EB\u30FB\u30E1\u30FC\u30AF\u30A2\u30C3\u30D7", "eng", "natural makeup"]),
    Object.freeze(["\u30CA\u30C3\u30D7\u30B5\u30C3\u30AF", "ger", "Knappsack"]),
    Object.freeze(["\u30CA\u30C3\u30D7\u30B6\u30C3\u30AF", "ger", "Knappsack"]),
    Object.freeze(["\u30CA\u30C4\u30E9", "por", "natura"]),
    Object.freeze(["\u30CA\u30C4\u30FC\u30E9", "por", "natura"]),
    Object.freeze(["\u30CA\u30C8\u30EA\u30A6\u30E0", "ger", "Natrium"]),
    Object.freeze(["\u30CA\u30C8\u30EA\u30A6\u30E0\u30A2\u30DE\u30EB\u30AC\u30E0", "ger", "Natriumamalgam"]),
    Object.freeze(["\u30CA\u30D5\u30BF\u30EA\u30F3", "ger", "Naphthalin"]),
    Object.freeze(["\u30CA\u30DD\u30EA\u30BF\u30F3", "fre", "napolitain"]),
    Object.freeze(["\u30CA\u30E0\u30D7\u30E9\u30FC", "tha", "nam pla"]),
    Object.freeze(["\u30CA\u30E6\u30BF", "san", "nayuta"]),
    Object.freeze(["\u30CA\u30EB\u30AD\u30C3\u30BD\u30B9", "gre", "narkissos"]),
    Object.freeze(["\u30CA\u30EB\u30B7\u30B7\u30B9\u30E0", "fre", "narcissisme"]),
    Object.freeze(["\u30CA\u30EB\u30B7\u30B9", "fre", "Narcisse"]),
    Object.freeze(["\u30CA\u30EB\u30C1\u30B7\u30BA\u30E0", "fre", "narcissisme"]),
    Object.freeze(["\u30CA\u30ED\u30FC\u30C9\u30CB\u30AD", "rus", "narodniki"]),
    Object.freeze(["\u30CA\u30F3", "chi", "n\xE1n"]),
    Object.freeze(["\u30CA\u30F3\u30D0\u30FC\u30D7\u30EC\u30A4\u30B9", "eng", "number place"]),
    Object.freeze(["\u30CA\u30F3\u30D0\u30FC\u30D7\u30EC\u30FC\u30B9", "eng", "number place"]),
    Object.freeze(["\u30CA\u30F3\u30D0\u30FC\u30FB\u30D7\u30EC\u30A4\u30B9", "eng", "number place"]),
    Object.freeze(["\u30CA\u30F3\u30D0\u30FC\u30FB\u30D7\u30EC\u30FC\u30B9", "eng", "number place"]),
    Object.freeze(["\u30CA\u30F3\u30D7\u30E9\u30FC", "tha", "nam pla"]),
    Object.freeze(["\u30CA\u30FC\u30A4\u30A2\u30B9", "gre", "Naias"]),
    Object.freeze(["\u30CA\u30FC\u30B9\u30B3\u30FC\u30EB", "eng", "nurse call"]),
    Object.freeze(["\u30CA\u30FC\u30B9\u30FB\u30B3\u30FC\u30EB", "eng", "nurse call"]),
    Object.freeze(["\u30CB\u30A2\u30B7\u30E7\u30A2", "eng", "nearshore"]),
    Object.freeze(["\u30CB\u30A4\u30CF\u30AA", "chi", "n\u01D0 h\u01CEo"]),
    Object.freeze(["\u30CB\u30A7\u30C3\u30C8", "rus", "nyet"]),
    Object.freeze(["\u30CB\u30A8\u30C3\u30C8", "rus", "nyet"]),
    Object.freeze(["\u30CB\u30AA\u30D6", "ger", "Niob"]),
    Object.freeze(["\u30CB\u30C0", "kor", "ni-da"]),
    Object.freeze(["\u30CB\u30D2\u30EB", "lat", "nihil"]),
    Object.freeze(["\u30CB\u30E5\u30FC\u30C8\u30ED", "kor", "nyuteulo"]),
    Object.freeze(["\u30CB\u30E5\u30FC\u30D5\u30A7\u30A4\u30B9", "eng", "new face"]),
    Object.freeze(["\u30CB\u30E5\u30FC\u30D5\u30A7\u30FC\u30B9", "eng", "new face"]),
    Object.freeze(["\u30CB\u30E5\u30FC\u30FB\u30D5\u30A7\u30A4\u30B9", "eng", "new face"]),
    Object.freeze(["\u30CB\u30E5\u30FC\u30FB\u30D5\u30A7\u30FC\u30B9", "eng", "new face"]),
    Object.freeze(["\u30CB\u30E7\u30A6\u30ED\u30A6\u30DF\u30A7\u30F3", "chi", "ni\xFAr\xF2u mi\xE0n"]),
    Object.freeze(["\u30CB\u30E7\u30A6\u30ED\u30FC\u30E1\u30F3", "chi", "ni\xFAr\xF2u mi\xE0n"]),
    Object.freeze(["\u30CB\u30E7\u30AF\u30DE\u30E0", "vie", "n\u01B0\u1EDBc m\u1EAFm"]),
    Object.freeze(["\u30CB\u30E7\u30AF\u30FB\u30DE\u30E0", "vie", "n\u01B0\u1EDBc m\u1EAFm"]),
    Object.freeze(["\u30CB\u30FC\u30CF\u30AA", "chi", "n\u01D0 h\u01CEo"]),
    Object.freeze(["\u30CC\u30AF\u30C6\u30FC", "kor", "neuktai"]),
    Object.freeze(["\u30CC\u30AF\u30DE\u30E0", "vie", "n\u01B0\u1EDBc m\u1EAFm"]),
    Object.freeze(["\u30CC\u30AF\u30FB\u30DE\u30E0", "vie", "n\u01B0\u1EDBc m\u1EAFm"]),
    Object.freeze(["\u30CC\u30C3\u30AF\u30DE\u30E0", "vie", "n\u01B0\u1EDBc m\u1EAFm"]),
    Object.freeze(["\u30CC\u30C3\u30AF\u30FB\u30DE\u30E0", "vie", "n\u01B0\u1EDBc m\u1EAFm"]),
    Object.freeze(["\u30CC\u30EF\u30FC\u30EB", "fre", "noir"]),
    Object.freeze(["\u30CC\u30FC\u30D9\u30EB", "fre", "nouvelle"]),
    Object.freeze(["\u30CC\u30FC\u30D9\u30EB\u30D0\u30FC\u30B0", "fre", "Nouvelle Vague"]),
    Object.freeze(["\u30CC\u30FC\u30D9\u30EB\u30FB\u30D0\u30FC\u30B0", "fre", "Nouvelle Vague"]),
    Object.freeze(["\u30CC\u30FC\u30DC", "fre", "nouveau"]),
    Object.freeze(["\u30CC\u30FC\u30DC\u30FC", "fre", "nouveau"]),
    Object.freeze(["\u30CC\u30FC\u30F4\u30A7\u30EB", "fre", "nouvelle"]),
    Object.freeze(["\u30CC\u30FC\u30F4\u30A7\u30EB\u30F4\u30A1\u30FC\u30B0", "fre", "Nouvelle Vague"]),
    Object.freeze(["\u30CC\u30FC\u30F4\u30A7\u30EB\u30FB\u30F4\u30A1\u30FC\u30B0", "fre", "Nouvelle Vague"]),
    Object.freeze(["\u30CC\u30FC\u30F4\u30A9", "fre", "nouveau"]),
    Object.freeze(["\u30CC\u30FC\u30F4\u30A9\u30FC", "fre", "nouveau"]),
    Object.freeze(["\u30CD\u30AA\u30A2\u30F3\u30D7\u30EC\u30C3\u30B7\u30E7\u30CB\u30B9\u30E0", "fre", "n\xE9o-impressionnisme"]),
    Object.freeze(["\u30CD\u30AA\u30B8\u30E0", "ger", "Neodym"]),
    Object.freeze(["\u30CD\u30AA\u30C8\u30DF\u30B9\u30E0", "fre", "n\xE9o-thomisme"]),
    Object.freeze(["\u30CD\u30AA\u30EA\u30A2\u30EA\u30BA\u30E2", "ita", "neorealismo"]),
    Object.freeze(["\u30CD\u30AA\u30EC\u30A2\u30EA\u30B9\u30E0", "fre", "n\xE9o-r\xE9alisme"]),
    Object.freeze(["\u30CD\u30AA\u30EC\u30A2\u30EA\u30BA\u30E2", "ita", "neorealismo"]),
    Object.freeze(["\u30CD\u30AA\u30FB\u30A2\u30F3\u30D7\u30EC\u30C3\u30B7\u30E7\u30CB\u30B9\u30E0", "fre", "n\xE9o-impressionnisme"]),
    Object.freeze(["\u30CD\u30AA\u30FB\u30EA\u30A2\u30EA\u30BA\u30E2", "ita", "neorealismo"]),
    Object.freeze(["\u30CD\u30AA\u30FB\u30EC\u30A2\u30EA\u30B9\u30E0", "fre", "n\xE9o-r\xE9alisme"]),
    Object.freeze(["\u30CD\u30AA\u30FB\u30EC\u30A2\u30EA\u30BA\u30E2", "ita", "neorealismo"]),
    Object.freeze(["\u30CD\u30AF\u30BF\u30EB", "gre", "nektar"]),
    Object.freeze(["\u30CD\u30AF\u30BF\u30FC\u30EB", "gre", "nektar"]),
    Object.freeze(["\u30CD\u30B0\u30EA\u30B8\u30A7", "fre", "n\xE9glig\xE9"]),
    Object.freeze(["\u30CD\u30B0\u30EA\u30C1\u30E5\u30FC\u30C9", "fre", "n\xE9gritude"]),
    Object.freeze(["\u30CD\u30B4\u30B7\u30A2\u30F3", "fre", "n\xE9gociant"]),
    Object.freeze(["\u30CD\u30B6\u30FC\u30E9\u30F3\u30C9", "dut", "Nederland"]),
    Object.freeze(["\u30CD\u30C3\u30C8\u30B9\u30C8\u30A2", "eng", "net store"]),
    Object.freeze(["\u30CD\u30C3\u30C8\u30B9\u30C8\u30FC\u30AB\u30FC", "eng", "net stalker"]),
    Object.freeze(["\u30CD\u30C3\u30C8\u30B9\u30C8\u30FC\u30AD\u30F3\u30B0", "eng", "net stalking"]),
    Object.freeze(["\u30CD\u30C3\u30C8\u30E1\u30C7\u30A3\u30A2", "eng", "net media"]),
    Object.freeze(["\u30CD\u30C3\u30C8\u30E6\u30FC\u30B6", "eng", "net user"]),
    Object.freeze(["\u30CD\u30C3\u30C8\u30E6\u30FC\u30B6\u30FC", "eng", "net user"]),
    Object.freeze(["\u30CD\u30C3\u30C8\u30FB\u30B9\u30C8\u30A2", "eng", "net store"]),
    Object.freeze(["\u30CD\u30C3\u30C8\u30FB\u30B9\u30C8\u30FC\u30AB\u30FC", "eng", "net stalker"]),
    Object.freeze(["\u30CD\u30C3\u30C8\u30FB\u30B9\u30C8\u30FC\u30AD\u30F3\u30B0", "eng", "net stalking"]),
    Object.freeze(["\u30CD\u30C3\u30C8\u30FB\u30E1\u30C7\u30A3\u30A2", "eng", "net media"]),
    Object.freeze(["\u30CD\u30C3\u30C8\u30FB\u30E6\u30FC\u30B6", "eng", "net user"]),
    Object.freeze(["\u30CD\u30C3\u30C8\u30FB\u30E6\u30FC\u30B6\u30FC", "eng", "net user"]),
    Object.freeze(["\u30CD\u30D0\u30FC\u30CF\u30C3\u30D7\u30F3", "eng", "never happen"]),
    Object.freeze(["\u30CD\u30D0\u30FC\u30FB\u30CF\u30C3\u30D7\u30F3", "eng", "never happen"]),
    Object.freeze(["\u30CD\u30D5\u30ED\u30FC\u30BC", "ger", "Nephrose"]),
    Object.freeze(["\u30CD\u30D7\u30C8\u30A5\u30CC\u30B9", "lat", "Neptunus"]),
    Object.freeze(["\u30CD\u30D7\u30C8\u30A5\u30FC\u30CC\u30B9", "lat", "Neptunus"]),
    Object.freeze(["\u30CD\u30D9", "fre", "n\xE9v\xE9"]),
    Object.freeze(["\u30CD\u30EA\u30C1\u30E3\u30AE", "kor", "naeryeo chagi"]),
    Object.freeze(["\u30CD\u30FC\u30C7\u30EB\u30E9\u30F3\u30C8", "dut", "Nederland"]),
    Object.freeze(["\u30CD\u30FC\u30C7\u30EB\u30E9\u30F3\u30C9", "dut", "Nederland"]),
    Object.freeze(["\u30CE\u30A2\u30FC\u30EB", "fre", "noir"]),
    Object.freeze(["\u30CE\u30A4\u30ED\u30F3", "ger", "Neuron"]),
    Object.freeze(["\u30CE\u30A4\u30ED\u30FC\u30BC", "ger", "Neurose"]),
    Object.freeze(["\u30CE\u30A8\u30EB", "fre", "No\xEBl"]),
    Object.freeze(["\u30CE\u30B9\u30BF\u30EB\u30B8\u30FC", "fre", "nostalgie"]),
    Object.freeze(["\u30CE\u30DE\u30C9\u30ED\u30B8\u30FC", "fre", "nomadologie"]),
    Object.freeze(["\u30CE\u30EB\u30DE", "rus", "norma"]),
    Object.freeze(["\u30CE\u30EB\u30DE\u30EB", "ger", "Normal"]),
    Object.freeze(["\u30CE\u30EF\u30BC\u30C3\u30C8", "fre", "noisette"]),
    Object.freeze(["\u30CE\u30EF\u30FC\u30EB", "fre", "noir"]),
    Object.freeze(["\u30CE\u30F3", "fre", "non"]),
    Object.freeze(["\u30CE\u30F3\u30A2\u30EB\u30B3\u30FC\u30EB\u30D3\u30FC\u30EB", "eng", "non-alcohol beer"]),
    Object.freeze(["\u30CE\u30F3\u30A2\u30EB\u30B3\u30FC\u30EB\u30FB\u30D3\u30FC\u30EB", "eng", "non-alcohol beer"]),
    Object.freeze(["\u30CE\u30F3\u30B7\u30EA\u30B3\u30F3", "eng", "non-silicone"]),
    Object.freeze(["\u30CE\u30F3\u30D6\u30EB", "fre", "nombre"]),
    Object.freeze(["\u30CE\u30F3\u30DD\u30EA", "eng", "nonpoli(tical)"]),
    Object.freeze(["\u30CE\u30F3\u30E9\u30FC", "vie", "n\xF3n l\xE1"]),
    Object.freeze(["\u30CE\u30F3\u30FB\u30E9\u30FC", "vie", "n\xF3n l\xE1"]),
    Object.freeze(["\u30CE\u30FC\u30C1\u30A7", "spa", "noche"]),
    Object.freeze(["\u30CE\u30FC\u30D8\u30EB\u30E1\u30C3\u30C8", "eng", "no helmet"]),
    Object.freeze(["\u30CE\u30FC\u30DE\u30B9\u30AF", "eng", "no mask"]),
    Object.freeze(["\u30CE\u30FC\u30EB\u30C3\u30AF", "eng", "no look"]),
    Object.freeze(["\u30CE\u30FC\u30FB\u30D8\u30EB\u30E1\u30C3\u30C8", "eng", "no helmet"]),
    Object.freeze(["\u30CE\u30FC\u30FB\u30DE\u30B9\u30AF", "eng", "no mask"]),
    Object.freeze(["\u30CE\u30FC\u30FB\u30EB\u30C3\u30AF", "eng", "no look"]),
    Object.freeze(["\u30CF\u30A4\u30A6\u30A7\u30A4\u30E9\u30B8\u30AA", "eng", "highway radio"]),
    Object.freeze(["\u30CF\u30A4\u30A6\u30A7\u30A4\u30FB\u30E9\u30B8\u30AA", "eng", "highway radio"]),
    Object.freeze(["\u30CF\u30A4\u30A6\u30A8\u30A4\u30E9\u30B8\u30AA", "eng", "highway radio"]),
    Object.freeze(["\u30CF\u30A4\u30AB\u30E9", "eng", "high collar"]),
    Object.freeze(["\u30CF\u30A4\u30AB\u30E9\u30FC", "eng", "high collar"]),
    Object.freeze(["\u30CF\u30A4\u30C6\u30A4\u30E9\u30AA\u30E6\u30A8", "chi", "h\u01CEid\u01D0-l\u0101oyu\xE8"]),
    Object.freeze(["\u30CF\u30A4\u30C6\u30F3\u30B7\u30E7\u30F3", "eng", "high tension"]),
    Object.freeze(["\u30CF\u30A4\u30DE\u30FC\u30C8", "ger", "Heimat"]),
    Object.freeze(["\u30CF\u30A4\u30E0", "ger", "Heim"]),
    Object.freeze(["\u30CF\u30A4\u30E9\u30FC\u30C6\u30F3", "ger", "heiraten"]),
    Object.freeze(["\u30CF\u30A4\u30E9\u30FC\u30C8", "ger", "Heirat"]),
    Object.freeze(["\u30CF\u30A4\u30EB", "ger", "Heil"]),
    Object.freeze(["\u30CF\u30A4\u30FB\u30C6\u30F3\u30B7\u30E7\u30F3", "eng", "high tension"]),
    Object.freeze(["\u30CF\u30A6", "por", "paus"]),
    Object.freeze(["\u30CF\u30A6\u30B8\u30F3\u30B0\u30B5\u30FC\u30D3\u30B9", "eng", "housing service"]),
    Object.freeze(["\u30CF\u30A6\u30B8\u30F3\u30B0\u30FB\u30B5\u30FC\u30D3\u30B9", "eng", "housing service"]),
    Object.freeze(["\u30CF\u30AA\u30E6\u30FC", "chi", "h\xE1oy\xF3u"]),
    Object.freeze(["\u30CF\u30C3\u30C8\u30AF", "kor", "hasdogeu"]),
    Object.freeze(["\u30CF\u30C3\u30C8\u30B0", "kor", "hasdogeu"]),
    Object.freeze(["\u30CF\u30C3\u30D7", "dut", "pap"]),
    Object.freeze(["\u30CF\u30C4", "eng", "hearts"]),
    Object.freeze(["\u30CF\u30DD\u30F3", "spa", "Japon"]),
    Object.freeze(["\u30CF\u30E9\u30A4\u30BD", "por", "para\xEDso"]),
    Object.freeze(["\u30CF\u30E9\u30B7\u30E7\u30FC", "rus", "khorosho"]),
    Object.freeze(["\u30CF\u30E9\u30DC\u30B8", "kor", "hal-abeoji"]),
    Object.freeze(["\u30CF\u30EA\u30B9\u30C8\u30B9", "rus", "Khristos"]),
    Object.freeze(["\u30CF\u30EB\u30C4", "ger", "Harz"]),
    Object.freeze(["\u30CF\u30EB\u30DE\u30B2\u30C9\u30F3", "gre", "Harmaged\u014Dn"]),
    Object.freeze(["\u30CF\u30EB\u30E2\u30CB", "kor", "halmeoni"]),
    Object.freeze(["\u30CF\u30F3\u30B0\u30A2\u30C3\u30D7", "eng", "hang-up"]),
    Object.freeze(["\u30CF\u30F3\u30B0\u30FB\u30A2\u30C3\u30D7", "eng", "hang-up"]),
    Object.freeze(["\u30CF\u30F3\u30C1\u30E3\u30F3", "chi", "b\xE0nzhu\u0101ng"]),
    Object.freeze(["\u30CF\u30F3\u30D4", "chi", "f\u01CEnb\xED"]),
    Object.freeze(["\u30CF\u30FC\u30B1\u30F3", "ger", "Haken"]),
    Object.freeze(["\u30CF\u30FC\u30C8\u30D5\u30EB", "eng", "heartful"]),
    Object.freeze(["\u30CF\u30FC\u30C9\u30B9\u30B1\u30B8\u30E5\u30FC\u30EB", "eng", "hard schedule"]),
    Object.freeze(["\u30CF\u30FC\u30C9\u30C9\u30EA\u30F3\u30AF", "eng", "hard drink"]),
    Object.freeze(["\u30CF\u30FC\u30C9\u30FB\u30B9\u30B1\u30B8\u30E5\u30FC\u30EB", "eng", "hard schedule"]),
    Object.freeze(["\u30CF\u30FC\u30C9\u30FB\u30C9\u30EA\u30F3\u30AF", "eng", "hard drink"]),
    Object.freeze(["\u30CF\u30FC\u30D5\u30A2\u30C3\u30D7", "eng", "half-up"]),
    Object.freeze(["\u30CF\u30FC\u30D5\u30FB\u30A2\u30C3\u30D7", "eng", "half-up"]),
    Object.freeze(["\u30D0\u30A4\u30DE\u30AF\u30EB\u30FC", "tha", "bai ma-gkrood"]),
    Object.freeze(["\u30D0\u30A4\u30DE\u30C3\u30AF\u30EB\u30FC", "tha", "bai ma-gkrood"]),
    Object.freeze(["\u30D0\u30A4\u30F3\u30DF\u30FC", "vie", "b\xE1nh m\xEC"]),
    Object.freeze(["\u30D0\u30A4\u30F3\u30FB\u30DF\u30FC", "vie", "b\xE1nh m\xEC"]),
    Object.freeze(["\u30D0\u30A6\u30C1\u30BA\u30E2", "por", "bautismo"]),
    Object.freeze(["\u30D0\u30A6\u30E0\u30AF\u30FC\u30D8\u30F3", "ger", "Baumkuchen"]),
    Object.freeze(["\u30D0\u30AB\u30E9", "fre", "baccara"]),
    Object.freeze(["\u30D0\u30AB\u30ED\u30EC\u30A2", "fre", "baccalaur\xE9at"]),
    Object.freeze(["\u30D0\u30AB\u30F3\u30B9", "fre", "vacances"]),
    Object.freeze(["\u30D0\u30AE\u30FC\u30AB\u30FC", "eng", "buggy car"]),
    Object.freeze(["\u30D0\u30AE\u30FC\u30FB\u30AB\u30FC", "eng", "buggy car"]),
    Object.freeze(["\u30D0\u30B7\u30E9\u30B9", "ger", "Bazillus"]),
    Object.freeze(["\u30D0\u30B8\u30EA\u30B3", "ita", "basilico"]),
    Object.freeze(["\u30D0\u30B9", "ger", "Bass"]),
    Object.freeze(["\u30D0\u30B9\u30A2\u30E1\u30CB\u30C6\u30A3", "eng", "bath amenity"]),
    Object.freeze(["\u30D0\u30B9\u30A2\u30E1\u30CB\u30C6\u30A3\u30FC", "eng", "bath amenity"]),
    Object.freeze(["\u30D0\u30B9\u30B1\u30C3\u30C8\u30B1\u30FC\u30B9", "eng", "basket case"]),
    Object.freeze(["\u30D0\u30B9\u30B1\u30C3\u30C8\u30FB\u30B1\u30FC\u30B9", "eng", "basket case"]),
    Object.freeze(["\u30D0\u30B9\u30BF\u30FC", "eng", "bastard"]),
    Object.freeze(["\u30D0\u30B9\u30FB\u30A2\u30E1\u30CB\u30C6\u30A3", "eng", "bath amenity"]),
    Object.freeze(["\u30D0\u30B9\u30FB\u30A2\u30E1\u30CB\u30C6\u30A3\u30FC", "eng", "bath amenity"]),
    Object.freeze(["\u30D0\u30BF\u30BF", "por", "batata"]),
    Object.freeze(["\u30D0\u30BF\u30FC\u30EB", "fre", "b\xE2tard"]),
    Object.freeze(["\u30D0\u30C1", "kor", "paji"]),
    Object.freeze(["\u30D0\u30C1\u30EB\u30B9", "ger", "Bazillus"]),
    Object.freeze(["\u30D0\u30C3\u30AF\u30C9\u30ED\u30C3\u30D7", "eng", "back drop"]),
    Object.freeze(["\u30D0\u30C3\u30AF\u30E9\u30F3\u30B8", "eng", "back lunge"]),
    Object.freeze(["\u30D0\u30C3\u30AF\u30FB\u30C9\u30ED\u30C3\u30D7", "eng", "back drop"]),
    Object.freeze(["\u30D0\u30C3\u30AF\u30FB\u30E9\u30F3\u30B8", "eng", "back lunge"]),
    Object.freeze(["\u30D0\u30C3\u30C6\u30E9", "por", "bateira"]),
    Object.freeze(["\u30D0\u30C3\u30C6\u30EC", "por", "bateira"]),
    Object.freeze(["\u30D0\u30C3\u30C6\u30FC\u30E9", "por", "bateira"]),
    Object.freeze(["\u30D0\u30C3\u30C8", "eng", "vat"]),
    Object.freeze(["\u30D0\u30CA\u30B8\u30F3", "ger", "Vanadin"]),
    Object.freeze(["\u30D0\u30CB\u30C6\u30A3\u30DF\u30E9\u30FC", "eng", "vanity mirror"]),
    Object.freeze(["\u30D0\u30CB\u30C6\u30A3\u30FB\u30DF\u30E9\u30FC", "eng", "vanity mirror"]),
    Object.freeze(["\u30D0\u30CB\u30C6\u30A3\u30FC\u30DF\u30E9\u30FC", "eng", "vanity mirror"]),
    Object.freeze(["\u30D0\u30CB\u30C6\u30A3\u30FC\u30FB\u30DF\u30E9\u30FC", "eng", "vanity mirror"]),
    Object.freeze(["\u30D0\u30D6\u30EA\u30FC", "eng", "bubbly"]),
    Object.freeze(["\u30D0\u30D7\u30C1\u30BA\u30E2", "por", "bautismo"]),
    Object.freeze(["\u30D0\u30D7\u30C6\u30A3\u30BA\u30E2", "por", "bautismo"]),
    Object.freeze(["\u30D0\u30E9\u30A4\u30BF", "eng", "baryta"]),
    Object.freeze(["\u30D0\u30E9\u30E2\u30F3", "san", "br\u0101hma\u1E47a"]),
    Object.freeze(["\u30D0\u30E9\u30E9\u30A4\u30AB", "rus", "balalayka"]),
    Object.freeze(["\u30D0\u30EA\u30A8\u30C6", "fre", "vari\xE9t\xE9"]),
    Object.freeze(["\u30D0\u30EA\u30AB\u30F3", "fre", "Bariquand (et Marre)"]),
    Object.freeze(["\u30D0\u30EA\u30BF", "eng", "baryta"]),
    Object.freeze(["\u30D0\u30EB\u30AB\u30ED\u30FC\u30E9", "ita", "barcarola"]),
    Object.freeze(["\u30D0\u30EB\u30AB\u30ED\u30FC\u30EC", "ger", "Barkarole"]),
    Object.freeze(["\u30D0\u30EB\u30B3\u30F3", "fre", "balcon"]),
    Object.freeze(["\u30D0\u30EB\u30B5\u30DF\u30B3", "ita", "balsamico"]),
    Object.freeze(["\u30D0\u30EB\u30CA", "san", "var\u1E47a"]),
    Object.freeze(["\u30D0\u30EB\u30D0\u30ED\u30A4", "gre", "barbaroi"]),
    Object.freeze(["\u30D0\u30EC\u30FC\u30B7\u30E5\u30FC\u30BA", "eng", "ballet shoes"]),
    Object.freeze(["\u30D0\u30EC\u30FC\u30FB\u30B7\u30E5\u30FC\u30BA", "eng", "ballet shoes"]),
    Object.freeze(["\u30D0\u30ED\u30F3\u30C7\u30C3\u30BB", "fre", "ballon d'essai"]),
    Object.freeze(["\u30D0\u30F3\u30C9\u30DE\u30F3", "eng", "bandman"]),
    Object.freeze(["\u30D0\u30F3\u30C9\u30FB\u30DE\u30F3", "eng", "bandman"]),
    Object.freeze(["\u30D0\u30F3\u30D0\u30F3\u30B8\u30FC", "chi", "b\xE0ngb\xE0ngj\u012B"]),
    Object.freeze(["\u30D0\u30F3\u30ED\u30BC", "fre", "vin ros\xE9"]),
    Object.freeze(["\u30D0\u30F3\u30FB\u30ED\u30BC", "fre", "vin ros\xE9"]),
    Object.freeze(["\u30D0\u30FC\u30B2\u30F3\u30D6\u30C3\u30AF", "eng", "bargain book"]),
    Object.freeze(["\u30D0\u30FC\u30B2\u30F3\u30FB\u30D6\u30C3\u30AF", "eng", "bargain book"]),
    Object.freeze(["\u30D0\u30FC\u30B8\u30F3\u30AA\u30A4\u30EB", "eng", "virgin oil"]),
    Object.freeze(["\u30D0\u30FC\u30B8\u30F3\u30FB\u30AA\u30A4\u30EB", "eng", "virgin oil"]),
    Object.freeze(["\u30D0\u30FC\u30E0\u30AF\u30FC\u30D8\u30F3", "ger", "Baumkuchen"]),
    Object.freeze(["\u30D0\u30FC\u30E9\u30C8", "hin", "Bharat"]),
    Object.freeze(["\u30D0\u30FC\u30EB", "eng", "bar"]),
    Object.freeze(["\u30D0\u30FC\u30EC\u30C3\u30B9\u30F3", "eng", "barre lesson"]),
    Object.freeze(["\u30D0\u30FC\u30F3", "ger", "Bahn"]),
    Object.freeze(["\u30D0\u30FC\u30FB\u30EC\u30C3\u30B9\u30F3", "eng", "barre lesson"]),
    Object.freeze(["\u30D1\u30A4", "chi", "p\xE1i"]),
    Object.freeze(["\u30D1\u30A4\u30AB\u30EB", "chi", "b\xE1ig\u0101nr"]),
    Object.freeze(["\u30D1\u30A4\u30AF\u30FC", "chi", "p\xE1ig\u01D4"]),
    Object.freeze(["\u30D1\u30A4\u30B0\u30FC", "chi", "p\xE1ig\u01D4"]),
    Object.freeze(["\u30D1\u30A4\u30BF\u30F3", "chi", "b\xE1it\u0101ng"]),
    Object.freeze(["\u30D1\u30A4\u30C1\u30E5\u30A6", "chi", "b\xE1iji\u01D4"]),
    Object.freeze(["\u30D1\u30A4\u30C1\u30FC", "chi", "paichi"]),
    Object.freeze(["\u30D1\u30A4\u30D1\u30F3", "chi", "b\xE1ib\u01CEn"]),
    Object.freeze(["\u30D1\u30A6", "por", "paus"]),
    Object.freeze(["\u30D1\u30A6\u30EA\u30B9\u30BF", "por", "Paulista"]),
    Object.freeze(["\u30D1\u30AA\u30BA", "chi", "b\u0101ozi"]),
    Object.freeze(["\u30D1\u30AF\u30C1\u30FC", "tha", "phakchi"]),
    Object.freeze(["\u30D1\u30B7\u30E3", "tur", "pa\u015Fa"]),
    Object.freeze(["\u30D1\u30B8", "kor", "paji"]),
    Object.freeze(["\u30D1\u30B9\u30CF", "rus", "paskha"]),
    Object.freeze(["\u30D1\u30C1\u30AD", "kor", "bakchigi"]),
    Object.freeze(["\u30D1\u30C1\u30EB\u30B9", "ger", "Bazillus"]),
    Object.freeze(["\u30D1\u30C3\u30AB\u30FC", "eng", "pucker"]),
    Object.freeze(["\u30D1\u30C3\u30B7\u30F3\u30B0", "eng", "passing"]),
    Object.freeze(["\u30D1\u30C3\u30C1\u30AE", "kor", "bakchigi"]),
    Object.freeze(["\u30D1\u30C3\u30D1", "por", "papa"]),
    Object.freeze(["\u30D1\u30C3\u30D7", "dut", "pap"]),
    Object.freeze(["\u30D1\u30C6\u30A3\u30B7\u30A8", "fre", "p\xE2tissier"]),
    Object.freeze(["\u30D1\u30C6\u30A3\u30B7\u30A8\u30FC\u30EB", "fre", "p\xE2tissi\xE8re"]),
    Object.freeze(["\u30D1\u30C6\u30B7\u30A7", "fre", "p\xE2tissier"]),
    Object.freeze(["\u30D1\u30C8\u30EA\u30AD", "lat", "patricii"]),
    Object.freeze(["\u30D1\u30C8\u30ED\u30FC\u30CD", "ger", "Patrone"]),
    Object.freeze(["\u30D1\u30CB\u30A8", "fre", "panier"]),
    Object.freeze(["\u30D1\u30D4\u30E8\u30F3", "fre", "papillon"]),
    Object.freeze(["\u30D1\u30D6\u30EA\u30C3\u30AF\u30D3\u30E5\u30FC\u30A4\u30F3\u30B0", "eng", "public viewing"]),
    Object.freeze(["\u30D1\u30D6\u30EA\u30C3\u30AF\u30FB\u30D3\u30E5\u30FC\u30A4\u30F3\u30B0", "eng", "public viewing"]),
    Object.freeze(["\u30D1\u30D7\u30EA\u30AB", "hun", "paprika"]),
    Object.freeze(["\u30D1\u30E9\u30A2\u30EB\u30C7\u30D2\u30C9", "ger", "Paraaldehyd"]),
    Object.freeze(["\u30D1\u30E9\u30A4\u30BD", "por", "para\xEDso"]),
    Object.freeze(["\u30D1\u30E9\u30A4\u30BE", "por", "para\xEDso"]),
    Object.freeze(["\u30D1\u30E9\u30C1\u30D5\u30B9", "ger", "Paratyphus"]),
    Object.freeze(["\u30D1\u30E9\u30C3\u30AF", "hin", "palak"]),
    Object.freeze(["\u30D1\u30EA\u30B8\u30E3\u30F3", "fre", "parisien"]),
    Object.freeze(["\u30D1\u30EB\u30B3", "ita", "parco"]),
    Object.freeze(["\u30D1\u30EB\u30BF\u30A4", "ger", "Partei"]),
    Object.freeze(["\u30D1\u30EB\u30D5\u30A1\u30F3", "fre", "parfum"]),
    Object.freeze(["\u30D1\u30EB\u30DF\u30B8\u30E3\u30FC\u30CE", "ita", "Parmigiano"]),
    Object.freeze(["\u30D1\u30EC\u30B9\u30C1\u30CA", "lat", "Palestina"]),
    Object.freeze(["\u30D1\u30EC\u30B9\u30C6\u30A3\u30CA", "lat", "Palestina"]),
    Object.freeze(["\u30D1\u30EF\u30FC\u30DC\u30FC\u30EB", "eng", "power ball"]),
    Object.freeze(["\u30D1\u30EF\u30FC\u30FB\u30DC\u30FC\u30EB", "eng", "power ball"]),
    Object.freeze(["\u30D1\u30F3", "por", "p\xE3o"]),
    Object.freeze(["\u30D1\u30F3\u30AA\u30EB\u30D0\u30F3", "fre", "pain au levain"]),
    Object.freeze(["\u30D1\u30F3\u30AA\u30EB\u30F4\u30A1\u30F3", "fre", "pain au levain"]),
    Object.freeze(["\u30D1\u30F3\u30BB", "fre", "pens\xE9e"]),
    Object.freeze(["\u30D1\u30F3\u30BF\u30AF\u30FC\u30EB", "fre", "pantacourt"]),
    Object.freeze(["\u30D1\u30F3\u30BF\u30ED\u30F3", "fre", "pantalon"]),
    Object.freeze(["\u30D1\u30F3\u30C1\u30AB\u30FC\u30DA\u30C3\u30C8", "eng", "needle-punch carpet"]),
    Object.freeze(["\u30D1\u30F3\u30C1\u30C9\u30E9\u30F3\u30AF", "eng", "punch drunk"]),
    Object.freeze(["\u30D1\u30F3\u30C1\u30FB\u30AB\u30FC\u30DA\u30C3\u30C8", "eng", "needle-punch carpet"]),
    Object.freeze(["\u30D1\u30F3\u30C1\u30FB\u30C9\u30E9\u30F3\u30AF", "eng", "punch drunk"]),
    Object.freeze(["\u30D1\u30F3\u30C4\u30A1\u30FC", "ger", "Panzer"]),
    Object.freeze(["\u30D1\u30F3\u30C9\u30EB", "fre", "peindre"]),
    Object.freeze(["\u30D1\u30F3\u30E4", "por", "panha"]),
    Object.freeze(["\u30D1\u30F3\u30EA\u30E5\u30B9\u30C6\u30A3\u30C3\u30AF", "fre", "pain rustique"]),
    Object.freeze(["\u30D1\u30F3\u30FB\u30AA\u30FB\u30EB\u30D0\u30F3", "fre", "pain au levain"]),
    Object.freeze(["\u30D1\u30F3\u30FB\u30AA\u30FB\u30EB\u30F4\u30A1\u30F3", "fre", "pain au levain"]),
    Object.freeze(["\u30D1\u30F3\u30FB\u30EA\u30E5\u30B9\u30C6\u30A3\u30C3\u30AF", "fre", "pain rustique"]),
    Object.freeze(["\u30D1\u30FC\u30AB\u30FC\u30DB", "tha", "bplaa gr\xE0 h\xF4h"]),
    Object.freeze(["\u30D1\u30FC\u30BD\u30CA\u30EB\u30EC\u30C3\u30B9\u30F3", "eng", "personal lesson"]),
    Object.freeze(["\u30D1\u30FC\u30BD\u30CA\u30EB\u30FB\u30EC\u30C3\u30B9\u30F3", "eng", "personal lesson"]),
    Object.freeze(["\u30D1\u30FC\u30C6\u30EB", "lat", "pater"]),
    Object.freeze(["\u30D1\u30FC\u30D1", "por", "papa"]),
    Object.freeze(["\u30D1\u30FC\u30D1\u30AA\u30C4\u30A1\u30A4", "chi", "b\u0101 b\u01CEo c\xE0i"]),
    Object.freeze(["\u30D1\u30FC\u30DD\u30FC\u30C4\u30A1\u30A4", "chi", "b\u0101 b\u01CEo c\xE0i"]),
    Object.freeze(["\u30D2\u30A2\u30EA\u30F3\u30B0", "eng", "hearing"]),
    Object.freeze(["\u30D2\u30A4\u30C7\u30B9", "lat", "fides"]),
    Object.freeze(["\u30D2\u30A8\u30E9\u30EB\u30AD\u30FC", "ger", "Hierachie"]),
    Object.freeze(["\u30D2\u30A8\u30E9\u30EB\u30D2\u30FC", "ger", "Hierachie"]),
    Object.freeze(["\u30D2\u30B9\u30C6\u30EA\u30FC", "ger", "Hysterie"]),
    Object.freeze(["\u30D2\u30C8\u30E9\u30FC\u30E6\u30FC\u30B2\u30F3\u30C8", "ger", "Hitlerjugend"]),
    Object.freeze(["\u30D2\u30C8\u30E9\u30FC\u30FB\u30E6\u30FC\u30B2\u30F3\u30C8", "ger", "Hitlerjugend"]),
    Object.freeze(["\u30D2\u30DD\u30B3\u30F3\u30C7\u30EA\u30FC", "ger", "Hypochondrie"]),
    Object.freeze(["\u30D2\u30E4\u30EA\u30F3\u30B0", "eng", "hearing"]),
    Object.freeze(["\u30D2\u30E5\u30C3\u30C6", "ger", "H\xFCtte"]),
    Object.freeze(["\u30D2\u30E5\u30FC\u30DE\u30F3\u30D3\u30FC\u30C8\u30DC\u30C3\u30AF\u30B9", "eng", "human beatbox"]),
    Object.freeze(["\u30D2\u30E5\u30FC\u30DE\u30F3\u30FB\u30D3\u30FC\u30C8\u30DC\u30C3\u30AF\u30B9", "eng", "human beatbox"]),
    Object.freeze(["\u30D2\u30EC", "fre", "filet"]),
    Object.freeze(["\u30D2\u30FC\u30C7\u30B9", "lat", "fides"]),
    Object.freeze(["\u30D2\u30FC\u30C8\u30F3", "fre", "piton"]),
    Object.freeze(["\u30D2\u30FC\u30EB\u30A2\u30A6\u30C8", "eng", "heel out"]),
    Object.freeze(["\u30D2\u30FC\u30EB\u30DE\u30FC\u30AF", "eng", "heel mark"]),
    Object.freeze(["\u30D2\u30FC\u30EB\u30FB\u30A2\u30A6\u30C8", "eng", "heel out"]),
    Object.freeze(["\u30D2\u30FC\u30EB\u30FB\u30DE\u30FC\u30AF", "eng", "heel mark"]),
    Object.freeze(["\u30D3\u30A2\u30F3\u30B3", "ita", "bianco"]),
    Object.freeze(["\u30D3\u30A8\u30BF", "ita", "piet\xE0"]),
    Object.freeze(["\u30D3\u30AA\u30C1\u30F3", "ger", "Biotin"]),
    Object.freeze(["\u30D3\u30AA\u30C8\u30FC\u30D7", "ger", "Biotop"]),
    Object.freeze(["\u30D3\u30AA\u30EB", "fre", "viole"]),
    Object.freeze(["\u30D3\u30AA\u30ED\u30F3", "fre", "violon"]),
    Object.freeze(["\u30D3\u30AA\u30FC\u30EB", "fre", "viole"]),
    Object.freeze(["\u30D3\u30B8\u30CD\u30B9\u30E1\u30FC\u30EB", "eng", "business mail"]),
    Object.freeze(["\u30D3\u30B8\u30CD\u30B9\u30FB\u30E1\u30FC\u30EB", "eng", "business mail"]),
    Object.freeze(["\u30D3\u30B8\u30E5", "eng", "visu(al)"]),
    Object.freeze(["\u30D3\u30B8\u30E5\u30A2\u30EA\u30B9\u30C8", "eng", "visualist"]),
    Object.freeze(["\u30D3\u30B8\u30E5\u30A6", "fre", "bijou"]),
    Object.freeze(["\u30D3\u30B8\u30E5\u30FC", "fre", "bijou"]),
    Object.freeze(["\u30D3\u30B9", "fre", "vis"]),
    Object.freeze(["\u30D3\u30BF\u30FC\u30C1\u30E7\u30B3\u30EC\u30FC\u30C8", "eng", "bitter chocolate"]),
    Object.freeze(["\u30D3\u30BF\u30FC\u30FB\u30C1\u30E7\u30B3\u30EC\u30FC\u30C8", "eng", "bitter chocolate"]),
    Object.freeze(["\u30D3\u30C7\u30AA\u30DC\u30FC\u30C9", "eng", "video board"]),
    Object.freeze(["\u30D3\u30C7\u30AA\u30FB\u30DC\u30FC\u30C9", "eng", "video board"]),
    Object.freeze(["\u30D3\u30D0\u30FC\u30AF", "ger", "Biwak"]),
    Object.freeze(["\u30D3\u30D5\u30C6\u30AD", "fre", "bifteck"]),
    Object.freeze(["\u30D3\u30E5\u30FC\u30B2\u30EB", "ger", "B\xFCgel"]),
    Object.freeze(["\u30D3\u30E5\u30FC\u30CD\u30F3\u30C9\u30E9\u30DE", "ger", "B\xFChnendrama"]),
    Object.freeze(["\u30D3\u30EB\u30BC\u30F3", "por", "virgem"]),
    Object.freeze(["\u30D3\u30ED\u30FC\u30C9", "por", "veludo"]),
    Object.freeze(["\u30D3\u30F3\u30C7\u30A3\u30F3\u30B0", "ger", "Bindung"]),
    Object.freeze(["\u30D3\u30FC\u30C9\u30ED", "por", "vidro"]),
    Object.freeze(["\u30D3\u30FC\u30EB", "dut", "bier"]),
    Object.freeze(["\u30D4\u30A2\u30B9", "eng", "pierce"]),
    Object.freeze(["\u30D4\u30A8\u30BF", "ita", "piet\xE0"]),
    Object.freeze(["\u30D4\u30A8\u30ED", "fre", "pierrot"]),
    Object.freeze(["\u30D4\u30AA\u30CB\u30FC\u30EB", "rus", "pioner"]),
    Object.freeze(["\u30D4\u30AA\u30CD\u30FC\u30EB", "rus", "pioner"]),
    Object.freeze(["\u30D4\u30AA\u30FC\u30CD", "ita", "pioniere"]),
    Object.freeze(["\u30D4\u30B6\u30CF\u30A6\u30B9", "eng", "pizza house"]),
    Object.freeze(["\u30D4\u30B6\u30FB\u30CF\u30A6\u30B9", "eng", "pizza house"]),
    Object.freeze(["\u30D4\u30B9\u30C6", "ger", "Piste"]),
    Object.freeze(["\u30D4\u30C3\u30AF\u30A2\u30C3\u30D7", "eng", "pick up"]),
    Object.freeze(["\u30D4\u30C3\u30AF\u30FB\u30A2\u30C3\u30D7", "eng", "pick up"]),
    Object.freeze(["\u30D4\u30C3\u30B1\u30EB", "ger", "Pickel"]),
    Object.freeze(["\u30D4\u30E5\u30EC", "fre", "pur\xE9e"]),
    Object.freeze(["\u30D4\u30E5\u30FC\u30EC", "fre", "pur\xE9e"]),
    Object.freeze(["\u30D4\u30ED\u30C6\u30A3", "fre", "pilotis"]),
    Object.freeze(["\u30D4\u30F3\u30A4\u30F3", "chi", "p\u012Bny\u012Bn"]),
    Object.freeze(["\u30D4\u30F3\u30AC", "por", "pinga"]),
    Object.freeze(["\u30D4\u30F3\u30BB\u30C3\u30C8", "dut", "pincet"]),
    Object.freeze(["\u30D4\u30F3\u30C8", "dut", "brandpunt"]),
    Object.freeze(["\u30D4\u30F3\u30C8\u30AC\u30E9\u30B9", "dut", "brandpunt glas"]),
    Object.freeze(["\u30D4\u30F3\u30C8\u30B0\u30E9\u30B9", "dut", "brandpunt glas"]),
    Object.freeze(["\u30D4\u30F3\u30C8\u30FB\u30AC\u30E9\u30B9", "dut", "brandpunt glas"]),
    Object.freeze(["\u30D4\u30F3\u30C8\u30FB\u30B0\u30E9\u30B9", "dut", "brandpunt glas"]),
    Object.freeze(["\u30D4\u30F3\u30D5", "chi", "p\xEDng h\xFA"]),
    Object.freeze(["\u30D4\u30F3\u30DB\u30FC", "chi", "p\xEDng h\xFA"]),
    Object.freeze(["\u30D4\u30FC\u30BF\u30F3", "chi", "p\xEDd\xE0n"]),
    Object.freeze(["\u30D4\u30FC\u30D1\u30A4", "chi", "b\xEC p\xE1i"]),
    Object.freeze(["\u30D4\u30FC\u30DE\u30F3", "fre", "piment"]),
    Object.freeze(["\u30D5\u30A1\u30A4\u30C6\u30A3\u30F3", "kor", "hwaiting"]),
    Object.freeze(["\u30D5\u30A1\u30A4\u30C6\u30A3\u30FC\u30F3", "kor", "hwaiting"]),
    Object.freeze(["\u30D5\u30A1\u30A6\u30B9\u30C8\u30DC\u30FC\u30EB", "ger", "Faustball"]),
    Object.freeze(["\u30D5\u30A1\u30B4\u30C3\u30C8", "ita", "fagotto"]),
    Object.freeze(["\u30D5\u30A1\u30B5\u30FC\u30C9", "fre", "fa\xE7ade"]),
    Object.freeze(["\u30D5\u30A1\u30B9\u30CA\u30FC", "eng", "fastener"]),
    Object.freeze(["\u30D5\u30A1\u30C3\u30B7\u30E7", "ita", "fascio"]),
    Object.freeze(["\u30D5\u30A1\u30CB\u30FC\u30D5\u30A7\u30A4\u30B9", "eng", "funny face"]),
    Object.freeze(["\u30D5\u30A1\u30CB\u30FC\u30D5\u30A7\u30FC\u30B9", "eng", "funny face"]),
    Object.freeze(["\u30D5\u30A1\u30CB\u30FC\u30FB\u30D5\u30A7\u30A4\u30B9", "eng", "funny face"]),
    Object.freeze(["\u30D5\u30A1\u30CB\u30FC\u30FB\u30D5\u30A7\u30FC\u30B9", "eng", "funny face"]),
    Object.freeze(["\u30D5\u30A1\u30F3\u30D1\u30A4", "chi", "f\u0101n p\xE1i"]),
    Object.freeze(["\u30D5\u30A1\u30F3\u30E9\u30F3\u30CA\u30FC", "eng", "fun runner"]),
    Object.freeze(["\u30D5\u30A1\u30F3\u30FB\u30E9\u30F3\u30CA\u30FC", "eng", "fun runner"]),
    Object.freeze(["\u30D5\u30A1\u30FC\u30EA\u30E5\u30FC", "chi", "hu\xE1li\xFA"]),
    Object.freeze(["\u30D5\u30A3\u30A2\u30F3\u30BB", "fre", "fianc\xE9(e)"]),
    Object.freeze(["\u30D5\u30A3\u30CB\u30C3\u30B7\u30E5\u30D1\u30A6\u30C0\u30FC", "eng", "finish powder"]),
    Object.freeze(["\u30D5\u30A3\u30CB\u30C3\u30B7\u30E5\u30FB\u30D1\u30A6\u30C0\u30FC", "eng", "finish powder"]),
    Object.freeze(["\u30D5\u30A3\u30EB\u30CF\u30FC\u30E2\u30CB\u30FC", "ger", "Philharmonie"]),
    Object.freeze(["\u30D5\u30A3\u30EC", "fre", "filet"]),
    Object.freeze(["\u30D5\u30A3\u30EC\u30FC", "fre", "filet"]),
    Object.freeze(["\u30D5\u30A5\u30AA\u30B0\u30A5\u30AA", "chi", "hu\u01D2gu\u014D"]),
    Object.freeze(["\u30D5\u30A7\u30A4\u30B9\u30AC\u30FC\u30C9", "eng", "face guard"]),
    Object.freeze(["\u30D5\u30A7\u30A4\u30B9\u30BD\u30FC\u30D7", "eng", "face soap"]),
    Object.freeze(["\u30D5\u30A7\u30A4\u30B9\u30FB\u30AC\u30FC\u30C9", "eng", "face guard"]),
    Object.freeze(["\u30D5\u30A7\u30A4\u30B9\u30FB\u30BD\u30FC\u30D7", "eng", "face soap"]),
    Object.freeze(["\u30D5\u30A7\u30A4\u30EB", "eng", "fail"]),
    Object.freeze(["\u30D5\u30A7\u30B9\u30BF", "ita", "festa"]),
    Object.freeze(["\u30D5\u30A7\u30B9\u30C8", "ger", "Fest"]),
    Object.freeze(["\u30D5\u30A7\u30BF", "gre", "pheta"]),
    Object.freeze(["\u30D5\u30A7\u30DF\u30CB\u30C6\u30A3", "eng", "feminity"]),
    Object.freeze(["\u30D5\u30A7\u30DF\u30CB\u30C6\u30A3\u30FC", "eng", "feminity"]),
    Object.freeze(["\u30D5\u30A7\u30F3\u30C1\u30E5\u30A6", "chi", "f\xE9nji\u01D4"]),
    Object.freeze(["\u30D5\u30A7\u30F3\u30C1\u30E5\u30FC", "chi", "f\xE9nji\u01D4"]),
    Object.freeze(["\u30D5\u30A7\u30FC\u30B9\u30AC\u30FC\u30C9", "eng", "face guard"]),
    Object.freeze(["\u30D5\u30A7\u30FC\u30B9\u30FB\u30AC\u30FC\u30C9", "eng", "face guard"]),
    Object.freeze(["\u30D5\u30A7\u30FC\u30EB", "eng", "fail"]),
    Object.freeze(["\u30D5\u30A9\u30B6\u30DF", "fre", "faux ami"]),
    Object.freeze(["\u30D5\u30A9\u30B9\u30B2\u30F3", "ger", "Phosgen"]),
    Object.freeze(["\u30D5\u30A9\u30C3\u30AF\u30B9\u30D5\u30A7\u30A4\u30B9", "eng", "foxface"]),
    Object.freeze(["\u30D5\u30A9\u30C8\u30B9\u30BF\u30F3\u30C9", "eng", "photo stand"]),
    Object.freeze(["\u30D5\u30A9\u30C8\u30FB\u30B9\u30BF\u30F3\u30C9", "eng", "photo stand"]),
    Object.freeze(["\u30D5\u30A9\u30CD\u30FC\u30E0", "fre", "phon\xE8me"]),
    Object.freeze(["\u30D5\u30A9\u30EB\u30DE\u30C3\u30B8", "ita", "formaggio"]),
    Object.freeze(["\u30D5\u30A9\u30EB\u30DE\u30C3\u30B8\u30AA", "ita", "formaggio"]),
    Object.freeze(["\u30D5\u30A9\u30EB\u30DE\u30EA\u30B9\u30E0", "fre", "formalisme"]),
    Object.freeze(["\u30D5\u30A9\u30EB\u30DE\u30EA\u30BA\u30E0", "rus", "formalizm"]),
    Object.freeze(["\u30D5\u30A9\u30EB\u30E0", "fre", "forme"]),
    Object.freeze(["\u30D5\u30A9\u30ED\u30FC\u30A2\u30C3\u30D7\u30DF\u30EB\u30AF", "eng", "follow-up milk"]),
    Object.freeze(["\u30D5\u30A9\u30ED\u30FC\u30A2\u30C3\u30D7\u30FB\u30DF\u30EB\u30AF", "eng", "follow-up milk"]),
    Object.freeze(["\u30D5\u30A9\u30F3\u30D1\u30A4", "chi", "f\u0113ng p\xE1i"]),
    Object.freeze(["\u30D5\u30A9\u30FC", "vie", "ph\u1EDF"]),
    Object.freeze(["\u30D5\u30A9\u30FC\u30D3\u30B9\u30E0", "fre", "Fauvisme"]),
    Object.freeze(["\u30D5\u30A9\u30FC\u30F4\u30A3\u30B9\u30E0", "fre", "Fauvisme"]),
    Object.freeze(["\u30D5\u30E2\u30FC\u30EB", "ger", "Humor"]),
    Object.freeze(["\u30D5\u30E5\u30FC\u30E9\u30FC", "ger", "F\xFChrer"]),
    Object.freeze(["\u30D5\u30E9\u30A4\u30B9", "fre", "fraise"]),
    Object.freeze(["\u30D5\u30E9\u30A4\u30C9\u30DD\u30C6\u30C8", "eng", "fried potato"]),
    Object.freeze(["\u30D5\u30E9\u30A4\u30C9\u30FB\u30DD\u30C6\u30C8", "eng", "fried potato"]),
    Object.freeze(["\u30D5\u30E9\u30A4\u30DD\u30C6\u30C8", "eng", "fried potato"]),
    Object.freeze(["\u30D5\u30E9\u30A4\u30FB\u30DD\u30C6\u30C8", "eng", "fried potato"]),
    Object.freeze(["\u30D5\u30E9\u30A6", "ger", "Frau"]),
    Object.freeze(["\u30D5\u30E9\u30B9\u30B3", "por", "frasco"]),
    Object.freeze(["\u30D5\u30E9\u30DE\u30F3", "fre", "Flamand"]),
    Object.freeze(["\u30D5\u30E9\u30F3\u30BB", "fre", "fran\xE7ais"]),
    Object.freeze(["\u30D5\u30E9\u30F3\u30D9", "fre", "flamb\xE9"]),
    Object.freeze(["\u30D5\u30E9\u30F3\u30DC\u30EF\u30FC\u30BA", "fre", "framboise"]),
    Object.freeze(["\u30D5\u30EA\u30AB\u30C7\u30EB", "fre", "fricadelle"]),
    Object.freeze(["\u30D5\u30EA\u30AB\u30C7\u30EC", "ger", "Frikadelle"]),
    Object.freeze(["\u30D5\u30EA\u30AB\u30C7\u30FC\u30EB", "fre", "fricadelle"]),
    Object.freeze(["\u30D5\u30EA\u30E5\u30FC\u30B2\u30EB", "ger", "Fl\xFCgel"]),
    Object.freeze(["\u30D5\u30EA\u30E5\u30FC\u30B2\u30EB\u30DB\u30EB\u30F3", "ger", "Fl\xFCgelhorn"]),
    Object.freeze(["\u30D5\u30EA\u30E5\u30FC\u30B2\u30EB\u30DB\u30FC\u30F3", "ger", "Fl\xFCgelhorn"]),
    Object.freeze(["\u30D5\u30EA\u30E5\u30FC\u30C8\u30A2\u30D9\u30C3\u30AF", "fre", "fl\xFBte \xE0 bec"]),
    Object.freeze(["\u30D5\u30EA\u30E5\u30FC\u30C8\u30FB\u30A2\u30FB\u30D9\u30C3\u30AF", "fre", "fl\xFBte \xE0 bec"]),
    Object.freeze(["\u30D5\u30EA\u30FC\u30B2\u30FC\u30E0", "eng", "free game"]),
    Object.freeze(["\u30D5\u30EA\u30FC\u30FB\u30B2\u30FC\u30E0", "eng", "free game"]),
    Object.freeze(["\u30D5\u30EB\u30B3\u30FC\u30B9", "eng", "full course"]),
    Object.freeze(["\u30D5\u30EB\u30F3\u30B1\u30EB", "ger", "Furunkel"]),
    Object.freeze(["\u30D5\u30EB\u30FB\u30B3\u30FC\u30B9", "eng", "full course"]),
    Object.freeze(["\u30D5\u30EB\u30FC\u30EC", "fre", "fleuret"]),
    Object.freeze(["\u30D5\u30EC\u30F3\u30C1\u30AB\u30F3\u30AB\u30F3", "eng", "French can-can"]),
    Object.freeze(["\u30D5\u30EC\u30F3\u30C1\u30FB\u30AB\u30F3\u30AB\u30F3", "eng", "French can-can"]),
    Object.freeze(["\u30D5\u30EC\u30FC\u30BA", "fre", "fraise"]),
    Object.freeze(["\u30D5\u30EC\u30FC\u30E0\u30EC\u30B9", "eng", "frameless"]),
    Object.freeze(["\u30D5\u30ED\u30A2\u30EA\u30F3\u30B0", "eng", "flooring"]),
    Object.freeze(["\u30D5\u30ED\u30A2\u30FC\u30EA\u30F3\u30B0", "eng", "flooring"]),
    Object.freeze(["\u30D5\u30ED\u30A4\u30E9\u30A4\u30F3", "ger", "Fr\xE4ulein"]),
    Object.freeze(["\u30D5\u30ED\u30DE\u30FC\u30B8\u30E5", "fre", "fromage"]),
    Object.freeze(["\u30D5\u30ED\u30FC\u30EA\u30F3\u30B0", "eng", "flooring"]),
    Object.freeze(["\u30D5\u30FC\u30AC", "ita", "fuga"]),
    Object.freeze(["\u30D5\u30FC\u30BA\u30D2\u30FC", "eng", "who's he"]),
    Object.freeze(["\u30D5\u30FC\u30ED", "chi", "f\xF9 l\xF9"]),
    Object.freeze(["\u30D6\u30A4\u30E9\u30A4\u30F3", "eng", "V-line"]),
    Object.freeze(["\u30D6\u30C3\u30BB", "fre", "bouch\xE9e"]),
    Object.freeze(["\u30D6\u30E9\u30C3\u30AF\u30B7\u30E3\u30D5\u30C8", "eng", "black shaft"]),
    Object.freeze(["\u30D6\u30E9\u30C3\u30AF\u30E9\u30A4\u30F3", "eng", "black line"]),
    Object.freeze(["\u30D6\u30E9\u30C3\u30AF\u30FB\u30B7\u30E3\u30D5\u30C8", "eng", "black shaft"]),
    Object.freeze(["\u30D6\u30E9\u30C3\u30AF\u30FB\u30E9\u30A4\u30F3", "eng", "black line"]),
    Object.freeze(["\u30D6\u30E9\u30D5\u30DE\u30FC", "san", "Brahm\u0101"]),
    Object.freeze(["\u30D6\u30E9\u30DE\u30F3\u30B8\u30A7", "fre", "blanc-manger"]),
    Object.freeze(["\u30D6\u30E9\u30F3\u30B8\u30A7\u30EA\u30FC", "fre", "boulangerie"]),
    Object.freeze(["\u30D6\u30E9\u30F3\u30B8\u30E5\u30EA\u30FC", "fre", "boulangerie"]),
    Object.freeze(["\u30D6\u30E9\u30F3\u30DE\u30F3\u30B8\u30A7", "fre", "blanc-manger"]),
    Object.freeze(["\u30D6\u30E9\u30FC\u30DE\u30F3", "san", "br\u0101hma\u1E47a"]),
    Object.freeze(["\u30D6\u30EA\u30AD", "dut", "blik"]),
    Object.freeze(["\u30D6\u30EA\u30C3\u30AD", "dut", "blik"]),
    Object.freeze(["\u30D6\u30EA\u30CB", "rus", "bliny"]),
    Object.freeze(["\u30D6\u30EA\u30CC\u30A4", "rus", "bliny"]),
    Object.freeze(["\u30D6\u30EB\u30BF\u30FC\u30CB\u30E5", "fre", "Bretagne"]),
    Object.freeze(["\u30D6\u30EB\u30FC\u30C6", "fre", "velout\xE9e"]),
    Object.freeze(["\u30D6\u30EC\u30A4\u30AD\u30F3", "eng", "breakin'"]),
    Object.freeze(["\u30D6\u30EC\u30BC", "fre", "braiser"]),
    Object.freeze(["\u30D6\u30EC\u30F3\u30C9\u30B3\u30FC\u30D2\u30FC", "eng", "blend coffee"]),
    Object.freeze(["\u30D6\u30EC\u30F3\u30C9\u30FB\u30B3\u30FC\u30D2\u30FC", "eng", "blend coffee"]),
    Object.freeze(["\u30D6\u30EC\u30FC\u30AD\u30E9\u30F3\u30D7", "eng", "brake lamp"]),
    Object.freeze(["\u30D6\u30EC\u30FC\u30AD\u30F3", "eng", "breakin'"]),
    Object.freeze(["\u30D6\u30EC\u30FC\u30AD\u30FB\u30E9\u30F3\u30D7", "eng", "brake lamp"]),
    Object.freeze(["\u30D6\u30ED\u30B3", "por", "bloco"]),
    Object.freeze(["\u30D6\u30ED\u30E0", "ger", "Brom"]),
    Object.freeze(["\u30D6\u30ED\u30E0\u30B7\u30A2\u30F3", "ger", "Bromcyan"]),
    Object.freeze(["\u30D6\u30F3\u30C9", "ger", "Bund"]),
    Object.freeze(["\u30D6\u30FC\u30E9\u30F3\u30B8\u30A7\u30EA\u30FC", "fre", "boulangerie"]),
    Object.freeze(["\u30D6\u30FC\u30E9\u30F3\u30B8\u30E5\u30EA\u30FC", "fre", "boulangerie"]),
    Object.freeze(["\u30D7\u30B7\u30ED\u30D5\u30A3\u30C8\u30F3", "lat", "psilophyton"]),
    Object.freeze(["\u30D7\u30C1", "fre", "petit"]),
    Object.freeze(["\u30D7\u30C8\u30EC\u30DE\u30A4\u30AA\u30B9", "gre", "Ptolemaios"]),
    Object.freeze(["\u30D7\u30E9\u30A4\u30D0\u30B7\u30FC\u30E2\u30FC\u30C9", "eng", "privacy mode"]),
    Object.freeze(["\u30D7\u30E9\u30B9\u30DF\u30F3", "ger", "Plasmin"]),
    Object.freeze(["\u30D7\u30E9\u30BB\u30AA\u30B8\u30A6\u30E0", "ger", "Praseodym"]),
    Object.freeze(["\u30D7\u30E9\u30BB\u30AA\u30B8\u30E0", "ger", "Praseodym"]),
    Object.freeze(["\u30D7\u30E9\u30BF\u30CA\u30B9", "lat", "platanus"]),
    Object.freeze(["\u30D7\u30E9\u30C1\u30CA", "spa", "platina"]),
    Object.freeze(["\u30D7\u30E9\u30CA\u30EA\u30A2", "lat", "planaria"]),
    Object.freeze(["\u30D7\u30E9\u30CF", "cze", "Praha"]),
    Object.freeze(["\u30D7\u30E9\u30EA\u30CD", "fre", "pralin\xE9"]),
    Object.freeze(["\u30D7\u30E9\u30EA\u30FC\u30CD", "fre", "pralin\xE9"]),
    Object.freeze(["\u30D7\u30E9\u30F3\u30BF\u30F3", "fre", "printemps"]),
    Object.freeze(["\u30D7\u30E9\u30F3\u30C8\u30D9\u30FC\u30B9", "eng", "plant base"]),
    Object.freeze(["\u30D7\u30EA\u30B9\u30C6\u30E9", "lat", "Pristella"]),
    Object.freeze(["\u30D7\u30EA\u30F3\u30AF\u30EB", "kor", "ppulingkeul"]),
    Object.freeze(["\u30D7\u30EA\u30F3\u30BF\u30F3", "fre", "printemps"]),
    Object.freeze(["\u30D7\u30EB\u30B9", "ger", "Puls"]),
    Object.freeze(["\u30D7\u30EB\u30C0\u30C3\u30AF", "kor", "buldak, puldak"]),
    Object.freeze(["\u30D7\u30EB\u30FC\u30AF", "ger", "Pflug"]),
    Object.freeze(["\u30D7\u30EB\u30FC\u30AF\u30D5\u30A1\u30FC\u30EC\u30F3", "ger", "Pflugfahren"]),
    Object.freeze(["\u30D7\u30EB\u30FC\u30AF\u30DC\u30FC\u30B2\u30F3", "ger", "Pflugbogen"]),
    Object.freeze(["\u30D7\u30EC\u30BF\u30DD\u30EB\u30C6", "fre", "pr\xEAt-\xE0-porter"]),
    Object.freeze(["\u30D7\u30EC\u30D1\u30E9\u30FC\u30C8", "ger", "Pr\xE4parat"]),
    Object.freeze(["\u30D7\u30ED", "ger", "Pro(zent)"]),
    Object.freeze(["\u30D7\u30ED\u30BB\u30F3\u30C8", "por", "procento"]),
    Object.freeze(["\u30D7\u30ED\u30C6\u30A2\u30FC\u30BC", "ger", "Protease"]),
    Object.freeze(["\u30D7\u30ED\u30C6\u30A4\u30CA\u30FC\u30BC", "ger", "Proteinase"]),
    Object.freeze(["\u30D7\u30ED\u30C6\u30FC\u30BC", "ger", "Prothese"]),
    Object.freeze(["\u30D7\u30ED\u30D0\u30A4\u30C0", "eng", "provider"]),
    Object.freeze(["\u30D7\u30ED\u30D0\u30A4\u30C0\u30FC", "eng", "provider"]),
    Object.freeze(["\u30D7\u30ED\u30D1", "eng", "propa(gandist)"]),
    Object.freeze(["\u30D7\u30ED\u30D1\u30FC", "eng", "propa(gandist)"]),
    Object.freeze(["\u30D7\u30ED\u30D5\u30A3\u30EB", "fre", "profil"]),
    Object.freeze(["\u30D7\u30ED\u30D5\u30A3\u30FC\u30EB", "fre", "profil"]),
    Object.freeze(["\u30D7\u30ED\u30E1\u30C6\u30A6\u30B9", "gre", "Prom\u0113the\xFAs"]),
    Object.freeze(["\u30D7\u30ED\u30E1\u30FC\u30C6\u30A6\u30B9", "gre", "Prom\u0113the\xFAs"]),
    Object.freeze(["\u30D7\u30ED\u30EC\u30B9", "eng", "pro(fessional) wres(tling)"]),
    Object.freeze(["\u30D7\u30ED\u30EC\u30BF\u30EA\u30A2", "ger", "Proletarier"]),
    Object.freeze(["\u30D7\u30ED\u30EC\u30BF\u30EA\u30A2\u30FC\u30C8", "ger", "Proletariat"]),
    Object.freeze(["\u30D7\u30FC\u30C9", "rus", "pud"]),
    Object.freeze(["\u30D7\u30FC\u30C9\u30EB", "fre", "poudre"]),
    Object.freeze(["\u30D8\u30AF\u30B5\u30E1\u30C8\u30ED\u30B9", "gre", "hexametros"]),
    Object.freeze(["\u30D8\u30AF\u30BB\u30F3\u30CF\u30A6\u30B9", "ger", "Hexenhaus"]),
    Object.freeze(["\u30D8\u30B2\u30E2\u30CB\u30FC", "ger", "Hegemonie"]),
    Object.freeze(["\u30D8\u30C3\u30C8", "dut", "vet"]),
    Object.freeze(["\u30D8\u30D6\u30E9\u30A4", "gre", "Hebraios"]),
    Object.freeze(["\u30D8\u30E9\u30AF\u30EC\u30B9", "gre", "H\u0113rakl\xEAs"]),
    Object.freeze(["\u30D8\u30EB", "ger", "Herr"]),
    Object.freeze(["\u30D8\u30EB\u30C1\u30E7\u30BD\u30F3", "kor", "heljoseon"]),
    Object.freeze(["\u30D8\u30EB\u30C4", "ger", "Herz"]),
    Object.freeze(["\u30D8\u30EC", "fre", "filet"]),
    Object.freeze(["\u30D8\u30F3\u30EB\u30FC\u30C0", "dut", "wijnruit"]),
    Object.freeze(["\u30D8\u30FC\u30E9\u30AF\u30EC\u30FC\u30B9", "gre", "H\u0113rakl\xEAs"]),
    Object.freeze(["\u30D9\u30AF\u30C8\u30EB", "ger", "Vektor"]),
    Object.freeze(["\u30D9\u30B8\u30D6\u30ED\u30B9", "eng", "veg broth"]),
    Object.freeze(["\u30D9\u30B8\u30FB\u30D6\u30ED\u30B9", "eng", "veg broth"]),
    Object.freeze(["\u30D9\u30B9\u30C8\u30D0\u30A4", "eng", "best buy"]),
    Object.freeze(["\u30D9\u30B9\u30C8\u30EF\u30F3", "eng", "best one"]),
    Object.freeze(["\u30D9\u30B9\u30C8\u30FB\u30D0\u30A4", "eng", "best buy"]),
    Object.freeze(["\u30D9\u30B9\u30C8\u30FB\u30EF\u30F3", "eng", "best one"]),
    Object.freeze(["\u30D9\u30C3\u30C8", "ger", "Bett"]),
    Object.freeze(["\u30D9\u30C8\u30F3", "fre", "b\xE9ton"]),
    Object.freeze(["\u30D9\u30CD\u30C1\u30A2", "ita", "Venezia"]),
    Object.freeze(["\u30D9\u30CD\u30C4\u30A3\u30A2", "ita", "Venezia"]),
    Object.freeze(["\u30D9\u30D3\u30FC\u30C1\u30A7\u30A2", "eng", "baby chair"]),
    Object.freeze(["\u30D9\u30D3\u30FC\u30C1\u30A7\u30A2\u30FC", "eng", "baby chair"]),
    Object.freeze(["\u30D9\u30D3\u30FC\u30FB\u30C1\u30A7\u30A2", "eng", "baby chair"]),
    Object.freeze(["\u30D9\u30D3\u30FC\u30FB\u30C1\u30A7\u30A2\u30FC", "eng", "baby chair"]),
    Object.freeze(["\u30D9\u30EB\u30AC\u30E2\u30C3\u30C8", "ita", "bergamotto"]),
    Object.freeze(["\u30D9\u30EB\u30B0", "ger", "Berg"]),
    Object.freeze(["\u30D9\u30EB\u30B9\u30BF", "rus", "versta"]),
    Object.freeze(["\u30D9\u30EC\u30FC", "fre", "b\xE9ret"]),
    Object.freeze(["\u30D9\u30F3\u30AC\u30E9", "dut", "Bengala"]),
    Object.freeze(["\u30D9\u30F3\u30B8\u30F3", "ger", "Benzin"]),
    Object.freeze(["\u30D9\u30F3\u30BE\u30FC\u30EB", "ger", "Benzol"]),
    Object.freeze(["\u30D9\u30F3\u30C6\u30A3", "ita", "venti"]),
    Object.freeze(["\u30D9\u30FC\u30B3\u30F3\u30A8\u30D4", "fre", "\xE9pi"]),
    Object.freeze(["\u30D9\u30FC\u30B3\u30F3\u30FB\u30A8\u30D4", "fre", "\xE9pi"]),
    Object.freeze(["\u30D9\u30FC\u30BC", "fre", "baiser"]),
    Object.freeze(["\u30DA\u30A2\u30F3", "fre", "P\xE9an"]),
    Object.freeze(["\u30DA\u30B9\u30C8", "ger", "Pest"]),
    Object.freeze(["\u30DA\u30C0\u30F3\u30C1\u30BA\u30E0", "fre", "p\xE9dantisme"]),
    Object.freeze(["\u30DA\u30C6\u30F3", "chi", "b\u0113ngzi"]),
    Object.freeze(["\u30DA\u30C8\u30ED\u30FC\u30EB", "fre", "p\xE9trole"]),
    Object.freeze(["\u30DA\u30CA\u30F3\u30C8\u30EC\u30FC\u30B9", "eng", "pennant race"]),
    Object.freeze(["\u30DA\u30CA\u30F3\u30C8\u30FB\u30EC\u30FC\u30B9", "eng", "pennant race"]),
    Object.freeze(["\u30DA\u30CB\u30D2", "ger", "Pfennig"]),
    Object.freeze(["\u30DA\u30DA\u30ED\u30F3\u30C1\u30FC\u30CB", "ita", "peperoncini"]),
    Object.freeze(["\u30DA\u30DA\u30ED\u30F3\u30C1\u30FC\u30CE", "ita", "peperoncino"]),
    Object.freeze(["\u30DA\u30EC\u30B9\u30C8\u30ED\u30A4\u30AB", "rus", "perestroyka"]),
    Object.freeze(["\u30DA\u30F3\u30AD", "dut", "pek"]),
    Object.freeze(["\u30DA\u30F3\u30BB", "fre", "pens\xE9e"]),
    Object.freeze(["\u30DA\u30F3\u30C6\u30B3\u30B9\u30C6", "gre", "pent\u0113kost\u0113"]),
    Object.freeze(["\u30DA\u30FC", "chi", "b\u011Bi"]),
    Object.freeze(["\u30DA\u30FC\u30ED\u30F3", "chi", "feilong"]),
    Object.freeze(["\u30DB\u30A4\u30B3\u30FC\u30ED\u30FC", "chi", "hu\xEDgu\u014Dr\xF2u"]),
    Object.freeze(["\u30DB\u30A4\u30C3\u30D1\u30FC", "eng", "whipper"]),
    Object.freeze(["\u30DB\u30A6\u30C6\u30A4\u30E9\u30AA\u30E6\u30A4", "chi", "h\xE9 d\u01D0 l\u0101o y\xFA"]),
    Object.freeze(["\u30DB\u30AB\u30F3\u30B9", "kor", "hokanseu"]),
    Object.freeze(["\u30DB\u30B9\u30B2\u30F3", "ger", "Phosgen"]),
    Object.freeze(["\u30DB\u30B9\u30C1\u30A2", "lat", "hostia"]),
    Object.freeze(["\u30DB\u30B9\u30C6\u30A3\u30A2", "lat", "hostia"]),
    Object.freeze(["\u30DB\u30C3\u30C8\u30EF\u30A4\u30F3", "eng", "hot wine"]),
    Object.freeze(["\u30DB\u30C3\u30C8\u30FB\u30EF\u30A4\u30F3", "eng", "hot wine"]),
    Object.freeze(["\u30DB\u30C3\u30D4\u30F3\u30B0", "eng", "hopping"]),
    Object.freeze(["\u30DB\u30C6\u30EA\u30A8", "fre", "h\xF4telier"]),
    Object.freeze(["\u30DB\u30D5\u30D6\u30ED\u30A4\u30CF\u30A6\u30B9", "ger", "Hofbr\xE4uhaus"]),
    Object.freeze(["\u30DB\u30DA\u30A4\u30ED", "por", "roupeiro"]),
    Object.freeze(["\u30DB\u30EA\u30BE\u30F3\u30C8", "ger", "Horizont"]),
    Object.freeze(["\u30DB\u30EB\u30DB\u30EB", "kor", "heolheol"]),
    Object.freeze(["\u30DB\u30EB\u30E2\u30F3", "ger", "Hormon"]),
    Object.freeze(["\u30DB\u30EB\u30F3", "ger", "Horn"]),
    Object.freeze(["\u30DB\u30EB\u30F3\u30D5\u30A7\u30EB\u30B9", "ger", "Hornfels"]),
    Object.freeze(["\u30DB\u30EF\u30A4\u30C8\u30E9\u30A4\u30F3", "eng", "white line"]),
    Object.freeze(["\u30DB\u30EF\u30B8\u30E3\u30AA\u30A4\u30A8\u30F3", "chi", "hu\u0101ji\u0101oy\xE1n"]),
    Object.freeze(["\u30DB\u30F3\u30A4\u30FC\u30BD\u30FC", "chi", "h\xF9ny\u012Bs\xE8"]),
    Object.freeze(["\u30DB\u30F3\u30B7\u30E3\u30AA", "chi", "h\xF3ng sh\u0101o"]),
    Object.freeze(["\u30DB\u30F3\u30C1\u30E3\u30F3\u30BF\u30A4\u30E4\u30AA\u30C1\u30E5\u30A6", "chi", "h\xF9n qu\xE1n d\xE0i y\u0101o ji\u01D4"]),
    Object.freeze(["\u30DB\u30F3\u30C1\u30E5\u30F3", "chi", "h\xF3ng zh\u014Dng"]),
    Object.freeze(["\u30DB\u30F3\u30D0\u30AA", "chi", "h\xF3ngb\u0101o"]),
    Object.freeze(["\u30DB\u30F3\u30D1\u30AA", "chi", "h\xF3ngb\u0101o"]),
    Object.freeze(["\u30DB\u30F3\u30ED\u30A6\u30C8\u30A6", "chi", "h\xF9n l\u01CEo t\xF3u"]),
    Object.freeze(["\u30DB\u30FC", "chi", "h\xE9"]),
    Object.freeze(["\u30DB\u30FC\u30B3\u30FC", "chi", "hu\u01D2gu\u014D"]),
    Object.freeze(["\u30DB\u30FC\u30B3\u30FC\u30BA", "chi", "hu\u01D2gu\u014Dzi"]),
    Object.freeze(["\u30DB\u30FC\u30B3\u30FC\u30C4", "chi", "hu\u01D2gu\u014Dzi"]),
    Object.freeze(["\u30DB\u30FC\u30B9", "dut", "hoos"]),
    Object.freeze(["\u30DB\u30FC\u30C6\u30A4\u30E9\u30AA\u30E6\u30A4", "chi", "h\xE9 d\u01D0 l\u0101o y\xFA"]),
    Object.freeze(["\u30DB\u30FC\u30C7\u30F3", "ger", "Hoden"]),
    Object.freeze(["\u30DB\u30FC\u30E0\u30B9\u30AF\u30FC\u30EB", "eng", "homeschool"]),
    Object.freeze(["\u30DB\u30FC\u30E0\u30BB\u30F3\u30BF\u30FC", "eng", "home center"]),
    Object.freeze(["\u30DB\u30FC\u30E0\u30C9\u30A2", "eng", "(plat)form door"]),
    Object.freeze(["\u30DB\u30FC\u30E0\u30FB\u30B9\u30AF\u30FC\u30EB", "eng", "homeschool"]),
    Object.freeze(["\u30DB\u30FC\u30E0\u30FB\u30BB\u30F3\u30BF\u30FC", "eng", "home center"]),
    Object.freeze(["\u30DB\u30FC\u30E0\u30FB\u30C9\u30A2", "eng", "(plat)form door"]),
    Object.freeze(["\u30DB\u30FC\u30E9", "chi", "h\xFAle"]),
    Object.freeze(["\u30DC\u30BF\u30F3", "por", "bot\xE3o"]),
    Object.freeze(["\u30DC\u30C7\u30A3\u30D3\u30EB", "eng", "body buil(ding)"]),
    Object.freeze(["\u30DC\u30C7\u30A3\u30E9\u30A4\u30F3", "eng", "body line"]),
    Object.freeze(["\u30DC\u30C7\u30A3\u30FB\u30E9\u30A4\u30F3", "eng", "body line"]),
    Object.freeze(["\u30DC\u30C7\u30A3\u30FC\u30D3\u30EB", "eng", "body buil(ding)"]),
    Object.freeze(["\u30DC\u30C7\u30A3\u30FC\u30E9\u30A4\u30F3", "eng", "body line"]),
    Object.freeze(["\u30DC\u30C7\u30A3\u30FC\u30FB\u30E9\u30A4\u30F3", "eng", "body line"]),
    Object.freeze(["\u30DC\u30C8\u30E0\u30B9", "eng", "bottoms"]),
    Object.freeze(["\u30DC\u30CA\u30BB\u30FC\u30E9", "ita", "buona sera"]),
    Object.freeze(["\u30DC\u30CA\u30FB\u30BB\u30FC\u30E9", "ita", "buona sera"]),
    Object.freeze(["\u30DC\u30E9\u30F3\u30C1", "por", "volante"]),
    Object.freeze(["\u30DC\u30EA\u30B7\u30A7\u30D3\u30AD", "rus", "Bol'sheviki"]),
    Object.freeze(["\u30DC\u30EA\u30B7\u30A7\u30D3\u30BA\u30E0", "rus", "Bol'shevizm"]),
    Object.freeze(["\u30DC\u30EA\u30B7\u30A7\u30F4\u30A3\u30AD", "rus", "Bol'sheviki"]),
    Object.freeze(["\u30DC\u30EA\u30B7\u30A7\u30F4\u30A3\u30BA\u30E0", "rus", "Bol'shevizm"]),
    Object.freeze(["\u30DC\u30EB\u30B7\u30A7\u30D3\u30AD", "rus", "Bol'sheviki"]),
    Object.freeze(["\u30DC\u30EB\u30B7\u30A7\u30D3\u30BA\u30E0", "rus", "Bol'shevizm"]),
    Object.freeze(["\u30DC\u30EB\u30B7\u30A7\u30F4\u30A3\u30AD", "rus", "Bol'sheviki"]),
    Object.freeze(["\u30DC\u30EB\u30B7\u30A7\u30F4\u30A3\u30BA\u30E0", "rus", "Bol'shevizm"]),
    Object.freeze(["\u30DC\u30EB\u30BE\u30A4", "rus", "borzoy"]),
    Object.freeze(["\u30DC\u30F3", "fre", "bon"]),
    Object.freeze(["\u30DC\u30F3\u30B4\u30EC", "ita", "vongole"]),
    Object.freeze(["\u30DC\u30F3\u30B8\u30E5\u30FC\u30EB", "fre", "bonjour"]),
    Object.freeze(["\u30DC\u30F3\u30B8\u30E7\u30EB\u30CE", "ita", "buon giorno"]),
    Object.freeze(["\u30DC\u30F3\u30BD\u30EF\u30FC\u30EB", "fre", "bonsoir"]),
    Object.freeze(["\u30DC\u30F3\u30D9", "ger", "Bombe"]),
    Object.freeze(["\u30DC\u30F3\u30DC\u30ED\u30FC\u30CB", "ita", "bomboloni"]),
    Object.freeze(["\u30DC\u30F3\u30FB\u30B8\u30E7\u30EB\u30CE", "ita", "buon giorno"]),
    Object.freeze(["\u30DC\u30FC\u30A4\u30B0\u30EB\u30FC\u30D7", "eng", "boy group"]),
    Object.freeze(["\u30DC\u30FC\u30A4\u30FB\u30B0\u30EB\u30FC\u30D7", "eng", "boy group"]),
    Object.freeze(["\u30DC\u30FC\u30B2\u30F3", "ger", "Bogen"]),
    Object.freeze(["\u30DC\u30FC\u30C8\u30DE\u30C3\u30C1", "eng", "vote match"]),
    Object.freeze(["\u30DC\u30FC\u30C8\u30FB\u30DE\u30C3\u30C1", "eng", "vote match"]),
    Object.freeze(["\u30DC\u30FC\u30CE", "ita", "buono"]),
    Object.freeze(["\u30DC\u30FC\u30EB\u30C9", "eng", "board"]),
    Object.freeze(["\u30DC\u30FC\u30ED", "por", "bolo"]),
    Object.freeze(["\u30DD\u30A2\u30BD\u30F3", "fre", "poisson"]),
    Object.freeze(["\u30DD\u30A8\u30B8\u30FC", "fre", "po\xE9sie"]),
    Object.freeze(["\u30DD\u30AB\u30DB\u30F3\u30BF\u30B9", "eng", "Pocahontas"]),
    Object.freeze(["\u30DD\u30B3\u30DA\u30F3", "chi", "b\xF9g\xF2ub\u011Bn"]),
    Object.freeze(["\u30DD\u30B9\u30C8\u30B3\u30ED\u30CA", "eng", "post corona"]),
    Object.freeze(["\u30DD\u30B9\u30C8\u30FB\u30B3\u30ED\u30CA", "eng", "post corona"]),
    Object.freeze(["\u30DD\u30BF\u30EA\u30F3\u30B0", "eng", "pottering"]),
    Object.freeze(["\u30DD\u30C3\u30D7\u30A2\u30C3\u30D7\u30D6\u30ED\u30C3\u30AF", "eng", "pop-up block"]),
    Object.freeze(["\u30DD\u30C3\u30D7\u30A2\u30C3\u30D7\u30FB\u30D6\u30ED\u30C3\u30AF", "eng", "pop-up block"]),
    Object.freeze(["\u30DD\u30C3\u30D7\u30B9", "eng", "pops"]),
    Object.freeze(["\u30DD\u30C3\u30D7\u30D6\u30ED\u30C3\u30AB\u30FC", "eng", "pop blocker"]),
    Object.freeze(["\u30DD\u30C3\u30D7\u30FB\u30D6\u30ED\u30C3\u30AB\u30FC", "eng", "pop blocker"]),
    Object.freeze(["\u30DD\u30C6\u30F3\u30C4", "ger", "Potenz"]),
    Object.freeze(["\u30DD\u30C9\u30D5\u30A3\u30EB\u30E0", "lat", "podophyllum"]),
    Object.freeze(["\u30DD\u30D4\u30E5\u30EA\u30B9\u30E0", "fre", "populisme"]),
    Object.freeze(["\u30DD\u30E2\u30C9\u30FC\u30ED", "ita", "pomodoro"]),
    Object.freeze(["\u30DD\u30EA\u30A8\u30C1\u30EC\u30F3", "ger", "Poly\xE4thylen"]),
    Object.freeze(["\u30DD\u30EA\u30AA\u30EF\u30AF\u30C1\u30F3", "ger", "Poliovakzin"]),
    Object.freeze(["\u30DD\u30EA\u30B5\u30FC\u30B8\u30E5", "fre", "polissage"]),
    Object.freeze(["\u30DD\u30EA\u30CB\u30E4", "rus", "polyn'ya"]),
    Object.freeze(["\u30DD\u30EA\u30D7\u30C6\u30EB\u30B9", "lat", "Polypterus"]),
    Object.freeze(["\u30DD\u30EB\u30C0\u30FC", "dut", "polder"]),
    Object.freeze(["\u30DD\u30EB\u30C1\u30AA", "lat", "portio"]),
    Object.freeze(["\u30DD\u30EF\u30BD\u30F3", "fre", "poisson"]),
    Object.freeze(["\u30DD\u30EF\u30ED", "fre", "poireau"]),
    Object.freeze(["\u30DD\u30EF\u30ED\u30FC", "fre", "poireau"]),
    Object.freeze(["\u30DD\u30F3", "chi", "p\xE8ng"]),
    Object.freeze(["\u30DD\u30F3\u30B9", "dut", "pons"]),
    Object.freeze(["\u30DD\u30F3\u30C6\u30AE", "kor", "beondegi"]),
    Object.freeze(["\u30DD\u30F3\u30C7\u30B1\u30FC\u30B8\u30E7", "por", "p\xE3o de queijo"]),
    Object.freeze(["\u30DD\u30F3\u30C9", "dut", "pond"]),
    Object.freeze(["\u30DD\u30F3\u30D7", "dut", "pomp"]),
    Object.freeze(["\u30DD\u30F3\u30E6\u30FC", "chi", "p\xE9ngyou"]),
    Object.freeze(["\u30DD\u30F3\u30FB\u30C7\u30FB\u30B1\u30FC\u30B8\u30E7", "por", "p\xE3o de queijo"]),
    Object.freeze(["\u30DD\u30FC\u30BA", "chi", "b\u0101ozi"]),
    Object.freeze(["\u30DE\u30A4\u30A6\u30A7\u30A4", "eng", "my way"]),
    Object.freeze(["\u30DE\u30A4\u30AF\u30ED\u30D0\u30B9", "eng", "microbus"]),
    Object.freeze(["\u30DE\u30A4\u30B9\u30BF\u30FC", "ger", "Meister"]),
    Object.freeze(["\u30DE\u30A4\u30E1\u30F3", "eng", "my man"]),
    Object.freeze(["\u30DE\u30A4\u30E8\u30B8\u30E7\u30FC\u30CC", "fre", "maillot jaune"]),
    Object.freeze(["\u30DE\u30A4\u30E8\u30FB\u30B8\u30E7\u30FC\u30CC", "fre", "maillot jaune"]),
    Object.freeze(["\u30DE\u30A4\u30FB\u30A6\u30A7\u30A4", "eng", "my way"]),
    Object.freeze(["\u30DE\u30AF\u30ED\u30B3\u30B9\u30E2\u30B9", "ger", "Makrokosmos"]),
    Object.freeze(["\u30DE\u30AF\u30ED\u30D3\u30AA\u30C6\u30A3\u30C3\u30AF", "fre", "macrobiotique"]),
    Object.freeze(["\u30DE\u30B3\u30ED\u30F3", "fre", "macaron"]),
    Object.freeze(["\u30DE\u30B7\u30A7\u30EA\u30FC", "fre", "ma ch\xE9rie"]),
    Object.freeze(["\u30DE\u30B8\u30C3\u30AF\u30A4\u30F3\u30AD", "eng", "Magic Ink"]),
    Object.freeze(["\u30DE\u30B8\u30C3\u30AF\u30C6\u30FC\u30D7", "eng", "Magic Tape"]),
    Object.freeze(["\u30DE\u30B8\u30C3\u30AF\u30FB\u30A4\u30F3\u30AD", "eng", "Magic Ink"]),
    Object.freeze(["\u30DE\u30B8\u30C3\u30AF\u30FB\u30C6\u30FC\u30D7", "eng", "Magic Tape"]),
    Object.freeze(["\u30DE\u30B9\u30C8", "eng", "must"]),
    Object.freeze(["\u30DE\u30C0\u30E0", "fre", "madame"]),
    Object.freeze(["\u30DE\u30C1\u30A8\u30FC\u30EB", "fre", "mati\xE8re"]),
    Object.freeze(["\u30DE\u30C1\u30CD", "fre", "matin\xE9e"]),
    Object.freeze(["\u30DE\u30C1\u30CD\u30FC", "fre", "matin\xE9e"]),
    Object.freeze(["\u30DE\u30C3\u30AB\u30EA", "kor", "maggeoli"]),
    Object.freeze(["\u30DE\u30C3\u30B3\u30EA", "kor", "maggeoli"]),
    Object.freeze(["\u30DE\u30C6\u30A3\u30A8\u30FC\u30EB", "fre", "mati\xE8re"]),
    Object.freeze(["\u30DE\u30C8\u30EA\u30E7\u30FC\u30B7\u30AB", "rus", "matr\xEBshka"]),
    Object.freeze(["\u30DE\u30C9\u30E9\u30FC", "eng", "muddler"]),
    Object.freeze(["\u30DE\u30C9\u30ED\u30B9", "dut", "matroos"]),
    Object.freeze(["\u30DE\u30CB\u30A8\u30EA\u30B9\u30E0", "fre", "mani\xE9risme"]),
    Object.freeze(["\u30DE\u30DB\u30E1\u30C3\u30C8", "lat", "Mahomet"]),
    Object.freeze(["\u30DE\u30DE\u30F3", "fre", "maman"]),
    Object.freeze(["\u30DE\u30E9", "san", "m\u0101ra"]),
    Object.freeze(["\u30DE\u30EA\u30A2", "lat", "Maria"]),
    Object.freeze(["\u30DE\u30EA\u30A2\u30FC\u30B8\u30E5", "fre", "mariage"]),
    Object.freeze(["\u30DE\u30EA\u30C3\u30B8\u30EA\u30F3\u30B0", "eng", "marriage ring"]),
    Object.freeze(["\u30DE\u30EA\u30C3\u30B8\u30FB\u30EA\u30F3\u30B0", "eng", "marriage ring"]),
    Object.freeze(["\u30DE\u30EA\u30CD", "fre", "marin\xE9"]),
    Object.freeze(["\u30DE\u30EA\u30F3\u30EC\u30B8\u30E3\u30FC", "eng", "marine leisure"]),
    Object.freeze(["\u30DE\u30EA\u30F3\u30FB\u30EC\u30B8\u30E3\u30FC", "eng", "marine leisure"]),
    Object.freeze(["\u30DE\u30EA\u30FC\u30B7\u30A2", "por", "mal\xEDcia"]),
    Object.freeze(["\u30DE\u30EB\u30AF", "ger", "Mark"]),
    Object.freeze(["\u30DE\u30EB\u30B7\u30A7", "fre", "march\xE9"]),
    Object.freeze(["\u30DE\u30EB\u30C1\u30D7\u30EC\u30A4", "eng", "multiplay"]),
    Object.freeze(["\u30DE\u30EB\u30C1\u30D7\u30EC\u30FC", "eng", "multiplay"]),
    Object.freeze(["\u30DE\u30EB\u30C1\u30EA\u30E8", "por", "martirio"]),
    Object.freeze(["\u30DE\u30EB\u30C4", "ger", "Malz"]),
    Object.freeze(["\u30DE\u30EB\u30C6\u30A3\u30EA\u30AA", "por", "martirio"]),
    Object.freeze(["\u30DE\u30EB\u30E1\u30ED", "por", "marmelo"]),
    Object.freeze(["\u30DE\u30ED\u30CB\u30A8", "fre", "marronnier"]),
    Object.freeze(["\u30DE\u30ED\u30F3", "fre", "marron"]),
    Object.freeze(["\u30DE\u30F3", "chi", "w\xE0n"]),
    Object.freeze(["\u30DE\u30F3\u30B7\u30E7\u30F3", "eng", "mansion"]),
    Object.freeze(["\u30DE\u30F3\u30B8\u30A7\u30EA\u30B3\u30F3", "por", "manjeric\xE3o"]),
    Object.freeze(["\u30DE\u30F3\u30BA", "chi", "w\xE0n zi"]),
    Object.freeze(["\u30DE\u30F3\u30BB\u30FC", "kor", "manse"]),
    Object.freeze(["\u30DE\u30F3\u30C6\u30EB", "dut", "mantel"]),
    Object.freeze(["\u30DE\u30F3\u30C8", "fre", "manteau"]),
    Object.freeze(["\u30DE\u30F3\u30C8\u30A6", "chi", "m\xE1ntou"]),
    Object.freeze(["\u30DE\u30F3\u30C8\u30FC", "chi", "m\xE1ntou"]),
    Object.freeze(["\u30DE\u30F3\u30D5\u30A1", "kor", "manhwa"]),
    Object.freeze(["\u30DE\u30F3\u30DE\u30F3\u30C7", "chi", "m\xE0n m\xE0n de"]),
    Object.freeze(["\u30DE\u30F3\u30DE\u30F3\u30C7\u30FC", "chi", "m\xE0n m\xE0n de"]),
    Object.freeze(["\u30DE\u30FB\u30B7\u30A7\u30EA\u30FC", "fre", "ma ch\xE9rie"]),
    Object.freeze(["\u30DE\u30FC\u30B7\u30E5", "fre", "m\xE2che"]),
    Object.freeze(["\u30DE\u30FC\u30B8\u30E3\u30F3", "chi", "m\xE1ji\xE0ng"]),
    Object.freeze(["\u30DE\u30FC\u30C8\u30FC", "chi", "m\u01CEtou"]),
    Object.freeze(["\u30DE\u30FC\u30DC", "chi", "m\xE1p\xF3"]),
    Object.freeze(["\u30DE\u30FC\u30DC\u30FC", "chi", "m\xE1p\xF3"]),
    Object.freeze(["\u30DE\u30FC\u30DC\u30FC\u30C9\u30FC\u30D5", "chi", "m\xE1p\xF3 d\xF2ufu"]),
    Object.freeze(["\u30DE\u30FC\u30E9", "spa", "mar\xE1"]),
    Object.freeze(["\u30DE\u30FC\u30E9\u30FC", "chi", "m\xE1l\xE0"]),
    Object.freeze(["\u30DE\u30FC\u30E9\u30FC\u30BF\u30F3", "chi", "m\xE1l\xE0t\xE0ng"]),
    Object.freeze(["\u30DE\u30FC\u30EB", "ger", "Maar"]),
    Object.freeze(["\u30DF\u30A4\u30E9", "por", "mirra"]),
    Object.freeze(["\u30DF\u30AA\u30AF\u30ED\u30CB\u30FC", "fre", "myoclonie"]),
    Object.freeze(["\u30DF\u30AF\u30ED\u30B3\u30B9\u30E2\u30B9", "ger", "Mikrokosmos"]),
    Object.freeze(["\u30DF\u30B0\u30EC\u30CB\u30F3", "ger", "Migr\xE4nin"]),
    Object.freeze(["\u30DF\u30B5", "lat", "missa"]),
    Object.freeze(["\u30DF\u30B5\u30F3\u30AC", "por", "mi\xE7anga"]),
    Object.freeze(["\u30DF\u30B9", "eng", "miss"]),
    Object.freeze(["\u30DF\u30BC\u30E9\u30D6\u30EB", "fre", "mis\xE9rable"]),
    Object.freeze(["\u30DF\u30C3\u30AF\u30B9\u30EB\u30FC\u30C4", "eng", "mixed roots"]),
    Object.freeze(["\u30DF\u30C3\u30AF\u30B9\u30FB\u30EB\u30FC\u30C4", "eng", "mixed roots"]),
    Object.freeze(["\u30DF\u30C3\u30C9\u30BB\u30F3\u30C1\u30E5\u30EA\u30FC", "eng", "mid-century"]),
    Object.freeze(["\u30DF\u30C3\u30C9\u30FB\u30BB\u30F3\u30C1\u30E5\u30EA\u30FC", "eng", "mid-century"]),
    Object.freeze(["\u30DF\u30CB\u30A2\u30EB\u30D0\u30E0", "eng", "mini album"]),
    Object.freeze(["\u30DF\u30CB\u30B3\u30F3\u30DD", "eng", "mini compo(nent)"]),
    Object.freeze(["\u30DF\u30CB\u30B3\u30FC\u30B9", "eng", "mini course"]),
    Object.freeze(["\u30DF\u30CB\u30E5\u30A8\u30C3\u30C8", "ger", "Menuett"]),
    Object.freeze(["\u30DF\u30CB\u30FB\u30A2\u30EB\u30D0\u30E0", "eng", "mini album"]),
    Object.freeze(["\u30DF\u30CB\u30FB\u30B3\u30FC\u30B9", "eng", "mini course"]),
    Object.freeze(["\u30DF\u30CE\u30BF\u30A6\u30EB\u30B9", "gre", "Minotauros"]),
    Object.freeze(["\u30DF\u30CE\u30BF\u30A6\u30ED\u30B9", "gre", "Minotauros"]),
    Object.freeze(["\u30DF\u30E2\u30EC", "fre", "mi-mollet"]),
    Object.freeze(["\u30DF\u30E5\u30F3\u30D8\u30F3", "ger", "M\xFCnchen"]),
    Object.freeze(["\u30DF\u30EA\u30B0\u30E9\u30E0", "fre", "milligramme"]),
    Object.freeze(["\u30DF\u30EA\u30E1\u30FC\u30BF\u30FC", "fre", "millim\xE8tre"]),
    Object.freeze(["\u30DF\u30EA\u30E1\u30FC\u30C8\u30EB", "fre", "millim\xE8tre"]),
    Object.freeze(["\u30DF\u30EA\u30E7\u30F3", "kor", "miryeong"]),
    Object.freeze(["\u30DF\u30EB\u30C6\u30A3\u30FC\u30E6", "fre", "myrtille"]),
    Object.freeze(["\u30DF\u30EB\u30E9", "lat", "myrrha"]),
    Object.freeze(["\u30DF\u30F3\u30C1", "eng", "mince"]),
    Object.freeze(["\u30DF\u30F3\u30CD", "ger", "Minne"]),
    Object.freeze(["\u30DF\u30F3\u30CD\u30B6\u30F3\u30B0", "ger", "Minnesang"]),
    Object.freeze(["\u30DF\u30F3\u30CD\u30B8\u30F3\u30AC\u30FC", "ger", "Minnes\xE4nger"]),
    Object.freeze(["\u30DF\u30F3\u30CD\u30BC\u30F3\u30AC\u30FC", "ger", "Minnes\xE4nger"]),
    Object.freeze(["\u30DF\u30FC\u30B7\u30A7\u30F3", "chi", "m\u01D0xi\xE0n"]),
    Object.freeze(["\u30DF\u30FC\u30C8", "eng", "meet"]),
    Object.freeze(["\u30DF\u30FC\u30CE\u30FC\u30BF\u30A6\u30ED\u30B9", "gre", "Minotauros"]),
    Object.freeze(["\u30E0\u30B0\u30F3\u30D5\u30A1", "kor", "mugunghwa"]),
    Object.freeze(["\u30E0\u30B9\u30AB\u30EA", "lat", "muscari"]),
    Object.freeze(["\u30E0\u30B9\u30ED\u30A6", "chi", "m\xF9x\u016Br\xF2u"]),
    Object.freeze(["\u30E0\u30C3\u30AF", "eng", "mook"]),
    Object.freeze(["\u30E0\u30C8\u30F3", "fre", "mouton"]),
    Object.freeze(["\u30E0\u30E9\u30FC\u30C8", "spa", "mulato"]),
    Object.freeze(["\u30E0\u30F3\u30C8\u30C6\u30E9\u30D4\u30FC", "ger", "Mundtherapie"]),
    Object.freeze(["\u30E0\u30F3\u30C8\u30FB\u30C6\u30E9\u30D4\u30FC", "ger", "Mundtherapie"]),
    Object.freeze(["\u30E0\u30F3\u30D7\u30B9", "ger", "Mumps"]),
    Object.freeze(["\u30E0\u30FC\u30B7\u30E5\u30FC\u30ED\u30A6", "chi", "m\xF9x\u016Br\xF2u"]),
    Object.freeze(["\u30E0\u30FC\u30B9\u30FC\u30ED\u30A6", "chi", "m\xF9x\u016Br\xF2u"]),
    Object.freeze(["\u30E0\u30FC\u30C1\u30E7", "spa", "mucho"]),
    Object.freeze(["\u30E0\u30FC\u30C7\u30A3", "eng", "moody"]),
    Object.freeze(["\u30E0\u30FC\u30C7\u30A3\u30FC", "eng", "moody"]),
    Object.freeze(["\u30E0\u30FC\u30C8\u30F3", "fre", "mouton"]),
    Object.freeze(["\u30E0\u30FC\u30D6\u30DE\u30F3", "fre", "mouvement"]),
    Object.freeze(["\u30E0\u30FC\u30EB", "fre", "moule"]),
    Object.freeze(["\u30E0\u30FC\u30F4\u30DE\u30F3", "fre", "mouvement"]),
    Object.freeze(["\u30E1\u30A4\u30AD\u30F3\u30B0", "eng", "making"]),
    Object.freeze(["\u30E1\u30A4\u30D5\u30A1\u30FC\u30BA", "chi", "m\xE9i f\u01CEzi"]),
    Object.freeze(["\u30E1\u30A4\u30F3\u30D0\u30F3\u30AF", "eng", "main bank"]),
    Object.freeze(["\u30E1\u30A4\u30F3\u30FB\u30D0\u30F3\u30AF", "eng", "main bank"]),
    Object.freeze(["\u30E1\u30B8\u30E3\u30FC\u30AB\u30C3\u30D7", "eng", "measure cup"]),
    Object.freeze(["\u30E1\u30B8\u30E3\u30FC\u30FB\u30AB\u30C3\u30D7", "eng", "measure cup"]),
    Object.freeze(["\u30E1\u30B9", "dut", "mes"]),
    Object.freeze(["\u30E1\u30B9\u30AB\u30EB", "spa", "mezcal"]),
    Object.freeze(["\u30E1\u30B9\u30B7\u30EA\u30F3\u30C0\u30FC", "ger", "Messzylinder"]),
    Object.freeze(["\u30E1\u30B9\u30D4\u30DA\u30C3\u30C8", "ger", "Messpipette"]),
    Object.freeze(["\u30E1\u30B9\u30D5\u30E9\u30B9\u30B3", "ger", "Messflasche"]),
    Object.freeze(["\u30E1\u30BB\u30CA", "fre", "m\xE9c\xE9nat"]),
    Object.freeze(["\u30E1\u30BE\u30F3", "fre", "maison"]),
    Object.freeze(["\u30E1\u30BF\u30B2\u30CE\u30E0", "ger", "Metagenom"]),
    Object.freeze(["\u30E1\u30BF\u30CE\u30FC\u30EB", "ger", "Methanol"]),
    Object.freeze(["\u30E1\u30BF\u30D5\u30A9\u30FC\u30EB", "fre", "m\xE9taphore"]),
    Object.freeze(["\u30E1\u30BF\u30E2\u30EB\u30D5\u30A9\u30FC\u30BC", "ger", "Metamorphose"]),
    Object.freeze(["\u30E1\u30BF\u30F3", "ger", "Methan"]),
    Object.freeze(["\u30E1\u30C1\u30CB\u30B9", "lat", "Metynnis"]),
    Object.freeze(["\u30E1\u30C1\u30EB\u30A2\u30EB\u30B3\u30FC\u30EB", "ger", "Methylalkohol"]),
    Object.freeze(["\u30E1\u30C3\u30B7\u30E5", "fre", "m\xE8che"]),
    Object.freeze(["\u30E1\u30C3\u30BB", "ger", "Messe"]),
    Object.freeze(["\u30E1\u30C3\u30C1\u30A7\u30F3", "ger", "M\xE4dchen"]),
    Object.freeze(["\u30E1\u30C7\u30A5\u30B5", "gre", "M\xE9dousa"]),
    Object.freeze(["\u30E1\u30C7\u30A5\u30FC\u30B5", "gre", "M\xE9dousa"]),
    Object.freeze(["\u30E1\u30C7\u30E5\u30FC\u30B5", "gre", "M\xE9dousa"]),
    Object.freeze(["\u30E1\u30C8\u30EA\u30C3\u30AF", "ger", "Metrik"]),
    Object.freeze(["\u30E1\u30C8\u30ED", "fre", "m\xE9tro"]),
    Object.freeze(["\u30E1\u30C8\u30ED\u30CE\u30FC\u30E0", "ger", "Metronom"]),
    Object.freeze(["\u30E1\u30C9\u30A5\u30B5", "gre", "M\xE9dousa"]),
    Object.freeze(["\u30E1\u30C9\u30A5\u30FC\u30B5", "gre", "M\xE9dousa"]),
    Object.freeze(["\u30E1\u30CC\u30A8\u30C3\u30C8", "ger", "Menuett"]),
    Object.freeze(["\u30E1\u30E2\u30EF\u30FC\u30EB", "fre", "m\xE9moires"]),
    Object.freeze(["\u30E1\u30EA\u30B1\u30F3", "eng", "American"]),
    Object.freeze(["\u30E1\u30EA\u30C3\u30B5", "lat", "melissa"]),
    Object.freeze(["\u30E1\u30EA\u30F3\u30B9", "spa", "merinos"]),
    Object.freeze(["\u30E1\u30EB\u30AF\u30DE\u30FC\u30EB", "ger", "Merkmal"]),
    Object.freeze(["\u30E1\u30EB\u30AF\u30EA\u30A6\u30B9", "lat", "Mercurius"]),
    Object.freeze(["\u30E1\u30EB\u30B7", "fre", "merci"]),
    Object.freeze(["\u30E1\u30EB\u30B7\u30FC", "fre", "merci"]),
    Object.freeze(["\u30E1\u30EB\u30D8\u30F3", "ger", "M\xE4rchen"]),
    Object.freeze(["\u30E1\u30EB\u30EB\u30FC\u30B5", "spa", "merluza"]),
    Object.freeze(["\u30E1\u30EC\u30F3\u30B9", "spa", "merinos"]),
    Object.freeze(["\u30E1\u30ED\u30F3\u30BD\u30FC\u30C0", "eng", "melon soda"]),
    Object.freeze(["\u30E1\u30ED\u30F3\u30FB\u30BD\u30FC\u30C0", "eng", "melon soda"]),
    Object.freeze(["\u30E1\u30F3\u30B7\u30A7\u30D3\u30AD", "rus", "Men'sheviki"]),
    Object.freeze(["\u30E1\u30F3\u30B7\u30A7\u30F4\u30A3\u30AD", "rus", "Men'sheviki"]),
    Object.freeze(["\u30E1\u30F3\u30B9", "ger", "Mens(truation)"]),
    Object.freeze(["\u30E1\u30F3\u30BA\u30B9\u30FC\u30C4", "eng", "men's suits"]),
    Object.freeze(["\u30E1\u30F3\u30BA\u30FB\u30B9\u30FC\u30C4", "eng", "men's suits"]),
    Object.freeze(["\u30E1\u30F3\u30BC\u30F3\u30C1\u30F3", "chi", "m\xE9n qi\xE1n q\u012Bng"]),
    Object.freeze(["\u30E1\u30F3\u30BC\u30F3\u30C1\u30F3\u30C4\u30E2\u30DB\u30FC", "chi", "m\xE9n qi\xE1n q\u012Bng z\xEC m\u014D h\xFA"]),
    Object.freeze(["\u30E1\u30F3\u30BF\u30A4", "kor", "myeongtae"]),
    Object.freeze(["\u30E1\u30F3\u30BF\u30EB\u30AF\u30EA\u30CB\u30C3\u30AF", "eng", "mental clinic"]),
    Object.freeze(["\u30E1\u30F3\u30BF\u30EB\u30FB\u30AF\u30EA\u30CB\u30C3\u30AF", "eng", "mental clinic"]),
    Object.freeze(["\u30E1\u30F3\u30C1", "eng", "mince"]),
    Object.freeze(["\u30E1\u30F3\u30C4", "chi", "mi\xE0nzi"]),
    Object.freeze(["\u30E1\u30F3\u30C8\u30FC\u30EB", "ger", "Menthol"]),
    Object.freeze(["\u30E1\u30F3\u30D5\u30A9\u30F3\u30D1\u30A4", "chi", "m\xE9n f\u0113ng p\xE1i"]),
    Object.freeze(["\u30E1\u30F3\u30DE", "chi", "mi\xE0nm\xE1"]),
    Object.freeze(["\u30E1\u30FC\u30AD\u30F3\u30B0", "eng", "making"]),
    Object.freeze(["\u30E1\u30FC\u30C8\u30EB", "fre", "m\xE8tre"]),
    Object.freeze(["\u30E1\u30FC\u30C8\u30EB\u30C9\u30C6\u30EB", "fre", "ma\xEEtre d'h\xF4tel"]),
    Object.freeze(["\u30E1\u30FC\u30C8\u30EB\u30FB\u30C9\u30C6\u30EB", "fre", "ma\xEEtre d'h\xF4tel"]),
    Object.freeze(["\u30E1\u30FC\u30D5\u30A1\u30FC\u30BA", "chi", "m\xE9i f\u01CEzi"]),
    Object.freeze(["\u30E1\u30FC\u30D5\u30A1\u30FC\u30C4", "chi", "m\xE9i f\u01CEzi"]),
    Object.freeze(["\u30E1\u30FC\u30EB\u30A2\u30AB\u30A6\u30F3\u30C8", "eng", "mail account"]),
    Object.freeze(["\u30E1\u30FC\u30EB\u30A2\u30C9\u30EC\u30B9", "eng", "mail address"]),
    Object.freeze(["\u30E1\u30FC\u30EB\u30DE\u30FC\u30B1\u30C6\u30A3\u30F3\u30B0", "eng", "mail marketing"]),
    Object.freeze(["\u30E1\u30FC\u30EB\u30FB\u30A2\u30AB\u30A6\u30F3\u30C8", "eng", "mail account"]),
    Object.freeze(["\u30E1\u30FC\u30EB\u30FB\u30A2\u30C9\u30EC\u30B9", "eng", "mail address"]),
    Object.freeze(["\u30E1\u30FC\u30EB\u30FB\u30DE\u30FC\u30B1\u30C6\u30A3\u30F3\u30B0", "eng", "mail marketing"]),
    Object.freeze(["\u30E1\u30FC\u30F3\u30D0\u30F3\u30AF", "eng", "main bank"]),
    Object.freeze(["\u30E1\u30FC\u30F3\u30FB\u30D0\u30F3\u30AF", "eng", "main bank"]),
    Object.freeze(["\u30E2\u30A4", "fin", "moi"]),
    Object.freeze(["\u30E2\u30B9\u30AF\u30EF", "rus", "Moskva"]),
    Object.freeze(["\u30E2\u30B9\u30EA\u30F3", "fre", "mousseline"]),
    Object.freeze(["\u30E2\u30CA\u30EA\u30B6", "ita", "Monna Lisa"]),
    Object.freeze(["\u30E2\u30CA\u30FB\u30EA\u30B6", "ita", "Monna Lisa"]),
    Object.freeze(["\u30E2\u30CE\u30DD\u30FC\u30EB", "ger", "Monopol"]),
    Object.freeze(["\u30E2\u30D0\u30A4\u30EB\u30D0\u30C3\u30C6\u30EA", "eng", "mobile battery"]),
    Object.freeze(["\u30E2\u30D0\u30A4\u30EB\u30D0\u30C3\u30C6\u30EA\u30FC", "eng", "mobile battery"]),
    Object.freeze(["\u30E2\u30D0\u30A4\u30EB\u30FB\u30D0\u30C3\u30C6\u30EA", "eng", "mobile battery"]),
    Object.freeze(["\u30E2\u30D0\u30A4\u30EB\u30FB\u30D0\u30C3\u30C6\u30EA\u30FC", "eng", "mobile battery"]),
    Object.freeze(["\u30E2\u30D2\u30AB\u30F3\u30AB\u30C3\u30C8", "eng", "Mohican cut"]),
    Object.freeze(["\u30E2\u30D2\u30AB\u30F3\u30FB\u30AB\u30C3\u30C8", "eng", "Mohican cut"]),
    Object.freeze(["\u30E2\u30EA\u30D6\u30C7\u30F3", "ger", "Molybd\xE4n"]),
    Object.freeze(["\u30E2\u30EA\u30D7\u30C7\u30F3", "ger", "Molybd\xE4n"]),
    Object.freeze(["\u30E2\u30EB", "ger", "Mol"]),
    Object.freeze(["\u30E2\u30EB\u30C7\u30F3\u30C8", "ger", "Mordent"]),
    Object.freeze(["\u30E2\u30EB\u30D2\u30CD", "dut", "morfine"]),
    Object.freeze(["\u30E2\u30EB\u30E2\u30C3\u30C8", "dut", "marmot"]),
    Object.freeze(["\u30E2\u30F3\u30B7\u30A7\u30EA\u30FC", "fre", "mon ch\xE9ri"]),
    Object.freeze(["\u30E2\u30F3\u30B9\u30C6\u30E9", "lat", "monstera"]),
    Object.freeze(["\u30E2\u30F3\u30D1\u30EA", "fre", "mon Paris"]),
    Object.freeze(["\u30E2\u30F3\u30FB\u30B7\u30A7\u30EA\u30FC", "fre", "mon ch\xE9ri"]),
    Object.freeze(["\u30E2\u30F3\u30FB\u30D1\u30EA", "fre", "mon Paris"]),
    Object.freeze(["\u30E2\u30FC\u30BC\u30EB", "ger", "Mausergewehr"]),
    Object.freeze(["\u30E2\u30FC\u30BF\u30FC\u30EC\u30FC\u30B9", "eng", "motor race"]),
    Object.freeze(["\u30E2\u30FC\u30BF\u30FC\u30FB\u30EC\u30FC\u30B9", "eng", "motor race"]),
    Object.freeze(["\u30E2\u30FC\u30C9", "fre", "mode"]),
    Object.freeze(["\u30E4\u30AA\u30C1\u30E5\u30A6\u30CF\u30A4", "chi", "y\u0101o ji\u01D4 p\xE1i"]),
    Object.freeze(["\u30E4\u30AA\u30C1\u30E5\u30A6\u30D1\u30A4", "chi", "y\u0101o ji\u01D4 p\xE1i"]),
    Object.freeze(["\u30E4\u30AA\u30C1\u30E5\u30FC\u30CF\u30A4", "chi", "y\u0101o ji\u01D4 p\xE1i"]),
    Object.freeze(["\u30E4\u30AA\u30C1\u30E5\u30FC\u30D1\u30A4", "chi", "y\u0101o ji\u01D4 p\xE1i"]),
    Object.freeze(["\u30E4\u30C3\u30B1", "ger", "Jacke"]),
    Object.freeze(["\u30E4\u30DD\u30F3\u30B9\u30AD\u30FC", "rus", "yaponskiy"]),
    Object.freeze(["\u30E4\u30E9\u30C3\u30D1", "spa", "jalapa"]),
    Object.freeze(["\u30E4\u30F3\u30C1\u30E7", "chi", "y\xE1ngch\u0113"]),
    Object.freeze(["\u30E4\u30F3\u30CB\u30E7\u30E0", "kor", "yangnyeom"]),
    Object.freeze(["\u30E4\u30F3\u30CB\u30E7\u30E0\u30C1\u30AD\u30F3", "kor", "yangnyeom chikin"]),
    Object.freeze(["\u30E4\u30F3\u30CB\u30E7\u30E0\u30FB\u30C1\u30AD\u30F3", "kor", "yangnyeom chikin"]),
    Object.freeze(["\u30E4\u30F3\u30CB\u30E7\u30F3", "kor", "yangnyeom"]),
    Object.freeze(["\u30E4\u30F3\u30CB\u30E7\u30F3\u30C1\u30AD\u30F3", "kor", "yangnyeom chikin"]),
    Object.freeze(["\u30E4\u30F3\u30CB\u30E7\u30F3\u30FB\u30C1\u30AD\u30F3", "kor", "yangnyeom chikin"]),
    Object.freeze(["\u30E4\u30F3\u30D4\u30FC", "chi", "y\xE1ngp\xED"]),
    Object.freeze(["\u30E4\u30F3\u30DE", "ger", "Jammer"]),
    Object.freeze(["\u30E4\u30FC", "ger", "ja"]),
    Object.freeze(["\u30E6\u30A2\u30F3", "chi", "yu\xE1n"]),
    Object.freeze(["\u30E6\u30A6\u30C6\u30A3\u30A2\u30AA", "chi", "y\xF3uti\xE1o"]),
    Object.freeze(["\u30E6\u30C0\u30E4", "lat", "Judaea"]),
    Object.freeze(["\u30E6\u30CA\u30CB\u30DF\u30B9\u30E0", "fre", "unanimisme"]),
    Object.freeze(["\u30E6\u30CB\u30D0\u30FC\u30B5\u30EB\u30DB\u30C3\u30B1\u30FC", "eng", "universal hockey"]),
    Object.freeze(["\u30E6\u30CB\u30D0\u30FC\u30B5\u30EB\u30FB\u30DB\u30C3\u30B1\u30FC", "eng", "universal hockey"]),
    Object.freeze(["\u30E6\u30DE\u30CB\u30B9\u30C8", "fre", "humaniste"]),
    Object.freeze(["\u30E6\u30DE\u30CB\u30B9\u30E0", "fre", "humanisme"]),
    Object.freeze(["\u30E6\u30DE\u30CB\u30C6", "fre", "humanit\xE9"]),
    Object.freeze(["\u30E6\u30EA\u30A4\u30AB", "gre", "heureka"]),
    Object.freeze(["\u30E6\u30F3\u30DC", "fre", "Yumbo"]),
    Object.freeze(["\u30E6\u30FC\u30B7\u30E3\u30F3", "chi", "y\xFAxi\u0101ng"]),
    Object.freeze(["\u30E6\u30FC\u30BF\u30CA\u30B8\u30FC", "ger", "Euthanasie"]),
    Object.freeze(["\u30E6\u30FC\u30BF\u30CA\u30FC\u30B8\u30FC", "ger", "Euthanasie"]),
    Object.freeze(["\u30E6\u30FC\u30EA\u30F3\u30C1\u30FC", "chi", "y\xF3u l\xEDn j\u012B"]),
    Object.freeze(["\u30E6\u30FC\u30EC\u30AB", "gre", "heureka"]),
    Object.freeze(["\u30E8\u30A4\u30AF", "fin", "joiku"]),
    Object.freeze(["\u30E8\u30A6\u30B0\u30EB\u30C8", "ger", "Yoghurt"]),
    Object.freeze(["\u30E8\u30A6\u30C6\u30A3\u30E4\u30AA", "chi", "y\xF3uti\xE1o"]),
    Object.freeze(["\u30E8\u30A6\u30C9", "ger", "Jod"]),
    Object.freeze(["\u30E8\u30AA\u30ED\u30C3\u30D1", "por", "Europa"]),
    Object.freeze(["\u30E8\u30AA\u30ED\u30C4\u30D1", "por", "Europa"]),
    Object.freeze(["\u30E8\u30B0\u30EB\u30C8", "ger", "Yoghurt"]),
    Object.freeze(["\u30E8\u30B8\u30A6\u30E0", "dut", "jodium"]),
    Object.freeze(["\u30E8\u30FC\u30B0\u30EB\u30C8", "ger", "Yoghurt"]),
    Object.freeze(["\u30E8\u30FC\u30C7\u30EB", "ger", "Jodel"]),
    Object.freeze(["\u30E8\u30FC\u30C9", "ger", "Jod"]),
    Object.freeze(["\u30E8\u30FC\u30C9\u30AB\u30EA\u30A6\u30E0", "ger", "Jodkalium"]),
    Object.freeze(["\u30E8\u30FC\u30C9\u30C1\u30F3\u30AD", "ger", "Jodtinktur"]),
    Object.freeze(["\u30E8\u30FC\u30ED\u30C3\u30D1", "por", "Europa"]),
    Object.freeze(["\u30E8\u30FC\u30ED\u30D1", "por", "Europa"]),
    Object.freeze(["\u30E9\u30A4\u30AF\u30EA\u30C3\u30AD", "tur", "laiklik"]),
    Object.freeze(["\u30E9\u30A4\u30C8\u30A2\u30C3\u30D7", "eng", "light up"]),
    Object.freeze(["\u30E9\u30A4\u30C8\u30FB\u30A2\u30C3\u30D7", "eng", "light up"]),
    Object.freeze(["\u30E9\u30A4\u30F3\u30D1\u30A6\u30C0\u30FC", "eng", "line powder"]),
    Object.freeze(["\u30E9\u30A4\u30F3\u30FB\u30D1\u30A6\u30C0\u30FC", "eng", "line powder"]),
    Object.freeze(["\u30E9\u30A6\u30F3\u30C0\u30FC", "eng", "rounder"]),
    Object.freeze(["\u30E9\u30AA\u30C1\u30E5\u30A6", "chi", "l\u01CEoji\u01D4"]),
    Object.freeze(["\u30E9\u30AA\u30C1\u30E5\u30FC", "chi", "l\u01CEoji\u01D4"]),
    Object.freeze(["\u30E9\u30AA\u30C8\u30A6\u30D1\u30A4", "chi", "l\u01CEo t\xF3u p\xE1i"]),
    Object.freeze(["\u30E9\u30AC\u30FC\u30DE\u30F3", "eng", "rugger man"]),
    Object.freeze(["\u30E9\u30AC\u30FC\u30FB\u30DE\u30F3", "eng", "rugger man"]),
    Object.freeze(["\u30E9\u30AF\u30C8\u30B2\u30F3", "ger", "Laktogen"]),
    Object.freeze(["\u30E9\u30AF\u30C8\u30FC\u30BC", "ger", "Laktose"]),
    Object.freeze(["\u30E9\u30B0\u30FC", "fre", "rago\xFBt"]),
    Object.freeze(["\u30E9\u30B7\u30E3", "por", "raxa"]),
    Object.freeze(["\u30E9\u30B9\u30BF\u30D5\u30A1\u30EA\u30BA\u30E0", "eng", "Rastafarism"]),
    Object.freeze(["\u30E9\u30C3\u30BF\u30EB", "ger", "Leiter"]),
    Object.freeze(["\u30E9\u30C3\u30C6", "ger", "Ratte"]),
    Object.freeze(["\u30E9\u30C6\u30EB\u30CD", "ger", "Laterne"]),
    Object.freeze(["\u30E9\u30D9\u30A4\u30AB", "por", "rabeca"]),
    Object.freeze(["\u30E9\u30E0\u30B3\u30FC\u30AF", "eng", "rum Coke"]),
    Object.freeze(["\u30E9\u30E0\u30CD", "eng", "lemonade"]),
    Object.freeze(["\u30E9\u30E0\u30FB\u30B3\u30FC\u30AF", "eng", "rum Coke"]),
    Object.freeze(["\u30E9\u30F3\u30AC\u30FC\u30B8\u30E5", "fre", "langage"]),
    Object.freeze(["\u30E9\u30F3\u30B0", "fre", "langue"]),
    Object.freeze(["\u30E9\u30F3\u30B0\u30C9\u30B7\u30E3", "fre", "langue de chat"]),
    Object.freeze(["\u30E9\u30F3\u30B0\u30FB\u30C9\u30FB\u30B7\u30E3", "fre", "langue de chat"]),
    Object.freeze(["\u30E9\u30F3\u30BF\u30F3", "ger", "Lanthan"]),
    Object.freeze(["\u30E9\u30F3\u30C1\u30A8", "fre", "rentier"]),
    Object.freeze(["\u30E9\u30F3\u30C7\u30D6\u30FC", "fre", "rendez-vous"]),
    Object.freeze(["\u30E9\u30F3\u30C7\u30F4\u30FC", "fre", "rendez-vous"]),
    Object.freeze(["\u30E9\u30F3\u30C9\u30BB\u30EB", "dut", "ransel"]),
    Object.freeze(["\u30E9\u30F3\u30CB\u30F3\u30B0\u30DE\u30B7\u30F3", "eng", "running machine"]),
    Object.freeze(["\u30E9\u30F3\u30CB\u30F3\u30B0\u30DE\u30B7\u30FC\u30F3", "eng", "running machine"]),
    Object.freeze(["\u30E9\u30F3\u30CB\u30F3\u30B0\u30FB\u30DE\u30B7\u30F3", "eng", "running machine"]),
    Object.freeze(["\u30E9\u30F3\u30CB\u30F3\u30B0\u30FB\u30DE\u30B7\u30FC\u30F3", "eng", "running machine"]),
    Object.freeze(["\u30E9\u30FC\u30B2", "ger", "Lage"]),
    Object.freeze(["\u30E9\u30FC\u30B2\u30EA", "rus", "lager'"]),
    Object.freeze(["\u30E9\u30FC\u30B2\u30EB", "rus", "lager'"]),
    Object.freeze(["\u30E9\u30FC\u30D0\u30A4\u30B5\u30A4", "chi", "l\xE0b\xE1ic\xE0i"]),
    Object.freeze(["\u30E9\u30FC\u30D0\u30A4\u30C4\u30A1\u30A4", "chi", "l\xE0b\xE1ic\xE0i"]),
    Object.freeze(["\u30E9\u30FC\u30D1\u30FC\u30C4\u30A1\u30A4", "chi", "l\xE0b\xE1ic\xE0i"]),
    Object.freeze(["\u30E9\u30FC\u30DE\u30F3", "ger", "Rahmen"]),
    Object.freeze(["\u30E9\u30FC\u30E6", "chi", "l\xE0y\xF3u"]),
    Object.freeze(["\u30EA\u30A2\u30EB\u30D5\u30A1\u30A4\u30C8", "eng", "real fight"]),
    Object.freeze(["\u30EA\u30A2\u30EB\u30FB\u30D5\u30A1\u30A4\u30C8", "eng", "real fight"]),
    Object.freeze(["\u30EA\u30A3\u30A6", "chi", "li\xF9"]),
    Object.freeze(["\u30EA\u30A6", "chi", "li\xF9"]),
    Object.freeze(["\u30EA\u30AB\u30AA\u30F3", "lat", "Lycaon"]),
    Object.freeze(["\u30EA\u30B5\u30A4\u30AF\u30EB\u30DC\u30C3\u30AF\u30B9", "eng", "recycle box"]),
    Object.freeze(["\u30EA\u30B5\u30A4\u30AF\u30EB\u30FB\u30DC\u30C3\u30AF\u30B9", "eng", "recycle box"]),
    Object.freeze(["\u30EA\u30B9", "ger", "Riss"]),
    Object.freeze(["\u30EA\u30B9\u30C8\u30E9\u30F3\u30C6", "ita", "ristorante"]),
    Object.freeze(["\u30EA\u30C3\u30D7\u30AF\u30EA\u30FC\u30E0", "eng", "lip cream"]),
    Object.freeze(["\u30EA\u30C3\u30D7\u30FB\u30AF\u30EA\u30FC\u30E0", "eng", "lip cream"]),
    Object.freeze(["\u30EA\u30C8\u30DF\u30C3\u30AF", "fre", "rythmique"]),
    Object.freeze(["\u30EA\u30D1\u30FC\u30BC", "ger", "Lipase"]),
    Object.freeze(["\u30EA\u30D2\u30E0\u30A4", "chi", "l\xE9uih h\xE0hng mui"]),
    Object.freeze(["\u30EA\u30D5\u30A9\u30FC\u30E0", "eng", "reform"]),
    Object.freeze(["\u30EA\u30D5\u30C6\u30A3\u30F3\u30B0", "eng", "lifting"]),
    Object.freeze(["\u30EA\u30D6", "eng", "lib"]),
    Object.freeze(["\u30EA\u30D9\u30F3\u30B8\u30DD\u30EB\u30CE", "eng", "revenge porno"]),
    Object.freeze(["\u30EA\u30D9\u30F3\u30B8\u30FB\u30DD\u30EB\u30CE", "eng", "revenge porno"]),
    Object.freeze(["\u30EA\u30DC\u30FC\u30F3\u30D9\u30A4\u30D3\u30FC", "eng", "reborn baby"]),
    Object.freeze(["\u30EA\u30DC\u30FC\u30F3\u30FB\u30D9\u30A4\u30D3\u30FC", "eng", "reborn baby"]),
    Object.freeze(["\u30EA\u30E3\u30F3", "chi", "li\u01CEng"]),
    Object.freeze(["\u30EA\u30E3\u30F3\u30B7\u30E3\u30F3\u30C6\u30F3", "chi", "li\u01CEng xi\xE0ng t\u012Bng"]),
    Object.freeze(["\u30EA\u30E3\u30F3\u30D4\u30FC", "chi", "li\xE1ngp\xED"]),
    Object.freeze(["\u30EA\u30E3\u30F3\u30DA\u30FC\u30B3\u30FC", "chi", "li\u01CEng b\u0113i k\u01D2u"]),
    Object.freeze(["\u30EA\u30E5\u30C3\u30AF\u30B5\u30C3\u30AF", "ger", "Rucksack"]),
    Object.freeze(["\u30EA\u30E5\u30C3\u30AF\u30B6\u30C3\u30AF", "ger", "Rucksack"]),
    Object.freeze(["\u30EA\u30E5\u30FC", "chi", "li\xF9"]),
    Object.freeze(["\u30EA\u30E5\u30FC\u30A4\u30FC\u30BD\u30FC", "chi", "l\u01DC y\u012B s\xE8"]),
    Object.freeze(["\u30EA\u30E5\u30FC\u30D5\u30A1", "chi", "l\u01DC f\u0101"]),
    Object.freeze(["\u30EA\u30E9", "fre", "lilas"]),
    Object.freeze(["\u30EA\u30F3\u30AF\u30D0\u30CA\u30FC", "eng", "link banner"]),
    Object.freeze(["\u30EA\u30F3\u30AF\u30FB\u30D0\u30CA\u30FC", "eng", "link banner"]),
    Object.freeze(["\u30EA\u30F3\u30B7\u30E3\u30F3\u30AB\u30A4\u30DB\u30A6", "chi", "l\u01D0ng sh\xE0ng k\u0101i hu\u0101"]),
    Object.freeze(["\u30EA\u30F3\u30B7\u30E3\u30F3\u30AB\u30A4\u30DB\u30FC", "chi", "l\u01D0ng sh\xE0ng k\u0101i hu\u0101"]),
    Object.freeze(["\u30EA\u30F3\u30B7\u30E3\u30F3\u30D1\u30A4", "chi", "l\u01D0ng sh\xE0ng p\xE1i"]),
    Object.freeze(["\u30EA\u30F3\u30C1", "eng", "lynch"]),
    Object.freeze(["\u30EA\u30F3\u30C7\u30F3", "ger", "Linden"]),
    Object.freeze(["\u30EA\u30F3\u30C7\u30F3\u30D0\u30A6\u30E0", "ger", "Lindenbaum"]),
    Object.freeze(["\u30EA\u30F3\u30CD\u30EB", "fre", "lini\xE8re"]),
    Object.freeze(["\u30EA\u30FC\u30C1", "chi", "l\xECzh\xED"]),
    Object.freeze(["\u30EA\u30FC\u30C8", "ger", "Lied"]),
    Object.freeze(["\u30EA\u30FC\u30C9", "ger", "Lied"]),
    Object.freeze(["\u30EA\u30FC\u30C9\u30F4\u30A9\u30FC", "fre", "ris de veau"]),
    Object.freeze(["\u30EA\u30FC\u30D1\u30A4", "chi", "l\u01D0 p\xE1i"]),
    Object.freeze(["\u30EA\u30FC\u30D2\u30F3\u30E0\u30A4", "chi", "l\xE9uih h\xE0hng mui"]),
    Object.freeze(["\u30EA\u30FC\u30D9", "ger", "Liebe"]),
    Object.freeze(["\u30EB\u30AF\u30BB\u30F3\u30D6\u30EB\u30AF", "ger", "Luxemburg"]),
    Object.freeze(["\u30EB\u30AF\u30BB\u30F3\u30D6\u30EB\u30B0", "ger", "Luxemburg"]),
    Object.freeze(["\u30EB\u30B3\u30E9", "ita", "rucola"]),
    Object.freeze(["\u30EB\u30B5\u30F3\u30C1\u30DE\u30F3", "fre", "ressentiment"]),
    Object.freeze(["\u30EB\u30B7\u30D5\u30A7\u30EB", "por", "L\xFAcifer"]),
    Object.freeze(["\u30EB\u30BB\u30C3\u30C8", "fre", "recette"]),
    Object.freeze(["\u30EB\u30C3\u30AF\u30B5\u30C3\u30AF", "ger", "Rucksack"]),
    Object.freeze(["\u30EB\u30C3\u30AF\u30B6\u30C3\u30AF", "ger", "Rucksack"]),
    Object.freeze(["\u30EB\u30C3\u30B3\u30E9", "ita", "rucola"]),
    Object.freeze(["\u30EB\u30D0\u30B7\u30AB", "rus", "rubashka"]),
    Object.freeze(["\u30EB\u30D1\u30B7\u30AB", "rus", "rubashka"]),
    Object.freeze(["\u30EB\u30D4\u30CA\u30B9", "lat", "lupinus"]),
    Object.freeze(["\u30EB\u30E0\u30C8\u30D7\u30D5", "ger", "Rumtopf"]),
    Object.freeze(["\u30EB\u30F3\u30B2", "ger", "Lunge"]),
    Object.freeze(["\u30EB\u30F3\u30BC", "ger", "Runse"]),
    Object.freeze(["\u30EB\u30F3\u30DA\u30F3", "ger", "Lumpen"]),
    Object.freeze(["\u30EB\u30F3\u30DA\u30F3\u30D7\u30ED\u30EC\u30BF\u30EA\u30A2\u30FC\u30C8", "ger", "Lumpenproletariat"]),
    Object.freeze(["\u30EB\u30F3\u30DA\u30F3\u30FB\u30D7\u30ED\u30EC\u30BF\u30EA\u30A2\u30FC\u30C8", "ger", "Lumpenproletariat"]),
    Object.freeze(["\u30EB\u30FC\u30B3\u30E9", "ita", "rucola"]),
    Object.freeze(["\u30EB\u30FC\u30BA", "eng", "loose"]),
    Object.freeze(["\u30EB\u30FC\u30C7\u30B5\u30C3\u30AF", "dut", "roede-zak"]),
    Object.freeze(["\u30EB\u30FC\u30D5\u30D0\u30EB\u30B3\u30CB\u30FC", "eng", "roof balcony"]),
    Object.freeze(["\u30EB\u30FC\u30D5\u30FB\u30D0\u30EB\u30B3\u30CB\u30FC", "eng", "roof balcony"]),
    Object.freeze(["\u30EB\u30FC\u30D6\u30EA", "rus", "rubl"]),
    Object.freeze(["\u30EB\u30FC\u30D6\u30EB", "rus", "rubl"]),
    Object.freeze(["\u30EB\u30FC\u30DA", "ger", "Lupe"]),
    Object.freeze(["\u30EB\u30FC\u30ED\u30FC\u30CF\u30F3", "chi", "l\u01D4 r\xF2u f\xE0n"]),
    Object.freeze(["\u30EB\u30FC\u30ED\u30FC\u30D5\u30A1\u30F3", "chi", "l\u01D4 r\xF2u f\xE0n"]),
    Object.freeze(["\u30EB\u30FC\u30F3\u30E9\u30FC\u30C8", "ger", "Rh\xF6nrad"]),
    Object.freeze(["\u30EC\u30A2\u30EA\u30B9\u30E0", "fre", "r\xE9alisme"]),
    Object.freeze(["\u30EC\u30A2\u30EA\u30C6", "fre", "r\xE9alit\xE9"]),
    Object.freeze(["\u30EC\u30A4\u30D1\u30FC", "eng", "raper"]),
    Object.freeze(["\u30EC\u30B8\u30AA\u30F3\u30C9\u30CC\u30FC\u30EB", "fre", "L\xE9gion d'honneur"]),
    Object.freeze(["\u30EC\u30B8\u30AA\u30F3\u30FB\u30C9\u30CC\u30FC\u30EB", "fre", "L\xE9gion d'honneur"]),
    Object.freeze(["\u30EC\u30B8\u30B9\u30BF\u30F3\u30B9", "fre", "r\xE9sistance"]),
    Object.freeze(["\u30EC\u30B8\u30B9\u30C8", "eng", "resist"]),
    Object.freeze(["\u30EC\u30B8\u30E1", "fre", "r\xE9sum\xE9"]),
    Object.freeze(["\u30EC\u30B8\u30E5\u30E1", "fre", "r\xE9sum\xE9"]),
    Object.freeze(["\u30EC\u30B9\u30D0\u30C8\u30EB", "eng", "res(ponse) battle"]),
    Object.freeze(["\u30EC\u30BB\u30D7\u30C8", "ger", "Rezept"]),
    Object.freeze(["\u30EC\u30C0\u30DE", "spa", "retama"]),
    Object.freeze(["\u30EC\u30C3\u30C6\u30EB", "dut", "Letter"]),
    Object.freeze(["\u30EC\u30D0\u30FC", "ger", "Leber"]),
    Object.freeze(["\u30EC\u30D7\u30E9", "lat", "lepra"]),
    Object.freeze(["\u30EC\u30DA\u30BC\u30F3", "eng", "represent"]),
    Object.freeze(["\u30EC\u30DA\u30EB\u30C8\u30EF\u30FC\u30EB", "fre", "r\xE9pertoire"]),
    Object.freeze(["\u30EC\u30F3\u30BF\u30EB\u30AA\u30D5\u30A3\u30B9", "eng", "rental office"]),
    Object.freeze(["\u30EC\u30F3\u30BF\u30EB\u30B5\u30FC\u30D0", "eng", "rental server"]),
    Object.freeze(["\u30EC\u30F3\u30BF\u30EB\u30B5\u30FC\u30D0\u30FC", "eng", "rental server"]),
    Object.freeze(["\u30EC\u30F3\u30BF\u30EB\u30FB\u30AA\u30D5\u30A3\u30B9", "eng", "rental office"]),
    Object.freeze(["\u30EC\u30F3\u30BF\u30EB\u30FB\u30B5\u30FC\u30D0", "eng", "rental server"]),
    Object.freeze(["\u30EC\u30F3\u30BF\u30EB\u30FB\u30B5\u30FC\u30D0\u30FC", "eng", "rental server"]),
    Object.freeze(["\u30EC\u30F3\u30C1\u30E3\u30F3", "chi", "li\xE1nzhu\u0101ng"]),
    Object.freeze(["\u30EC\u30F3\u30D5\u30A9\u30F3\u30D1\u30A4", "chi", "li\xE1n f\u0113ng p\xE1i"]),
    Object.freeze(["\u30EC\u30FC\u30A8\u30F3", "ger", "Lehen"]),
    Object.freeze(["\u30EC\u30FC\u30B7\u30FC", "eng", "racy"]),
    Object.freeze(["\u30EC\u30FC\u30BC\u30C9\u30E9\u30DE", "ger", "Lesedrama"]),
    Object.freeze(["\u30EC\u30FC\u30D9\u30F3", "ger", "Leben"]),
    Object.freeze(["\u30EC\u30FC\u30D9\u30F3\u30B9\u30D5\u30A3\u30ED\u30BE\u30D5\u30A3\u30FC", "ger", "Lebensphilosophie"]),
    Object.freeze(["\u30ED\u30A4\u30B7\u30F3", "ger", "Leucin"]),
    Object.freeze(["\u30ED\u30A4\u30DE\u30C1\u30B9", "ger", "Rheumatismus"]),
    Object.freeze(["\u30ED\u30A6\u30B8\u30A2\u30E2", "chi", "r\xF2uji\u0101m\xF3"]),
    Object.freeze(["\u30ED\u30A6\u30B8\u30E3\u30FC\u30E2\u30FC", "chi", "r\xF2uji\u0101m\xF3"]),
    Object.freeze(["\u30ED\u30A6\u30EA\u30E5", "fin", "l\xF6yly"]),
    Object.freeze(["\u30ED\u30A6\u30EA\u30E5\u30A6", "fin", "l\xF6yly"]),
    Object.freeze(["\u30ED\u30AA\u30B8\u30E3\u30FC\u30E2\u30FC", "chi", "r\xF2uji\u0101m\xF3"]),
    Object.freeze(["\u30ED\u30AF\u30E0", "tur", "lokum"]),
    Object.freeze(["\u30ED\u30B3", "eng", "loco, local"]),
    Object.freeze(["\u30ED\u30B6\u30EA\u30AA", "por", "ros\xE1rio"]),
    Object.freeze(["\u30ED\u30B7\u30A2", "rus", "Rossiya"]),
    Object.freeze(["\u30ED\u30B7\u30A2\u30F3\u30C6\u30A3\u30FC", "eng", "Russian tea"]),
    Object.freeze(["\u30ED\u30B7\u30A2\u30F3\u30FB\u30C6\u30A3\u30FC", "eng", "Russian tea"]),
    Object.freeze(["\u30ED\u30B7\u30E4", "rus", "Rossiya"]),
    Object.freeze(["\u30ED\u30B9\u30C8\u30EB", "dut", "rooster"]),
    Object.freeze(["\u30ED\u30C3\u30AF\u30B0\u30E9\u30B9", "eng", "rock glass"]),
    Object.freeze(["\u30ED\u30C3\u30AF\u30FB\u30B0\u30E9\u30B9", "eng", "rock glass"]),
    Object.freeze(["\u30ED\u30C3\u30BD", "ita", "rosso"]),
    Object.freeze(["\u30ED\u30C3\u30C8", "eng", "lot"]),
    Object.freeze(["\u30ED\u30C8", "eng", "lot"]),
    Object.freeze(["\u30ED\u30DC\u30C3\u30C8\u30A2\u30FC\u30E0", "eng", "robot arm"]),
    Object.freeze(["\u30ED\u30DC\u30C3\u30C8\u30FB\u30A2\u30FC\u30E0", "eng", "robot arm"]),
    Object.freeze(["\u30ED\u30DE\u30F3", "fre", "roman"]),
    Object.freeze(["\u30ED\u30DE\u30F3\u30C1\u30B9\u30E0", "fre", "romantisme"]),
    Object.freeze(["\u30ED\u30DE\u30F3\u30C6\u30A3\u30B9\u30E0", "fre", "romantisme"]),
    Object.freeze(["\u30ED\u30EF\u30A4\u30A2\u30EB", "fre", "royale"]),
    Object.freeze(["\u30ED\u30EF\u30A4\u30E4\u30EB", "fre", "royale"]),
    Object.freeze(["\u30ED\u30F3", "chi", "r\xF3ng"]),
    Object.freeze(["\u30ED\u30FC\u30AB\u30EB\u30D5\u30FC\u30C9", "eng", "local food"]),
    Object.freeze(["\u30ED\u30FC\u30AB\u30EB\u30FB\u30D5\u30FC\u30C9", "eng", "local food"]),
    Object.freeze(["\u30ED\u30FC\u30B8\u30E3\u30FC\u30E2\u30FC", "chi", "r\xF2uji\u0101m\xF3"]),
    Object.freeze(["\u30ED\u30FC\u30BD\u30D5\u30A1", "eng", "low sofa"]),
    Object.freeze(["\u30ED\u30FC\u30BD\u30D5\u30A1\u30FC", "eng", "low sofa"]),
    Object.freeze(["\u30ED\u30FC\u30C6\u30F3\u30B7\u30E7\u30F3", "eng", "low tension"]),
    Object.freeze(["\u30ED\u30FC\u30C8\u30EB", "chi", "l\u01CEot\xF3ur"]),
    Object.freeze(["\u30ED\u30FC\u30DE\u30CA\u30A4\u30BA", "eng", "romanize"]),
    Object.freeze(["\u30ED\u30FC\u30DE\u30F3", "fre", "roman"]),
    Object.freeze(["\u30ED\u30FC\u30EA\u30A8", "fre", "laurier"]),
    Object.freeze(["\u30ED\u30FC\u30FB\u30BD\u30D5\u30A1", "eng", "low sofa"]),
    Object.freeze(["\u30ED\u30FC\u30FB\u30BD\u30D5\u30A1\u30FC", "eng", "low sofa"]),
    Object.freeze(["\u30ED\u30FC\u30FB\u30C6\u30F3\u30B7\u30E7\u30F3", "eng", "low tension"]),
    Object.freeze(["\u30EF\u30A4\u30B7\u30E3\u30C4", "eng", "white shirt"]),
    Object.freeze(["\u30EF\u30A4\u30C9\u30B3\u30F3\u30D0\u30FC\u30BF\u30FC", "eng", "wide converter"]),
    Object.freeze(["\u30EF\u30A4\u30C9\u30D1\u30F3\u30C4", "eng", "wide pants"]),
    Object.freeze(["\u30EF\u30A4\u30C9\u30FB\u30B3\u30F3\u30D0\u30FC\u30BF\u30FC", "eng", "wide converter"]),
    Object.freeze(["\u30EF\u30A4\u30C9\u30FB\u30D1\u30F3\u30C4", "eng", "wide pants"]),
    Object.freeze(["\u30EF\u30AF\u30C1\u30F3", "ger", "Vakzin"]),
    Object.freeze(["\u30EF\u30C3\u30D5\u30EB\u30E1\u30FC\u30AB\u30FC", "eng", "waffle maker"]),
    Object.freeze(["\u30EF\u30C3\u30D5\u30EB\u30FB\u30E1\u30FC\u30AB\u30FC", "eng", "waffle maker"]),
    Object.freeze(["\u30EF\u30C3\u30DA\u30F3", "ger", "Wappen"]),
    Object.freeze(["\u30EF\u30EB\u30AD\u30E5\u30EA\u30A8", "ger", "Walk\xFCre"]),
    Object.freeze(["\u30EF\u30EB\u30AD\u30E5\u30FC\u30EC", "ger", "Walk\xFCre"]),
    Object.freeze(["\u30EF\u30EF\u30B5\u30A4", "chi", "w\xE1wac\xE0i"]),
    Object.freeze(["\u30EF\u30F3", "chi", "w\xE0n"]),
    Object.freeze(["\u30EF\u30F3\u30BA", "chi", "w\xE0n zi"]),
    Object.freeze(["\u30EF\u30F3\u30BF\u30F3", "chi", "wantan"]),
    Object.freeze(["\u30EF\u30F3\u30BF\u30F3\u30E1\u30F3", "chi", "w\xE0hn t\u0101n mihn"]),
    Object.freeze(["\u30EF\u30F3\u30C0\u30FC\u30D5\u30A9\u30FC\u30B2\u30EB", "ger", "Wandervogel"]),
    Object.freeze(["\u30EF\u30F3\u30C4", "chi", "w\xE0n zi"]),
    Object.freeze(["\u30EF\u30F3\u30C7\u30EB\u30F3\u30B0", "ger", "Wanderung"]),
    Object.freeze(["\u30EF\u30F3\u30D1\u30A4", "chi", "w\xE1ng p\xE1i"]),
    Object.freeze(["\u30EF\u30F3\u30D4\u30FC\u30B9", "eng", "one-piece"]),
    Object.freeze(["\u30EF\u30F3\u30DB\u30F3", "chi", "w\u01CEngh\xF3ng"]),
    Object.freeze(["\u30EF\u30F3\u30DB\u30FC\u30EB", "eng", "one whole"]),
    Object.freeze(["\u30EF\u30F3\u30E9", "chi", "w\xE1nli\u01CEo"]),
    Object.freeze(["\u30EF\u30F3\u30FB\u30DB\u30FC\u30EB", "eng", "one whole"]),
    Object.freeze(["\u30EF\u30FC\u30AF\u30C1\u30A7\u30A2", "eng", "work chair"]),
    Object.freeze(["\u30EF\u30FC\u30AF\u30FB\u30C1\u30A7\u30A2", "eng", "work chair"]),
    Object.freeze(["\u30F4\u30A1\u30A4\u30B9\u30F4\u30EB\u30B9\u30C8", "ger", "Wei\xDFwurst"]),
    Object.freeze(["\u30F4\u30A1\u30AB\u30F3\u30B9", "fre", "vacances"]),
    Object.freeze(["\u30F4\u30A1\u30EA\u30A2\u30BF\u30B9", "lat", "variatus"]),
    Object.freeze(["\u30F4\u30A1\u30EA\u30A8\u30C6", "fre", "vari\xE9t\xE9"]),
    Object.freeze(["\u30F4\u30A1\u30EA\u30A8\u30C6\u30A3", "fre", "vari\xE9t\xE9"]),
    Object.freeze(["\u30F4\u30A1\u30EB\u30AD\u30E5\u30EA\u30E4", "ger", "Walk\xFCre"]),
    Object.freeze(["\u30F4\u30A1\u30EB\u30AD\u30E5\u30FC\u30EC", "ger", "Walk\xFCre"]),
    Object.freeze(["\u30F4\u30A1\u30EB\u30CA", "san", "var\u1E47a"]),
    Object.freeze(["\u30F4\u30A1\u30F3\u30ED\u30BC", "fre", "vin ros\xE9"]),
    Object.freeze(["\u30F4\u30A1\u30F3\u30FB\u30ED\u30BC", "fre", "vin ros\xE9"]),
    Object.freeze(["\u30F4\u30A1\u30FC\u30B8\u30F3\u30AA\u30A4\u30EB", "eng", "virgin oil"]),
    Object.freeze(["\u30F4\u30A3\u30AA\u30EB", "fre", "viole"]),
    Object.freeze(["\u30F4\u30A3\u30AA\u30ED\u30F3", "fre", "violon"]),
    Object.freeze(["\u30F4\u30A3\u30AA\u30FC\u30EB", "fre", "viole"]),
    Object.freeze(["\u30F4\u30A3\u30CD\u30FC\u30B0\u30EB", "fre", "vinaigre"]),
    Object.freeze(["\u30F4\u30A3\u30FC", "fre", "vie"]),
    Object.freeze(["\u30F4\u30A7\u30CD\u30C1\u30A2", "ita", "Venezia"]),
    Object.freeze(["\u30F4\u30A7\u30CD\u30C4\u30A3\u30A2", "ita", "Venezia"]),
    Object.freeze(["\u30F4\u30A7\u30CD\u30FC\u30C4\u30A3\u30A2", "ita", "Venezia"]),
    Object.freeze(["\u30F4\u30A7\u30EB\u30B9\u30BF", "rus", "versta"]),
    Object.freeze(["\u30F4\u30A7\u30F3\u30C6\u30A3", "ita", "venti"]),
    Object.freeze(["\u30F4\u30A9\u30F3\u30B4\u30EC", "ita", "vongole"]),
    Object.freeze(["\u30F4\u30EB\u30AC\u30BF", "lat", "vulgata"]),
    Object.freeze(["\u30F4\u30EB\u30AC\u30FC\u30BF", "lat", "vulgata"]),
    Object.freeze(["\u30F4\u30EB\u30FC\u30C6", "fre", "velout\xE9e"])
  ]);

  // src/loanword-origins.mjs
  var REVIEWED_AT = "2026-08-22";
  var LOANWORD_LANGUAGE_MARKS = Object.freeze({
    en: null,
    fr: "\u4ECF",
    de: "\u72EC",
    es: "\u897F",
    it: "\u4F0A",
    nl: "\u862D",
    pt: "\u8461",
    ru: "\u9732",
    zh: "\u4E2D",
    ko: "\u97D3",
    no: "\u8AFE",
    fi: "\u82AC",
    tr: "\u571F",
    la: "\u7F85",
    el: "\u5E0C",
    vi: "\u8D8A",
    sa: "\u68B5",
    th: "\u6CF0",
    hi: "\u5370",
    sv: "\u745E",
    mn: "\u8499",
    hu: "\u6D2A",
    ms: "\u99AC",
    da: "\u4E01",
    cs: "\u6377"
  });
  var CURATED_LOANWORD_DEFINITIONS = Object.freeze([
    // English. English origins intentionally have no country mark.
    ["en-account", "en", "account", ["\u30A2\u30AB\u30A6\u30F3\u30C8"]],
    ["en-access", "en", "access", ["\u30A2\u30AF\u30BB\u30B9"]],
    ["en-update", "en", "update", ["\u30A2\u30C3\u30D7\u30C7\u30FC\u30C8"]],
    ["en-algorithm", "en", "algorithm", ["\u30A2\u30EB\u30B4\u30EA\u30BA\u30E0"]],
    ["en-animation", "en", "animation", ["\u30A2\u30CB\u30E1\u30FC\u30B7\u30E7\u30F3"]],
    ["en-event", "en", "event", ["\u30A4\u30D9\u30F3\u30C8"]],
    ["en-interview", "en", "interview", ["\u30A4\u30F3\u30BF\u30D3\u30E5\u30FC"]],
    ["en-web", "en", "web", ["\u30A6\u30A7\u30D6"]],
    ["en-engine", "en", "engine", ["\u30A8\u30F3\u30B8\u30F3"]],
    ["en-online", "en", "online", ["\u30AA\u30F3\u30E9\u30A4\u30F3"]],
    ["en-offline", "en", "offline", ["\u30AA\u30D5\u30E9\u30A4\u30F3"]],
    ["en-camera", "en", "camera", ["\u30AB\u30E1\u30E9"]],
    ["en-cloud", "en", "cloud", ["\u30AF\u30E9\u30A6\u30C9"]],
    ["en-click", "en", "click", ["\u30AF\u30EA\u30C3\u30AF"]],
    ["en-game", "en", "game", ["\u30B2\u30FC\u30E0"]],
    ["en-content", "en", "content", ["\u30B3\u30F3\u30C6\u30F3\u30C4"]],
    ["en-computer", "en", "computer", ["\u30B3\u30F3\u30D4\u30E5\u30FC\u30BF\u30FC", "\u30B3\u30F3\u30D4\u30E5\u30FC\u30BF"]],
    ["en-server", "en", "server", ["\u30B5\u30FC\u30D0\u30FC", "\u30B5\u30FC\u30D0"]],
    ["en-site", "en", "site", ["\u30B5\u30A4\u30C8"]],
    ["en-system", "en", "system", ["\u30B7\u30B9\u30C6\u30E0"]],
    ["en-sports", "en", "sports", ["\u30B9\u30DD\u30FC\u30C4"]],
    ["en-smartphone", "en", "smartphone", ["\u30B9\u30DE\u30FC\u30C8\u30D5\u30A9\u30F3"]],
    ["en-security", "en", "security", ["\u30BB\u30AD\u30E5\u30EA\u30C6\u30A3"]],
    ["en-software", "en", "software", ["\u30BD\u30D5\u30C8\u30A6\u30A7\u30A2"]],
    ["en-download", "en", "download", ["\u30C0\u30A6\u30F3\u30ED\u30FC\u30C9"]],
    ["en-data", "en", "data", ["\u30C7\u30FC\u30BF"]],
    ["en-database", "en", "database", ["\u30C7\u30FC\u30BF\u30D9\u30FC\u30B9", "\u30C7\u30FC\u30BF\u30FB\u30D9\u30FC\u30B9"]],
    ["en-digital", "en", "digital", ["\u30C7\u30B8\u30BF\u30EB"]],
    ["en-television", "en", "television", ["\u30C6\u30EC\u30D3"]],
    ["en-network", "en", "network", ["\u30CD\u30C3\u30C8\u30EF\u30FC\u30AF"]],
    ["en-news", "en", "news", ["\u30CB\u30E5\u30FC\u30B9"]],
    ["en-hardware", "en", "hardware", ["\u30CF\u30FC\u30C9\u30A6\u30A7\u30A2"]],
    ["en-file", "en", "file", ["\u30D5\u30A1\u30A4\u30EB"]],
    ["en-browser", "en", "browser", ["\u30D6\u30E9\u30A6\u30B6\u30FC", "\u30D6\u30E9\u30A6\u30B6"]],
    ["en-privacy", "en", "privacy", ["\u30D7\u30E9\u30A4\u30D0\u30B7\u30FC"]],
    ["en-program", "en", "program", ["\u30D7\u30ED\u30B0\u30E9\u30E0"]],
    ["en-page", "en", "page", ["\u30DA\u30FC\u30B8"]],
    ["en-mail", "en", "mail", ["\u30E1\u30FC\u30EB"]],
    ["en-model", "en", "model", ["\u30E2\u30C7\u30EB"]],
    ["en-link", "en", "link", ["\u30EA\u30F3\u30AF"]],
    ["en-login", "en", "login", ["\u30ED\u30B0\u30A4\u30F3"]],
    ["en-report", "en", "report", ["\u30EC\u30DD\u30FC\u30C8"]],
    ["en-hotel", "en", "hotel", ["\u30DB\u30C6\u30EB"]],
    ["en-taxi", "en", "taxi", ["\u30BF\u30AF\u30B7\u30FC"]],
    ["en-bus", "en", "bus", ["\u30D0\u30B9"]],
    ["en-sandwich", "en", "sandwich", ["\u30B5\u30F3\u30C9\u30A4\u30C3\u30C1"]],
    // French.
    ["fr-coup-etat", "fr", "coup d'\xC9tat", ["\u30AF\u30FC\u30C7\u30BF\u30FC"]],
    ["fr-enquete", "fr", "enqu\xEAte", ["\u30A2\u30F3\u30B1\u30FC\u30C8"]],
    ["fr-atelier", "fr", "atelier", ["\u30A2\u30C8\u30EA\u30A8"]],
    ["fr-a-la-carte", "fr", "\xE0 la carte", ["\u30A2\u30E9\u30AB\u30EB\u30C8", "\u30A2\u30FB\u30E9\u30FB\u30AB\u30EB\u30C8"]],
    ["fr-hors-doeuvre", "fr", "hors-d'\u0153uvre", ["\u30AA\u30FC\u30C9\u30D6\u30EB"]],
    ["fr-gourmet", "fr", "gourmet", ["\u30B0\u30EB\u30E1"]],
    ["fr-concours", "fr", "concours", ["\u30B3\u30F3\u30AF\u30FC\u30EB"]],
    ["fr-conte", "fr", "conte", ["\u30B3\u30F3\u30C8"]],
    ["fr-genre", "fr", "genre", ["\u30B8\u30E3\u30F3\u30EB"]],
    ["fr-dessin", "fr", "dessin", ["\u30C7\u30C3\u30B5\u30F3"]],
    ["fr-debut", "fr", "d\xE9but", ["\u30C7\u30D3\u30E5\u30FC"]],
    ["fr-ballet", "fr", "ballet", ["\u30D0\u30EC\u30A8"]],
    ["fr-boutique", "fr", "boutique", ["\u30D6\u30C6\u30A3\u30C3\u30AF"]],
    ["fr-mayonnaise", "fr", "mayonnaise", ["\u30DE\u30E8\u30CD\u30FC\u30BA"]],
    ["fr-reportage", "fr", "reportage", ["\u30EB\u30DD\u30EB\u30BF\u30FC\u30B8\u30E5"]],
    ["fr-silhouette", "fr", "silhouette", ["\u30B7\u30EB\u30A8\u30C3\u30C8"]],
    ["fr-crayon", "fr", "crayon", ["\u30AF\u30EC\u30E8\u30F3"]],
    ["fr-restaurant", "fr", "restaurant", ["\u30EC\u30B9\u30C8\u30E9\u30F3"]],
    ["fr-etiquette", "fr", "\xE9tiquette", ["\u30A8\u30C1\u30B1\u30C3\u30C8"]],
    ["fr-cabaret", "fr", "cabaret", ["\u30AD\u30E3\u30D0\u30EC\u30FC"]],
    ["fr-parfait", "fr", "parfait", ["\u30D1\u30D5\u30A7"]],
    ["fr-potage", "fr", "potage", ["\u30DD\u30BF\u30FC\u30B8\u30E5"]],
    ["fr-croissant", "fr", "croissant", ["\u30AF\u30ED\u30EF\u30C3\u30B5\u30F3"]],
    ["fr-chanson", "fr", "chanson", ["\u30B7\u30E3\u30F3\u30BD\u30F3"]],
    // German.
    ["de-arbeit", "de", "Arbeit", ["\u30A2\u30EB\u30D0\u30A4\u30C8"]],
    ["de-allergie", "de", "Allergie", ["\u30A2\u30EC\u30EB\u30AE\u30FC"]],
    ["de-energie", "de", "Energie", ["\u30A8\u30CD\u30EB\u30AE\u30FC"]],
    ["de-gips", "de", "Gips", ["\u30AE\u30D7\u30B9"]],
    ["de-karte", "de", "Karte", ["\u30AB\u30EB\u30C6"]],
    ["de-neurose", "de", "Neurose", ["\u30CE\u30A4\u30ED\u30FC\u30BC"]],
    ["de-maerchen", "de", "M\xE4rchen", ["\u30E1\u30EB\u30D8\u30F3"]],
    ["de-gelaende", "de", "Gel\xE4nde", ["\u30B2\u30EC\u30F3\u30C7"]],
    ["de-rucksack", "de", "Rucksack", ["\u30EA\u30E5\u30C3\u30AF\u30B5\u30C3\u30AF"]],
    ["de-seminar", "de", "Seminar", ["\u30BC\u30DF\u30CA\u30FC\u30EB"]],
    ["de-thema", "de", "Thema", ["\u30C6\u30FC\u30DE"]],
    ["de-vakzin", "de", "Vakzin", ["\u30EF\u30AF\u30C1\u30F3"]],
    ["de-natrium", "de", "Natrium", ["\u30CA\u30C8\u30EA\u30A6\u30E0"]],
    ["de-kalium", "de", "Kalium", ["\u30AB\u30EA\u30A6\u30E0"]],
    // Spanish.
    ["es-guerrilla", "es", "guerrilla", ["\u30B2\u30EA\u30E9"]],
    ["es-tortilla", "es", "tortilla", ["\u30C8\u30EB\u30C6\u30A3\u30FC\u30E4"]],
    ["es-salsa", "es", "salsa", ["\u30B5\u30EB\u30B5"]],
    ["es-paella", "es", "paella", ["\u30D1\u30A8\u30EA\u30A2"]],
    ["es-flamenco", "es", "flamenco", ["\u30D5\u30E9\u30E1\u30F3\u30B3"]],
    ["es-siesta", "es", "siesta", ["\u30B7\u30A8\u30B9\u30BF"]],
    ["es-macho", "es", "macho", ["\u30DE\u30C3\u30C1\u30E7"]],
    ["es-el-nino", "es", "El Ni\xF1o", ["\u30A8\u30EB\u30CB\u30FC\u30CB\u30E7"]],
    ["es-armadillo", "es", "armadillo", ["\u30A2\u30EB\u30DE\u30B8\u30ED"]],
    // Italian.
    ["it-opera", "it", "opera", ["\u30AA\u30DA\u30E9"]],
    ["it-sonata", "it", "sonata", ["\u30BD\u30CA\u30BF"]],
    ["it-tempo", "it", "tempo", ["\u30C6\u30F3\u30DD"]],
    ["it-piano", "it", "piano", ["\u30D4\u30A2\u30CE"]],
    ["it-forte", "it", "forte", ["\u30D5\u30A9\u30EB\u30C6"]],
    ["it-soprano", "it", "soprano", ["\u30BD\u30D7\u30E9\u30CE"]],
    ["it-aria", "it", "aria", ["\u30A2\u30EA\u30A2"]],
    ["it-ballerina", "it", "ballerina", ["\u30D0\u30EC\u30EA\u30FC\u30CA"]],
    ["it-carpaccio", "it", "carpaccio", ["\u30AB\u30EB\u30D1\u30C3\u30C1\u30E7"]],
    ["it-tiramisu", "it", "tiramis\xF9", ["\u30C6\u30A3\u30E9\u30DF\u30B9"]],
    ["it-pasta", "it", "pasta", ["\u30D1\u30B9\u30BF"]],
    ["it-pizza", "it", "pizza", ["\u30D4\u30B6"]],
    ["it-risotto", "it", "risotto", ["\u30EA\u30BE\u30C3\u30C8"]],
    ["it-gelato", "it", "gelato", ["\u30B8\u30A7\u30E9\u30FC\u30C8"]],
    ["it-espresso", "it", "espresso", ["\u30A8\u30B9\u30D7\u30EC\u30C3\u30BD"]],
    ["it-cappuccino", "it", "cappuccino", ["\u30AB\u30D7\u30C1\u30FC\u30CE"]],
    // Dutch (historical direct loans into Japanese).
    ["nl-glas", "nl", "glas", ["\u30AC\u30E9\u30B9"]],
    ["nl-koffie", "nl", "koffie", ["\u30B3\u30FC\u30D2\u30FC"]],
    ["nl-bier", "nl", "bier", ["\u30D3\u30FC\u30EB"]],
    ["nl-ransel", "nl", "ransel", ["\u30E9\u30F3\u30C9\u30BB\u30EB"]],
    ["nl-gom", "nl", "gom", ["\u30B4\u30E0"]],
    ["nl-blik", "nl", "blik", ["\u30D6\u30EA\u30AD"]],
    ["nl-pincet", "nl", "pincet", ["\u30D4\u30F3\u30BB\u30C3\u30C8"]],
    ["nl-mes", "nl", "mes", ["\u30E1\u30B9"]],
    ["nl-orgel", "nl", "orgel", ["\u30AA\u30EB\u30B4\u30FC\u30EB"]],
    ["nl-lens", "nl", "lens", ["\u30EC\u30F3\u30BA"]],
    // Portuguese (historical direct loans into Japanese).
    ["pt-pao", "pt", "p\xE3o", ["\u30D1\u30F3"]],
    ["pt-botao", "pt", "bot\xE3o", ["\u30DC\u30BF\u30F3"]],
    ["pt-capa", "pt", "capa", ["\u30AB\u30C3\u30D1"]],
    ["pt-sabao", "pt", "sab\xE3o", ["\u30B7\u30E3\u30DC\u30F3"]],
    ["pt-vidro", "pt", "vidro", ["\u30D3\u30FC\u30C9\u30ED"]],
    ["pt-confeito", "pt", "confeito", ["\u30B3\u30F3\u30DA\u30A4\u30C8\u30A6", "\u30B3\u30F3\u30DA\u30A4\u30C8\u30FC"]],
    ["pt-tabaco", "pt", "tabaco", ["\u30BF\u30D0\u30B3"]],
    ["pt-jorro", "pt", "jorro", ["\u30B8\u30E7\u30A6\u30ED"]],
    ["pt-carta", "pt", "carta", ["\u30AB\u30EB\u30BF"]],
    ["pt-cristao", "pt", "crist\xE3o", ["\u30AD\u30EA\u30B7\u30BF\u30F3"]],
    // Russian.
    ["ru-ikra", "ru", "\u0438\u043A\u0440\u0430", ["\u30A4\u30AF\u30E9"]],
    ["ru-norma", "ru", "\u043D\u043E\u0440\u043C\u0430", ["\u30CE\u30EB\u30DE"]],
    ["ru-kombinat", "ru", "\u043A\u043E\u043C\u0431\u0438\u043D\u0430\u0442", ["\u30B3\u30F3\u30D3\u30CA\u30FC\u30C8"]],
    ["ru-troika", "ru", "\u0442\u0440\u043E\u0439\u043A\u0430", ["\u30C8\u30ED\u30A4\u30AB"]],
    ["ru-pechka", "ru", "\u043F\u0435\u0447\u043A\u0430", ["\u30DA\u30C1\u30AB"]],
    ["ru-pirozhki", "ru", "\u043F\u0438\u0440\u043E\u0436\u043A\u0438", ["\u30D4\u30ED\u30B7\u30AD"]],
    ["ru-borshch", "ru", "\u0431\u043E\u0440\u0449", ["\u30DC\u30EB\u30B7\u30C1"]],
    ["ru-vodka", "ru", "\u0432\u043E\u0434\u043A\u0430", ["\u30A6\u30A9\u30C3\u30AB"]],
    // Other high-confidence direct loans.
    ["zh-jiaozi", "zh", "\u9903\u5B50", ["\u30AE\u30E7\u30FC\u30B6", "\u30AE\u30E7\u30A6\u30B6"]],
    ["zh-shaomai", "zh", "\u71D2\u8CE3", ["\u30B7\u30E5\u30FC\u30DE\u30A4"]],
    ["zh-chaofan", "zh", "\u7092\u98EF", ["\u30C1\u30E3\u30FC\u30CF\u30F3"]],
    ["zh-majiang", "zh", "\u9EBB\u5C07", ["\u30DE\u30FC\u30B8\u30E3\u30F3"]],
    ["zh-wulong", "zh", "\u70CF\u9F8D", ["\u30A6\u30FC\u30ED\u30F3"]],
    ["ko-gimchi", "ko", "\uAE40\uCE58", ["\u30AD\u30E0\u30C1"]],
    ["ko-bibimbap", "ko", "\uBE44\uBE54\uBC25", ["\u30D3\u30D3\u30F3\u30D0", "\u30D4\u30D3\u30F3\u30D1"]],
    ["ko-namul", "ko", "\uB098\uBB3C", ["\u30CA\u30E0\u30EB"]],
    ["ko-makgeolli", "ko", "\uB9C9\uAC78\uB9AC", ["\u30DE\u30C3\u30B3\u30EA"]],
    ["ko-jjigae", "ko", "\uCC0C\uAC1C", ["\u30C1\u30B2"]],
    ["ko-tteokbokki", "ko", "\uB5A1\uBCF6\uC774", ["\u30C8\u30C3\u30DD\u30C3\u30AD"]],
    ["no-ski", "no", "ski", ["\u30B9\u30AD\u30FC"]],
    ["fi-sauna", "fi", "sauna", ["\u30B5\u30A6\u30CA"]],
    ["tr-yogurt", "tr", "yo\u011Furt", ["\u30E8\u30FC\u30B0\u30EB\u30C8"]]
  ]);
  var JMDICT_LANGUAGE_CODES = Object.freeze({
    eng: "en",
    fre: "fr",
    ger: "de",
    spa: "es",
    ita: "it",
    dut: "nl",
    por: "pt",
    rus: "ru",
    chi: "zh",
    kor: "ko",
    nor: "no",
    fin: "fi",
    tur: "tr",
    lat: "la",
    gre: "el",
    vie: "vi",
    san: "sa",
    tha: "th",
    hin: "hi",
    swe: "sv",
    mon: "mn",
    hun: "hu",
    may: "ms",
    dan: "da",
    cze: "cs"
  });
  var CURATED_SURFACES = new Set(
    CURATED_LOANWORD_DEFINITIONS.flatMap(([, , , surfaces]) => surfaces)
  );
  var GENERATED_LOANWORD_DEFINITIONS = JMDICT_LOANWORD_ORIGINS.filter(([surface]) => !CURATED_SURFACES.has(surface)).map(([surface, rawLanguage, origin], index) => {
    const language = JMDICT_LANGUAGE_CODES[rawLanguage];
    if (!language) {
      throw new Error(`Unknown JMdict loanword language: ${rawLanguage}`);
    }
    return Object.freeze([
      `jmdict-${rawLanguage}-${String(index).padStart(4, "0")}`,
      language,
      origin,
      Object.freeze([surface])
    ]);
  });
  function defineLoanword([id, language, origin, rawSurfaces], source = "curated") {
    const countryMark = LOANWORD_LANGUAGE_MARKS[language];
    if (countryMark === void 0) {
      throw new Error(`Unknown loanword language: ${language}`);
    }
    const surfaces = Object.freeze([...rawSurfaces]);
    return Object.freeze({
      id,
      languageCode: language,
      languageLabel: countryMark,
      language,
      countryMark,
      origin,
      surfaces,
      confidence: source === "curated" ? "high" : "dictionary",
      reviewedAt: source === "curated" ? REVIEWED_AT : JMDICT_LOANWORD_ORIGIN_METADATA.dictionaryDate,
      source
    });
  }
  var LOANWORD_ORIGINS = Object.freeze(
    [
      ...CURATED_LOANWORD_DEFINITIONS.map((definition) => defineLoanword(definition)),
      ...GENERATED_LOANWORD_DEFINITIONS.map((definition) => defineLoanword(definition, "jmdict"))
    ]
  );
  var SURFACE_INDEX = /* @__PURE__ */ new Map();
  for (const entry of LOANWORD_ORIGINS) {
    for (const surface of entry.surfaces) {
      if (SURFACE_INDEX.has(surface)) {
        throw new Error(`Duplicate loanword surface: ${surface}`);
      }
      SURFACE_INDEX.set(surface, entry);
    }
  }
  var MATCH_CANDIDATES_BY_FIRST_CHARACTER = /* @__PURE__ */ new Map();
  for (const [surface, entry] of SURFACE_INDEX) {
    const firstCharacter = surface[0];
    const candidates = MATCH_CANDIDATES_BY_FIRST_CHARACTER.get(firstCharacter) ?? [];
    candidates.push(Object.freeze({ surface, entry }));
    MATCH_CANDIDATES_BY_FIRST_CHARACTER.set(firstCharacter, candidates);
  }
  for (const [firstCharacter, candidates] of MATCH_CANDIDATES_BY_FIRST_CHARACTER) {
    candidates.sort(
      (left, right) => right.surface.length - left.surface.length || left.surface.localeCompare(right.surface, "ja")
    );
    MATCH_CANDIDATES_BY_FIRST_CHARACTER.set(firstCharacter, Object.freeze(candidates));
  }
  var KATAKANA_WORD_CHARACTER = /^[\p{Script=Katakana}ーｰ]$/u;
  function isKatakanaWordCharacter(character) {
    return Boolean(character) && KATAKANA_WORD_CHARACTER.test(character);
  }
  function hasSafeKatakanaBoundaries(text, start, end) {
    return !isKatakanaWordCharacter(text[start - 1]) && !isKatakanaWordCharacter(text[end]);
  }
  var AMBIGUOUS_PERSON_NAME_SURFACES = /* @__PURE__ */ new Set(["\u30C8\u30E9\u30F3\u30D7"]);
  var PERSON_TITLE_AFTER = /^(?:氏|さん|大統領|前大統領|元大統領|首相|会長|選手|監督|容疑者|被告|議員)/u;
  function looksLikePersonNameContext(text, surface, end) {
    return AMBIGUOUS_PERSON_NAME_SURFACES.has(surface) && PERSON_TITLE_AFTER.test(text.slice(end));
  }
  function findCompleteCompoundPath(text, runStart, runEnd) {
    const paths = /* @__PURE__ */ new Map([[runEnd, Object.freeze([])]]);
    for (let position = runEnd - 1; position >= runStart; position -= 1) {
      const candidates = MATCH_CANDIDATES_BY_FIRST_CHARACTER.get(text[position]) ?? [];
      let bestPath = null;
      for (const candidate of candidates) {
        const end = position + candidate.surface.length;
        const suffix = paths.get(end);
        if (end > runEnd || !suffix || !text.startsWith(candidate.surface, position) || looksLikePersonNameContext(text, candidate.surface, end)) {
          continue;
        }
        const path2 = Object.freeze([candidate, ...suffix]);
        if (!bestPath || path2.length < bestPath.length) {
          bestPath = path2;
        }
      }
      if (bestPath) {
        paths.set(position, bestPath);
      }
    }
    const path = paths.get(runStart);
    return path?.length >= 2 ? path : null;
  }
  function createMatch(text, start, surface, entry) {
    const end = start + surface.length;
    const annotation = formatLoanwordAnnotation(entry);
    return Object.freeze({
      id: entry.id,
      start,
      end,
      surface: text.slice(start, end),
      origin: entry.origin,
      languageCode: entry.languageCode,
      languageLabel: entry.languageLabel,
      display: annotation,
      // Backward-compatible aliases make the matcher easy to consume from
      // older content-controller prototypes.
      language: entry.language,
      countryMark: entry.countryMark,
      annotation
    });
  }
  function formatLoanwordAnnotation(entry) {
    if (!entry || typeof entry.origin !== "string") {
      throw new TypeError("A loanword-origin entry is required");
    }
    return entry.countryMark ? `\uFF08${entry.countryMark}\uFF09${entry.origin}` : entry.origin;
  }
  function findLoanwordMatches(text) {
    if (typeof text !== "string") {
      throw new TypeError("Loanword matching requires a string");
    }
    const matches = [];
    let start = 0;
    while (start < text.length) {
      const candidates = MATCH_CANDIDATES_BY_FIRST_CHARACTER.get(text[start]) ?? [];
      const candidate = candidates.find(({ surface: surface2 }) => {
        const end2 = start + surface2.length;
        return text.startsWith(surface2, start) && hasSafeKatakanaBoundaries(text, start, end2) && !looksLikePersonNameContext(text, surface2, end2);
      });
      if (!candidate && isKatakanaWordCharacter(text[start]) && !isKatakanaWordCharacter(text[start - 1])) {
        let runEnd = start + 1;
        while (runEnd < text.length && isKatakanaWordCharacter(text[runEnd])) {
          runEnd += 1;
        }
        const compoundPath = findCompleteCompoundPath(text, start, runEnd);
        if (compoundPath) {
          let partStart = start;
          for (const part of compoundPath) {
            matches.push(createMatch(text, partStart, part.surface, part.entry));
            partStart += part.surface.length;
          }
        }
        start = runEnd;
        continue;
      }
      if (!candidate) {
        const codePoint = text.codePointAt(start);
        start += codePoint > 65535 ? 2 : 1;
        continue;
      }
      const { surface, entry } = candidate;
      const end = start + surface.length;
      matches.push(createMatch(text, start, surface, entry));
      start = end;
    }
    return Object.freeze(matches);
  }

  // src/content.js
  var CONTROLLER_KEY = "__japaneseFuriganaAiController__";
  var RUBY_ATTRIBUTE = "data-jp-furigana";
  var FOREIGN_PERSON_RUBY_ATTRIBUTE = "data-jp-foreign-person";
  var STYLE_ID = "jp-furigana-ai-style";
  var TOAST_ID = "jp-furigana-ai-toast";
  var TRANSLATION_CONTROLLER_KEY = "__japaneseSelectionTranslationController__";
  var TRANSLATION_UI_ATTRIBUTE = "data-jp-translation-ui";
  var TRANSLATION_CONTROLLER_ATTRIBUTE = "data-jp-translation-controller";
  var LOANWORD_CONTROLLER_KEY = "__japaneseLoanwordOriginController__";
  var LOANWORD_ATTRIBUTE = "data-jp-loanword-origin";
  var LOANWORD_STYLE_ID = "jp-loanword-origin-style";
  var LOANWORD_TOAST_ID = "jp-loanword-origin-toast";
  var LOANWORD_COLLAPSE_CHARACTER_LIMIT = 12;
  var CONTENT_BUILD_VERSION = "2.5.0";
  var MAX_TRANSLATION_CHARACTERS = 12e3;
  var SKIPPED_SELECTOR = [
    "script",
    "style",
    "noscript",
    "textarea",
    "input",
    "select",
    "option",
    "button",
    "code",
    "pre",
    "kbd",
    "samp",
    "ruby",
    "rt",
    "rp",
    "svg",
    "math",
    `[${TRANSLATION_UI_ATTRIBUTE}]`,
    "[hidden]",
    "[aria-hidden='true']",
    "[contenteditable]:not([contenteditable='false'])"
  ].join(",");
  var LOANWORD_SKIPPED_SELECTOR = [
    SKIPPED_SELECTOR,
    `[${LOANWORD_ATTRIBUTE}]`,
    `[${TRANSLATION_CONTROLLER_ATTRIBUTE}]`
  ].join(",");
  var KATAKANA_CANDIDATE_PATTERN = /[\u30A1-\u30FA\u30FD\u30FE\u30FC]/u;
  var CONTEXT_CANDIDATE_PATTERN = /[日月火水木金土雨笑泣辛後立主人妊娠高血圧腎症博士課程本研究幹細胞頭頸部浸透初相転移平均場自治厨売時骨髄協働既読公録昨夏中巨非常]/u;
  var CONTEXT_MUTATION_PATTERN = /[()（）0-9０-９日月火水木金土]/u;
  var escapeRegularExpression = (value) => value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  var foreignPersonNameCharacters = [...new Set(
    FOREIGN_PERSON_NAMES.flatMap((entry) => entry.surfaces.flatMap((surface) => Array.from(surface)))
  )];
  var foreignPersonMutationTerms = [.../* @__PURE__ */ new Set([
    ...FOREIGN_PERSON_NAMES.flatMap((entry) => [
      ...entry.surfaces,
      ...entry.roleHints,
      ...entry.blockedSuffixes
    ]),
    ...Object.values(PERSON_COUNTRY_HINTS).flat(),
    ...PERSON_ROLE_HINTS
  ])].filter(Boolean).sort((left, right) => right.length - left.length);
  var FOREIGN_PERSON_CONTEXT_PATTERN = new RegExp(
    foreignPersonNameCharacters.map(escapeRegularExpression).join("|"),
    "u"
  );
  var FOREIGN_PERSON_MUTATION_PATTERN = new RegExp(
    foreignPersonMutationTerms.map(escapeRegularExpression).join("|"),
    "u"
  );
  var FOREIGN_PERSON_SURFACE_PATTERN = new RegExp(
    FOREIGN_PERSON_NAMES.flatMap((entry) => entry.surfaces).sort((left, right) => right.length - left.length).map(escapeRegularExpression).join("|"),
    "u"
  );
  var foreignPersonAnnotationSignatures = new Set(
    FOREIGN_PERSON_NAMES.flatMap((entry) => entry.surfaces.flatMap(
      (surface) => getForeignPersonNameParts(entry, surface).map((part) => `${part.surface}\0${part.reading}`)
    ))
  );
  var CONTEXT_CHARACTER_LIMIT = 48;
  var CONTEXT_NODE_LIMIT = 64;
  var INLINE_DISPLAYS = /* @__PURE__ */ new Set(["inline", "inline-block", "inline-flex", "inline-grid", "contents"]);
  var SEMANTIC_INLINE_TAGS = /* @__PURE__ */ new Set([
    "A",
    "ABBR",
    "B",
    "BDI",
    "BDO",
    "CITE",
    "EM",
    "I",
    "LABEL",
    "MARK",
    "Q",
    "S",
    "SMALL",
    "SPAN",
    "STRONG",
    "SUB",
    "SUP",
    "TIME",
    "U"
  ]);
  var HARD_BOUNDARY_TAGS = /* @__PURE__ */ new Set([
    "BR",
    "HR",
    "IMG",
    "PICTURE",
    "VIDEO",
    "AUDIO",
    "CANVAS",
    "IFRAME",
    "OBJECT",
    "EMBED"
  ]);
  var TRANSLATION_BLOCK_TAGS = /* @__PURE__ */ new Set([
    "ADDRESS",
    "ARTICLE",
    "ASIDE",
    "BLOCKQUOTE",
    "DD",
    "DIV",
    "DL",
    "DT",
    "FIGCAPTION",
    "FIGURE",
    "FOOTER",
    "H1",
    "H2",
    "H3",
    "H4",
    "H5",
    "H6",
    "HEADER",
    "LI",
    "MAIN",
    "NAV",
    "OL",
    "P",
    "SECTION",
    "TABLE",
    "TD",
    "TH",
    "TR",
    "UL"
  ]);
  function containsContextCandidate(value) {
    return CONTEXT_CANDIDATE_PATTERN.test(value) || FOREIGN_PERSON_CONTEXT_PATTERN.test(value);
  }
  function containsContextMutation(value) {
    return CONTEXT_MUTATION_PATTERN.test(value) || FOREIGN_PERSON_MUTATION_PATTERN.test(value);
  }
  function appendSelectionFragmentText(node, chunks) {
    if (node.nodeType === Node.TEXT_NODE) {
      chunks.push(node.nodeValue || "");
      return;
    }
    if (node.nodeType !== Node.ELEMENT_NODE) {
      Array.from(node.childNodes || []).forEach((child) => appendSelectionFragmentText(child, chunks));
      return;
    }
    const element = node;
    if (element.matches(`rt, rp, [${TRANSLATION_UI_ATTRIBUTE}]`) || element.closest(`[${TRANSLATION_UI_ATTRIBUTE}]`)) {
      return;
    }
    if (element.tagName === "BR") {
      chunks.push("\n");
      return;
    }
    Array.from(element.childNodes).forEach((child) => appendSelectionFragmentText(child, chunks));
    if (TRANSLATION_BLOCK_TAGS.has(element.tagName) && !chunks.at(-1)?.endsWith("\n")) {
      chunks.push("\n");
    }
  }
  function getSelectedSourceText(selection, range) {
    const fragment = range.cloneContents();
    if (!fragment.querySelector?.("rt, rp")) {
      return selection.toString().trim();
    }
    const chunks = [];
    Array.from(fragment.childNodes).forEach((node) => appendSelectionFragmentText(node, chunks));
    return chunks.join("").trim();
  }
  function classifySelection(text) {
    const sentenceEndCount = (text.match(/(?:。|[！？!?]+)/gu) || []).length;
    if (/\r|\n/u.test(text) || sentenceEndCount >= 2 || text.length >= 180) {
      return "paragraph";
    }
    if (sentenceEndCount === 1 || /\s/u.test(text) || text.length >= 24) {
      return "sentence";
    }
    return "word";
  }
  function selectionTypeLabel(selectionType) {
    if (selectionType === "paragraph") {
      return "\u6BB5\u843D";
    }
    if (selectionType === "sentence") {
      return "\u53E5\u5B50";
    }
    return "\u8BCD\u8BED";
  }
  function getUsableRangeRect(range) {
    const rects = Array.from(range.getClientRects());
    const rect = [...rects].reverse().find((item) => item.width > 0 || item.height > 0) || range.getBoundingClientRect();
    if (!rect || !rect.width && !rect.height) {
      return null;
    }
    return {
      top: rect.top,
      right: rect.right,
      bottom: rect.bottom,
      left: rect.left,
      width: rect.width,
      height: rect.height
    };
  }
  function sendRuntimeMessage(message) {
    return new Promise((resolve, reject) => {
      let settled = false;
      const finish = (callback, value) => {
        if (settled) {
          return;
        }
        settled = true;
        callback(value);
      };
      try {
        const possiblePromise = chrome.runtime.sendMessage(message, (response) => {
          const runtimeError = chrome.runtime.lastError;
          if (runtimeError) {
            finish(reject, new Error(runtimeError.message));
            return;
          }
          finish(resolve, response);
        });
        if (possiblePromise?.then) {
          possiblePromise.then(
            (response) => finish(resolve, response),
            (error) => finish(reject, error)
          );
        }
      } catch (error) {
        finish(reject, error);
      }
    });
  }
  function normalizeTokenUsage(payload) {
    const usage = payload?.usage || payload?.tokenUsage || payload?.tokens || {};
    const inputTokens = Number(usage.inputTokens ?? usage.input_tokens ?? usage.promptTokens ?? usage.prompt_tokens);
    const outputTokens = Number(usage.outputTokens ?? usage.output_tokens ?? usage.completionTokens ?? usage.completion_tokens);
    const explicitTotal = Number(usage.totalTokens ?? usage.total_tokens ?? usage.total);
    const hasInput = Number.isFinite(inputTokens);
    const hasOutput = Number.isFinite(outputTokens);
    const totalTokens = Number.isFinite(explicitTotal) ? explicitTotal : hasInput || hasOutput ? (hasInput ? inputTokens : 0) + (hasOutput ? outputTokens : 0) : null;
    return {
      inputTokens: hasInput ? inputTokens : null,
      outputTokens: hasOutput ? outputTokens : null,
      totalTokens
    };
  }
  function getTranslationPayload(response) {
    const payload = response?.data || response?.result || response;
    const responseErrorCode = response?.error?.code || response?.code || payload?.error?.code || payload?.code;
    if (!response || response.ok === false || response.success === false || payload?.ok === false || response?.error || /CONFIG_REQUIRED|HOST_PERMISSION_REQUIRED/u.test(String(responseErrorCode || "").toUpperCase())) {
      const errorValue = response?.error || payload?.error || response;
      const error = new Error(
        typeof errorValue === "string" ? errorValue : errorValue?.message || response?.message || "\u7FFB\u8BD1\u670D\u52A1\u6CA1\u6709\u8FD4\u56DE\u6709\u6548\u7ED3\u679C\u3002"
      );
      error.code = errorValue?.code || response?.code || payload?.code || "TRANSLATION_FAILED";
      throw error;
    }
    const translation = payload?.translation ?? payload?.translatedText ?? payload?.translated_text ?? payload?.text ?? payload?.content;
    if (typeof translation !== "string" || !translation.trim()) {
      const error = new Error("\u7FFB\u8BD1\u670D\u52A1\u6CA1\u6709\u8FD4\u56DE\u8BD1\u6587\uFF0C\u8BF7\u91CD\u8BD5\u3002");
      error.code = "EMPTY_TRANSLATION";
      throw error;
    }
    return {
      translation: translation.trim(),
      targetLanguage: payload?.targetLanguage ?? payload?.target_language ?? payload?.target ?? response?.targetLanguage ?? "\u76EE\u6807\u8BED\u8A00",
      selectionType: payload?.selectionType,
      usage: normalizeTokenUsage(payload)
    };
  }
  function sanitizeTranslationErrorMessage(value) {
    return String(value || "").replace(/\b(?:sk|key)-[A-Za-z0-9_-]{8,}\b/giu, "[\u5DF2\u9690\u85CF]").replace(/Bearer\s+[A-Za-z0-9._~+\/-]{8,}/giu, "Bearer [\u5DF2\u9690\u85CF]").slice(0, 240);
  }
  function describeTranslationError(error) {
    const code = String(error?.code || "").toUpperCase();
    const message = sanitizeTranslationErrorMessage(error?.message || error);
    if (/CONFIG_REQUIRED|API_KEY_MISSING|API_KEY_(?:NOT_)?CONFIGURED|NOT_CONFIGURED/u.test(code + message.toUpperCase())) {
      return {
        message: "\u5C1A\u672A\u914D\u7F6E\u7FFB\u8BD1 API\u3002\u8BF7\u6253\u5F00\u7BA1\u7406\u9762\u677F\u586B\u5199 OpenAI \u517C\u5BB9 API Key\u3001BaseURL \u548C\u6A21\u578B\u3002",
        showOptions: true
      };
    }
    if (/HOST_PERMISSION_REQUIRED|HOST_PERMISSION|PERMISSION_DENIED/u.test(code + message.toUpperCase())) {
      return {
        message: "\u5F53\u524D API BaseURL \u5C1A\u672A\u83B7\u5F97\u8BBF\u95EE\u6743\u9650\u3002\u8BF7\u6253\u5F00\u7BA1\u7406\u9762\u677F\u68C0\u67E5\u5730\u5740\u5E76\u5B8C\u6210\u6388\u6743\u3002",
        showOptions: true
      };
    }
    if (/AUTHENTICATION_FAILED|API_ACCESS_DENIED|UNAUTHORIZED|FORBIDDEN|\b401\b|\b403\b/u.test(code + message.toUpperCase())) {
      return {
        message: "API \u9274\u6743\u5931\u8D25\u3002\u8BF7\u6253\u5F00\u7BA1\u7406\u9762\u677F\u68C0\u67E5 API Key\u3001BaseURL \u548C\u670D\u52A1\u6743\u9650\u3002",
        showOptions: true
      };
    }
    if (/EXTENSION CONTEXT INVALIDATED|RECEIVING END DOES NOT EXIST/u.test(message.toUpperCase())) {
      return {
        message: "\u6269\u5C55\u521A\u521A\u66F4\u65B0\uFF0C\u8BF7\u5237\u65B0\u5F53\u524D\u7F51\u9875\u540E\u518D\u8BD5\u3002",
        showOptions: false
      };
    }
    return {
      message: message ? `\u7FFB\u8BD1\u5931\u8D25\uFF1A${message}` : "\u7FFB\u8BD1\u5931\u8D25\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5\u3002",
      showOptions: false
    };
  }
  var SelectionTranslationController = class {
    constructor() {
      this.buildVersion = CONTENT_BUILD_VERSION;
      this.host = null;
      this.shadowRoot = null;
      this.actionButton = null;
      this.card = null;
      this.cardTitle = null;
      this.typeBadge = null;
      this.status = null;
      this.targetRow = null;
      this.targetValue = null;
      this.translation = null;
      this.usage = null;
      this.copyButton = null;
      this.retryButton = null;
      this.optionsButton = null;
      this.lastSelection = null;
      this.lastRequest = null;
      this.lastTranslation = "";
      this.anchorRect = null;
      this.selectionTimer = null;
      this.requestId = 0;
      this.install();
    }
    install() {
      this.ensureUi();
      document.addEventListener("mouseup", (event) => this.handleSelectionEvent(event), true);
      document.addEventListener("keyup", (event) => this.handleSelectionEvent(event), true);
      window.addEventListener("resize", () => this.keepUiInViewport(), { passive: true });
    }
    ensureUi() {
      if (!this.host) {
        this.createUi();
      }
      if (!this.host.isConnected) {
        (document.documentElement || document).append(this.host);
      }
      document.querySelectorAll(
        `[${TRANSLATION_UI_ATTRIBUTE}][aria-live="polite"]:not([role])`
      ).forEach((element) => {
        if (element !== this.host) {
          element.remove();
        }
      });
    }
    createUi() {
      const host = document.createElement("div");
      host.setAttribute(TRANSLATION_UI_ATTRIBUTE, "");
      host.setAttribute(TRANSLATION_CONTROLLER_ATTRIBUTE, "active");
      host.setAttribute("aria-live", "polite");
      for (const [property, value] of Object.entries({
        all: "initial",
        position: "fixed",
        inset: "0 auto auto 0",
        width: "0",
        height: "0",
        overflow: "visible",
        pointerEvents: "none",
        zIndex: "2147483647"
      })) {
        host.style.setProperty(property.replace(/[A-Z]/g, (match) => `-${match.toLowerCase()}`), value, "important");
      }
      const shadowRoot = host.attachShadow({ mode: "closed" });
      const style = document.createElement("style");
      style.textContent = `
      :host { all: initial !important; }
      *, *::before, *::after { box-sizing: border-box; }
      button { font: inherit; }
      [hidden] { display: none !important; }
      .action {
        position: fixed;
        z-index: 2147483647;
        min-height: 36px;
        padding: 8px 13px;
        border: 1px solid rgba(255,255,255,.28);
        border-radius: 999px;
        color: #fff;
        background: #175cd3;
        box-shadow: 0 8px 24px rgba(16,24,40,.28);
        cursor: pointer;
        pointer-events: auto;
        font: 600 13px/1.2 system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
        white-space: nowrap;
      }
      .action:hover { background: #1849a9; }
      .action:focus-visible, .control:focus-visible {
        outline: 3px solid rgba(83,177,253,.55);
        outline-offset: 2px;
      }
      .card {
        position: fixed;
        z-index: 2147483647;
        width: min(390px, calc(100vw - 16px));
        max-height: min(520px, calc(100vh - 16px));
        overflow: auto;
        padding: 15px;
        border: 1px solid #d0d5dd;
        border-radius: 14px;
        color: #101828;
        background: #fff;
        box-shadow: 0 16px 48px rgba(16,24,40,.28);
        pointer-events: auto;
        font: 14px/1.55 system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
        text-align: left;
        word-break: break-word;
      }
      .header { display: flex; align-items: center; gap: 8px; margin-bottom: 12px; }
      .title { flex: 1; margin: 0; color: #101828; font-size: 15px; line-height: 1.3; font-weight: 700; }
      .badge {
        padding: 2px 8px;
        border-radius: 999px;
        color: #1849a9;
        background: #eff8ff;
        font-size: 12px;
        font-weight: 600;
      }
      .close {
        width: 30px;
        height: 30px;
        padding: 0;
        border: 0;
        border-radius: 8px;
        color: #475467;
        background: transparent;
        cursor: pointer;
        font-size: 20px;
        line-height: 1;
      }
      .close:hover { background: #f2f4f7; }
      .status { margin: 0; color: #475467; }
      .status.error { color: #b42318; }
      .target { display: flex; gap: 6px; margin-bottom: 8px; color: #667085; font-size: 12px; }
      .target strong { color: #344054; font-weight: 600; }
      .translation {
        min-height: 44px;
        max-height: 300px;
        overflow: auto;
        padding: 12px;
        border-radius: 10px;
        color: #101828;
        background: #f9fafb;
        white-space: pre-wrap;
        user-select: text;
      }
      .usage { margin-top: 8px; color: #667085; font-size: 12px; }
      .controls { display: flex; flex-wrap: wrap; gap: 8px; margin-top: 13px; }
      .control {
        min-height: 34px;
        padding: 7px 11px;
        border: 1px solid #d0d5dd;
        border-radius: 8px;
        color: #344054;
        background: #fff;
        cursor: pointer;
        font-size: 13px;
        font-weight: 600;
      }
      .control:hover { background: #f9fafb; }
      .control.primary { border-color: #175cd3; color: #fff; background: #175cd3; }
      .control.primary:hover { background: #1849a9; }
      .control:disabled { opacity: .5; cursor: default; }
      .spinner::before {
        content: "";
        display: inline-block;
        width: 12px;
        height: 12px;
        margin-right: 7px;
        border: 2px solid #b2ccff;
        border-top-color: #175cd3;
        border-radius: 50%;
        vertical-align: -2px;
        animation: spin .8s linear infinite;
      }
      @keyframes spin { to { transform: rotate(360deg); } }
    `;
      const actionButton = document.createElement("button");
      actionButton.type = "button";
      actionButton.className = "action";
      actionButton.hidden = true;
      actionButton.textContent = "\u7FFB\u8BD1";
      actionButton.addEventListener("click", () => void this.translateLastSelection());
      const card = document.createElement("section");
      card.className = "card";
      card.hidden = true;
      card.setAttribute("role", "dialog");
      card.setAttribute("aria-label", "\u5212\u8BCD\u7FFB\u8BD1\u7ED3\u679C");
      const header = document.createElement("div");
      header.className = "header";
      const cardTitle = document.createElement("h2");
      cardTitle.className = "title";
      cardTitle.textContent = "\u5212\u8BCD\u7FFB\u8BD1";
      const typeBadge = document.createElement("span");
      typeBadge.className = "badge";
      typeBadge.textContent = "\u8BCD\u8BED";
      const closeButton = document.createElement("button");
      closeButton.type = "button";
      closeButton.className = "close";
      closeButton.setAttribute("aria-label", "\u5173\u95ED\u7FFB\u8BD1\u7ED3\u679C");
      closeButton.textContent = "\xD7";
      closeButton.addEventListener("click", () => this.hideAll());
      header.append(cardTitle, typeBadge, closeButton);
      const status = document.createElement("p");
      status.className = "status";
      status.hidden = true;
      const targetRow = document.createElement("div");
      targetRow.className = "target";
      targetRow.hidden = true;
      const targetLabel = document.createElement("span");
      targetLabel.textContent = "\u76EE\u6807\u8BED\u8A00\uFF1A";
      const targetValue = document.createElement("strong");
      targetRow.append(targetLabel, targetValue);
      const translation = document.createElement("div");
      translation.className = "translation";
      translation.hidden = true;
      translation.setAttribute("role", "document");
      const usage = document.createElement("div");
      usage.className = "usage";
      usage.hidden = true;
      const controls = document.createElement("div");
      controls.className = "controls";
      const copyButton = document.createElement("button");
      copyButton.type = "button";
      copyButton.className = "control primary";
      copyButton.textContent = "\u590D\u5236\u8BD1\u6587";
      copyButton.hidden = true;
      copyButton.addEventListener("click", () => void this.copyTranslation());
      const retryButton = document.createElement("button");
      retryButton.type = "button";
      retryButton.className = "control";
      retryButton.textContent = "\u91CD\u8BD5";
      retryButton.hidden = true;
      retryButton.addEventListener("click", () => void this.retry());
      const optionsButton = document.createElement("button");
      optionsButton.type = "button";
      optionsButton.className = "control";
      optionsButton.textContent = "\u6253\u5F00\u7BA1\u7406\u9762\u677F";
      optionsButton.hidden = true;
      optionsButton.addEventListener("click", () => void this.openOptions());
      controls.append(copyButton, retryButton, optionsButton);
      card.append(header, status, targetRow, translation, usage, controls);
      const protectUiInteraction = (event) => {
        event.stopPropagation();
        if (event.type === "mousedown") {
          event.preventDefault();
        }
      };
      ["pointerdown", "mousedown", "mouseup", "click", "dblclick", "keydown", "keyup"].forEach((type) => {
        shadowRoot.addEventListener(type, protectUiInteraction);
      });
      shadowRoot.append(style, actionButton, card);
      this.host = host;
      this.shadowRoot = shadowRoot;
      this.actionButton = actionButton;
      this.card = card;
      this.cardTitle = cardTitle;
      this.typeBadge = typeBadge;
      this.status = status;
      this.targetRow = targetRow;
      this.targetValue = targetValue;
      this.translation = translation;
      this.usage = usage;
      this.copyButton = copyButton;
      this.retryButton = retryButton;
      this.optionsButton = optionsButton;
    }
    isUiEvent(event) {
      return event.composedPath?.().includes(this.host) || event.target === this.host;
    }
    handleSelectionEvent(event) {
      if (this.isUiEvent(event)) {
        return;
      }
      if (event.type === "keyup" && ["Shift", "Control", "Alt", "Meta"].includes(event.key)) {
        return;
      }
      clearTimeout(this.selectionTimer);
      this.selectionTimer = setTimeout(() => this.updateSelection(), 16);
    }
    updateSelection() {
      this.ensureUi();
      const selection = window.getSelection();
      if (!selection || selection.isCollapsed || selection.rangeCount === 0) {
        this.actionButton.hidden = true;
        return;
      }
      const range = selection.getRangeAt(0);
      const ancestor = range.commonAncestorContainer.nodeType === Node.ELEMENT_NODE ? range.commonAncestorContainer : range.commonAncestorContainer.parentElement;
      if (ancestor?.closest?.(`[${TRANSLATION_UI_ATTRIBUTE}]`)) {
        return;
      }
      const text = getSelectedSourceText(selection, range);
      if (!text) {
        this.actionButton.hidden = true;
        return;
      }
      const anchorRect = getUsableRangeRect(range);
      if (!anchorRect) {
        this.actionButton.hidden = true;
        return;
      }
      const selectionType = classifySelection(text);
      this.lastSelection = { text, selectionType };
      this.anchorRect = anchorRect;
      this.actionButton.textContent = `\u7FFB\u8BD1${selectionTypeLabel(selectionType)}`;
      this.card.hidden = true;
      this.actionButton.hidden = false;
      this.positionElement(this.actionButton, anchorRect);
    }
    positionElement(element, anchorRect = this.anchorRect) {
      if (!anchorRect || element.hidden) {
        return;
      }
      element.style.visibility = "hidden";
      element.style.left = "8px";
      element.style.top = "8px";
      const measured = element.getBoundingClientRect();
      const width = measured.width || (element === this.card ? Math.min(390, window.innerWidth - 16) : 110);
      const height = measured.height || (element === this.card ? 180 : 36);
      const margin = 8;
      const centeredLeft = anchorRect.left + anchorRect.width / 2 - width / 2;
      const left = Math.max(margin, Math.min(centeredLeft, window.innerWidth - width - margin));
      const roomBelow = window.innerHeight - anchorRect.bottom;
      const preferredTop = roomBelow >= height + 12 ? anchorRect.bottom + 8 : anchorRect.top - height - 8;
      const top = Math.max(margin, Math.min(preferredTop, window.innerHeight - height - margin));
      element.style.left = `${Math.round(left)}px`;
      element.style.top = `${Math.round(top)}px`;
      element.style.visibility = "visible";
    }
    keepUiInViewport() {
      if (!this.actionButton?.hidden) {
        this.positionElement(this.actionButton);
      }
      if (!this.card?.hidden) {
        this.positionElement(this.card);
      }
    }
    async translateLastSelection() {
      const selected = this.lastSelection;
      if (!selected?.text.trim()) {
        return;
      }
      this.actionButton.hidden = true;
      this.lastRequest = {
        type: "TRANSLATE_TEXT",
        text: selected.text,
        selectionType: selected.selectionType,
        pageUrl: location.href,
        pageTitle: document.title
      };
      this.typeBadge.textContent = selectionTypeLabel(selected.selectionType);
      this.cardTitle.textContent = "\u5212\u8BCD\u7FFB\u8BD1";
      this.card.hidden = false;
      this.positionElement(this.card);
      if (selected.text.length > MAX_TRANSLATION_CHARACTERS) {
        this.showError(
          `\u9009\u4E2D\u6587\u672C\u5171 ${selected.text.length.toLocaleString()} \u4E2A\u5B57\u7B26\uFF0C\u5355\u6B21\u6700\u591A\u7FFB\u8BD1 ${MAX_TRANSLATION_CHARACTERS.toLocaleString()} \u4E2A\u5B57\u7B26\u3002`,
          false
        );
        return;
      }
      await this.runTranslation(this.lastRequest);
    }
    async runTranslation(request) {
      const currentRequestId = ++this.requestId;
      this.showLoading();
      try {
        const response = await sendRuntimeMessage(request);
        if (currentRequestId !== this.requestId) {
          return;
        }
        const result = getTranslationPayload(response);
        this.showResult(result);
      } catch (error) {
        if (currentRequestId !== this.requestId) {
          return;
        }
        const description = describeTranslationError(error);
        this.showError(description.message, description.showOptions);
      }
    }
    showLoading() {
      this.status.hidden = false;
      this.status.className = "status spinner";
      this.status.textContent = "\u6B63\u5728\u7FFB\u8BD1\u2026";
      this.targetRow.hidden = true;
      this.translation.hidden = true;
      this.translation.textContent = "";
      this.usage.hidden = true;
      this.usage.textContent = "";
      this.copyButton.hidden = true;
      this.retryButton.hidden = true;
      this.optionsButton.hidden = true;
      this.positionElement(this.card);
    }
    showResult(result) {
      this.lastTranslation = result.translation;
      this.status.hidden = true;
      this.status.className = "status";
      this.targetValue.textContent = String(result.targetLanguage || "\u76EE\u6807\u8BED\u8A00");
      this.targetRow.hidden = false;
      this.translation.textContent = result.translation;
      this.translation.hidden = false;
      const usageParts = [];
      if (result.usage.inputTokens !== null) {
        usageParts.push(`\u8F93\u5165 ${result.usage.inputTokens.toLocaleString()}`);
      }
      if (result.usage.outputTokens !== null) {
        usageParts.push(`\u8F93\u51FA ${result.usage.outputTokens.toLocaleString()}`);
      }
      if (result.usage.totalTokens !== null) {
        usageParts.push(`\u5408\u8BA1 ${result.usage.totalTokens.toLocaleString()}`);
      }
      this.usage.textContent = usageParts.length ? `Token\uFF1A${usageParts.join(" \xB7 ")}` : "Token\uFF1A\u670D\u52A1\u672A\u8FD4\u56DE\u6D88\u8017\u6570\u636E";
      this.usage.hidden = false;
      this.copyButton.hidden = false;
      this.copyButton.disabled = false;
      this.copyButton.textContent = "\u590D\u5236\u8BD1\u6587";
      this.retryButton.hidden = false;
      this.optionsButton.hidden = true;
      this.positionElement(this.card);
    }
    showError(message, showOptions) {
      this.lastTranslation = "";
      this.status.hidden = false;
      this.status.className = "status error";
      this.status.textContent = message;
      this.targetRow.hidden = true;
      this.translation.hidden = true;
      this.translation.textContent = "";
      this.usage.hidden = true;
      this.copyButton.hidden = true;
      this.retryButton.hidden = false;
      this.optionsButton.hidden = !showOptions;
      this.positionElement(this.card);
    }
    async retry() {
      if (!this.lastRequest || this.lastRequest.text.length > MAX_TRANSLATION_CHARACTERS) {
        return;
      }
      await this.runTranslation(this.lastRequest);
    }
    async copyTranslation() {
      if (!this.lastTranslation) {
        return;
      }
      let copied = false;
      try {
        await navigator.clipboard.writeText(this.lastTranslation);
        copied = true;
      } catch (_error) {
        const fallback = document.createElement("textarea");
        fallback.value = this.lastTranslation;
        fallback.setAttribute("aria-hidden", "true");
        Object.assign(fallback.style, {
          position: "fixed",
          left: "-9999px",
          width: "1px",
          height: "1px",
          opacity: "0"
        });
        this.shadowRoot.append(fallback);
        fallback.select();
        try {
          copied = document.execCommand("copy");
        } finally {
          fallback.remove();
        }
      }
      if (copied) {
        this.copyButton.textContent = "\u5DF2\u590D\u5236";
        setTimeout(() => {
          if (this.copyButton) {
            this.copyButton.textContent = "\u590D\u5236\u8BD1\u6587";
          }
        }, 1600);
      } else {
        this.copyButton.textContent = "\u590D\u5236\u5931\u8D25";
      }
    }
    async openOptions() {
      this.optionsButton.disabled = true;
      this.optionsButton.textContent = "\u6B63\u5728\u6253\u5F00\u2026";
      try {
        await sendRuntimeMessage({ type: "OPEN_TRANSLATION_OPTIONS" });
        this.optionsButton.textContent = "\u5DF2\u6253\u5F00\u7BA1\u7406\u9762\u677F";
      } catch (error) {
        this.status.hidden = false;
        this.status.className = "status error";
        this.status.textContent = describeTranslationError(error).message;
        this.optionsButton.textContent = "\u6253\u5F00\u7BA1\u7406\u9762\u677F";
      } finally {
        this.optionsButton.disabled = false;
      }
    }
    hideAll() {
      this.requestId += 1;
      this.actionButton.hidden = true;
      this.card.hidden = true;
    }
  };
  function getDisplay(element, displayCache) {
    if (!displayCache.has(element)) {
      displayCache.set(element, getComputedStyle(element).display);
    }
    return displayCache.get(element);
  }
  function findInlineContextBoundaryFromElement(element, displayCache) {
    let current = element;
    let boundary = current;
    while (current && current !== document.body && current !== document.documentElement) {
      boundary = current;
      if (!SEMANTIC_INLINE_TAGS.has(current.tagName) && !INLINE_DISPLAYS.has(getDisplay(current, displayCache))) {
        break;
      }
      current = current.parentElement;
    }
    return boundary;
  }
  function findInlineContextBoundary(node, displayCache) {
    return findInlineContextBoundaryFromElement(node.parentElement, displayCache);
  }
  function getContextRefreshRoot(target, displayCache) {
    let element = target.nodeType === Node.TEXT_NODE ? target.parentElement : target;
    if (!(element instanceof Element)) {
      return null;
    }
    const pluginRuby = element.closest(`ruby[${RUBY_ATTRIBUTE}]`);
    if (pluginRuby) {
      pluginRuby.dataset.jpOriginal = pluginRuby.firstChild?.textContent || pluginRuby.dataset.jpOriginal || "";
      element = pluginRuby.parentElement;
    }
    const boundary = findInlineContextBoundaryFromElement(element, displayCache);
    if (!boundary || ["HTML", "BODY", "MAIN", "ARTICLE", "SECTION", "UL", "OL", "TABLE"].includes(boundary.tagName) || (boundary.textContent?.length || 0) > 512) {
      return null;
    }
    return boundary;
  }
  function collectMutationSourceText(node, limit = 512) {
    if (!node || limit <= 0) {
      return "";
    }
    if (node.nodeType === Node.TEXT_NODE) {
      return (node.nodeValue || "").slice(0, limit);
    }
    if (node.nodeType !== Node.ELEMENT_NODE) {
      return "";
    }
    if (node.matches(`ruby[${RUBY_ATTRIBUTE}]`)) {
      return (node.dataset.jpOriginal || node.firstChild?.textContent || "").slice(0, limit);
    }
    if (node.matches("rt, rp")) {
      return "";
    }
    let result = "";
    for (const child of node.childNodes) {
      result += collectMutationSourceText(child, limit - result.length);
      if (result.length >= limit) {
        break;
      }
    }
    return result;
  }
  function mutationNodesContainContext(nodeList) {
    return Array.from(nodeList).some(
      (node) => containsContextMutation(collectMutationSourceText(node))
    );
  }
  function mutationNodesContainForeignNameCharacter(nodeList) {
    return Array.from(nodeList).some(
      (node) => FOREIGN_PERSON_CONTEXT_PATTERN.test(collectMutationSourceText(node))
    );
  }
  function contextualRootContainsForeignPerson(root) {
    return FOREIGN_PERSON_SURFACE_PATTERN.test(collectMutationSourceText(root));
  }
  function getElementDisposition(element, boundary, displayCache) {
    if (element.matches(`ruby[${RUBY_ATTRIBUTE}]`)) {
      return "plugin-ruby";
    }
    if (element.matches(SKIPPED_SELECTOR) || HARD_BOUNDARY_TAGS.has(element.tagName)) {
      return "barrier";
    }
    if (element === boundary || SEMANTIC_INLINE_TAGS.has(element.tagName) || INLINE_DISPLAYS.has(getDisplay(element, displayCache))) {
      return "inline";
    }
    return "barrier";
  }
  function normalizeAdjacentText(value) {
    return value.replace(/[\r\n\f]+/g, " ");
  }
  function nextNodeAfter(node, boundary) {
    let current = node;
    while (current && current !== boundary) {
      if (current.nextSibling) {
        return current.nextSibling;
      }
      current = current.parentNode;
    }
    return null;
  }
  function previousNodeBefore(node, boundary) {
    let current = node;
    while (current && current !== boundary) {
      if (current.previousSibling) {
        return current.previousSibling;
      }
      current = current.parentNode;
    }
    return null;
  }
  function collectFollowingContext(node, boundary, displayCache) {
    let current = nextNodeAfter(node, boundary);
    let result = "";
    let visitedNodes = 0;
    while (current && visitedNodes < CONTEXT_NODE_LIMIT && result.length < CONTEXT_CHARACTER_LIMIT) {
      visitedNodes += 1;
      if (current.nodeType === Node.TEXT_NODE) {
        result += normalizeAdjacentText(current.nodeValue || "");
        current = nextNodeAfter(current, boundary);
        continue;
      }
      if (current.nodeType !== Node.ELEMENT_NODE) {
        current = nextNodeAfter(current, boundary);
        continue;
      }
      const disposition = getElementDisposition(current, boundary, displayCache);
      if (disposition === "barrier") {
        break;
      }
      if (disposition === "plugin-ruby") {
        result += normalizeAdjacentText(current.dataset.jpOriginal || "");
        current = nextNodeAfter(current, boundary);
        continue;
      }
      current = current.firstChild || nextNodeAfter(current, boundary);
    }
    return result.slice(0, CONTEXT_CHARACTER_LIMIT);
  }
  function collectPrecedingContext(node, boundary, displayCache) {
    let current = previousNodeBefore(node, boundary);
    let result = "";
    let visitedNodes = 0;
    while (current && visitedNodes < CONTEXT_NODE_LIMIT && result.length < CONTEXT_CHARACTER_LIMIT) {
      visitedNodes += 1;
      if (current.nodeType === Node.TEXT_NODE) {
        result = `${normalizeAdjacentText(current.nodeValue || "")}${result}`;
        current = previousNodeBefore(current, boundary);
        continue;
      }
      if (current.nodeType !== Node.ELEMENT_NODE) {
        current = previousNodeBefore(current, boundary);
        continue;
      }
      const disposition = getElementDisposition(current, boundary, displayCache);
      if (disposition === "barrier") {
        break;
      }
      if (disposition === "plugin-ruby") {
        result = `${normalizeAdjacentText(current.dataset.jpOriginal || "")}${result}`;
        current = previousNodeBefore(current, boundary);
        continue;
      }
      current = current.lastChild || previousNodeBefore(current, boundary);
    }
    return result.slice(-CONTEXT_CHARACTER_LIMIT);
  }
  function collectAdjacentInlineContext(node, displayCache) {
    if (!containsContextCandidate(node.nodeValue || "")) {
      return { prefix: "", suffix: "" };
    }
    const boundary = findInlineContextBoundary(node, displayCache);
    if (!boundary) {
      return { prefix: "", suffix: "" };
    }
    return {
      prefix: collectPrecedingContext(node, boundary, displayCache),
      suffix: collectFollowingContext(node, boundary, displayCache)
    };
  }
  function isLoanwordElementHidden(element) {
    for (let current = element; current instanceof Element; current = current.parentElement) {
      if (current.hidden || current.getAttribute("aria-hidden") === "true") {
        return true;
      }
      const style = getComputedStyle(current);
      if (style.display === "none" || style.visibility === "hidden" || style.visibility === "collapse" || style.contentVisibility === "hidden") {
        return true;
      }
    }
    return false;
  }
  function shouldCollapseLoanwordAnnotation(surface, annotation) {
    const annotationLength = Array.from(annotation).length;
    const surfaceLength = Math.max(1, Array.from(surface).length);
    return annotationLength > Math.max(
      LOANWORD_COLLAPSE_CHARACTER_LIMIT,
      surfaceLength * 2
    );
  }
  var LoanwordOriginController = class {
    constructor() {
      this.buildVersion = CONTENT_BUILD_VERSION;
      this.phase = "idle";
      this.count = 0;
      this.errorMessage = "";
      this.observer = null;
      this.pendingRoots = /* @__PURE__ */ new Set();
      this.flushTimer = null;
      this.runId = 0;
    }
    getStatus() {
      if (this.phase === "enabled") {
        this.syncCount();
      }
      return {
        phase: this.phase,
        enabled: this.phase === "enabled",
        count: this.count,
        message: this.errorMessage
      };
    }
    async toggle() {
      if (this.phase === "enabled" || this.phase === "loading") {
        this.disable();
        return this.getStatus();
      }
      return this.enable();
    }
    async enable() {
      if (this.phase === "enabled" || this.phase === "loading") {
        return this.getStatus();
      }
      const currentRun = ++this.runId;
      this.phase = "loading";
      this.errorMessage = "";
      this.installStyle();
      try {
        this.count = 0;
        this.processRoot(document.body || document.documentElement);
        if (currentRun !== this.runId) {
          return this.getStatus();
        }
        this.startObserver();
        this.phase = "enabled";
        this.showToast(`\u5DF2\u6807\u6CE8 ${this.count} \u5904\u7247\u5047\u540D\u5916\u6765\u8BED\u539F\u8BCD`, "success");
      } catch (error) {
        if (currentRun !== this.runId) {
          return this.getStatus();
        }
        this.phase = "error";
        this.errorMessage = error instanceof Error ? error.message : String(error);
        this.removeStyle();
        this.showToast(`\u5916\u6765\u8BED\u6807\u6CE8\u5931\u8D25\uFF1A${this.errorMessage}`, "error", 6e3);
        console.error("[\u65E5\u8BED\u6C49\u5B57 AI \u8BFB\u97F3\u52A9\u624B\uFF1A\u5916\u6765\u8BED\u539F\u8BCD]", error);
      }
      return this.getStatus();
    }
    disable() {
      this.runId += 1;
      this.observer?.disconnect();
      this.observer = null;
      this.pendingRoots.clear();
      if (this.flushTimer !== null) {
        clearTimeout(this.flushTimer);
        this.flushTimer = null;
      }
      const changedParents = /* @__PURE__ */ new Set();
      document.querySelectorAll(`ruby[${LOANWORD_ATTRIBUTE}]`).forEach((ruby) => {
        if (ruby.parentNode) {
          changedParents.add(ruby.parentNode);
        }
        ruby.replaceWith(document.createTextNode(
          ruby.dataset.jpOriginal || ruby.firstChild?.textContent || ""
        ));
      });
      changedParents.forEach((parent) => parent.normalize());
      this.removeStyle();
      this.count = 0;
      this.phase = "idle";
      this.errorMessage = "";
      this.showToast("\u5DF2\u79FB\u9664\u5916\u6765\u8BED\u539F\u8BCD\u6807\u6CE8", "success");
      return this.getStatus();
    }
    processRoot(root) {
      if (!root) {
        return;
      }
      if (root.nodeType === Node.TEXT_NODE) {
        this.processTextNode(root);
        return;
      }
      if (!(root instanceof Element || root instanceof Document || root instanceof DocumentFragment)) {
        return;
      }
      if (root instanceof Element && root.matches(LOANWORD_SKIPPED_SELECTOR)) {
        return;
      }
      const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
        acceptNode: (node) => this.isEligibleTextNode(node) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT
      });
      const nodes = [];
      while (walker.nextNode()) {
        nodes.push(walker.currentNode);
      }
      nodes.forEach((node) => this.processTextNode(node));
    }
    isEligibleTextNode(node) {
      if (!node.nodeValue || !KATAKANA_CANDIDATE_PATTERN.test(node.nodeValue)) {
        return false;
      }
      const parent = node.parentElement;
      return Boolean(
        parent && !parent.closest(LOANWORD_SKIPPED_SELECTOR) && !isLoanwordElementHidden(parent)
      );
    }
    processTextNode(node) {
      if (!node.isConnected || !this.isEligibleTextNode(node)) {
        return;
      }
      const originalText = node.nodeValue;
      const matches = findLoanwordMatches(originalText);
      if (!matches.length) {
        return;
      }
      const fragment = document.createDocumentFragment();
      let offset = 0;
      let addedCount = 0;
      for (const match of matches) {
        const start = Number(match.start);
        const end = Number(match.end);
        if (!Number.isInteger(start) || !Number.isInteger(end) || start < offset || end <= start || end > originalText.length) {
          continue;
        }
        const surface = originalText.slice(start, end);
        const annotation = String(match.display || match.annotation || match.origin || "").trim();
        if (!annotation) {
          continue;
        }
        fragment.append(document.createTextNode(originalText.slice(offset, start)));
        fragment.append(this.createAnnotation(surface, annotation, match));
        offset = end;
        addedCount += 1;
      }
      if (!addedCount) {
        return;
      }
      fragment.append(document.createTextNode(originalText.slice(offset)));
      node.replaceWith(fragment);
      this.count += addedCount;
    }
    createAnnotation(surface, annotation, match) {
      const ruby = document.createElement("ruby");
      ruby.setAttribute(LOANWORD_ATTRIBUTE, "");
      ruby.dataset.jpOriginal = surface;
      if (match.id) {
        ruby.dataset.jpLoanwordId = String(match.id);
      }
      if (match.languageCode || match.language) {
        ruby.dataset.jpLoanwordLanguage = String(match.languageCode || match.language);
      }
      ruby.append(document.createTextNode(surface));
      const rt = document.createElement("rt");
      if (!shouldCollapseLoanwordAnnotation(surface, annotation)) {
        rt.textContent = annotation;
        ruby.append(rt);
        return ruby;
      }
      ruby.dataset.jpLoanwordCollapsible = "true";
      const toggle = document.createElement("span");
      toggle.setAttribute("data-jp-loanword-toggle", "");
      toggle.setAttribute("role", "button");
      toggle.setAttribute("tabindex", "0");
      toggle.setAttribute("aria-expanded", "false");
      toggle.setAttribute("aria-label", `\u663E\u793A\u5B8C\u6574\u5916\u6765\u8BED\u539F\u8BCD\uFF1A${annotation}`);
      toggle.title = `\u70B9\u51FB\u663E\u793A\u5B8C\u6574\u539F\u8BCD\uFF1A${annotation}`;
      toggle.textContent = annotation;
      const setExpanded = (expanded) => {
        toggle.setAttribute("aria-expanded", String(expanded));
        toggle.setAttribute(
          "aria-label",
          expanded ? `\u6536\u8D77\u5916\u6765\u8BED\u539F\u8BCD\uFF1A${annotation}` : `\u663E\u793A\u5B8C\u6574\u5916\u6765\u8BED\u539F\u8BCD\uFF1A${annotation}`
        );
        toggle.title = expanded ? "\u70B9\u51FB\u6536\u8D77\u539F\u8BCD" : `\u70B9\u51FB\u663E\u793A\u5B8C\u6574\u539F\u8BCD\uFF1A${annotation}`;
      };
      toggle.addEventListener("click", (event) => {
        event.preventDefault();
        event.stopPropagation();
        setExpanded(toggle.getAttribute("aria-expanded") !== "true");
      });
      toggle.addEventListener("keydown", (event) => {
        if (event.key !== "Enter" && event.key !== " ") {
          return;
        }
        event.preventDefault();
        event.stopPropagation();
        setExpanded(toggle.getAttribute("aria-expanded") !== "true");
      });
      rt.append(toggle);
      ruby.append(rt);
      return ruby;
    }
    syncCount() {
      this.count = document.querySelectorAll(`ruby[${LOANWORD_ATTRIBUTE}]`).length;
    }
    observeDocumentChanges() {
      this.observer?.observe(document.body || document.documentElement, {
        childList: true,
        subtree: true,
        characterData: true,
        attributes: true,
        attributeFilter: ["class", "style", "hidden", "aria-hidden"]
      });
    }
    startObserver() {
      this.observer?.disconnect();
      this.observer = new MutationObserver((mutations) => {
        for (const mutation of mutations) {
          if (mutation.type === "characterData") {
            this.pendingRoots.add(mutation.target);
            continue;
          }
          if (mutation.type === "attributes") {
            this.pendingRoots.add(mutation.target);
            continue;
          }
          mutation.addedNodes.forEach((node) => this.pendingRoots.add(node));
        }
        this.scheduleFlush();
      });
      this.observeDocumentChanges();
    }
    scheduleFlush() {
      if (this.flushTimer !== null || this.phase !== "enabled") {
        return;
      }
      this.flushTimer = setTimeout(() => {
        this.flushTimer = null;
        const roots = Array.from(this.pendingRoots);
        this.pendingRoots.clear();
        this.observer?.disconnect();
        try {
          roots.forEach((root) => this.processRoot(root));
          this.syncCount();
        } finally {
          if (this.phase === "enabled") {
            this.observeDocumentChanges();
          }
        }
      }, 60);
    }
    installStyle() {
      if (document.getElementById(LOANWORD_STYLE_ID)) {
        return;
      }
      const style = document.createElement("style");
      style.id = LOANWORD_STYLE_ID;
      style.textContent = `
      ruby[${LOANWORD_ATTRIBUTE}] {
        display: ruby !important;
        position: static !important;
        margin: 0 !important;
        padding: 0 !important;
        border: 0 !important;
        background: transparent !important;
        white-space: nowrap !important;
        ruby-position: over !important;
        ruby-align: center !important;
        /* Latin/source-language labels must participate in line fitting. Auto
           overhang can leak an rt fragment beyond a narrow article column. */
        ruby-overhang: none !important;
      }
      ruby[${LOANWORD_ATTRIBUTE}] > rt {
        display: ruby-text !important;
        position: static !important;
        margin: 0 !important;
        padding: 0 !important;
        border: 0 !important;
        background: transparent !important;
        opacity: 1 !important;
        transform: none !important;
        font-family: system-ui, -apple-system, "Segoe UI", sans-serif !important;
        font-size: 0.52em !important;
        font-style: normal !important;
        font-weight: 650 !important;
        line-height: 1 !important;
        color: #175cd3 !important;
        letter-spacing: normal !important;
        word-spacing: normal !important;
        text-align: center !important;
        text-decoration: none !important;
        text-indent: 0 !important;
        text-transform: none !important;
        white-space: nowrap !important;
        user-select: text !important;
      }
      ruby[${LOANWORD_ATTRIBUTE}] [data-jp-loanword-toggle] {
        all: unset !important;
        box-sizing: border-box !important;
        display: inline-block !important;
        max-inline-size: 12ch !important;
        overflow: hidden !important;
        text-overflow: ellipsis !important;
        white-space: nowrap !important;
        color: inherit !important;
        border-block-end: 1px dotted currentColor !important;
        cursor: pointer !important;
        user-select: none !important;
      }
      ruby[${LOANWORD_ATTRIBUTE}] [data-jp-loanword-toggle][aria-expanded="true"] {
        max-inline-size: none !important;
        overflow: visible !important;
        text-overflow: clip !important;
      }
      ruby[${LOANWORD_ATTRIBUTE}] [data-jp-loanword-toggle]:focus-visible {
        outline: 2px solid #1570ef !important;
        outline-offset: 2px !important;
        border-radius: 2px !important;
      }
    `;
      (document.head || document.documentElement).append(style);
    }
    removeStyle() {
      document.getElementById(LOANWORD_STYLE_ID)?.remove();
    }
    showToast(message, kind = "success", duration = 2600) {
      let toast = document.getElementById(LOANWORD_TOAST_ID);
      if (!toast) {
        toast = document.createElement("div");
        toast.id = LOANWORD_TOAST_ID;
        toast.setAttribute(TRANSLATION_UI_ATTRIBUTE, "");
        toast.setAttribute("role", "status");
        Object.assign(toast.style, {
          position: "fixed",
          zIndex: "2147483647",
          top: "70px",
          right: "18px",
          maxWidth: "360px",
          padding: "12px 16px",
          borderRadius: "10px",
          color: "#fff",
          font: "600 14px/1.45 system-ui, sans-serif",
          boxShadow: "0 8px 28px rgba(0, 0, 0, .24)",
          transition: "opacity .2s ease",
          pointerEvents: "none"
        });
        document.documentElement.append(toast);
      }
      toast.style.background = kind === "error" ? "#b42318" : "#175cd3";
      toast.style.opacity = "1";
      toast.textContent = message;
      clearTimeout(toast.__jpLoanwordTimer);
      if (duration > 0) {
        toast.__jpLoanwordTimer = setTimeout(() => {
          toast.style.opacity = "0";
          setTimeout(() => toast.remove(), 220);
        }, duration);
      }
    }
  };
  var FuriganaController = class {
    constructor() {
      this.buildVersion = CONTENT_BUILD_VERSION;
      this.phase = "idle";
      this.count = 0;
      this.errorMessage = "";
      this.tokenizer = null;
      this.tokenizerPromise = null;
      this.observer = null;
      this.pendingRoots = /* @__PURE__ */ new Set();
      this.pendingContextRefreshRoots = /* @__PURE__ */ new Set();
      this.flushTimer = null;
      this.runId = 0;
    }
    getStatus() {
      if (this.phase === "enabled") {
        this.syncCount();
      }
      return {
        phase: this.phase,
        enabled: this.phase === "enabled",
        count: this.count,
        message: this.errorMessage
      };
    }
    async toggle() {
      if (this.phase === "enabled" || this.phase === "loading") {
        this.disable();
        return this.getStatus();
      }
      await this.enable();
      return this.getStatus();
    }
    async enable() {
      if (this.phase === "enabled" || this.phase === "loading") {
        return;
      }
      const currentRun = ++this.runId;
      this.phase = "loading";
      this.errorMessage = "";
      this.showToast("\u6B63\u5728\u672C\u5730\u5206\u6790\u65E5\u8BED\u8BFB\u97F3\u2026", "loading", 0);
      this.installStyle();
      try {
        const tokenizer = await this.getTokenizer();
        if (currentRun !== this.runId) {
          return;
        }
        this.count = 0;
        this.processRoot(document.body || document.documentElement, tokenizer);
        this.startObserver();
        this.phase = "enabled";
        this.showToast(`\u5DF2\u6807\u6CE8 ${this.count} \u5904\u6C49\u5B57\u8BFB\u97F3`, "success");
      } catch (error) {
        if (currentRun !== this.runId) {
          return;
        }
        this.phase = "error";
        this.tokenizerPromise = null;
        this.errorMessage = error instanceof Error ? error.message : String(error);
        this.removeStyle();
        this.showToast(`\u6807\u6CE8\u5931\u8D25\uFF1A${this.errorMessage}`, "error", 6e3);
        console.error("[\u65E5\u8BED\u6C49\u5B57 AI \u8BFB\u97F3\u52A9\u624B]", error);
      }
    }
    disable() {
      this.runId += 1;
      this.observer?.disconnect();
      this.observer = null;
      this.pendingRoots.clear();
      this.pendingContextRefreshRoots.clear();
      if (this.flushTimer !== null) {
        clearTimeout(this.flushTimer);
        this.flushTimer = null;
      }
      const changedParents = /* @__PURE__ */ new Set();
      document.querySelectorAll(`ruby[${RUBY_ATTRIBUTE}]`).forEach((ruby) => {
        if (ruby.parentNode) {
          changedParents.add(ruby.parentNode);
        }
        ruby.replaceWith(document.createTextNode(ruby.dataset.jpOriginal || ruby.firstChild?.textContent || ""));
      });
      changedParents.forEach((parent) => parent.normalize());
      this.removeStyle();
      this.count = 0;
      this.phase = "idle";
      this.errorMessage = "";
      this.showToast("\u5DF2\u79FB\u9664\u8BFB\u97F3\u6807\u6CE8", "success");
    }
    getTokenizer() {
      if (this.tokenizer) {
        return Promise.resolve(this.tokenizer);
      }
      if (!this.tokenizerPromise) {
        const dictionaryPath = chrome.runtime.getURL("dict/");
        this.tokenizerPromise = new Promise((resolve, reject) => {
          import_kuromoji.default.builder({ dicPath: dictionaryPath }).build((error, tokenizer) => {
            if (error) {
              reject(error);
              return;
            }
            this.tokenizer = tokenizer;
            resolve(tokenizer);
          });
        });
      }
      return this.tokenizerPromise;
    }
    processRoot(root, tokenizer = this.tokenizer) {
      if (!root || !tokenizer) {
        return;
      }
      if (root.nodeType === Node.TEXT_NODE) {
        if (!this.isEligibleTextNode(root)) {
          return;
        }
        this.processTextNode(root, tokenizer, collectAdjacentInlineContext(root, /* @__PURE__ */ new WeakMap()));
        return;
      }
      if (!(root instanceof Element || root instanceof Document || root instanceof DocumentFragment)) {
        return;
      }
      if (root instanceof Element && root.matches(SKIPPED_SELECTOR)) {
        return;
      }
      const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
        acceptNode: (node) => this.isEligibleTextNode(node) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT
      });
      const nodes = [];
      while (walker.nextNode()) {
        nodes.push(walker.currentNode);
      }
      const displayCache = /* @__PURE__ */ new WeakMap();
      const jobs = nodes.map((node) => ({
        node,
        context: collectAdjacentInlineContext(node, displayCache)
      }));
      jobs.forEach(({ node, context }) => this.processTextNode(node, tokenizer, context));
    }
    isEligibleTextNode(node) {
      if (!node.nodeValue || !containsKanji(node.nodeValue)) {
        return false;
      }
      const parent = node.parentElement;
      return Boolean(parent && !parent.closest(SKIPPED_SELECTOR));
    }
    processTextNode(node, tokenizer, context = {}) {
      if (!node.isConnected || !this.isEligibleTextNode(node)) {
        return;
      }
      const originalText = node.nodeValue;
      const segments = buildAnnotationSegments(originalText, tokenizer, context);
      if (!segments.some((segment) => segment.reading)) {
        return;
      }
      const fragment = document.createDocumentFragment();
      for (const segment of segments) {
        if (!segment.reading) {
          fragment.append(document.createTextNode(segment.text));
          continue;
        }
        const ruby = document.createElement("ruby");
        ruby.setAttribute(RUBY_ATTRIBUTE, "");
        if (foreignPersonAnnotationSignatures.has(`${segment.text}\0${segment.reading}`)) {
          ruby.setAttribute(FOREIGN_PERSON_RUBY_ATTRIBUTE, "");
        }
        ruby.dataset.jpOriginal = segment.text;
        ruby.append(document.createTextNode(segment.text));
        const rt = document.createElement("rt");
        rt.textContent = segment.reading;
        ruby.append(rt);
        fragment.append(ruby);
        this.count += 1;
      }
      node.replaceWith(fragment);
    }
    syncCount() {
      this.count = document.querySelectorAll(`ruby[${RUBY_ATTRIBUTE}]`).length;
    }
    refreshContextualRoot(root, tokenizer = this.tokenizer) {
      if (!root?.isConnected || !tokenizer || !(root instanceof Element)) {
        return;
      }
      const changedParents = /* @__PURE__ */ new Set();
      root.querySelectorAll(`ruby[${RUBY_ATTRIBUTE}]`).forEach((ruby) => {
        const original = ruby.dataset.jpOriginal || ruby.firstChild?.textContent || "";
        if (!containsContextCandidate(original)) {
          return;
        }
        if (ruby.parentNode) {
          changedParents.add(ruby.parentNode);
        }
        ruby.replaceWith(document.createTextNode(original));
      });
      if (changedParents.size === 0) {
        return;
      }
      changedParents.forEach((parent) => parent.normalize());
      this.processRoot(root, tokenizer);
    }
    observeDocumentChanges() {
      this.observer?.observe(document.body || document.documentElement, {
        childList: true,
        subtree: true,
        characterData: true,
        characterDataOldValue: true
      });
    }
    startObserver() {
      this.observer?.disconnect();
      this.observer = new MutationObserver((mutations) => {
        const displayCache = /* @__PURE__ */ new WeakMap();
        for (const mutation of mutations) {
          if (mutation.type === "characterData") {
            this.pendingRoots.add(mutation.target);
            const currentValue = mutation.target.nodeValue || "";
            const oldValue = mutation.oldValue || "";
            const directContextChange2 = containsContextMutation(currentValue) || containsContextMutation(oldValue);
            const personCharacterChange2 = FOREIGN_PERSON_CONTEXT_PATTERN.test(currentValue) || FOREIGN_PERSON_CONTEXT_PATTERN.test(oldValue);
            if (directContextChange2 || personCharacterChange2) {
              const refreshRoot = getContextRefreshRoot(mutation.target, displayCache);
              if (refreshRoot && (directContextChange2 || contextualRootContainsForeignPerson(refreshRoot) || FOREIGN_PERSON_CONTEXT_PATTERN.test(oldValue) && Boolean(refreshRoot.querySelector(
                `ruby[${RUBY_ATTRIBUTE}][${FOREIGN_PERSON_RUBY_ATTRIBUTE}]`
              )))) {
                this.pendingContextRefreshRoots.add(refreshRoot);
              }
            }
            continue;
          }
          mutation.addedNodes.forEach((node) => this.pendingRoots.add(node));
          const directContextChange = mutationNodesContainContext(mutation.addedNodes) || mutationNodesContainContext(mutation.removedNodes);
          const personCharacterChange = mutationNodesContainForeignNameCharacter(mutation.addedNodes) || mutationNodesContainForeignNameCharacter(mutation.removedNodes);
          if (directContextChange || personCharacterChange) {
            const refreshRoot = getContextRefreshRoot(mutation.target, displayCache);
            if (refreshRoot && (directContextChange || contextualRootContainsForeignPerson(refreshRoot) || mutationNodesContainForeignNameCharacter(mutation.removedNodes) && Boolean(refreshRoot.querySelector(
              `ruby[${RUBY_ATTRIBUTE}][${FOREIGN_PERSON_RUBY_ATTRIBUTE}]`
            )))) {
              this.pendingContextRefreshRoots.add(refreshRoot);
            }
          }
        }
        this.scheduleFlush();
      });
      this.observeDocumentChanges();
    }
    scheduleFlush() {
      if (this.flushTimer !== null || this.phase !== "enabled") {
        return;
      }
      this.flushTimer = setTimeout(() => {
        this.flushTimer = null;
        const roots = Array.from(this.pendingRoots);
        const refreshRoots = Array.from(this.pendingContextRefreshRoots);
        this.pendingRoots.clear();
        this.pendingContextRefreshRoots.clear();
        this.observer?.disconnect();
        try {
          refreshRoots.forEach((root) => this.refreshContextualRoot(root));
          roots.forEach((root) => this.processRoot(root));
          this.syncCount();
        } finally {
          if (this.phase === "enabled") {
            this.observeDocumentChanges();
          }
        }
      }, 60);
    }
    installStyle() {
      if (document.getElementById(STYLE_ID)) {
        return;
      }
      const style = document.createElement("style");
      style.id = STYLE_ID;
      style.textContent = `
      ruby[${RUBY_ATTRIBUTE}] {
        ruby-position: over !important;
        ruby-align: center !important;
        ruby-overhang: auto !important;
      }
      ruby[${RUBY_ATTRIBUTE}] > rt {
        font-size: 0.55em !important;
        line-height: 1 !important;
        color: #b42318 !important;
        font-weight: 600 !important;
        letter-spacing: normal !important;
        word-spacing: normal !important;
        text-align: center !important;
        text-indent: 0 !important;
        white-space: nowrap !important;
        user-select: none !important;
      }
    `;
      (document.head || document.documentElement).append(style);
    }
    removeStyle() {
      document.getElementById(STYLE_ID)?.remove();
    }
    showToast(message, kind = "success", duration = 2600) {
      let toast = document.getElementById(TOAST_ID);
      if (!toast) {
        toast = document.createElement("div");
        toast.id = TOAST_ID;
        toast.setAttribute(TRANSLATION_UI_ATTRIBUTE, "");
        toast.setAttribute("role", "status");
        Object.assign(toast.style, {
          position: "fixed",
          zIndex: "2147483647",
          top: "18px",
          right: "18px",
          maxWidth: "340px",
          padding: "12px 16px",
          borderRadius: "10px",
          color: "#fff",
          font: "600 14px/1.45 system-ui, sans-serif",
          boxShadow: "0 8px 28px rgba(0, 0, 0, .24)",
          transition: "opacity .2s ease",
          pointerEvents: "none"
        });
        document.documentElement.append(toast);
      }
      toast.style.background = kind === "error" ? "#b42318" : kind === "loading" ? "#344054" : "#067647";
      toast.style.opacity = "1";
      toast.textContent = message;
      clearTimeout(toast.__jpFuriganaTimer);
      if (duration > 0) {
        toast.__jpFuriganaTimer = setTimeout(() => {
          toast.style.opacity = "0";
          setTimeout(() => toast.remove(), 220);
        }, duration);
      }
    }
  };
  if (globalThis[TRANSLATION_CONTROLLER_KEY]?.buildVersion !== CONTENT_BUILD_VERSION) {
    globalThis[TRANSLATION_CONTROLLER_KEY] = new SelectionTranslationController();
  }
  if (globalThis[LOANWORD_CONTROLLER_KEY]?.buildVersion !== CONTENT_BUILD_VERSION) {
    const loanwordController = new LoanwordOriginController();
    globalThis[LOANWORD_CONTROLLER_KEY] = loanwordController;
    chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
      if (message?.type === "GET_LOANWORD_ORIGIN_STATUS") {
        sendResponse(loanwordController.getStatus());
        return false;
      }
      if (message?.type === "TOGGLE_LOANWORD_ORIGINS") {
        loanwordController.toggle().then(sendResponse);
        return true;
      }
      if (message?.type === "ENABLE_LOANWORD_ORIGINS") {
        loanwordController.enable().then(sendResponse);
        return true;
      }
      if (message?.type === "REMOVE_LOANWORD_ORIGINS") {
        sendResponse(loanwordController.disable());
        return false;
      }
      return false;
    });
  }
  var loanwordOnlyBootstrap = globalThis.__JP_LOANWORD_ONLY_BOOTSTRAP__ === true;
  delete globalThis.__JP_LOANWORD_ONLY_BOOTSTRAP__;
  if (globalThis[CONTROLLER_KEY]?.buildVersion !== CONTENT_BUILD_VERSION) {
    const controller = new FuriganaController();
    globalThis[CONTROLLER_KEY] = controller;
    chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
      if (message?.type === "GET_FURIGANA_STATUS") {
        sendResponse(controller.getStatus());
        return false;
      }
      if (message?.type === "TOGGLE_FURIGANA") {
        controller.toggle().then(sendResponse);
        return true;
      }
      return false;
    });
    if (!loanwordOnlyBootstrap) {
      void controller.enable();
    }
  }
})();
