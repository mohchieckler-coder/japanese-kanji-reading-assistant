"use strict";
(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __commonJS = (cb, mod) => function __require() {
    try {
      return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
    } catch (e) {
      throw mod = 0, e;
    }
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));

  // node_modules/kuromoji/src/viterbi/ViterbiNode.js
  var require_ViterbiNode = __commonJS({
    "node_modules/kuromoji/src/viterbi/ViterbiNode.js"(exports, module) {
      "use strict";
      function ViterbiNode(node_name, node_cost, start_pos, length, type, left_id, right_id, surface_form) {
        this.name = node_name;
        this.cost = node_cost;
        this.start_pos = start_pos;
        this.length = length;
        this.left_id = left_id;
        this.right_id = right_id;
        this.prev = null;
        this.surface_form = surface_form;
        if (type === "BOS") {
          this.shortest_cost = 0;
        } else {
          this.shortest_cost = Number.MAX_VALUE;
        }
        this.type = type;
      }
      module.exports = ViterbiNode;
    }
  });

  // node_modules/kuromoji/src/viterbi/ViterbiLattice.js
  var require_ViterbiLattice = __commonJS({
    "node_modules/kuromoji/src/viterbi/ViterbiLattice.js"(exports, module) {
      "use strict";
      var ViterbiNode = require_ViterbiNode();
      function ViterbiLattice() {
        this.nodes_end_at = [];
        this.nodes_end_at[0] = [new ViterbiNode(-1, 0, 0, 0, "BOS", 0, 0, "")];
        this.eos_pos = 1;
      }
      ViterbiLattice.prototype.append = function(node) {
        var last_pos = node.start_pos + node.length - 1;
        if (this.eos_pos < last_pos) {
          this.eos_pos = last_pos;
        }
        var prev_nodes = this.nodes_end_at[last_pos];
        if (prev_nodes == null) {
          prev_nodes = [];
        }
        prev_nodes.push(node);
        this.nodes_end_at[last_pos] = prev_nodes;
      };
      ViterbiLattice.prototype.appendEos = function() {
        var last_index = this.nodes_end_at.length;
        this.eos_pos++;
        this.nodes_end_at[last_index] = [new ViterbiNode(-1, 0, this.eos_pos, 0, "EOS", 0, 0, "")];
      };
      module.exports = ViterbiLattice;
    }
  });

  // node_modules/kuromoji/src/util/SurrogateAwareString.js
  var require_SurrogateAwareString = __commonJS({
    "node_modules/kuromoji/src/util/SurrogateAwareString.js"(exports, module) {
      "use strict";
      function SurrogateAwareString(str) {
        this.str = str;
        this.index_mapping = [];
        for (var pos = 0; pos < str.length; pos++) {
          var ch = str.charAt(pos);
          this.index_mapping.push(pos);
          if (SurrogateAwareString.isSurrogatePair(ch)) {
            pos++;
          }
        }
        this.length = this.index_mapping.length;
      }
      SurrogateAwareString.prototype.slice = function(index) {
        if (this.index_mapping.length <= index) {
          return "";
        }
        var surrogate_aware_index = this.index_mapping[index];
        return this.str.slice(surrogate_aware_index);
      };
      SurrogateAwareString.prototype.charAt = function(index) {
        if (this.str.length <= index) {
          return "";
        }
        var surrogate_aware_start_index = this.index_mapping[index];
        var surrogate_aware_end_index = this.index_mapping[index + 1];
        if (surrogate_aware_end_index == null) {
          return this.str.slice(surrogate_aware_start_index);
        }
        return this.str.slice(surrogate_aware_start_index, surrogate_aware_end_index);
      };
      SurrogateAwareString.prototype.charCodeAt = function(index) {
        if (this.index_mapping.length <= index) {
          return NaN;
        }
        var surrogate_aware_index = this.index_mapping[index];
        var upper = this.str.charCodeAt(surrogate_aware_index);
        var lower;
        if (upper >= 55296 && upper <= 56319 && surrogate_aware_index < this.str.length) {
          lower = this.str.charCodeAt(surrogate_aware_index + 1);
          if (lower >= 56320 && lower <= 57343) {
            return (upper - 55296) * 1024 + lower - 56320 + 65536;
          }
        }
        return upper;
      };
      SurrogateAwareString.prototype.toString = function() {
        return this.str;
      };
      SurrogateAwareString.isSurrogatePair = function(ch) {
        var utf16_code = ch.charCodeAt(0);
        if (utf16_code >= 55296 && utf16_code <= 56319) {
          return true;
        } else {
          return false;
        }
      };
      module.exports = SurrogateAwareString;
    }
  });

  // node_modules/kuromoji/src/viterbi/ViterbiBuilder.js
  var require_ViterbiBuilder = __commonJS({
    "node_modules/kuromoji/src/viterbi/ViterbiBuilder.js"(exports, module) {
      "use strict";
      var ViterbiNode = require_ViterbiNode();
      var ViterbiLattice = require_ViterbiLattice();
      var SurrogateAwareString = require_SurrogateAwareString();
      function ViterbiBuilder(dic) {
        this.trie = dic.trie;
        this.token_info_dictionary = dic.token_info_dictionary;
        this.unknown_dictionary = dic.unknown_dictionary;
      }
      ViterbiBuilder.prototype.build = function(sentence_str) {
        var lattice = new ViterbiLattice();
        var sentence = new SurrogateAwareString(sentence_str);
        var key, trie_id, left_id, right_id, word_cost;
        for (var pos = 0; pos < sentence.length; pos++) {
          var tail = sentence.slice(pos);
          var vocabulary = this.trie.commonPrefixSearch(tail);
          for (var n = 0; n < vocabulary.length; n++) {
            trie_id = vocabulary[n].v;
            key = vocabulary[n].k;
            var token_info_ids = this.token_info_dictionary.target_map[trie_id];
            for (var i = 0; i < token_info_ids.length; i++) {
              var token_info_id = parseInt(token_info_ids[i]);
              left_id = this.token_info_dictionary.dictionary.getShort(token_info_id);
              right_id = this.token_info_dictionary.dictionary.getShort(token_info_id + 2);
              word_cost = this.token_info_dictionary.dictionary.getShort(token_info_id + 4);
              lattice.append(new ViterbiNode(token_info_id, word_cost, pos + 1, key.length, "KNOWN", left_id, right_id, key));
            }
          }
          var surrogate_aware_tail = new SurrogateAwareString(tail);
          var head_char = new SurrogateAwareString(surrogate_aware_tail.charAt(0));
          var head_char_class = this.unknown_dictionary.lookup(head_char.toString());
          if (vocabulary == null || vocabulary.length === 0 || head_char_class.is_always_invoke === 1) {
            key = head_char;
            if (head_char_class.is_grouping === 1 && 1 < surrogate_aware_tail.length) {
              for (var k = 1; k < surrogate_aware_tail.length; k++) {
                var next_char = surrogate_aware_tail.charAt(k);
                var next_char_class = this.unknown_dictionary.lookup(next_char);
                if (head_char_class.class_name !== next_char_class.class_name) {
                  break;
                }
                key += next_char;
              }
            }
            var unk_ids = this.unknown_dictionary.target_map[head_char_class.class_id];
            for (var j = 0; j < unk_ids.length; j++) {
              var unk_id = parseInt(unk_ids[j]);
              left_id = this.unknown_dictionary.dictionary.getShort(unk_id);
              right_id = this.unknown_dictionary.dictionary.getShort(unk_id + 2);
              word_cost = this.unknown_dictionary.dictionary.getShort(unk_id + 4);
              lattice.append(new ViterbiNode(unk_id, word_cost, pos + 1, key.length, "UNKNOWN", left_id, right_id, key.toString()));
            }
          }
        }
        lattice.appendEos();
        return lattice;
      };
      module.exports = ViterbiBuilder;
    }
  });

  // node_modules/kuromoji/src/viterbi/ViterbiSearcher.js
  var require_ViterbiSearcher = __commonJS({
    "node_modules/kuromoji/src/viterbi/ViterbiSearcher.js"(exports, module) {
      "use strict";
      function ViterbiSearcher(connection_costs) {
        this.connection_costs = connection_costs;
      }
      ViterbiSearcher.prototype.search = function(lattice) {
        lattice = this.forward(lattice);
        return this.backward(lattice);
      };
      ViterbiSearcher.prototype.forward = function(lattice) {
        var i, j, k;
        for (i = 1; i <= lattice.eos_pos; i++) {
          var nodes = lattice.nodes_end_at[i];
          if (nodes == null) {
            continue;
          }
          for (j = 0; j < nodes.length; j++) {
            var node = nodes[j];
            var cost = Number.MAX_VALUE;
            var shortest_prev_node;
            var prev_nodes = lattice.nodes_end_at[node.start_pos - 1];
            if (prev_nodes == null) {
              continue;
            }
            for (k = 0; k < prev_nodes.length; k++) {
              var prev_node = prev_nodes[k];
              var edge_cost;
              if (node.left_id == null || prev_node.right_id == null) {
                console.log("Left or right is null");
                edge_cost = 0;
              } else {
                edge_cost = this.connection_costs.get(prev_node.right_id, node.left_id);
              }
              var _cost = prev_node.shortest_cost + edge_cost + node.cost;
              if (_cost < cost) {
                shortest_prev_node = prev_node;
                cost = _cost;
              }
            }
            node.prev = shortest_prev_node;
            node.shortest_cost = cost;
          }
        }
        return lattice;
      };
      ViterbiSearcher.prototype.backward = function(lattice) {
        var shortest_path = [];
        var eos = lattice.nodes_end_at[lattice.nodes_end_at.length - 1][0];
        var node_back = eos.prev;
        if (node_back == null) {
          return [];
        }
        while (node_back.type !== "BOS") {
          shortest_path.push(node_back);
          if (node_back.prev == null) {
            return [];
          }
          node_back = node_back.prev;
        }
        return shortest_path.reverse();
      };
      module.exports = ViterbiSearcher;
    }
  });

  // node_modules/kuromoji/src/util/IpadicFormatter.js
  var require_IpadicFormatter = __commonJS({
    "node_modules/kuromoji/src/util/IpadicFormatter.js"(exports, module) {
      "use strict";
      function IpadicFormatter() {
      }
      IpadicFormatter.prototype.formatEntry = function(word_id, position, type, features) {
        var token = {};
        token.word_id = word_id;
        token.word_type = type;
        token.word_position = position;
        token.surface_form = features[0];
        token.pos = features[1];
        token.pos_detail_1 = features[2];
        token.pos_detail_2 = features[3];
        token.pos_detail_3 = features[4];
        token.conjugated_type = features[5];
        token.conjugated_form = features[6];
        token.basic_form = features[7];
        token.reading = features[8];
        token.pronunciation = features[9];
        return token;
      };
      IpadicFormatter.prototype.formatUnknownEntry = function(word_id, position, type, features, surface_form) {
        var token = {};
        token.word_id = word_id;
        token.word_type = type;
        token.word_position = position;
        token.surface_form = surface_form;
        token.pos = features[1];
        token.pos_detail_1 = features[2];
        token.pos_detail_2 = features[3];
        token.pos_detail_3 = features[4];
        token.conjugated_type = features[5];
        token.conjugated_form = features[6];
        token.basic_form = features[7];
        return token;
      };
      module.exports = IpadicFormatter;
    }
  });

  // node_modules/kuromoji/src/Tokenizer.js
  var require_Tokenizer = __commonJS({
    "node_modules/kuromoji/src/Tokenizer.js"(exports, module) {
      "use strict";
      var ViterbiBuilder = require_ViterbiBuilder();
      var ViterbiSearcher = require_ViterbiSearcher();
      var IpadicFormatter = require_IpadicFormatter();
      var PUNCTUATION = /、|。/;
      function Tokenizer(dic) {
        this.token_info_dictionary = dic.token_info_dictionary;
        this.unknown_dictionary = dic.unknown_dictionary;
        this.viterbi_builder = new ViterbiBuilder(dic);
        this.viterbi_searcher = new ViterbiSearcher(dic.connection_costs);
        this.formatter = new IpadicFormatter();
      }
      Tokenizer.splitByPunctuation = function(input) {
        var sentences = [];
        var tail = input;
        while (true) {
          if (tail === "") {
            break;
          }
          var index = tail.search(PUNCTUATION);
          if (index < 0) {
            sentences.push(tail);
            break;
          }
          sentences.push(tail.substring(0, index + 1));
          tail = tail.substring(index + 1);
        }
        return sentences;
      };
      Tokenizer.prototype.tokenize = function(text) {
        var sentences = Tokenizer.splitByPunctuation(text);
        var tokens = [];
        for (var i = 0; i < sentences.length; i++) {
          var sentence = sentences[i];
          this.tokenizeForSentence(sentence, tokens);
        }
        return tokens;
      };
      Tokenizer.prototype.tokenizeForSentence = function(sentence, tokens) {
        if (tokens == null) {
          tokens = [];
        }
        var lattice = this.getLattice(sentence);
        var best_path = this.viterbi_searcher.search(lattice);
        var last_pos = 0;
        if (tokens.length > 0) {
          last_pos = tokens[tokens.length - 1].word_position;
        }
        for (var j = 0; j < best_path.length; j++) {
          var node = best_path[j];
          var token, features, features_line;
          if (node.type === "KNOWN") {
            features_line = this.token_info_dictionary.getFeatures(node.name);
            if (features_line == null) {
              features = [];
            } else {
              features = features_line.split(",");
            }
            token = this.formatter.formatEntry(node.name, last_pos + node.start_pos, node.type, features);
          } else if (node.type === "UNKNOWN") {
            features_line = this.unknown_dictionary.getFeatures(node.name);
            if (features_line == null) {
              features = [];
            } else {
              features = features_line.split(",");
            }
            token = this.formatter.formatUnknownEntry(node.name, last_pos + node.start_pos, node.type, features, node.surface_form);
          } else {
            token = this.formatter.formatEntry(node.name, last_pos + node.start_pos, node.type, []);
          }
          tokens.push(token);
        }
        return tokens;
      };
      Tokenizer.prototype.getLattice = function(text) {
        return this.viterbi_builder.build(text);
      };
      module.exports = Tokenizer;
    }
  });

  // node_modules/zlibjs/bin/gunzip.min.js
  var require_gunzip_min = __commonJS({
    "node_modules/zlibjs/bin/gunzip.min.js"(exports) {
      (function() {
        "use strict";
        function n(e) {
          throw e;
        }
        var p = void 0, aa = this;
        function t(e, b) {
          var d = e.split("."), c = aa;
          !(d[0] in c) && c.execScript && c.execScript("var " + d[0]);
          for (var a; d.length && (a = d.shift()); ) !d.length && b !== p ? c[a] = b : c = c[a] ? c[a] : c[a] = {};
        }
        ;
        var x = "undefined" !== typeof Uint8Array && "undefined" !== typeof Uint16Array && "undefined" !== typeof Uint32Array && "undefined" !== typeof DataView;
        new (x ? Uint8Array : Array)(256);
        var y;
        for (y = 0; 256 > y; ++y) for (var A = y, ba = 7, A = A >>> 1; A; A >>>= 1) --ba;
        function B(e, b, d) {
          var c, a = "number" === typeof b ? b : b = 0, f = "number" === typeof d ? d : e.length;
          c = -1;
          for (a = f & 7; a--; ++b) c = c >>> 8 ^ C[(c ^ e[b]) & 255];
          for (a = f >> 3; a--; b += 8) c = c >>> 8 ^ C[(c ^ e[b]) & 255], c = c >>> 8 ^ C[(c ^ e[b + 1]) & 255], c = c >>> 8 ^ C[(c ^ e[b + 2]) & 255], c = c >>> 8 ^ C[(c ^ e[b + 3]) & 255], c = c >>> 8 ^ C[(c ^ e[b + 4]) & 255], c = c >>> 8 ^ C[(c ^ e[b + 5]) & 255], c = c >>> 8 ^ C[(c ^ e[b + 6]) & 255], c = c >>> 8 ^ C[(c ^ e[b + 7]) & 255];
          return (c ^ 4294967295) >>> 0;
        }
        var D = [
          0,
          1996959894,
          3993919788,
          2567524794,
          124634137,
          1886057615,
          3915621685,
          2657392035,
          249268274,
          2044508324,
          3772115230,
          2547177864,
          162941995,
          2125561021,
          3887607047,
          2428444049,
          498536548,
          1789927666,
          4089016648,
          2227061214,
          450548861,
          1843258603,
          4107580753,
          2211677639,
          325883990,
          1684777152,
          4251122042,
          2321926636,
          335633487,
          1661365465,
          4195302755,
          2366115317,
          997073096,
          1281953886,
          3579855332,
          2724688242,
          1006888145,
          1258607687,
          3524101629,
          2768942443,
          901097722,
          1119000684,
          3686517206,
          2898065728,
          853044451,
          1172266101,
          3705015759,
          2882616665,
          651767980,
          1373503546,
          3369554304,
          3218104598,
          565507253,
          1454621731,
          3485111705,
          3099436303,
          671266974,
          1594198024,
          3322730930,
          2970347812,
          795835527,
          1483230225,
          3244367275,
          3060149565,
          1994146192,
          31158534,
          2563907772,
          4023717930,
          1907459465,
          112637215,
          2680153253,
          3904427059,
          2013776290,
          251722036,
          2517215374,
          3775830040,
          2137656763,
          141376813,
          2439277719,
          3865271297,
          1802195444,
          476864866,
          2238001368,
          4066508878,
          1812370925,
          453092731,
          2181625025,
          4111451223,
          1706088902,
          314042704,
          2344532202,
          4240017532,
          1658658271,
          366619977,
          2362670323,
          4224994405,
          1303535960,
          984961486,
          2747007092,
          3569037538,
          1256170817,
          1037604311,
          2765210733,
          3554079995,
          1131014506,
          879679996,
          2909243462,
          3663771856,
          1141124467,
          855842277,
          2852801631,
          3708648649,
          1342533948,
          654459306,
          3188396048,
          3373015174,
          1466479909,
          544179635,
          3110523913,
          3462522015,
          1591671054,
          702138776,
          2966460450,
          3352799412,
          1504918807,
          783551873,
          3082640443,
          3233442989,
          3988292384,
          2596254646,
          62317068,
          1957810842,
          3939845945,
          2647816111,
          81470997,
          1943803523,
          3814918930,
          2489596804,
          225274430,
          2053790376,
          3826175755,
          2466906013,
          167816743,
          2097651377,
          4027552580,
          2265490386,
          503444072,
          1762050814,
          4150417245,
          2154129355,
          426522225,
          1852507879,
          4275313526,
          2312317920,
          282753626,
          1742555852,
          4189708143,
          2394877945,
          397917763,
          1622183637,
          3604390888,
          2714866558,
          953729732,
          1340076626,
          3518719985,
          2797360999,
          1068828381,
          1219638859,
          3624741850,
          2936675148,
          906185462,
          1090812512,
          3747672003,
          2825379669,
          829329135,
          1181335161,
          3412177804,
          3160834842,
          628085408,
          1382605366,
          3423369109,
          3138078467,
          570562233,
          1426400815,
          3317316542,
          2998733608,
          733239954,
          1555261956,
          3268935591,
          3050360625,
          752459403,
          1541320221,
          2607071920,
          3965973030,
          1969922972,
          40735498,
          2617837225,
          3943577151,
          1913087877,
          83908371,
          2512341634,
          3803740692,
          2075208622,
          213261112,
          2463272603,
          3855990285,
          2094854071,
          198958881,
          2262029012,
          4057260610,
          1759359992,
          534414190,
          2176718541,
          4139329115,
          1873836001,
          414664567,
          2282248934,
          4279200368,
          1711684554,
          285281116,
          2405801727,
          4167216745,
          1634467795,
          376229701,
          2685067896,
          3608007406,
          1308918612,
          956543938,
          2808555105,
          3495958263,
          1231636301,
          1047427035,
          2932959818,
          3654703836,
          1088359270,
          936918e3,
          2847714899,
          3736837829,
          1202900863,
          817233897,
          3183342108,
          3401237130,
          1404277552,
          615818150,
          3134207493,
          3453421203,
          1423857449,
          601450431,
          3009837614,
          3294710456,
          1567103746,
          711928724,
          3020668471,
          3272380065,
          1510334235,
          755167117
        ], C = x ? new Uint32Array(D) : D;
        function E() {
        }
        E.prototype.getName = function() {
          return this.name;
        };
        E.prototype.getData = function() {
          return this.data;
        };
        E.prototype.G = function() {
          return this.H;
        };
        function G(e) {
          var b = e.length, d = 0, c = Number.POSITIVE_INFINITY, a, f, k, l, m, r, q, g, h, v;
          for (g = 0; g < b; ++g) e[g] > d && (d = e[g]), e[g] < c && (c = e[g]);
          a = 1 << d;
          f = new (x ? Uint32Array : Array)(a);
          k = 1;
          l = 0;
          for (m = 2; k <= d; ) {
            for (g = 0; g < b; ++g) if (e[g] === k) {
              r = 0;
              q = l;
              for (h = 0; h < k; ++h) r = r << 1 | q & 1, q >>= 1;
              v = k << 16 | g;
              for (h = r; h < a; h += m) f[h] = v;
              ++l;
            }
            ++k;
            l <<= 1;
            m <<= 1;
          }
          return [f, d, c];
        }
        ;
        var J = [], K;
        for (K = 0; 288 > K; K++) switch (true) {
          case 143 >= K:
            J.push([K + 48, 8]);
            break;
          case 255 >= K:
            J.push([K - 144 + 400, 9]);
            break;
          case 279 >= K:
            J.push([K - 256 + 0, 7]);
            break;
          case 287 >= K:
            J.push([K - 280 + 192, 8]);
            break;
          default:
            n("invalid literal: " + K);
        }
        var ca = (function() {
          function e(a) {
            switch (true) {
              case 3 === a:
                return [257, a - 3, 0];
              case 4 === a:
                return [258, a - 4, 0];
              case 5 === a:
                return [259, a - 5, 0];
              case 6 === a:
                return [260, a - 6, 0];
              case 7 === a:
                return [261, a - 7, 0];
              case 8 === a:
                return [262, a - 8, 0];
              case 9 === a:
                return [263, a - 9, 0];
              case 10 === a:
                return [264, a - 10, 0];
              case 12 >= a:
                return [265, a - 11, 1];
              case 14 >= a:
                return [266, a - 13, 1];
              case 16 >= a:
                return [267, a - 15, 1];
              case 18 >= a:
                return [268, a - 17, 1];
              case 22 >= a:
                return [269, a - 19, 2];
              case 26 >= a:
                return [270, a - 23, 2];
              case 30 >= a:
                return [271, a - 27, 2];
              case 34 >= a:
                return [
                  272,
                  a - 31,
                  2
                ];
              case 42 >= a:
                return [273, a - 35, 3];
              case 50 >= a:
                return [274, a - 43, 3];
              case 58 >= a:
                return [275, a - 51, 3];
              case 66 >= a:
                return [276, a - 59, 3];
              case 82 >= a:
                return [277, a - 67, 4];
              case 98 >= a:
                return [278, a - 83, 4];
              case 114 >= a:
                return [279, a - 99, 4];
              case 130 >= a:
                return [280, a - 115, 4];
              case 162 >= a:
                return [281, a - 131, 5];
              case 194 >= a:
                return [282, a - 163, 5];
              case 226 >= a:
                return [283, a - 195, 5];
              case 257 >= a:
                return [284, a - 227, 5];
              case 258 === a:
                return [285, a - 258, 0];
              default:
                n("invalid length: " + a);
            }
          }
          var b = [], d, c;
          for (d = 3; 258 >= d; d++) c = e(d), b[d] = c[2] << 24 | c[1] << 16 | c[0];
          return b;
        })();
        x && new Uint32Array(ca);
        function L(e, b) {
          this.i = [];
          this.j = 32768;
          this.d = this.f = this.c = this.n = 0;
          this.input = x ? new Uint8Array(e) : e;
          this.o = false;
          this.k = M;
          this.w = false;
          if (b || !(b = {})) b.index && (this.c = b.index), b.bufferSize && (this.j = b.bufferSize), b.bufferType && (this.k = b.bufferType), b.resize && (this.w = b.resize);
          switch (this.k) {
            case N:
              this.a = 32768;
              this.b = new (x ? Uint8Array : Array)(32768 + this.j + 258);
              break;
            case M:
              this.a = 0;
              this.b = new (x ? Uint8Array : Array)(this.j);
              this.e = this.D;
              this.q = this.A;
              this.l = this.C;
              break;
            default:
              n(Error("invalid inflate mode"));
          }
        }
        var N = 0, M = 1;
        L.prototype.g = function() {
          for (; !this.o; ) {
            var e = P(this, 3);
            e & 1 && (this.o = true);
            e >>>= 1;
            switch (e) {
              case 0:
                var b = this.input, d = this.c, c = this.b, a = this.a, f = b.length, k = p, l = p, m = c.length, r = p;
                this.d = this.f = 0;
                d + 1 >= f && n(Error("invalid uncompressed block header: LEN"));
                k = b[d++] | b[d++] << 8;
                d + 1 >= f && n(Error("invalid uncompressed block header: NLEN"));
                l = b[d++] | b[d++] << 8;
                k === ~l && n(Error("invalid uncompressed block header: length verify"));
                d + k > b.length && n(Error("input buffer is broken"));
                switch (this.k) {
                  case N:
                    for (; a + k > c.length; ) {
                      r = m - a;
                      k -= r;
                      if (x) c.set(b.subarray(d, d + r), a), a += r, d += r;
                      else for (; r--; ) c[a++] = b[d++];
                      this.a = a;
                      c = this.e();
                      a = this.a;
                    }
                    break;
                  case M:
                    for (; a + k > c.length; ) c = this.e({ t: 2 });
                    break;
                  default:
                    n(Error("invalid inflate mode"));
                }
                if (x) c.set(b.subarray(d, d + k), a), a += k, d += k;
                else for (; k--; ) c[a++] = b[d++];
                this.c = d;
                this.a = a;
                this.b = c;
                break;
              case 1:
                this.l(da, ea);
                break;
              case 2:
                for (var q = P(this, 5) + 257, g = P(this, 5) + 1, h = P(this, 4) + 4, v = new (x ? Uint8Array : Array)(Q.length), s = p, F = p, H = p, w = p, z = p, O = p, I = p, u = p, Z = p, u = 0; u < h; ++u) v[Q[u]] = P(this, 3);
                if (!x) {
                  u = h;
                  for (h = v.length; u < h; ++u) v[Q[u]] = 0;
                }
                s = G(v);
                w = new (x ? Uint8Array : Array)(q + g);
                u = 0;
                for (Z = q + g; u < Z; ) switch (z = R(this, s), z) {
                  case 16:
                    for (I = 3 + P(this, 2); I--; ) w[u++] = O;
                    break;
                  case 17:
                    for (I = 3 + P(this, 3); I--; ) w[u++] = 0;
                    O = 0;
                    break;
                  case 18:
                    for (I = 11 + P(this, 7); I--; ) w[u++] = 0;
                    O = 0;
                    break;
                  default:
                    O = w[u++] = z;
                }
                F = x ? G(w.subarray(0, q)) : G(w.slice(0, q));
                H = x ? G(w.subarray(q)) : G(w.slice(q));
                this.l(F, H);
                break;
              default:
                n(Error("unknown BTYPE: " + e));
            }
          }
          return this.q();
        };
        var S = [16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15], Q = x ? new Uint16Array(S) : S, fa = [3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27, 31, 35, 43, 51, 59, 67, 83, 99, 115, 131, 163, 195, 227, 258, 258, 258], ga = x ? new Uint16Array(fa) : fa, ha = [0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0, 0, 0], T = x ? new Uint8Array(ha) : ha, ia = [1, 2, 3, 4, 5, 7, 9, 13, 17, 25, 33, 49, 65, 97, 129, 193, 257, 385, 513, 769, 1025, 1537, 2049, 3073, 4097, 6145, 8193, 12289, 16385, 24577], ja = x ? new Uint16Array(ia) : ia, ka = [
          0,
          0,
          0,
          0,
          1,
          1,
          2,
          2,
          3,
          3,
          4,
          4,
          5,
          5,
          6,
          6,
          7,
          7,
          8,
          8,
          9,
          9,
          10,
          10,
          11,
          11,
          12,
          12,
          13,
          13
        ], U = x ? new Uint8Array(ka) : ka, V = new (x ? Uint8Array : Array)(288), W, la;
        W = 0;
        for (la = V.length; W < la; ++W) V[W] = 143 >= W ? 8 : 255 >= W ? 9 : 279 >= W ? 7 : 8;
        var da = G(V), X = new (x ? Uint8Array : Array)(30), Y, ma;
        Y = 0;
        for (ma = X.length; Y < ma; ++Y) X[Y] = 5;
        var ea = G(X);
        function P(e, b) {
          for (var d = e.f, c = e.d, a = e.input, f = e.c, k = a.length, l; c < b; ) f >= k && n(Error("input buffer is broken")), d |= a[f++] << c, c += 8;
          l = d & (1 << b) - 1;
          e.f = d >>> b;
          e.d = c - b;
          e.c = f;
          return l;
        }
        function R(e, b) {
          for (var d = e.f, c = e.d, a = e.input, f = e.c, k = a.length, l = b[0], m = b[1], r, q; c < m && !(f >= k); ) d |= a[f++] << c, c += 8;
          r = l[d & (1 << m) - 1];
          q = r >>> 16;
          q > c && n(Error("invalid code length: " + q));
          e.f = d >> q;
          e.d = c - q;
          e.c = f;
          return r & 65535;
        }
        L.prototype.l = function(e, b) {
          var d = this.b, c = this.a;
          this.r = e;
          for (var a = d.length - 258, f, k, l, m; 256 !== (f = R(this, e)); ) if (256 > f) c >= a && (this.a = c, d = this.e(), c = this.a), d[c++] = f;
          else {
            k = f - 257;
            m = ga[k];
            0 < T[k] && (m += P(this, T[k]));
            f = R(this, b);
            l = ja[f];
            0 < U[f] && (l += P(this, U[f]));
            c >= a && (this.a = c, d = this.e(), c = this.a);
            for (; m--; ) d[c] = d[c++ - l];
          }
          for (; 8 <= this.d; ) this.d -= 8, this.c--;
          this.a = c;
        };
        L.prototype.C = function(e, b) {
          var d = this.b, c = this.a;
          this.r = e;
          for (var a = d.length, f, k, l, m; 256 !== (f = R(this, e)); ) if (256 > f) c >= a && (d = this.e(), a = d.length), d[c++] = f;
          else {
            k = f - 257;
            m = ga[k];
            0 < T[k] && (m += P(this, T[k]));
            f = R(this, b);
            l = ja[f];
            0 < U[f] && (l += P(this, U[f]));
            c + m > a && (d = this.e(), a = d.length);
            for (; m--; ) d[c] = d[c++ - l];
          }
          for (; 8 <= this.d; ) this.d -= 8, this.c--;
          this.a = c;
        };
        L.prototype.e = function() {
          var e = new (x ? Uint8Array : Array)(this.a - 32768), b = this.a - 32768, d, c, a = this.b;
          if (x) e.set(a.subarray(32768, e.length));
          else {
            d = 0;
            for (c = e.length; d < c; ++d) e[d] = a[d + 32768];
          }
          this.i.push(e);
          this.n += e.length;
          if (x) a.set(a.subarray(b, b + 32768));
          else for (d = 0; 32768 > d; ++d) a[d] = a[b + d];
          this.a = 32768;
          return a;
        };
        L.prototype.D = function(e) {
          var b, d = this.input.length / this.c + 1 | 0, c, a, f, k = this.input, l = this.b;
          e && ("number" === typeof e.t && (d = e.t), "number" === typeof e.z && (d += e.z));
          2 > d ? (c = (k.length - this.c) / this.r[2], f = 258 * (c / 2) | 0, a = f < l.length ? l.length + f : l.length << 1) : a = l.length * d;
          x ? (b = new Uint8Array(a), b.set(l)) : b = l;
          return this.b = b;
        };
        L.prototype.q = function() {
          var e = 0, b = this.b, d = this.i, c, a = new (x ? Uint8Array : Array)(this.n + (this.a - 32768)), f, k, l, m;
          if (0 === d.length) return x ? this.b.subarray(32768, this.a) : this.b.slice(32768, this.a);
          f = 0;
          for (k = d.length; f < k; ++f) {
            c = d[f];
            l = 0;
            for (m = c.length; l < m; ++l) a[e++] = c[l];
          }
          f = 32768;
          for (k = this.a; f < k; ++f) a[e++] = b[f];
          this.i = [];
          return this.buffer = a;
        };
        L.prototype.A = function() {
          var e, b = this.a;
          x ? this.w ? (e = new Uint8Array(b), e.set(this.b.subarray(0, b))) : e = this.b.subarray(0, b) : (this.b.length > b && (this.b.length = b), e = this.b);
          return this.buffer = e;
        };
        function $(e) {
          this.input = e;
          this.c = 0;
          this.m = [];
          this.s = false;
        }
        $.prototype.F = function() {
          this.s || this.g();
          return this.m.slice();
        };
        $.prototype.g = function() {
          for (var e = this.input.length; this.c < e; ) {
            var b = new E(), d = p, c = p, a = p, f = p, k = p, l = p, m = p, r = p, q = p, g = this.input, h = this.c;
            b.u = g[h++];
            b.v = g[h++];
            (31 !== b.u || 139 !== b.v) && n(Error("invalid file signature:" + b.u + "," + b.v));
            b.p = g[h++];
            switch (b.p) {
              case 8:
                break;
              default:
                n(Error("unknown compression method: " + b.p));
            }
            b.h = g[h++];
            r = g[h++] | g[h++] << 8 | g[h++] << 16 | g[h++] << 24;
            b.H = new Date(1e3 * r);
            b.N = g[h++];
            b.M = g[h++];
            0 < (b.h & 4) && (b.I = g[h++] | g[h++] << 8, h += b.I);
            if (0 < (b.h & 8)) {
              m = [];
              for (l = 0; 0 < (k = g[h++]); ) m[l++] = String.fromCharCode(k);
              b.name = m.join("");
            }
            if (0 < (b.h & 16)) {
              m = [];
              for (l = 0; 0 < (k = g[h++]); ) m[l++] = String.fromCharCode(k);
              b.J = m.join("");
            }
            0 < (b.h & 2) && (b.B = B(g, 0, h) & 65535, b.B !== (g[h++] | g[h++] << 8) && n(Error("invalid header crc16")));
            d = g[g.length - 4] | g[g.length - 3] << 8 | g[g.length - 2] << 16 | g[g.length - 1] << 24;
            g.length - h - 4 - 4 < 512 * d && (f = d);
            c = new L(g, { index: h, bufferSize: f });
            b.data = a = c.g();
            h = c.c;
            b.K = q = (g[h++] | g[h++] << 8 | g[h++] << 16 | g[h++] << 24) >>> 0;
            B(a, p, p) !== q && n(Error("invalid CRC-32 checksum: 0x" + B(a, p, p).toString(16) + " / 0x" + q.toString(16)));
            b.L = d = (g[h++] | g[h++] << 8 | g[h++] << 16 | g[h++] << 24) >>> 0;
            (a.length & 4294967295) !== d && n(Error("invalid input size: " + (a.length & 4294967295) + " / " + d));
            this.m.push(b);
            this.c = h;
          }
          this.s = true;
          var v = this.m, s, F, H = 0, w = 0, z;
          s = 0;
          for (F = v.length; s < F; ++s) w += v[s].data.length;
          if (x) {
            z = new Uint8Array(w);
            for (s = 0; s < F; ++s) z.set(v[s].data, H), H += v[s].data.length;
          } else {
            z = [];
            for (s = 0; s < F; ++s) z[s] = v[s].data;
            z = Array.prototype.concat.apply([], z);
          }
          return z;
        };
        t("Zlib.Gunzip", $);
        t("Zlib.Gunzip.prototype.decompress", $.prototype.g);
        t("Zlib.Gunzip.prototype.getMembers", $.prototype.F);
        t("Zlib.GunzipMember", E);
        t("Zlib.GunzipMember.prototype.getName", E.prototype.getName);
        t("Zlib.GunzipMember.prototype.getData", E.prototype.getData);
        t("Zlib.GunzipMember.prototype.getMtime", E.prototype.G);
      }).call(exports);
    }
  });

  // src/path-shim.cjs
  var require_path_shim = __commonJS({
    "src/path-shim.cjs"(exports, module) {
      "use strict";
      module.exports = {
        join(base, ...parts) {
          const normalizedBase = String(base).replace(/[\\/]+$/, "");
          const suffix = parts.map((part) => String(part).replace(/^[\\/]+|[\\/]+$/g, "")).filter(Boolean).join("/");
          return suffix ? `${normalizedBase}/${suffix}` : normalizedBase;
        }
      };
    }
  });

  // node_modules/async/dist/async.js
  var require_async = __commonJS({
    "node_modules/async/dist/async.js"(exports, module) {
      (function(global2, factory) {
        typeof exports === "object" && typeof module !== "undefined" ? factory(exports) : typeof define === "function" && define.amd ? define(["exports"], factory) : factory(global2.async = global2.async || {});
      })(exports, (function(exports2) {
        "use strict";
        function slice(arrayLike, start) {
          start = start | 0;
          var newLen = Math.max(arrayLike.length - start, 0);
          var newArr = Array(newLen);
          for (var idx = 0; idx < newLen; idx++) {
            newArr[idx] = arrayLike[start + idx];
          }
          return newArr;
        }
        var apply = function(fn) {
          var args = slice(arguments, 1);
          return function() {
            var callArgs = slice(arguments);
            return fn.apply(null, args.concat(callArgs));
          };
        };
        var initialParams = function(fn) {
          return function() {
            var args = slice(arguments);
            var callback = args.pop();
            fn.call(this, args, callback);
          };
        };
        function isObject(value) {
          var type = typeof value;
          return value != null && (type == "object" || type == "function");
        }
        var hasSetImmediate = typeof setImmediate === "function" && setImmediate;
        var hasNextTick = typeof process === "object" && typeof process.nextTick === "function";
        function fallback(fn) {
          setTimeout(fn, 0);
        }
        function wrap(defer) {
          return function(fn) {
            var args = slice(arguments, 1);
            defer(function() {
              fn.apply(null, args);
            });
          };
        }
        var _defer;
        if (hasSetImmediate) {
          _defer = setImmediate;
        } else if (hasNextTick) {
          _defer = process.nextTick;
        } else {
          _defer = fallback;
        }
        var setImmediate$1 = wrap(_defer);
        function asyncify(func) {
          return initialParams(function(args, callback) {
            var result;
            try {
              result = func.apply(this, args);
            } catch (e) {
              return callback(e);
            }
            if (isObject(result) && typeof result.then === "function") {
              result.then(function(value) {
                invokeCallback(callback, null, value);
              }, function(err) {
                invokeCallback(callback, err.message ? err : new Error(err));
              });
            } else {
              callback(null, result);
            }
          });
        }
        function invokeCallback(callback, error, value) {
          try {
            callback(error, value);
          } catch (e) {
            setImmediate$1(rethrow, e);
          }
        }
        function rethrow(error) {
          throw error;
        }
        var supportsSymbol = typeof Symbol === "function";
        function isAsync(fn) {
          return supportsSymbol && fn[Symbol.toStringTag] === "AsyncFunction";
        }
        function wrapAsync(asyncFn) {
          return isAsync(asyncFn) ? asyncify(asyncFn) : asyncFn;
        }
        function applyEach$1(eachfn) {
          return function(fns) {
            var args = slice(arguments, 1);
            var go = initialParams(function(args2, callback) {
              var that = this;
              return eachfn(fns, function(fn, cb) {
                wrapAsync(fn).apply(that, args2.concat(cb));
              }, callback);
            });
            if (args.length) {
              return go.apply(this, args);
            } else {
              return go;
            }
          };
        }
        var freeGlobal = typeof global == "object" && global && global.Object === Object && global;
        var freeSelf = typeof self == "object" && self && self.Object === Object && self;
        var root = freeGlobal || freeSelf || Function("return this")();
        var Symbol$1 = root.Symbol;
        var objectProto = Object.prototype;
        var hasOwnProperty = objectProto.hasOwnProperty;
        var nativeObjectToString = objectProto.toString;
        var symToStringTag$1 = Symbol$1 ? Symbol$1.toStringTag : void 0;
        function getRawTag(value) {
          var isOwn = hasOwnProperty.call(value, symToStringTag$1), tag = value[symToStringTag$1];
          try {
            value[symToStringTag$1] = void 0;
            var unmasked = true;
          } catch (e) {
          }
          var result = nativeObjectToString.call(value);
          if (unmasked) {
            if (isOwn) {
              value[symToStringTag$1] = tag;
            } else {
              delete value[symToStringTag$1];
            }
          }
          return result;
        }
        var objectProto$1 = Object.prototype;
        var nativeObjectToString$1 = objectProto$1.toString;
        function objectToString(value) {
          return nativeObjectToString$1.call(value);
        }
        var nullTag = "[object Null]";
        var undefinedTag = "[object Undefined]";
        var symToStringTag = Symbol$1 ? Symbol$1.toStringTag : void 0;
        function baseGetTag(value) {
          if (value == null) {
            return value === void 0 ? undefinedTag : nullTag;
          }
          return symToStringTag && symToStringTag in Object(value) ? getRawTag(value) : objectToString(value);
        }
        var asyncTag = "[object AsyncFunction]";
        var funcTag = "[object Function]";
        var genTag = "[object GeneratorFunction]";
        var proxyTag = "[object Proxy]";
        function isFunction(value) {
          if (!isObject(value)) {
            return false;
          }
          var tag = baseGetTag(value);
          return tag == funcTag || tag == genTag || tag == asyncTag || tag == proxyTag;
        }
        var MAX_SAFE_INTEGER = 9007199254740991;
        function isLength(value) {
          return typeof value == "number" && value > -1 && value % 1 == 0 && value <= MAX_SAFE_INTEGER;
        }
        function isArrayLike(value) {
          return value != null && isLength(value.length) && !isFunction(value);
        }
        var breakLoop = {};
        function noop() {
        }
        function once(fn) {
          return function() {
            if (fn === null) return;
            var callFn = fn;
            fn = null;
            callFn.apply(this, arguments);
          };
        }
        var iteratorSymbol = typeof Symbol === "function" && Symbol.iterator;
        var getIterator = function(coll) {
          return iteratorSymbol && coll[iteratorSymbol] && coll[iteratorSymbol]();
        };
        function baseTimes(n, iteratee) {
          var index2 = -1, result = Array(n);
          while (++index2 < n) {
            result[index2] = iteratee(index2);
          }
          return result;
        }
        function isObjectLike(value) {
          return value != null && typeof value == "object";
        }
        var argsTag = "[object Arguments]";
        function baseIsArguments(value) {
          return isObjectLike(value) && baseGetTag(value) == argsTag;
        }
        var objectProto$3 = Object.prototype;
        var hasOwnProperty$2 = objectProto$3.hasOwnProperty;
        var propertyIsEnumerable = objectProto$3.propertyIsEnumerable;
        var isArguments = baseIsArguments(/* @__PURE__ */ (function() {
          return arguments;
        })()) ? baseIsArguments : function(value) {
          return isObjectLike(value) && hasOwnProperty$2.call(value, "callee") && !propertyIsEnumerable.call(value, "callee");
        };
        var isArray = Array.isArray;
        function stubFalse() {
          return false;
        }
        var freeExports = typeof exports2 == "object" && exports2 && !exports2.nodeType && exports2;
        var freeModule = freeExports && typeof module == "object" && module && !module.nodeType && module;
        var moduleExports = freeModule && freeModule.exports === freeExports;
        var Buffer2 = moduleExports ? root.Buffer : void 0;
        var nativeIsBuffer = Buffer2 ? Buffer2.isBuffer : void 0;
        var isBuffer = nativeIsBuffer || stubFalse;
        var MAX_SAFE_INTEGER$1 = 9007199254740991;
        var reIsUint = /^(?:0|[1-9]\d*)$/;
        function isIndex(value, length) {
          var type = typeof value;
          length = length == null ? MAX_SAFE_INTEGER$1 : length;
          return !!length && (type == "number" || type != "symbol" && reIsUint.test(value)) && (value > -1 && value % 1 == 0 && value < length);
        }
        var argsTag$1 = "[object Arguments]";
        var arrayTag = "[object Array]";
        var boolTag = "[object Boolean]";
        var dateTag = "[object Date]";
        var errorTag = "[object Error]";
        var funcTag$1 = "[object Function]";
        var mapTag = "[object Map]";
        var numberTag = "[object Number]";
        var objectTag = "[object Object]";
        var regexpTag = "[object RegExp]";
        var setTag = "[object Set]";
        var stringTag = "[object String]";
        var weakMapTag = "[object WeakMap]";
        var arrayBufferTag = "[object ArrayBuffer]";
        var dataViewTag = "[object DataView]";
        var float32Tag = "[object Float32Array]";
        var float64Tag = "[object Float64Array]";
        var int8Tag = "[object Int8Array]";
        var int16Tag = "[object Int16Array]";
        var int32Tag = "[object Int32Array]";
        var uint8Tag = "[object Uint8Array]";
        var uint8ClampedTag = "[object Uint8ClampedArray]";
        var uint16Tag = "[object Uint16Array]";
        var uint32Tag = "[object Uint32Array]";
        var typedArrayTags = {};
        typedArrayTags[float32Tag] = typedArrayTags[float64Tag] = typedArrayTags[int8Tag] = typedArrayTags[int16Tag] = typedArrayTags[int32Tag] = typedArrayTags[uint8Tag] = typedArrayTags[uint8ClampedTag] = typedArrayTags[uint16Tag] = typedArrayTags[uint32Tag] = true;
        typedArrayTags[argsTag$1] = typedArrayTags[arrayTag] = typedArrayTags[arrayBufferTag] = typedArrayTags[boolTag] = typedArrayTags[dataViewTag] = typedArrayTags[dateTag] = typedArrayTags[errorTag] = typedArrayTags[funcTag$1] = typedArrayTags[mapTag] = typedArrayTags[numberTag] = typedArrayTags[objectTag] = typedArrayTags[regexpTag] = typedArrayTags[setTag] = typedArrayTags[stringTag] = typedArrayTags[weakMapTag] = false;
        function baseIsTypedArray(value) {
          return isObjectLike(value) && isLength(value.length) && !!typedArrayTags[baseGetTag(value)];
        }
        function baseUnary(func) {
          return function(value) {
            return func(value);
          };
        }
        var freeExports$1 = typeof exports2 == "object" && exports2 && !exports2.nodeType && exports2;
        var freeModule$1 = freeExports$1 && typeof module == "object" && module && !module.nodeType && module;
        var moduleExports$1 = freeModule$1 && freeModule$1.exports === freeExports$1;
        var freeProcess = moduleExports$1 && freeGlobal.process;
        var nodeUtil = (function() {
          try {
            var types = freeModule$1 && freeModule$1.require && freeModule$1.require("util").types;
            if (types) {
              return types;
            }
            return freeProcess && freeProcess.binding && freeProcess.binding("util");
          } catch (e) {
          }
        })();
        var nodeIsTypedArray = nodeUtil && nodeUtil.isTypedArray;
        var isTypedArray = nodeIsTypedArray ? baseUnary(nodeIsTypedArray) : baseIsTypedArray;
        var objectProto$2 = Object.prototype;
        var hasOwnProperty$1 = objectProto$2.hasOwnProperty;
        function arrayLikeKeys(value, inherited) {
          var isArr = isArray(value), isArg = !isArr && isArguments(value), isBuff = !isArr && !isArg && isBuffer(value), isType = !isArr && !isArg && !isBuff && isTypedArray(value), skipIndexes = isArr || isArg || isBuff || isType, result = skipIndexes ? baseTimes(value.length, String) : [], length = result.length;
          for (var key in value) {
            if ((inherited || hasOwnProperty$1.call(value, key)) && !(skipIndexes && // Safari 9 has enumerable `arguments.length` in strict mode.
            (key == "length" || // Node.js 0.10 has enumerable non-index properties on buffers.
            isBuff && (key == "offset" || key == "parent") || // PhantomJS 2 has enumerable non-index properties on typed arrays.
            isType && (key == "buffer" || key == "byteLength" || key == "byteOffset") || // Skip index properties.
            isIndex(key, length)))) {
              result.push(key);
            }
          }
          return result;
        }
        var objectProto$5 = Object.prototype;
        function isPrototype(value) {
          var Ctor = value && value.constructor, proto = typeof Ctor == "function" && Ctor.prototype || objectProto$5;
          return value === proto;
        }
        function overArg(func, transform2) {
          return function(arg) {
            return func(transform2(arg));
          };
        }
        var nativeKeys = overArg(Object.keys, Object);
        var objectProto$4 = Object.prototype;
        var hasOwnProperty$3 = objectProto$4.hasOwnProperty;
        function baseKeys(object) {
          if (!isPrototype(object)) {
            return nativeKeys(object);
          }
          var result = [];
          for (var key in Object(object)) {
            if (hasOwnProperty$3.call(object, key) && key != "constructor") {
              result.push(key);
            }
          }
          return result;
        }
        function keys(object) {
          return isArrayLike(object) ? arrayLikeKeys(object) : baseKeys(object);
        }
        function createArrayIterator(coll) {
          var i = -1;
          var len = coll.length;
          return function next() {
            return ++i < len ? { value: coll[i], key: i } : null;
          };
        }
        function createES2015Iterator(iterator2) {
          var i = -1;
          return function next() {
            var item = iterator2.next();
            if (item.done)
              return null;
            i++;
            return { value: item.value, key: i };
          };
        }
        function createObjectIterator(obj) {
          var okeys = keys(obj);
          var i = -1;
          var len = okeys.length;
          return function next() {
            var key = okeys[++i];
            if (key === "__proto__") {
              return next();
            }
            return i < len ? { value: obj[key], key } : null;
          };
        }
        function iterator(coll) {
          if (isArrayLike(coll)) {
            return createArrayIterator(coll);
          }
          var iterator2 = getIterator(coll);
          return iterator2 ? createES2015Iterator(iterator2) : createObjectIterator(coll);
        }
        function onlyOnce(fn) {
          return function() {
            if (fn === null) throw new Error("Callback was already called.");
            var callFn = fn;
            fn = null;
            callFn.apply(this, arguments);
          };
        }
        function _eachOfLimit(limit) {
          return function(obj, iteratee, callback) {
            callback = once(callback || noop);
            if (limit <= 0 || !obj) {
              return callback(null);
            }
            var nextElem = iterator(obj);
            var done = false;
            var running = 0;
            var looping = false;
            function iterateeCallback(err, value) {
              running -= 1;
              if (err) {
                done = true;
                callback(err);
              } else if (value === breakLoop || done && running <= 0) {
                done = true;
                return callback(null);
              } else if (!looping) {
                replenish();
              }
            }
            function replenish() {
              looping = true;
              while (running < limit && !done) {
                var elem = nextElem();
                if (elem === null) {
                  done = true;
                  if (running <= 0) {
                    callback(null);
                  }
                  return;
                }
                running += 1;
                iteratee(elem.value, elem.key, onlyOnce(iterateeCallback));
              }
              looping = false;
            }
            replenish();
          };
        }
        function eachOfLimit(coll, limit, iteratee, callback) {
          _eachOfLimit(limit)(coll, wrapAsync(iteratee), callback);
        }
        function doLimit(fn, limit) {
          return function(iterable, iteratee, callback) {
            return fn(iterable, limit, iteratee, callback);
          };
        }
        function eachOfArrayLike(coll, iteratee, callback) {
          callback = once(callback || noop);
          var index2 = 0, completed = 0, length = coll.length;
          if (length === 0) {
            callback(null);
          }
          function iteratorCallback(err, value) {
            if (err) {
              callback(err);
            } else if (++completed === length || value === breakLoop) {
              callback(null);
            }
          }
          for (; index2 < length; index2++) {
            iteratee(coll[index2], index2, onlyOnce(iteratorCallback));
          }
        }
        var eachOfGeneric = doLimit(eachOfLimit, Infinity);
        var eachOf = function(coll, iteratee, callback) {
          var eachOfImplementation = isArrayLike(coll) ? eachOfArrayLike : eachOfGeneric;
          eachOfImplementation(coll, wrapAsync(iteratee), callback);
        };
        function doParallel(fn) {
          return function(obj, iteratee, callback) {
            return fn(eachOf, obj, wrapAsync(iteratee), callback);
          };
        }
        function _asyncMap(eachfn, arr, iteratee, callback) {
          callback = callback || noop;
          arr = arr || [];
          var results = [];
          var counter = 0;
          var _iteratee = wrapAsync(iteratee);
          eachfn(arr, function(value, _, callback2) {
            var index2 = counter++;
            _iteratee(value, function(err, v) {
              results[index2] = v;
              callback2(err);
            });
          }, function(err) {
            callback(err, results);
          });
        }
        var map = doParallel(_asyncMap);
        var applyEach = applyEach$1(map);
        function doParallelLimit(fn) {
          return function(obj, limit, iteratee, callback) {
            return fn(_eachOfLimit(limit), obj, wrapAsync(iteratee), callback);
          };
        }
        var mapLimit = doParallelLimit(_asyncMap);
        var mapSeries = doLimit(mapLimit, 1);
        var applyEachSeries = applyEach$1(mapSeries);
        function arrayEach(array, iteratee) {
          var index2 = -1, length = array == null ? 0 : array.length;
          while (++index2 < length) {
            if (iteratee(array[index2], index2, array) === false) {
              break;
            }
          }
          return array;
        }
        function createBaseFor(fromRight) {
          return function(object, iteratee, keysFunc) {
            var index2 = -1, iterable = Object(object), props = keysFunc(object), length = props.length;
            while (length--) {
              var key = props[fromRight ? length : ++index2];
              if (iteratee(iterable[key], key, iterable) === false) {
                break;
              }
            }
            return object;
          };
        }
        var baseFor = createBaseFor();
        function baseForOwn(object, iteratee) {
          return object && baseFor(object, iteratee, keys);
        }
        function baseFindIndex(array, predicate, fromIndex, fromRight) {
          var length = array.length, index2 = fromIndex + (fromRight ? 1 : -1);
          while (fromRight ? index2-- : ++index2 < length) {
            if (predicate(array[index2], index2, array)) {
              return index2;
            }
          }
          return -1;
        }
        function baseIsNaN(value) {
          return value !== value;
        }
        function strictIndexOf(array, value, fromIndex) {
          var index2 = fromIndex - 1, length = array.length;
          while (++index2 < length) {
            if (array[index2] === value) {
              return index2;
            }
          }
          return -1;
        }
        function baseIndexOf(array, value, fromIndex) {
          return value === value ? strictIndexOf(array, value, fromIndex) : baseFindIndex(array, baseIsNaN, fromIndex);
        }
        var auto = function(tasks, concurrency, callback) {
          if (typeof concurrency === "function") {
            callback = concurrency;
            concurrency = null;
          }
          callback = once(callback || noop);
          var keys$$1 = keys(tasks);
          var numTasks = keys$$1.length;
          if (!numTasks) {
            return callback(null);
          }
          if (!concurrency) {
            concurrency = numTasks;
          }
          var results = {};
          var runningTasks = 0;
          var hasError = false;
          var listeners = /* @__PURE__ */ Object.create(null);
          var readyTasks = [];
          var readyToCheck = [];
          var uncheckedDependencies = {};
          baseForOwn(tasks, function(task, key) {
            if (!isArray(task)) {
              enqueueTask(key, [task]);
              readyToCheck.push(key);
              return;
            }
            var dependencies = task.slice(0, task.length - 1);
            var remainingDependencies = dependencies.length;
            if (remainingDependencies === 0) {
              enqueueTask(key, task);
              readyToCheck.push(key);
              return;
            }
            uncheckedDependencies[key] = remainingDependencies;
            arrayEach(dependencies, function(dependencyName) {
              if (!tasks[dependencyName]) {
                throw new Error("async.auto task `" + key + "` has a non-existent dependency `" + dependencyName + "` in " + dependencies.join(", "));
              }
              addListener(dependencyName, function() {
                remainingDependencies--;
                if (remainingDependencies === 0) {
                  enqueueTask(key, task);
                }
              });
            });
          });
          checkForDeadlocks();
          processQueue();
          function enqueueTask(key, task) {
            readyTasks.push(function() {
              runTask(key, task);
            });
          }
          function processQueue() {
            if (readyTasks.length === 0 && runningTasks === 0) {
              return callback(null, results);
            }
            while (readyTasks.length && runningTasks < concurrency) {
              var run = readyTasks.shift();
              run();
            }
          }
          function addListener(taskName, fn) {
            var taskListeners = listeners[taskName];
            if (!taskListeners) {
              taskListeners = listeners[taskName] = [];
            }
            taskListeners.push(fn);
          }
          function taskComplete(taskName) {
            var taskListeners = listeners[taskName] || [];
            arrayEach(taskListeners, function(fn) {
              fn();
            });
            processQueue();
          }
          function runTask(key, task) {
            if (hasError) return;
            var taskCallback = onlyOnce(function(err, result) {
              runningTasks--;
              if (arguments.length > 2) {
                result = slice(arguments, 1);
              }
              if (err) {
                var safeResults = {};
                baseForOwn(results, function(val, rkey) {
                  safeResults[rkey] = val;
                });
                safeResults[key] = result;
                hasError = true;
                listeners = /* @__PURE__ */ Object.create(null);
                callback(err, safeResults);
              } else {
                results[key] = result;
                taskComplete(key);
              }
            });
            runningTasks++;
            var taskFn = wrapAsync(task[task.length - 1]);
            if (task.length > 1) {
              taskFn(results, taskCallback);
            } else {
              taskFn(taskCallback);
            }
          }
          function checkForDeadlocks() {
            var currentTask;
            var counter = 0;
            while (readyToCheck.length) {
              currentTask = readyToCheck.pop();
              counter++;
              arrayEach(getDependents(currentTask), function(dependent) {
                if (--uncheckedDependencies[dependent] === 0) {
                  readyToCheck.push(dependent);
                }
              });
            }
            if (counter !== numTasks) {
              throw new Error(
                "async.auto cannot execute tasks due to a recursive dependency"
              );
            }
          }
          function getDependents(taskName) {
            var result = [];
            baseForOwn(tasks, function(task, key) {
              if (isArray(task) && baseIndexOf(task, taskName, 0) >= 0) {
                result.push(key);
              }
            });
            return result;
          }
        };
        function arrayMap(array, iteratee) {
          var index2 = -1, length = array == null ? 0 : array.length, result = Array(length);
          while (++index2 < length) {
            result[index2] = iteratee(array[index2], index2, array);
          }
          return result;
        }
        var symbolTag = "[object Symbol]";
        function isSymbol(value) {
          return typeof value == "symbol" || isObjectLike(value) && baseGetTag(value) == symbolTag;
        }
        var INFINITY = 1 / 0;
        var symbolProto = Symbol$1 ? Symbol$1.prototype : void 0;
        var symbolToString = symbolProto ? symbolProto.toString : void 0;
        function baseToString(value) {
          if (typeof value == "string") {
            return value;
          }
          if (isArray(value)) {
            return arrayMap(value, baseToString) + "";
          }
          if (isSymbol(value)) {
            return symbolToString ? symbolToString.call(value) : "";
          }
          var result = value + "";
          return result == "0" && 1 / value == -INFINITY ? "-0" : result;
        }
        function baseSlice(array, start, end) {
          var index2 = -1, length = array.length;
          if (start < 0) {
            start = -start > length ? 0 : length + start;
          }
          end = end > length ? length : end;
          if (end < 0) {
            end += length;
          }
          length = start > end ? 0 : end - start >>> 0;
          start >>>= 0;
          var result = Array(length);
          while (++index2 < length) {
            result[index2] = array[index2 + start];
          }
          return result;
        }
        function castSlice(array, start, end) {
          var length = array.length;
          end = end === void 0 ? length : end;
          return !start && end >= length ? array : baseSlice(array, start, end);
        }
        function charsEndIndex(strSymbols, chrSymbols) {
          var index2 = strSymbols.length;
          while (index2-- && baseIndexOf(chrSymbols, strSymbols[index2], 0) > -1) {
          }
          return index2;
        }
        function charsStartIndex(strSymbols, chrSymbols) {
          var index2 = -1, length = strSymbols.length;
          while (++index2 < length && baseIndexOf(chrSymbols, strSymbols[index2], 0) > -1) {
          }
          return index2;
        }
        function asciiToArray(string) {
          return string.split("");
        }
        var rsAstralRange = "\\ud800-\\udfff";
        var rsComboMarksRange = "\\u0300-\\u036f";
        var reComboHalfMarksRange = "\\ufe20-\\ufe2f";
        var rsComboSymbolsRange = "\\u20d0-\\u20ff";
        var rsComboRange = rsComboMarksRange + reComboHalfMarksRange + rsComboSymbolsRange;
        var rsVarRange = "\\ufe0e\\ufe0f";
        var rsZWJ = "\\u200d";
        var reHasUnicode = RegExp("[" + rsZWJ + rsAstralRange + rsComboRange + rsVarRange + "]");
        function hasUnicode(string) {
          return reHasUnicode.test(string);
        }
        var rsAstralRange$1 = "\\ud800-\\udfff";
        var rsComboMarksRange$1 = "\\u0300-\\u036f";
        var reComboHalfMarksRange$1 = "\\ufe20-\\ufe2f";
        var rsComboSymbolsRange$1 = "\\u20d0-\\u20ff";
        var rsComboRange$1 = rsComboMarksRange$1 + reComboHalfMarksRange$1 + rsComboSymbolsRange$1;
        var rsVarRange$1 = "\\ufe0e\\ufe0f";
        var rsAstral = "[" + rsAstralRange$1 + "]";
        var rsCombo = "[" + rsComboRange$1 + "]";
        var rsFitz = "\\ud83c[\\udffb-\\udfff]";
        var rsModifier = "(?:" + rsCombo + "|" + rsFitz + ")";
        var rsNonAstral = "[^" + rsAstralRange$1 + "]";
        var rsRegional = "(?:\\ud83c[\\udde6-\\uddff]){2}";
        var rsSurrPair = "[\\ud800-\\udbff][\\udc00-\\udfff]";
        var rsZWJ$1 = "\\u200d";
        var reOptMod = rsModifier + "?";
        var rsOptVar = "[" + rsVarRange$1 + "]?";
        var rsOptJoin = "(?:" + rsZWJ$1 + "(?:" + [rsNonAstral, rsRegional, rsSurrPair].join("|") + ")" + rsOptVar + reOptMod + ")*";
        var rsSeq = rsOptVar + reOptMod + rsOptJoin;
        var rsSymbol = "(?:" + [rsNonAstral + rsCombo + "?", rsCombo, rsRegional, rsSurrPair, rsAstral].join("|") + ")";
        var reUnicode = RegExp(rsFitz + "(?=" + rsFitz + ")|" + rsSymbol + rsSeq, "g");
        function unicodeToArray(string) {
          return string.match(reUnicode) || [];
        }
        function stringToArray(string) {
          return hasUnicode(string) ? unicodeToArray(string) : asciiToArray(string);
        }
        function toString(value) {
          return value == null ? "" : baseToString(value);
        }
        var reTrim = /^\s+|\s+$/g;
        function trim(string, chars, guard) {
          string = toString(string);
          if (string && (guard || chars === void 0)) {
            return string.replace(reTrim, "");
          }
          if (!string || !(chars = baseToString(chars))) {
            return string;
          }
          var strSymbols = stringToArray(string), chrSymbols = stringToArray(chars), start = charsStartIndex(strSymbols, chrSymbols), end = charsEndIndex(strSymbols, chrSymbols) + 1;
          return castSlice(strSymbols, start, end).join("");
        }
        var FN_ARGS = /^(?:async\s+)?(function)?\s*[^\(]*\(\s*([^\)]*)\)/m;
        var FN_ARG_SPLIT = /,/;
        var FN_ARG = /(=.+)?(\s*)$/;
        var STRIP_COMMENTS = /((\/\/.*$)|(\/\*[\s\S]*?\*\/))/mg;
        function parseParams(func) {
          func = func.toString().replace(STRIP_COMMENTS, "");
          func = func.match(FN_ARGS)[2].replace(" ", "");
          func = func ? func.split(FN_ARG_SPLIT) : [];
          func = func.map(function(arg) {
            return trim(arg.replace(FN_ARG, ""));
          });
          return func;
        }
        function autoInject(tasks, callback) {
          var newTasks = {};
          baseForOwn(tasks, function(taskFn, key) {
            var params;
            var fnIsAsync = isAsync(taskFn);
            var hasNoDeps = !fnIsAsync && taskFn.length === 1 || fnIsAsync && taskFn.length === 0;
            if (isArray(taskFn)) {
              params = taskFn.slice(0, -1);
              taskFn = taskFn[taskFn.length - 1];
              newTasks[key] = params.concat(params.length > 0 ? newTask : taskFn);
            } else if (hasNoDeps) {
              newTasks[key] = taskFn;
            } else {
              params = parseParams(taskFn);
              if (taskFn.length === 0 && !fnIsAsync && params.length === 0) {
                throw new Error("autoInject task functions require explicit parameters.");
              }
              if (!fnIsAsync) params.pop();
              newTasks[key] = params.concat(newTask);
            }
            function newTask(results, taskCb) {
              var newArgs = arrayMap(params, function(name) {
                return results[name];
              });
              newArgs.push(taskCb);
              wrapAsync(taskFn).apply(null, newArgs);
            }
          });
          auto(newTasks, callback);
        }
        function DLL() {
          this.head = this.tail = null;
          this.length = 0;
        }
        function setInitial(dll, node) {
          dll.length = 1;
          dll.head = dll.tail = node;
        }
        DLL.prototype.removeLink = function(node) {
          if (node.prev) node.prev.next = node.next;
          else this.head = node.next;
          if (node.next) node.next.prev = node.prev;
          else this.tail = node.prev;
          node.prev = node.next = null;
          this.length -= 1;
          return node;
        };
        DLL.prototype.empty = function() {
          while (this.head) this.shift();
          return this;
        };
        DLL.prototype.insertAfter = function(node, newNode) {
          newNode.prev = node;
          newNode.next = node.next;
          if (node.next) node.next.prev = newNode;
          else this.tail = newNode;
          node.next = newNode;
          this.length += 1;
        };
        DLL.prototype.insertBefore = function(node, newNode) {
          newNode.prev = node.prev;
          newNode.next = node;
          if (node.prev) node.prev.next = newNode;
          else this.head = newNode;
          node.prev = newNode;
          this.length += 1;
        };
        DLL.prototype.unshift = function(node) {
          if (this.head) this.insertBefore(this.head, node);
          else setInitial(this, node);
        };
        DLL.prototype.push = function(node) {
          if (this.tail) this.insertAfter(this.tail, node);
          else setInitial(this, node);
        };
        DLL.prototype.shift = function() {
          return this.head && this.removeLink(this.head);
        };
        DLL.prototype.pop = function() {
          return this.tail && this.removeLink(this.tail);
        };
        DLL.prototype.toArray = function() {
          var arr = Array(this.length);
          var curr = this.head;
          for (var idx = 0; idx < this.length; idx++) {
            arr[idx] = curr.data;
            curr = curr.next;
          }
          return arr;
        };
        DLL.prototype.remove = function(testFn) {
          var curr = this.head;
          while (!!curr) {
            var next = curr.next;
            if (testFn(curr)) {
              this.removeLink(curr);
            }
            curr = next;
          }
          return this;
        };
        function queue(worker, concurrency, payload) {
          if (concurrency == null) {
            concurrency = 1;
          } else if (concurrency === 0) {
            throw new Error("Concurrency must not be zero");
          }
          var _worker = wrapAsync(worker);
          var numRunning = 0;
          var workersList = [];
          var processingScheduled = false;
          function _insert(data, insertAtFront, callback) {
            if (callback != null && typeof callback !== "function") {
              throw new Error("task callback must be a function");
            }
            q.started = true;
            if (!isArray(data)) {
              data = [data];
            }
            if (data.length === 0 && q.idle()) {
              return setImmediate$1(function() {
                q.drain();
              });
            }
            for (var i = 0, l = data.length; i < l; i++) {
              var item = {
                data: data[i],
                callback: callback || noop
              };
              if (insertAtFront) {
                q._tasks.unshift(item);
              } else {
                q._tasks.push(item);
              }
            }
            if (!processingScheduled) {
              processingScheduled = true;
              setImmediate$1(function() {
                processingScheduled = false;
                q.process();
              });
            }
          }
          function _next(tasks) {
            return function(err) {
              numRunning -= 1;
              for (var i = 0, l = tasks.length; i < l; i++) {
                var task = tasks[i];
                var index2 = baseIndexOf(workersList, task, 0);
                if (index2 === 0) {
                  workersList.shift();
                } else if (index2 > 0) {
                  workersList.splice(index2, 1);
                }
                task.callback.apply(task, arguments);
                if (err != null) {
                  q.error(err, task.data);
                }
              }
              if (numRunning <= q.concurrency - q.buffer) {
                q.unsaturated();
              }
              if (q.idle()) {
                q.drain();
              }
              q.process();
            };
          }
          var isProcessing = false;
          var q = {
            _tasks: new DLL(),
            concurrency,
            payload,
            saturated: noop,
            unsaturated: noop,
            buffer: concurrency / 4,
            empty: noop,
            drain: noop,
            error: noop,
            started: false,
            paused: false,
            push: function(data, callback) {
              _insert(data, false, callback);
            },
            kill: function() {
              q.drain = noop;
              q._tasks.empty();
            },
            unshift: function(data, callback) {
              _insert(data, true, callback);
            },
            remove: function(testFn) {
              q._tasks.remove(testFn);
            },
            process: function() {
              if (isProcessing) {
                return;
              }
              isProcessing = true;
              while (!q.paused && numRunning < q.concurrency && q._tasks.length) {
                var tasks = [], data = [];
                var l = q._tasks.length;
                if (q.payload) l = Math.min(l, q.payload);
                for (var i = 0; i < l; i++) {
                  var node = q._tasks.shift();
                  tasks.push(node);
                  workersList.push(node);
                  data.push(node.data);
                }
                numRunning += 1;
                if (q._tasks.length === 0) {
                  q.empty();
                }
                if (numRunning === q.concurrency) {
                  q.saturated();
                }
                var cb = onlyOnce(_next(tasks));
                _worker(data, cb);
              }
              isProcessing = false;
            },
            length: function() {
              return q._tasks.length;
            },
            running: function() {
              return numRunning;
            },
            workersList: function() {
              return workersList;
            },
            idle: function() {
              return q._tasks.length + numRunning === 0;
            },
            pause: function() {
              q.paused = true;
            },
            resume: function() {
              if (q.paused === false) {
                return;
              }
              q.paused = false;
              setImmediate$1(q.process);
            }
          };
          return q;
        }
        function cargo(worker, payload) {
          return queue(worker, 1, payload);
        }
        var eachOfSeries = doLimit(eachOfLimit, 1);
        function reduce(coll, memo, iteratee, callback) {
          callback = once(callback || noop);
          var _iteratee = wrapAsync(iteratee);
          eachOfSeries(coll, function(x, i, callback2) {
            _iteratee(memo, x, function(err, v) {
              memo = v;
              callback2(err);
            });
          }, function(err) {
            callback(err, memo);
          });
        }
        function seq() {
          var _functions = arrayMap(arguments, wrapAsync);
          return function() {
            var args = slice(arguments);
            var that = this;
            var cb = args[args.length - 1];
            if (typeof cb == "function") {
              args.pop();
            } else {
              cb = noop;
            }
            reduce(
              _functions,
              args,
              function(newargs, fn, cb2) {
                fn.apply(that, newargs.concat(function(err) {
                  var nextargs = slice(arguments, 1);
                  cb2(err, nextargs);
                }));
              },
              function(err, results) {
                cb.apply(that, [err].concat(results));
              }
            );
          };
        }
        var compose = function() {
          return seq.apply(null, slice(arguments).reverse());
        };
        var _concat = Array.prototype.concat;
        var concatLimit = function(coll, limit, iteratee, callback) {
          callback = callback || noop;
          var _iteratee = wrapAsync(iteratee);
          mapLimit(coll, limit, function(val, callback2) {
            _iteratee(val, function(err) {
              if (err) return callback2(err);
              return callback2(null, slice(arguments, 1));
            });
          }, function(err, mapResults) {
            var result = [];
            for (var i = 0; i < mapResults.length; i++) {
              if (mapResults[i]) {
                result = _concat.apply(result, mapResults[i]);
              }
            }
            return callback(err, result);
          });
        };
        var concat = doLimit(concatLimit, Infinity);
        var concatSeries = doLimit(concatLimit, 1);
        var constant = function() {
          var values = slice(arguments);
          var args = [null].concat(values);
          return function() {
            var callback = arguments[arguments.length - 1];
            return callback.apply(this, args);
          };
        };
        function identity(value) {
          return value;
        }
        function _createTester(check, getResult) {
          return function(eachfn, arr, iteratee, cb) {
            cb = cb || noop;
            var testPassed = false;
            var testResult;
            eachfn(arr, function(value, _, callback) {
              iteratee(value, function(err, result) {
                if (err) {
                  callback(err);
                } else if (check(result) && !testResult) {
                  testPassed = true;
                  testResult = getResult(true, value);
                  callback(null, breakLoop);
                } else {
                  callback();
                }
              });
            }, function(err) {
              if (err) {
                cb(err);
              } else {
                cb(null, testPassed ? testResult : getResult(false));
              }
            });
          };
        }
        function _findGetResult(v, x) {
          return x;
        }
        var detect = doParallel(_createTester(identity, _findGetResult));
        var detectLimit = doParallelLimit(_createTester(identity, _findGetResult));
        var detectSeries = doLimit(detectLimit, 1);
        function consoleFunc(name) {
          return function(fn) {
            var args = slice(arguments, 1);
            args.push(function(err) {
              var args2 = slice(arguments, 1);
              if (typeof console === "object") {
                if (err) {
                  if (console.error) {
                    console.error(err);
                  }
                } else if (console[name]) {
                  arrayEach(args2, function(x) {
                    console[name](x);
                  });
                }
              }
            });
            wrapAsync(fn).apply(null, args);
          };
        }
        var dir = consoleFunc("dir");
        function doDuring(fn, test, callback) {
          callback = onlyOnce(callback || noop);
          var _fn = wrapAsync(fn);
          var _test = wrapAsync(test);
          function next(err) {
            if (err) return callback(err);
            var args = slice(arguments, 1);
            args.push(check);
            _test.apply(this, args);
          }
          function check(err, truth) {
            if (err) return callback(err);
            if (!truth) return callback(null);
            _fn(next);
          }
          check(null, true);
        }
        function doWhilst(iteratee, test, callback) {
          callback = onlyOnce(callback || noop);
          var _iteratee = wrapAsync(iteratee);
          var next = function(err) {
            if (err) return callback(err);
            var args = slice(arguments, 1);
            if (test.apply(this, args)) return _iteratee(next);
            callback.apply(null, [null].concat(args));
          };
          _iteratee(next);
        }
        function doUntil(iteratee, test, callback) {
          doWhilst(iteratee, function() {
            return !test.apply(this, arguments);
          }, callback);
        }
        function during(test, fn, callback) {
          callback = onlyOnce(callback || noop);
          var _fn = wrapAsync(fn);
          var _test = wrapAsync(test);
          function next(err) {
            if (err) return callback(err);
            _test(check);
          }
          function check(err, truth) {
            if (err) return callback(err);
            if (!truth) return callback(null);
            _fn(next);
          }
          _test(check);
        }
        function _withoutIndex(iteratee) {
          return function(value, index2, callback) {
            return iteratee(value, callback);
          };
        }
        function eachLimit(coll, iteratee, callback) {
          eachOf(coll, _withoutIndex(wrapAsync(iteratee)), callback);
        }
        function eachLimit$1(coll, limit, iteratee, callback) {
          _eachOfLimit(limit)(coll, _withoutIndex(wrapAsync(iteratee)), callback);
        }
        var eachSeries = doLimit(eachLimit$1, 1);
        function ensureAsync(fn) {
          if (isAsync(fn)) return fn;
          return initialParams(function(args, callback) {
            var sync = true;
            args.push(function() {
              var innerArgs = arguments;
              if (sync) {
                setImmediate$1(function() {
                  callback.apply(null, innerArgs);
                });
              } else {
                callback.apply(null, innerArgs);
              }
            });
            fn.apply(this, args);
            sync = false;
          });
        }
        function notId(v) {
          return !v;
        }
        var every = doParallel(_createTester(notId, notId));
        var everyLimit = doParallelLimit(_createTester(notId, notId));
        var everySeries = doLimit(everyLimit, 1);
        function baseProperty(key) {
          return function(object) {
            return object == null ? void 0 : object[key];
          };
        }
        function filterArray(eachfn, arr, iteratee, callback) {
          var truthValues = new Array(arr.length);
          eachfn(arr, function(x, index2, callback2) {
            iteratee(x, function(err, v) {
              truthValues[index2] = !!v;
              callback2(err);
            });
          }, function(err) {
            if (err) return callback(err);
            var results = [];
            for (var i = 0; i < arr.length; i++) {
              if (truthValues[i]) results.push(arr[i]);
            }
            callback(null, results);
          });
        }
        function filterGeneric(eachfn, coll, iteratee, callback) {
          var results = [];
          eachfn(coll, function(x, index2, callback2) {
            iteratee(x, function(err, v) {
              if (err) {
                callback2(err);
              } else {
                if (v) {
                  results.push({ index: index2, value: x });
                }
                callback2();
              }
            });
          }, function(err) {
            if (err) {
              callback(err);
            } else {
              callback(null, arrayMap(results.sort(function(a, b) {
                return a.index - b.index;
              }), baseProperty("value")));
            }
          });
        }
        function _filter(eachfn, coll, iteratee, callback) {
          var filter2 = isArrayLike(coll) ? filterArray : filterGeneric;
          filter2(eachfn, coll, wrapAsync(iteratee), callback || noop);
        }
        var filter = doParallel(_filter);
        var filterLimit = doParallelLimit(_filter);
        var filterSeries = doLimit(filterLimit, 1);
        function forever(fn, errback) {
          var done = onlyOnce(errback || noop);
          var task = wrapAsync(ensureAsync(fn));
          function next(err) {
            if (err) return done(err);
            task(next);
          }
          next();
        }
        var groupByLimit = function(coll, limit, iteratee, callback) {
          callback = callback || noop;
          var _iteratee = wrapAsync(iteratee);
          mapLimit(coll, limit, function(val, callback2) {
            _iteratee(val, function(err, key) {
              if (err) return callback2(err);
              return callback2(null, { key, val });
            });
          }, function(err, mapResults) {
            var result = {};
            var hasOwnProperty2 = Object.prototype.hasOwnProperty;
            for (var i = 0; i < mapResults.length; i++) {
              if (mapResults[i]) {
                var key = mapResults[i].key;
                var val = mapResults[i].val;
                if (hasOwnProperty2.call(result, key)) {
                  result[key].push(val);
                } else {
                  result[key] = [val];
                }
              }
            }
            return callback(err, result);
          });
        };
        var groupBy = doLimit(groupByLimit, Infinity);
        var groupBySeries = doLimit(groupByLimit, 1);
        var log = consoleFunc("log");
        function mapValuesLimit(obj, limit, iteratee, callback) {
          callback = once(callback || noop);
          var newObj = {};
          var _iteratee = wrapAsync(iteratee);
          eachOfLimit(obj, limit, function(val, key, next) {
            _iteratee(val, key, function(err, result) {
              if (err) return next(err);
              newObj[key] = result;
              next();
            });
          }, function(err) {
            callback(err, newObj);
          });
        }
        var mapValues = doLimit(mapValuesLimit, Infinity);
        var mapValuesSeries = doLimit(mapValuesLimit, 1);
        function has(obj, key) {
          return key in obj;
        }
        function memoize(fn, hasher) {
          var memo = /* @__PURE__ */ Object.create(null);
          var queues = /* @__PURE__ */ Object.create(null);
          hasher = hasher || identity;
          var _fn = wrapAsync(fn);
          var memoized = initialParams(function memoized2(args, callback) {
            var key = hasher.apply(null, args);
            if (has(memo, key)) {
              setImmediate$1(function() {
                callback.apply(null, memo[key]);
              });
            } else if (has(queues, key)) {
              queues[key].push(callback);
            } else {
              queues[key] = [callback];
              _fn.apply(null, args.concat(function() {
                var args2 = slice(arguments);
                memo[key] = args2;
                var q = queues[key];
                delete queues[key];
                for (var i = 0, l = q.length; i < l; i++) {
                  q[i].apply(null, args2);
                }
              }));
            }
          });
          memoized.memo = memo;
          memoized.unmemoized = fn;
          return memoized;
        }
        var _defer$1;
        if (hasNextTick) {
          _defer$1 = process.nextTick;
        } else if (hasSetImmediate) {
          _defer$1 = setImmediate;
        } else {
          _defer$1 = fallback;
        }
        var nextTick = wrap(_defer$1);
        function _parallel(eachfn, tasks, callback) {
          callback = callback || noop;
          var results = isArrayLike(tasks) ? [] : {};
          eachfn(tasks, function(task, key, callback2) {
            wrapAsync(task)(function(err, result) {
              if (arguments.length > 2) {
                result = slice(arguments, 1);
              }
              results[key] = result;
              callback2(err);
            });
          }, function(err) {
            callback(err, results);
          });
        }
        function parallelLimit(tasks, callback) {
          _parallel(eachOf, tasks, callback);
        }
        function parallelLimit$1(tasks, limit, callback) {
          _parallel(_eachOfLimit(limit), tasks, callback);
        }
        var queue$1 = function(worker, concurrency) {
          var _worker = wrapAsync(worker);
          return queue(function(items, cb) {
            _worker(items[0], cb);
          }, concurrency, 1);
        };
        var priorityQueue = function(worker, concurrency) {
          var q = queue$1(worker, concurrency);
          q.push = function(data, priority, callback) {
            if (callback == null) callback = noop;
            if (typeof callback !== "function") {
              throw new Error("task callback must be a function");
            }
            q.started = true;
            if (!isArray(data)) {
              data = [data];
            }
            if (data.length === 0) {
              return setImmediate$1(function() {
                q.drain();
              });
            }
            priority = priority || 0;
            var nextNode = q._tasks.head;
            while (nextNode && priority >= nextNode.priority) {
              nextNode = nextNode.next;
            }
            for (var i = 0, l = data.length; i < l; i++) {
              var item = {
                data: data[i],
                priority,
                callback
              };
              if (nextNode) {
                q._tasks.insertBefore(nextNode, item);
              } else {
                q._tasks.push(item);
              }
            }
            setImmediate$1(q.process);
          };
          delete q.unshift;
          return q;
        };
        function race(tasks, callback) {
          callback = once(callback || noop);
          if (!isArray(tasks)) return callback(new TypeError("First argument to race must be an array of functions"));
          if (!tasks.length) return callback();
          for (var i = 0, l = tasks.length; i < l; i++) {
            wrapAsync(tasks[i])(callback);
          }
        }
        function reduceRight(array, memo, iteratee, callback) {
          var reversed = slice(array).reverse();
          reduce(reversed, memo, iteratee, callback);
        }
        function reflect(fn) {
          var _fn = wrapAsync(fn);
          return initialParams(function reflectOn(args, reflectCallback) {
            args.push(function callback(error, cbArg) {
              if (error) {
                reflectCallback(null, { error });
              } else {
                var value;
                if (arguments.length <= 2) {
                  value = cbArg;
                } else {
                  value = slice(arguments, 1);
                }
                reflectCallback(null, { value });
              }
            });
            return _fn.apply(this, args);
          });
        }
        function reflectAll(tasks) {
          var results;
          if (isArray(tasks)) {
            results = arrayMap(tasks, reflect);
          } else {
            results = {};
            baseForOwn(tasks, function(task, key) {
              results[key] = reflect.call(this, task);
            });
          }
          return results;
        }
        function reject$1(eachfn, arr, iteratee, callback) {
          _filter(eachfn, arr, function(value, cb) {
            iteratee(value, function(err, v) {
              cb(err, !v);
            });
          }, callback);
        }
        var reject = doParallel(reject$1);
        var rejectLimit = doParallelLimit(reject$1);
        var rejectSeries = doLimit(rejectLimit, 1);
        function constant$1(value) {
          return function() {
            return value;
          };
        }
        function retry(opts, task, callback) {
          var DEFAULT_TIMES = 5;
          var DEFAULT_INTERVAL = 0;
          var options = {
            times: DEFAULT_TIMES,
            intervalFunc: constant$1(DEFAULT_INTERVAL)
          };
          function parseTimes(acc, t) {
            if (typeof t === "object") {
              acc.times = +t.times || DEFAULT_TIMES;
              acc.intervalFunc = typeof t.interval === "function" ? t.interval : constant$1(+t.interval || DEFAULT_INTERVAL);
              acc.errorFilter = t.errorFilter;
            } else if (typeof t === "number" || typeof t === "string") {
              acc.times = +t || DEFAULT_TIMES;
            } else {
              throw new Error("Invalid arguments for async.retry");
            }
          }
          if (arguments.length < 3 && typeof opts === "function") {
            callback = task || noop;
            task = opts;
          } else {
            parseTimes(options, opts);
            callback = callback || noop;
          }
          if (typeof task !== "function") {
            throw new Error("Invalid arguments for async.retry");
          }
          var _task = wrapAsync(task);
          var attempt = 1;
          function retryAttempt() {
            _task(function(err) {
              if (err && attempt++ < options.times && (typeof options.errorFilter != "function" || options.errorFilter(err))) {
                setTimeout(retryAttempt, options.intervalFunc(attempt));
              } else {
                callback.apply(null, arguments);
              }
            });
          }
          retryAttempt();
        }
        var retryable = function(opts, task) {
          if (!task) {
            task = opts;
            opts = null;
          }
          var _task = wrapAsync(task);
          return initialParams(function(args, callback) {
            function taskFn(cb) {
              _task.apply(null, args.concat(cb));
            }
            if (opts) retry(opts, taskFn, callback);
            else retry(taskFn, callback);
          });
        };
        function series(tasks, callback) {
          _parallel(eachOfSeries, tasks, callback);
        }
        var some = doParallel(_createTester(Boolean, identity));
        var someLimit = doParallelLimit(_createTester(Boolean, identity));
        var someSeries = doLimit(someLimit, 1);
        function sortBy(coll, iteratee, callback) {
          var _iteratee = wrapAsync(iteratee);
          map(coll, function(x, callback2) {
            _iteratee(x, function(err, criteria) {
              if (err) return callback2(err);
              callback2(null, { value: x, criteria });
            });
          }, function(err, results) {
            if (err) return callback(err);
            callback(null, arrayMap(results.sort(comparator), baseProperty("value")));
          });
          function comparator(left, right) {
            var a = left.criteria, b = right.criteria;
            return a < b ? -1 : a > b ? 1 : 0;
          }
        }
        function timeout(asyncFn, milliseconds, info) {
          var fn = wrapAsync(asyncFn);
          return initialParams(function(args, callback) {
            var timedOut = false;
            var timer;
            function timeoutCallback() {
              var name = asyncFn.name || "anonymous";
              var error = new Error('Callback function "' + name + '" timed out.');
              error.code = "ETIMEDOUT";
              if (info) {
                error.info = info;
              }
              timedOut = true;
              callback(error);
            }
            args.push(function() {
              if (!timedOut) {
                callback.apply(null, arguments);
                clearTimeout(timer);
              }
            });
            timer = setTimeout(timeoutCallback, milliseconds);
            fn.apply(null, args);
          });
        }
        var nativeCeil = Math.ceil;
        var nativeMax = Math.max;
        function baseRange(start, end, step, fromRight) {
          var index2 = -1, length = nativeMax(nativeCeil((end - start) / (step || 1)), 0), result = Array(length);
          while (length--) {
            result[fromRight ? length : ++index2] = start;
            start += step;
          }
          return result;
        }
        function timeLimit(count, limit, iteratee, callback) {
          var _iteratee = wrapAsync(iteratee);
          mapLimit(baseRange(0, count, 1), limit, _iteratee, callback);
        }
        var times = doLimit(timeLimit, Infinity);
        var timesSeries = doLimit(timeLimit, 1);
        function transform(coll, accumulator, iteratee, callback) {
          if (arguments.length <= 3) {
            callback = iteratee;
            iteratee = accumulator;
            accumulator = isArray(coll) ? [] : {};
          }
          callback = once(callback || noop);
          var _iteratee = wrapAsync(iteratee);
          eachOf(coll, function(v, k, cb) {
            _iteratee(accumulator, v, k, cb);
          }, function(err) {
            callback(err, accumulator);
          });
        }
        function tryEach(tasks, callback) {
          var error = null;
          var result;
          callback = callback || noop;
          eachSeries(tasks, function(task, callback2) {
            wrapAsync(task)(function(err, res) {
              if (arguments.length > 2) {
                result = slice(arguments, 1);
              } else {
                result = res;
              }
              error = err;
              callback2(!err);
            });
          }, function() {
            callback(error, result);
          });
        }
        function unmemoize(fn) {
          return function() {
            return (fn.unmemoized || fn).apply(null, arguments);
          };
        }
        function whilst(test, iteratee, callback) {
          callback = onlyOnce(callback || noop);
          var _iteratee = wrapAsync(iteratee);
          if (!test()) return callback(null);
          var next = function(err) {
            if (err) return callback(err);
            if (test()) return _iteratee(next);
            var args = slice(arguments, 1);
            callback.apply(null, [null].concat(args));
          };
          _iteratee(next);
        }
        function until(test, iteratee, callback) {
          whilst(function() {
            return !test.apply(this, arguments);
          }, iteratee, callback);
        }
        var waterfall = function(tasks, callback) {
          callback = once(callback || noop);
          if (!isArray(tasks)) return callback(new Error("First argument to waterfall must be an array of functions"));
          if (!tasks.length) return callback();
          var taskIndex = 0;
          function nextTask(args) {
            var task = wrapAsync(tasks[taskIndex++]);
            args.push(onlyOnce(next));
            task.apply(null, args);
          }
          function next(err) {
            if (err || taskIndex === tasks.length) {
              return callback.apply(null, arguments);
            }
            nextTask(slice(arguments, 1));
          }
          nextTask([]);
        };
        var index = {
          apply,
          applyEach,
          applyEachSeries,
          asyncify,
          auto,
          autoInject,
          cargo,
          compose,
          concat,
          concatLimit,
          concatSeries,
          constant,
          detect,
          detectLimit,
          detectSeries,
          dir,
          doDuring,
          doUntil,
          doWhilst,
          during,
          each: eachLimit,
          eachLimit: eachLimit$1,
          eachOf,
          eachOfLimit,
          eachOfSeries,
          eachSeries,
          ensureAsync,
          every,
          everyLimit,
          everySeries,
          filter,
          filterLimit,
          filterSeries,
          forever,
          groupBy,
          groupByLimit,
          groupBySeries,
          log,
          map,
          mapLimit,
          mapSeries,
          mapValues,
          mapValuesLimit,
          mapValuesSeries,
          memoize,
          nextTick,
          parallel: parallelLimit,
          parallelLimit: parallelLimit$1,
          priorityQueue,
          queue: queue$1,
          race,
          reduce,
          reduceRight,
          reflect,
          reflectAll,
          reject,
          rejectLimit,
          rejectSeries,
          retry,
          retryable,
          seq,
          series,
          setImmediate: setImmediate$1,
          some,
          someLimit,
          someSeries,
          sortBy,
          timeout,
          times,
          timesLimit: timeLimit,
          timesSeries,
          transform,
          tryEach,
          unmemoize,
          until,
          waterfall,
          whilst,
          // aliases
          all: every,
          allLimit: everyLimit,
          allSeries: everySeries,
          any: some,
          anyLimit: someLimit,
          anySeries: someSeries,
          find: detect,
          findLimit: detectLimit,
          findSeries: detectSeries,
          forEach: eachLimit,
          forEachSeries: eachSeries,
          forEachLimit: eachLimit$1,
          forEachOf: eachOf,
          forEachOfSeries: eachOfSeries,
          forEachOfLimit: eachOfLimit,
          inject: reduce,
          foldl: reduce,
          foldr: reduceRight,
          select: filter,
          selectLimit: filterLimit,
          selectSeries: filterSeries,
          wrapSync: asyncify
        };
        exports2["default"] = index;
        exports2.apply = apply;
        exports2.applyEach = applyEach;
        exports2.applyEachSeries = applyEachSeries;
        exports2.asyncify = asyncify;
        exports2.auto = auto;
        exports2.autoInject = autoInject;
        exports2.cargo = cargo;
        exports2.compose = compose;
        exports2.concat = concat;
        exports2.concatLimit = concatLimit;
        exports2.concatSeries = concatSeries;
        exports2.constant = constant;
        exports2.detect = detect;
        exports2.detectLimit = detectLimit;
        exports2.detectSeries = detectSeries;
        exports2.dir = dir;
        exports2.doDuring = doDuring;
        exports2.doUntil = doUntil;
        exports2.doWhilst = doWhilst;
        exports2.during = during;
        exports2.each = eachLimit;
        exports2.eachLimit = eachLimit$1;
        exports2.eachOf = eachOf;
        exports2.eachOfLimit = eachOfLimit;
        exports2.eachOfSeries = eachOfSeries;
        exports2.eachSeries = eachSeries;
        exports2.ensureAsync = ensureAsync;
        exports2.every = every;
        exports2.everyLimit = everyLimit;
        exports2.everySeries = everySeries;
        exports2.filter = filter;
        exports2.filterLimit = filterLimit;
        exports2.filterSeries = filterSeries;
        exports2.forever = forever;
        exports2.groupBy = groupBy;
        exports2.groupByLimit = groupByLimit;
        exports2.groupBySeries = groupBySeries;
        exports2.log = log;
        exports2.map = map;
        exports2.mapLimit = mapLimit;
        exports2.mapSeries = mapSeries;
        exports2.mapValues = mapValues;
        exports2.mapValuesLimit = mapValuesLimit;
        exports2.mapValuesSeries = mapValuesSeries;
        exports2.memoize = memoize;
        exports2.nextTick = nextTick;
        exports2.parallel = parallelLimit;
        exports2.parallelLimit = parallelLimit$1;
        exports2.priorityQueue = priorityQueue;
        exports2.queue = queue$1;
        exports2.race = race;
        exports2.reduce = reduce;
        exports2.reduceRight = reduceRight;
        exports2.reflect = reflect;
        exports2.reflectAll = reflectAll;
        exports2.reject = reject;
        exports2.rejectLimit = rejectLimit;
        exports2.rejectSeries = rejectSeries;
        exports2.retry = retry;
        exports2.retryable = retryable;
        exports2.seq = seq;
        exports2.series = series;
        exports2.setImmediate = setImmediate$1;
        exports2.some = some;
        exports2.someLimit = someLimit;
        exports2.someSeries = someSeries;
        exports2.sortBy = sortBy;
        exports2.timeout = timeout;
        exports2.times = times;
        exports2.timesLimit = timeLimit;
        exports2.timesSeries = timesSeries;
        exports2.transform = transform;
        exports2.tryEach = tryEach;
        exports2.unmemoize = unmemoize;
        exports2.until = until;
        exports2.waterfall = waterfall;
        exports2.whilst = whilst;
        exports2.all = every;
        exports2.allLimit = everyLimit;
        exports2.allSeries = everySeries;
        exports2.any = some;
        exports2.anyLimit = someLimit;
        exports2.anySeries = someSeries;
        exports2.find = detect;
        exports2.findLimit = detectLimit;
        exports2.findSeries = detectSeries;
        exports2.forEach = eachLimit;
        exports2.forEachSeries = eachSeries;
        exports2.forEachLimit = eachLimit$1;
        exports2.forEachOf = eachOf;
        exports2.forEachOfSeries = eachOfSeries;
        exports2.forEachOfLimit = eachOfLimit;
        exports2.inject = reduce;
        exports2.foldl = reduce;
        exports2.foldr = reduceRight;
        exports2.select = filter;
        exports2.selectLimit = filterLimit;
        exports2.selectSeries = filterSeries;
        exports2.wrapSync = asyncify;
        Object.defineProperty(exports2, "__esModule", { value: true });
      }));
    }
  });

  // node_modules/doublearray/doublearray.js
  var require_doublearray = __commonJS({
    "node_modules/doublearray/doublearray.js"(exports, module) {
      (function() {
        "use strict";
        var TERM_CHAR = "\0", TERM_CODE = 0, ROOT_ID = 0, NOT_FOUND = -1, BASE_SIGNED = true, CHECK_SIGNED = true, BASE_BYTES = 4, CHECK_BYTES = 4, MEMORY_EXPAND_RATIO = 2;
        var newBC = function(initial_size) {
          if (initial_size == null) {
            initial_size = 1024;
          }
          var initBase = function(_base, start, end) {
            for (var i = start; i < end; i++) {
              _base[i] = -i + 1;
            }
            if (0 < check.array[check.array.length - 1]) {
              var last_used_id = check.array.length - 2;
              while (0 < check.array[last_used_id]) {
                last_used_id--;
              }
              _base[start] = -last_used_id;
            }
          };
          var initCheck = function(_check, start, end) {
            for (var i = start; i < end; i++) {
              _check[i] = -i - 1;
            }
          };
          var realloc = function(min_size) {
            var new_size = min_size * MEMORY_EXPAND_RATIO;
            var base_new_array = newArrayBuffer(base.signed, base.bytes, new_size);
            initBase(base_new_array, base.array.length, new_size);
            base_new_array.set(base.array);
            base.array = null;
            base.array = base_new_array;
            var check_new_array = newArrayBuffer(check.signed, check.bytes, new_size);
            initCheck(check_new_array, check.array.length, new_size);
            check_new_array.set(check.array);
            check.array = null;
            check.array = check_new_array;
          };
          var first_unused_node = ROOT_ID + 1;
          var base = {
            signed: BASE_SIGNED,
            bytes: BASE_BYTES,
            array: newArrayBuffer(BASE_SIGNED, BASE_BYTES, initial_size)
          };
          var check = {
            signed: CHECK_SIGNED,
            bytes: CHECK_BYTES,
            array: newArrayBuffer(CHECK_SIGNED, CHECK_BYTES, initial_size)
          };
          base.array[ROOT_ID] = 1;
          check.array[ROOT_ID] = ROOT_ID;
          initBase(base.array, ROOT_ID + 1, base.array.length);
          initCheck(check.array, ROOT_ID + 1, check.array.length);
          return {
            getBaseBuffer: function() {
              return base.array;
            },
            getCheckBuffer: function() {
              return check.array;
            },
            loadBaseBuffer: function(base_buffer) {
              base.array = base_buffer;
              return this;
            },
            loadCheckBuffer: function(check_buffer) {
              check.array = check_buffer;
              return this;
            },
            size: function() {
              return Math.max(base.array.length, check.array.length);
            },
            getBase: function(index) {
              if (base.array.length - 1 < index) {
                return -index + 1;
              }
              return base.array[index];
            },
            getCheck: function(index) {
              if (check.array.length - 1 < index) {
                return -index - 1;
              }
              return check.array[index];
            },
            setBase: function(index, base_value) {
              if (base.array.length - 1 < index) {
                realloc(index);
              }
              base.array[index] = base_value;
            },
            setCheck: function(index, check_value) {
              if (check.array.length - 1 < index) {
                realloc(index);
              }
              check.array[index] = check_value;
            },
            setFirstUnusedNode: function(index) {
              first_unused_node = index;
            },
            getFirstUnusedNode: function() {
              return first_unused_node;
            },
            shrink: function() {
              var last_index = this.size() - 1;
              while (true) {
                if (0 <= check.array[last_index]) {
                  break;
                }
                last_index--;
              }
              base.array = base.array.subarray(0, last_index + 2);
              check.array = check.array.subarray(0, last_index + 2);
            },
            calc: function() {
              var unused_count = 0;
              var size = check.array.length;
              for (var i = 0; i < size; i++) {
                if (check.array[i] < 0) {
                  unused_count++;
                }
              }
              return {
                all: size,
                unused: unused_count,
                efficiency: (size - unused_count) / size
              };
            },
            dump: function() {
              var dump_base = "";
              var dump_check = "";
              var i;
              for (i = 0; i < base.array.length; i++) {
                dump_base = dump_base + " " + this.getBase(i);
              }
              for (i = 0; i < check.array.length; i++) {
                dump_check = dump_check + " " + this.getCheck(i);
              }
              console.log("base:" + dump_base);
              console.log("chck:" + dump_check);
              return "base:" + dump_base + " chck:" + dump_check;
            }
          };
        };
        function DoubleArrayBuilder(initial_size) {
          this.bc = newBC(initial_size);
          this.keys = [];
        }
        DoubleArrayBuilder.prototype.append = function(key, record) {
          this.keys.push({ k: key, v: record });
          return this;
        };
        DoubleArrayBuilder.prototype.build = function(keys, sorted) {
          if (keys == null) {
            keys = this.keys;
          }
          if (keys == null) {
            return new DoubleArray(this.bc);
          }
          if (sorted == null) {
            sorted = false;
          }
          var buff_keys = keys.map(function(k) {
            return {
              k: stringToUtf8Bytes(k.k + TERM_CHAR),
              v: k.v
            };
          });
          if (sorted) {
            this.keys = buff_keys;
          } else {
            this.keys = buff_keys.sort(function(k1, k2) {
              var b1 = k1.k;
              var b2 = k2.k;
              var min_length = Math.min(b1.length, b2.length);
              for (var pos = 0; pos < min_length; pos++) {
                if (b1[pos] === b2[pos]) {
                  continue;
                }
                return b1[pos] - b2[pos];
              }
              return b1.length - b2.length;
            });
          }
          buff_keys = null;
          this._build(ROOT_ID, 0, 0, this.keys.length);
          return new DoubleArray(this.bc);
        };
        DoubleArrayBuilder.prototype._build = function(parent_index, position, start, length) {
          var children_info = this.getChildrenInfo(position, start, length);
          var _base = this.findAllocatableBase(children_info);
          this.setBC(parent_index, children_info, _base);
          for (var i = 0; i < children_info.length; i = i + 3) {
            var child_code = children_info[i];
            if (child_code === TERM_CODE) {
              continue;
            }
            var child_start = children_info[i + 1];
            var child_len = children_info[i + 2];
            var child_index = _base + child_code;
            this._build(child_index, position + 1, child_start, child_len);
          }
        };
        DoubleArrayBuilder.prototype.getChildrenInfo = function(position, start, length) {
          var current_char = this.keys[start].k[position];
          var i = 0;
          var children_info = new Int32Array(length * 3);
          children_info[i++] = current_char;
          children_info[i++] = start;
          var next_pos = start;
          var start_pos = start;
          for (; next_pos < start + length; next_pos++) {
            var next_char = this.keys[next_pos].k[position];
            if (current_char !== next_char) {
              children_info[i++] = next_pos - start_pos;
              children_info[i++] = next_char;
              children_info[i++] = next_pos;
              current_char = next_char;
              start_pos = next_pos;
            }
          }
          children_info[i++] = next_pos - start_pos;
          children_info = children_info.subarray(0, i);
          return children_info;
        };
        DoubleArrayBuilder.prototype.setBC = function(parent_id, children_info, _base) {
          var bc = this.bc;
          bc.setBase(parent_id, _base);
          var i;
          for (i = 0; i < children_info.length; i = i + 3) {
            var code = children_info[i];
            var child_id = _base + code;
            var prev_unused_id = -bc.getBase(child_id);
            var next_unused_id = -bc.getCheck(child_id);
            if (child_id !== bc.getFirstUnusedNode()) {
              bc.setCheck(prev_unused_id, -next_unused_id);
            } else {
              bc.setFirstUnusedNode(next_unused_id);
            }
            bc.setBase(next_unused_id, -prev_unused_id);
            var check = parent_id;
            bc.setCheck(child_id, check);
            if (code === TERM_CODE) {
              var start_pos = children_info[i + 1];
              var value = this.keys[start_pos].v;
              if (value == null) {
                value = 0;
              }
              var base = -value - 1;
              bc.setBase(child_id, base);
            }
          }
        };
        DoubleArrayBuilder.prototype.findAllocatableBase = function(children_info) {
          var bc = this.bc;
          var _base;
          var curr = bc.getFirstUnusedNode();
          while (true) {
            _base = curr - children_info[0];
            if (_base < 0) {
              curr = -bc.getCheck(curr);
              continue;
            }
            var empty_area_found = true;
            for (var i = 0; i < children_info.length; i = i + 3) {
              var code = children_info[i];
              var candidate_id = _base + code;
              if (!this.isUnusedNode(candidate_id)) {
                curr = -bc.getCheck(curr);
                empty_area_found = false;
                break;
              }
            }
            if (empty_area_found) {
              return _base;
            }
          }
        };
        DoubleArrayBuilder.prototype.isUnusedNode = function(index) {
          var bc = this.bc;
          var check = bc.getCheck(index);
          if (index === ROOT_ID) {
            return false;
          }
          if (check < 0) {
            return true;
          }
          return false;
        };
        function DoubleArray(bc) {
          this.bc = bc;
          this.bc.shrink();
        }
        DoubleArray.prototype.contain = function(key) {
          var bc = this.bc;
          key += TERM_CHAR;
          var buffer = stringToUtf8Bytes(key);
          var parent = ROOT_ID;
          var child = NOT_FOUND;
          for (var i = 0; i < buffer.length; i++) {
            var code = buffer[i];
            child = this.traverse(parent, code);
            if (child === NOT_FOUND) {
              return false;
            }
            if (bc.getBase(child) <= 0) {
              return true;
            } else {
              parent = child;
              continue;
            }
          }
          return false;
        };
        DoubleArray.prototype.lookup = function(key) {
          key += TERM_CHAR;
          var buffer = stringToUtf8Bytes(key);
          var parent = ROOT_ID;
          var child = NOT_FOUND;
          for (var i = 0; i < buffer.length; i++) {
            var code = buffer[i];
            child = this.traverse(parent, code);
            if (child === NOT_FOUND) {
              return NOT_FOUND;
            }
            parent = child;
          }
          var base = this.bc.getBase(child);
          if (base <= 0) {
            return -base - 1;
          } else {
            return NOT_FOUND;
          }
        };
        DoubleArray.prototype.commonPrefixSearch = function(key) {
          var buffer = stringToUtf8Bytes(key);
          var parent = ROOT_ID;
          var child = NOT_FOUND;
          var result = [];
          for (var i = 0; i < buffer.length; i++) {
            var code = buffer[i];
            child = this.traverse(parent, code);
            if (child !== NOT_FOUND) {
              parent = child;
              var grand_child = this.traverse(child, TERM_CODE);
              if (grand_child !== NOT_FOUND) {
                var base = this.bc.getBase(grand_child);
                var r = {};
                if (base <= 0) {
                  r.v = -base - 1;
                }
                r.k = utf8BytesToString(arrayCopy(buffer, 0, i + 1));
                result.push(r);
              }
              continue;
            } else {
              break;
            }
          }
          return result;
        };
        DoubleArray.prototype.traverse = function(parent, code) {
          var child = this.bc.getBase(parent) + code;
          if (this.bc.getCheck(child) === parent) {
            return child;
          } else {
            return NOT_FOUND;
          }
        };
        DoubleArray.prototype.size = function() {
          return this.bc.size();
        };
        DoubleArray.prototype.calc = function() {
          return this.bc.calc();
        };
        DoubleArray.prototype.dump = function() {
          return this.bc.dump();
        };
        var newArrayBuffer = function(signed, bytes, size) {
          if (signed) {
            switch (bytes) {
              case 1:
                return new Int8Array(size);
              case 2:
                return new Int16Array(size);
              case 4:
                return new Int32Array(size);
              default:
                throw new RangeError("Invalid newArray parameter element_bytes:" + bytes);
            }
          } else {
            switch (bytes) {
              case 1:
                return new Uint8Array(size);
              case 2:
                return new Uint16Array(size);
              case 4:
                return new Uint32Array(size);
              default:
                throw new RangeError("Invalid newArray parameter element_bytes:" + bytes);
            }
          }
        };
        var arrayCopy = function(src, src_offset, length) {
          var buffer = new ArrayBuffer(length);
          var dstU8 = new Uint8Array(buffer, 0, length);
          var srcU8 = src.subarray(src_offset, length);
          dstU8.set(srcU8);
          return dstU8;
        };
        var stringToUtf8Bytes = function(str) {
          var bytes = new Uint8Array(new ArrayBuffer(str.length * 4));
          var i = 0, j = 0;
          while (i < str.length) {
            var unicode_code;
            var utf16_code = str.charCodeAt(i++);
            if (utf16_code >= 55296 && utf16_code <= 56319) {
              var upper = utf16_code;
              var lower = str.charCodeAt(i++);
              if (lower >= 56320 && lower <= 57343) {
                unicode_code = (upper - 55296) * (1 << 10) + (1 << 16) + (lower - 56320);
              } else {
                return null;
              }
            } else {
              unicode_code = utf16_code;
            }
            if (unicode_code < 128) {
              bytes[j++] = unicode_code;
            } else if (unicode_code < 1 << 11) {
              bytes[j++] = unicode_code >>> 6 | 192;
              bytes[j++] = unicode_code & 63 | 128;
            } else if (unicode_code < 1 << 16) {
              bytes[j++] = unicode_code >>> 12 | 224;
              bytes[j++] = unicode_code >> 6 & 63 | 128;
              bytes[j++] = unicode_code & 63 | 128;
            } else if (unicode_code < 1 << 21) {
              bytes[j++] = unicode_code >>> 18 | 240;
              bytes[j++] = unicode_code >> 12 & 63 | 128;
              bytes[j++] = unicode_code >> 6 & 63 | 128;
              bytes[j++] = unicode_code & 63 | 128;
            } else {
            }
          }
          return bytes.subarray(0, j);
        };
        var utf8BytesToString = function(bytes) {
          var str = "";
          var code, b1, b2, b3, b4, upper, lower;
          var i = 0;
          while (i < bytes.length) {
            b1 = bytes[i++];
            if (b1 < 128) {
              code = b1;
            } else if (b1 >> 5 === 6) {
              b2 = bytes[i++];
              code = (b1 & 31) << 6 | b2 & 63;
            } else if (b1 >> 4 === 14) {
              b2 = bytes[i++];
              b3 = bytes[i++];
              code = (b1 & 15) << 12 | (b2 & 63) << 6 | b3 & 63;
            } else {
              b2 = bytes[i++];
              b3 = bytes[i++];
              b4 = bytes[i++];
              code = (b1 & 7) << 18 | (b2 & 63) << 12 | (b3 & 63) << 6 | b4 & 63;
            }
            if (code < 65536) {
              str += String.fromCharCode(code);
            } else {
              code -= 65536;
              upper = 55296 | code >> 10;
              lower = 56320 | code & 1023;
              str += String.fromCharCode(upper, lower);
            }
          }
          return str;
        };
        var doublearray = {
          builder: function(initial_size) {
            return new DoubleArrayBuilder(initial_size);
          },
          load: function(base_buffer, check_buffer) {
            var bc = newBC(0);
            bc.loadBaseBuffer(base_buffer);
            bc.loadCheckBuffer(check_buffer);
            return new DoubleArray(bc);
          }
        };
        if ("undefined" === typeof module) {
          window.doublearray = doublearray;
        } else {
          module.exports = doublearray;
        }
      })();
    }
  });

  // node_modules/kuromoji/src/util/ByteBuffer.js
  var require_ByteBuffer = __commonJS({
    "node_modules/kuromoji/src/util/ByteBuffer.js"(exports, module) {
      "use strict";
      var stringToUtf8Bytes = function(str) {
        var bytes = new Uint8Array(str.length * 4);
        var i = 0, j = 0;
        while (i < str.length) {
          var unicode_code;
          var utf16_code = str.charCodeAt(i++);
          if (utf16_code >= 55296 && utf16_code <= 56319) {
            var upper = utf16_code;
            var lower = str.charCodeAt(i++);
            if (lower >= 56320 && lower <= 57343) {
              unicode_code = (upper - 55296) * (1 << 10) + (1 << 16) + (lower - 56320);
            } else {
              return null;
            }
          } else {
            unicode_code = utf16_code;
          }
          if (unicode_code < 128) {
            bytes[j++] = unicode_code;
          } else if (unicode_code < 1 << 11) {
            bytes[j++] = unicode_code >>> 6 | 192;
            bytes[j++] = unicode_code & 63 | 128;
          } else if (unicode_code < 1 << 16) {
            bytes[j++] = unicode_code >>> 12 | 224;
            bytes[j++] = unicode_code >> 6 & 63 | 128;
            bytes[j++] = unicode_code & 63 | 128;
          } else if (unicode_code < 1 << 21) {
            bytes[j++] = unicode_code >>> 18 | 240;
            bytes[j++] = unicode_code >> 12 & 63 | 128;
            bytes[j++] = unicode_code >> 6 & 63 | 128;
            bytes[j++] = unicode_code & 63 | 128;
          } else {
          }
        }
        return bytes.subarray(0, j);
      };
      var utf8BytesToString = function(bytes) {
        var str = "";
        var code, b1, b2, b3, b4, upper, lower;
        var i = 0;
        while (i < bytes.length) {
          b1 = bytes[i++];
          if (b1 < 128) {
            code = b1;
          } else if (b1 >> 5 === 6) {
            b2 = bytes[i++];
            code = (b1 & 31) << 6 | b2 & 63;
          } else if (b1 >> 4 === 14) {
            b2 = bytes[i++];
            b3 = bytes[i++];
            code = (b1 & 15) << 12 | (b2 & 63) << 6 | b3 & 63;
          } else {
            b2 = bytes[i++];
            b3 = bytes[i++];
            b4 = bytes[i++];
            code = (b1 & 7) << 18 | (b2 & 63) << 12 | (b3 & 63) << 6 | b4 & 63;
          }
          if (code < 65536) {
            str += String.fromCharCode(code);
          } else {
            code -= 65536;
            upper = 55296 | code >> 10;
            lower = 56320 | code & 1023;
            str += String.fromCharCode(upper, lower);
          }
        }
        return str;
      };
      function ByteBuffer(arg) {
        var initial_size;
        if (arg == null) {
          initial_size = 1024 * 1024;
        } else if (typeof arg === "number") {
          initial_size = arg;
        } else if (arg instanceof Uint8Array) {
          this.buffer = arg;
          this.position = 0;
          return;
        } else {
          throw typeof arg + " is invalid parameter type for ByteBuffer constructor";
        }
        this.buffer = new Uint8Array(initial_size);
        this.position = 0;
      }
      ByteBuffer.prototype.size = function() {
        return this.buffer.length;
      };
      ByteBuffer.prototype.reallocate = function() {
        var new_array = new Uint8Array(this.buffer.length * 2);
        new_array.set(this.buffer);
        this.buffer = new_array;
      };
      ByteBuffer.prototype.shrink = function() {
        this.buffer = this.buffer.subarray(0, this.position);
        return this.buffer;
      };
      ByteBuffer.prototype.put = function(b) {
        if (this.buffer.length < this.position + 1) {
          this.reallocate();
        }
        this.buffer[this.position++] = b;
      };
      ByteBuffer.prototype.get = function(index) {
        if (index == null) {
          index = this.position;
          this.position += 1;
        }
        if (this.buffer.length < index + 1) {
          return 0;
        }
        return this.buffer[index];
      };
      ByteBuffer.prototype.putShort = function(num) {
        if (65535 < num) {
          throw num + " is over short value";
        }
        var lower = 255 & num;
        var upper = (65280 & num) >> 8;
        this.put(lower);
        this.put(upper);
      };
      ByteBuffer.prototype.getShort = function(index) {
        if (index == null) {
          index = this.position;
          this.position += 2;
        }
        if (this.buffer.length < index + 2) {
          return 0;
        }
        var lower = this.buffer[index];
        var upper = this.buffer[index + 1];
        var value = (upper << 8) + lower;
        if (value & 32768) {
          value = -(value - 1 ^ 65535);
        }
        return value;
      };
      ByteBuffer.prototype.putInt = function(num) {
        if (4294967295 < num) {
          throw num + " is over integer value";
        }
        var b0 = 255 & num;
        var b1 = (65280 & num) >> 8;
        var b2 = (16711680 & num) >> 16;
        var b3 = (4278190080 & num) >> 24;
        this.put(b0);
        this.put(b1);
        this.put(b2);
        this.put(b3);
      };
      ByteBuffer.prototype.getInt = function(index) {
        if (index == null) {
          index = this.position;
          this.position += 4;
        }
        if (this.buffer.length < index + 4) {
          return 0;
        }
        var b0 = this.buffer[index];
        var b1 = this.buffer[index + 1];
        var b2 = this.buffer[index + 2];
        var b3 = this.buffer[index + 3];
        return (b3 << 24) + (b2 << 16) + (b1 << 8) + b0;
      };
      ByteBuffer.prototype.readInt = function() {
        var pos = this.position;
        this.position += 4;
        return this.getInt(pos);
      };
      ByteBuffer.prototype.putString = function(str) {
        var bytes = stringToUtf8Bytes(str);
        for (var i = 0; i < bytes.length; i++) {
          this.put(bytes[i]);
        }
        this.put(0);
      };
      ByteBuffer.prototype.getString = function(index) {
        var buf = [], ch;
        if (index == null) {
          index = this.position;
        }
        while (true) {
          if (this.buffer.length < index + 1) {
            break;
          }
          ch = this.get(index++);
          if (ch === 0) {
            break;
          } else {
            buf.push(ch);
          }
        }
        this.position = index;
        return utf8BytesToString(buf);
      };
      module.exports = ByteBuffer;
    }
  });

  // node_modules/kuromoji/src/dict/TokenInfoDictionary.js
  var require_TokenInfoDictionary = __commonJS({
    "node_modules/kuromoji/src/dict/TokenInfoDictionary.js"(exports, module) {
      "use strict";
      var ByteBuffer = require_ByteBuffer();
      function TokenInfoDictionary() {
        this.dictionary = new ByteBuffer(10 * 1024 * 1024);
        this.target_map = {};
        this.pos_buffer = new ByteBuffer(10 * 1024 * 1024);
      }
      TokenInfoDictionary.prototype.buildDictionary = function(entries) {
        var dictionary_entries = {};
        for (var i = 0; i < entries.length; i++) {
          var entry = entries[i];
          if (entry.length < 4) {
            continue;
          }
          var surface_form = entry[0];
          var left_id = entry[1];
          var right_id = entry[2];
          var word_cost = entry[3];
          var feature = entry.slice(4).join(",");
          if (!isFinite(left_id) || !isFinite(right_id) || !isFinite(word_cost)) {
            console.log(entry);
          }
          var token_info_id = this.put(left_id, right_id, word_cost, surface_form, feature);
          dictionary_entries[token_info_id] = surface_form;
        }
        this.dictionary.shrink();
        this.pos_buffer.shrink();
        return dictionary_entries;
      };
      TokenInfoDictionary.prototype.put = function(left_id, right_id, word_cost, surface_form, feature) {
        var token_info_id = this.dictionary.position;
        var pos_id = this.pos_buffer.position;
        this.dictionary.putShort(left_id);
        this.dictionary.putShort(right_id);
        this.dictionary.putShort(word_cost);
        this.dictionary.putInt(pos_id);
        this.pos_buffer.putString(surface_form + "," + feature);
        return token_info_id;
      };
      TokenInfoDictionary.prototype.addMapping = function(source, target) {
        var mapping = this.target_map[source];
        if (mapping == null) {
          mapping = [];
        }
        mapping.push(target);
        this.target_map[source] = mapping;
      };
      TokenInfoDictionary.prototype.targetMapToBuffer = function() {
        var buffer = new ByteBuffer();
        var map_keys_size = Object.keys(this.target_map).length;
        buffer.putInt(map_keys_size);
        for (var key in this.target_map) {
          var values = this.target_map[key];
          var map_values_size = values.length;
          buffer.putInt(parseInt(key));
          buffer.putInt(map_values_size);
          for (var i = 0; i < values.length; i++) {
            buffer.putInt(values[i]);
          }
        }
        return buffer.shrink();
      };
      TokenInfoDictionary.prototype.loadDictionary = function(array_buffer) {
        this.dictionary = new ByteBuffer(array_buffer);
        return this;
      };
      TokenInfoDictionary.prototype.loadPosVector = function(array_buffer) {
        this.pos_buffer = new ByteBuffer(array_buffer);
        return this;
      };
      TokenInfoDictionary.prototype.loadTargetMap = function(array_buffer) {
        var buffer = new ByteBuffer(array_buffer);
        buffer.position = 0;
        this.target_map = {};
        buffer.readInt();
        while (true) {
          if (buffer.buffer.length < buffer.position + 1) {
            break;
          }
          var key = buffer.readInt();
          var map_values_size = buffer.readInt();
          for (var i = 0; i < map_values_size; i++) {
            var value = buffer.readInt();
            this.addMapping(key, value);
          }
        }
        return this;
      };
      TokenInfoDictionary.prototype.getFeatures = function(token_info_id_str) {
        var token_info_id = parseInt(token_info_id_str);
        if (isNaN(token_info_id)) {
          return "";
        }
        var pos_id = this.dictionary.getInt(token_info_id + 6);
        return this.pos_buffer.getString(pos_id);
      };
      module.exports = TokenInfoDictionary;
    }
  });

  // node_modules/kuromoji/src/dict/ConnectionCosts.js
  var require_ConnectionCosts = __commonJS({
    "node_modules/kuromoji/src/dict/ConnectionCosts.js"(exports, module) {
      "use strict";
      function ConnectionCosts(forward_dimension, backward_dimension) {
        this.forward_dimension = forward_dimension;
        this.backward_dimension = backward_dimension;
        this.buffer = new Int16Array(forward_dimension * backward_dimension + 2);
        this.buffer[0] = forward_dimension;
        this.buffer[1] = backward_dimension;
      }
      ConnectionCosts.prototype.put = function(forward_id, backward_id, cost) {
        var index = forward_id * this.backward_dimension + backward_id + 2;
        if (this.buffer.length < index + 1) {
          throw "ConnectionCosts buffer overflow";
        }
        this.buffer[index] = cost;
      };
      ConnectionCosts.prototype.get = function(forward_id, backward_id) {
        var index = forward_id * this.backward_dimension + backward_id + 2;
        if (this.buffer.length < index + 1) {
          throw "ConnectionCosts buffer overflow";
        }
        return this.buffer[index];
      };
      ConnectionCosts.prototype.loadConnectionCosts = function(connection_costs_buffer) {
        this.forward_dimension = connection_costs_buffer[0];
        this.backward_dimension = connection_costs_buffer[1];
        this.buffer = connection_costs_buffer;
      };
      module.exports = ConnectionCosts;
    }
  });

  // node_modules/kuromoji/src/dict/CharacterClass.js
  var require_CharacterClass = __commonJS({
    "node_modules/kuromoji/src/dict/CharacterClass.js"(exports, module) {
      "use strict";
      function CharacterClass(class_id, class_name, is_always_invoke, is_grouping, max_length) {
        this.class_id = class_id;
        this.class_name = class_name;
        this.is_always_invoke = is_always_invoke;
        this.is_grouping = is_grouping;
        this.max_length = max_length;
      }
      module.exports = CharacterClass;
    }
  });

  // node_modules/kuromoji/src/dict/InvokeDefinitionMap.js
  var require_InvokeDefinitionMap = __commonJS({
    "node_modules/kuromoji/src/dict/InvokeDefinitionMap.js"(exports, module) {
      "use strict";
      var ByteBuffer = require_ByteBuffer();
      var CharacterClass = require_CharacterClass();
      function InvokeDefinitionMap() {
        this.map = [];
        this.lookup_table = {};
      }
      InvokeDefinitionMap.load = function(invoke_def_buffer) {
        var invoke_def = new InvokeDefinitionMap();
        var character_category_definition = [];
        var buffer = new ByteBuffer(invoke_def_buffer);
        while (buffer.position + 1 < buffer.size()) {
          var class_id = character_category_definition.length;
          var is_always_invoke = buffer.get();
          var is_grouping = buffer.get();
          var max_length = buffer.getInt();
          var class_name = buffer.getString();
          character_category_definition.push(new CharacterClass(class_id, class_name, is_always_invoke, is_grouping, max_length));
        }
        invoke_def.init(character_category_definition);
        return invoke_def;
      };
      InvokeDefinitionMap.prototype.init = function(character_category_definition) {
        if (character_category_definition == null) {
          return;
        }
        for (var i = 0; i < character_category_definition.length; i++) {
          var character_class = character_category_definition[i];
          this.map[i] = character_class;
          this.lookup_table[character_class.class_name] = i;
        }
      };
      InvokeDefinitionMap.prototype.getCharacterClass = function(class_id) {
        return this.map[class_id];
      };
      InvokeDefinitionMap.prototype.lookup = function(class_name) {
        var class_id = this.lookup_table[class_name];
        if (class_id == null) {
          return null;
        }
        return class_id;
      };
      InvokeDefinitionMap.prototype.toBuffer = function() {
        var buffer = new ByteBuffer();
        for (var i = 0; i < this.map.length; i++) {
          var char_class = this.map[i];
          buffer.put(char_class.is_always_invoke);
          buffer.put(char_class.is_grouping);
          buffer.putInt(char_class.max_length);
          buffer.putString(char_class.class_name);
        }
        buffer.shrink();
        return buffer.buffer;
      };
      module.exports = InvokeDefinitionMap;
    }
  });

  // node_modules/kuromoji/src/dict/CharacterDefinition.js
  var require_CharacterDefinition = __commonJS({
    "node_modules/kuromoji/src/dict/CharacterDefinition.js"(exports, module) {
      "use strict";
      var InvokeDefinitionMap = require_InvokeDefinitionMap();
      var CharacterClass = require_CharacterClass();
      var SurrogateAwareString = require_SurrogateAwareString();
      var DEFAULT_CATEGORY = "DEFAULT";
      function CharacterDefinition() {
        this.character_category_map = new Uint8Array(65536);
        this.compatible_category_map = new Uint32Array(65536);
        this.invoke_definition_map = null;
      }
      CharacterDefinition.load = function(cat_map_buffer, compat_cat_map_buffer, invoke_def_buffer) {
        var char_def = new CharacterDefinition();
        char_def.character_category_map = cat_map_buffer;
        char_def.compatible_category_map = compat_cat_map_buffer;
        char_def.invoke_definition_map = InvokeDefinitionMap.load(invoke_def_buffer);
        return char_def;
      };
      CharacterDefinition.parseCharCategory = function(class_id, parsed_category_def) {
        var category = parsed_category_def[1];
        var invoke = parseInt(parsed_category_def[2]);
        var grouping = parseInt(parsed_category_def[3]);
        var max_length = parseInt(parsed_category_def[4]);
        if (!isFinite(invoke) || invoke !== 0 && invoke !== 1) {
          console.log("char.def parse error. INVOKE is 0 or 1 in:" + invoke);
          return null;
        }
        if (!isFinite(grouping) || grouping !== 0 && grouping !== 1) {
          console.log("char.def parse error. GROUP is 0 or 1 in:" + grouping);
          return null;
        }
        if (!isFinite(max_length) || max_length < 0) {
          console.log("char.def parse error. LENGTH is 1 to n:" + max_length);
          return null;
        }
        var is_invoke = invoke === 1;
        var is_grouping = grouping === 1;
        return new CharacterClass(class_id, category, is_invoke, is_grouping, max_length);
      };
      CharacterDefinition.parseCategoryMapping = function(parsed_category_mapping) {
        var start = parseInt(parsed_category_mapping[1]);
        var default_category = parsed_category_mapping[2];
        var compatible_category = 3 < parsed_category_mapping.length ? parsed_category_mapping.slice(3) : [];
        if (!isFinite(start) || start < 0 || start > 65535) {
          console.log("char.def parse error. CODE is invalid:" + start);
        }
        return { start, default: default_category, compatible: compatible_category };
      };
      CharacterDefinition.parseRangeCategoryMapping = function(parsed_category_mapping) {
        var start = parseInt(parsed_category_mapping[1]);
        var end = parseInt(parsed_category_mapping[2]);
        var default_category = parsed_category_mapping[3];
        var compatible_category = 4 < parsed_category_mapping.length ? parsed_category_mapping.slice(4) : [];
        if (!isFinite(start) || start < 0 || start > 65535) {
          console.log("char.def parse error. CODE is invalid:" + start);
        }
        if (!isFinite(end) || end < 0 || end > 65535) {
          console.log("char.def parse error. CODE is invalid:" + end);
        }
        return { start, end, default: default_category, compatible: compatible_category };
      };
      CharacterDefinition.prototype.initCategoryMappings = function(category_mapping) {
        var code_point;
        if (category_mapping != null) {
          for (var i = 0; i < category_mapping.length; i++) {
            var mapping = category_mapping[i];
            var end = mapping.end || mapping.start;
            for (code_point = mapping.start; code_point <= end; code_point++) {
              this.character_category_map[code_point] = this.invoke_definition_map.lookup(mapping.default);
              for (var j = 0; j < mapping.compatible.length; j++) {
                var bitset = this.compatible_category_map[code_point];
                var compatible_category = mapping.compatible[j];
                if (compatible_category == null) {
                  continue;
                }
                var class_id = this.invoke_definition_map.lookup(compatible_category);
                if (class_id == null) {
                  continue;
                }
                var class_id_bit = 1 << class_id;
                bitset = bitset | class_id_bit;
                this.compatible_category_map[code_point] = bitset;
              }
            }
          }
        }
        var default_id = this.invoke_definition_map.lookup(DEFAULT_CATEGORY);
        if (default_id == null) {
          return;
        }
        for (code_point = 0; code_point < this.character_category_map.length; code_point++) {
          if (this.character_category_map[code_point] === 0) {
            this.character_category_map[code_point] = 1 << default_id;
          }
        }
      };
      CharacterDefinition.prototype.lookupCompatibleCategory = function(ch) {
        var classes = [];
        var code = ch.charCodeAt(0);
        var integer;
        if (code < this.compatible_category_map.length) {
          integer = this.compatible_category_map[code];
        }
        if (integer == null || integer === 0) {
          return classes;
        }
        for (var bit = 0; bit < 32; bit++) {
          if (integer << 31 - bit >>> 31 === 1) {
            var character_class = this.invoke_definition_map.getCharacterClass(bit);
            if (character_class == null) {
              continue;
            }
            classes.push(character_class);
          }
        }
        return classes;
      };
      CharacterDefinition.prototype.lookup = function(ch) {
        var class_id;
        var code = ch.charCodeAt(0);
        if (SurrogateAwareString.isSurrogatePair(ch)) {
          class_id = this.invoke_definition_map.lookup(DEFAULT_CATEGORY);
        } else if (code < this.character_category_map.length) {
          class_id = this.character_category_map[code];
        }
        if (class_id == null) {
          class_id = this.invoke_definition_map.lookup(DEFAULT_CATEGORY);
        }
        return this.invoke_definition_map.getCharacterClass(class_id);
      };
      module.exports = CharacterDefinition;
    }
  });

  // node_modules/kuromoji/src/dict/UnknownDictionary.js
  var require_UnknownDictionary = __commonJS({
    "node_modules/kuromoji/src/dict/UnknownDictionary.js"(exports, module) {
      "use strict";
      var TokenInfoDictionary = require_TokenInfoDictionary();
      var CharacterDefinition = require_CharacterDefinition();
      var ByteBuffer = require_ByteBuffer();
      function UnknownDictionary() {
        this.dictionary = new ByteBuffer(10 * 1024 * 1024);
        this.target_map = {};
        this.pos_buffer = new ByteBuffer(10 * 1024 * 1024);
        this.character_definition = null;
      }
      UnknownDictionary.prototype = Object.create(TokenInfoDictionary.prototype);
      UnknownDictionary.prototype.characterDefinition = function(character_definition) {
        this.character_definition = character_definition;
        return this;
      };
      UnknownDictionary.prototype.lookup = function(ch) {
        return this.character_definition.lookup(ch);
      };
      UnknownDictionary.prototype.lookupCompatibleCategory = function(ch) {
        return this.character_definition.lookupCompatibleCategory(ch);
      };
      UnknownDictionary.prototype.loadUnknownDictionaries = function(unk_buffer, unk_pos_buffer, unk_map_buffer, cat_map_buffer, compat_cat_map_buffer, invoke_def_buffer) {
        this.loadDictionary(unk_buffer);
        this.loadPosVector(unk_pos_buffer);
        this.loadTargetMap(unk_map_buffer);
        this.character_definition = CharacterDefinition.load(cat_map_buffer, compat_cat_map_buffer, invoke_def_buffer);
      };
      module.exports = UnknownDictionary;
    }
  });

  // node_modules/kuromoji/src/dict/DynamicDictionaries.js
  var require_DynamicDictionaries = __commonJS({
    "node_modules/kuromoji/src/dict/DynamicDictionaries.js"(exports, module) {
      "use strict";
      var doublearray = require_doublearray();
      var TokenInfoDictionary = require_TokenInfoDictionary();
      var ConnectionCosts = require_ConnectionCosts();
      var UnknownDictionary = require_UnknownDictionary();
      function DynamicDictionaries(trie, token_info_dictionary, connection_costs, unknown_dictionary) {
        if (trie != null) {
          this.trie = trie;
        } else {
          this.trie = doublearray.builder(0).build([
            { k: "", v: 1 }
          ]);
        }
        if (token_info_dictionary != null) {
          this.token_info_dictionary = token_info_dictionary;
        } else {
          this.token_info_dictionary = new TokenInfoDictionary();
        }
        if (connection_costs != null) {
          this.connection_costs = connection_costs;
        } else {
          this.connection_costs = new ConnectionCosts(0, 0);
        }
        if (unknown_dictionary != null) {
          this.unknown_dictionary = unknown_dictionary;
        } else {
          this.unknown_dictionary = new UnknownDictionary();
        }
      }
      DynamicDictionaries.prototype.loadTrie = function(base_buffer, check_buffer) {
        this.trie = doublearray.load(base_buffer, check_buffer);
        return this;
      };
      DynamicDictionaries.prototype.loadTokenInfoDictionaries = function(token_info_buffer, pos_buffer, target_map_buffer) {
        this.token_info_dictionary.loadDictionary(token_info_buffer);
        this.token_info_dictionary.loadPosVector(pos_buffer);
        this.token_info_dictionary.loadTargetMap(target_map_buffer);
        return this;
      };
      DynamicDictionaries.prototype.loadConnectionCosts = function(cc_buffer) {
        this.connection_costs.loadConnectionCosts(cc_buffer);
        return this;
      };
      DynamicDictionaries.prototype.loadUnknownDictionaries = function(unk_buffer, unk_pos_buffer, unk_map_buffer, cat_map_buffer, compat_cat_map_buffer, invoke_def_buffer) {
        this.unknown_dictionary.loadUnknownDictionaries(unk_buffer, unk_pos_buffer, unk_map_buffer, cat_map_buffer, compat_cat_map_buffer, invoke_def_buffer);
        return this;
      };
      module.exports = DynamicDictionaries;
    }
  });

  // node_modules/kuromoji/src/loader/DictionaryLoader.js
  var require_DictionaryLoader = __commonJS({
    "node_modules/kuromoji/src/loader/DictionaryLoader.js"(exports, module) {
      "use strict";
      var path = require_path_shim();
      var async = require_async();
      var DynamicDictionaries = require_DynamicDictionaries();
      function DictionaryLoader(dic_path) {
        this.dic = new DynamicDictionaries();
        this.dic_path = dic_path;
      }
      DictionaryLoader.prototype.loadArrayBuffer = function(file, callback) {
        throw new Error("DictionaryLoader#loadArrayBuffer should be overwrite");
      };
      DictionaryLoader.prototype.load = function(load_callback) {
        var dic = this.dic;
        var dic_path = this.dic_path;
        var loadArrayBuffer = this.loadArrayBuffer;
        async.parallel([
          // Trie
          function(callback) {
            async.map(["base.dat.gz", "check.dat.gz"], function(filename, _callback) {
              loadArrayBuffer(path.join(dic_path, filename), function(err, buffer) {
                if (err) {
                  return _callback(err);
                }
                _callback(null, buffer);
              });
            }, function(err, buffers) {
              if (err) {
                return callback(err);
              }
              var base_buffer = new Int32Array(buffers[0]);
              var check_buffer = new Int32Array(buffers[1]);
              dic.loadTrie(base_buffer, check_buffer);
              callback(null);
            });
          },
          // Token info dictionaries
          function(callback) {
            async.map(["tid.dat.gz", "tid_pos.dat.gz", "tid_map.dat.gz"], function(filename, _callback) {
              loadArrayBuffer(path.join(dic_path, filename), function(err, buffer) {
                if (err) {
                  return _callback(err);
                }
                _callback(null, buffer);
              });
            }, function(err, buffers) {
              if (err) {
                return callback(err);
              }
              var token_info_buffer = new Uint8Array(buffers[0]);
              var pos_buffer = new Uint8Array(buffers[1]);
              var target_map_buffer = new Uint8Array(buffers[2]);
              dic.loadTokenInfoDictionaries(token_info_buffer, pos_buffer, target_map_buffer);
              callback(null);
            });
          },
          // Connection cost matrix
          function(callback) {
            loadArrayBuffer(path.join(dic_path, "cc.dat.gz"), function(err, buffer) {
              if (err) {
                return callback(err);
              }
              var cc_buffer = new Int16Array(buffer);
              dic.loadConnectionCosts(cc_buffer);
              callback(null);
            });
          },
          // Unknown dictionaries
          function(callback) {
            async.map(["unk.dat.gz", "unk_pos.dat.gz", "unk_map.dat.gz", "unk_char.dat.gz", "unk_compat.dat.gz", "unk_invoke.dat.gz"], function(filename, _callback) {
              loadArrayBuffer(path.join(dic_path, filename), function(err, buffer) {
                if (err) {
                  return _callback(err);
                }
                _callback(null, buffer);
              });
            }, function(err, buffers) {
              if (err) {
                return callback(err);
              }
              var unk_buffer = new Uint8Array(buffers[0]);
              var unk_pos_buffer = new Uint8Array(buffers[1]);
              var unk_map_buffer = new Uint8Array(buffers[2]);
              var cat_map_buffer = new Uint8Array(buffers[3]);
              var compat_cat_map_buffer = new Uint32Array(buffers[4]);
              var invoke_def_buffer = new Uint8Array(buffers[5]);
              dic.loadUnknownDictionaries(unk_buffer, unk_pos_buffer, unk_map_buffer, cat_map_buffer, compat_cat_map_buffer, invoke_def_buffer);
              callback(null);
            });
          }
        ], function(err) {
          load_callback(err, dic);
        });
      };
      module.exports = DictionaryLoader;
    }
  });

  // node_modules/kuromoji/src/loader/BrowserDictionaryLoader.js
  var require_BrowserDictionaryLoader = __commonJS({
    "node_modules/kuromoji/src/loader/BrowserDictionaryLoader.js"(exports, module) {
      "use strict";
      var zlib = require_gunzip_min();
      var DictionaryLoader = require_DictionaryLoader();
      function BrowserDictionaryLoader(dic_path) {
        DictionaryLoader.apply(this, [dic_path]);
      }
      BrowserDictionaryLoader.prototype = Object.create(DictionaryLoader.prototype);
      BrowserDictionaryLoader.prototype.loadArrayBuffer = function(url, callback) {
        var xhr = new XMLHttpRequest();
        xhr.open("GET", url, true);
        xhr.responseType = "arraybuffer";
        xhr.onload = function() {
          if (this.status > 0 && this.status !== 200) {
            callback(xhr.statusText, null);
            return;
          }
          var arraybuffer = this.response;
          var gz = new zlib.Zlib.Gunzip(new Uint8Array(arraybuffer));
          var typed_array = gz.decompress();
          callback(null, typed_array.buffer);
        };
        xhr.onerror = function(err) {
          callback(err, null);
        };
        xhr.send();
      };
      module.exports = BrowserDictionaryLoader;
    }
  });

  // node_modules/kuromoji/src/TokenizerBuilder.js
  var require_TokenizerBuilder = __commonJS({
    "node_modules/kuromoji/src/TokenizerBuilder.js"(exports, module) {
      "use strict";
      var Tokenizer = require_Tokenizer();
      var DictionaryLoader = require_BrowserDictionaryLoader();
      function TokenizerBuilder(option) {
        if (option.dicPath == null) {
          this.dic_path = "dict/";
        } else {
          this.dic_path = option.dicPath;
        }
      }
      TokenizerBuilder.prototype.build = function(callback) {
        var loader = new DictionaryLoader(this.dic_path);
        loader.load(function(err, dic) {
          callback(err, new Tokenizer(dic));
        });
      };
      module.exports = TokenizerBuilder;
    }
  });

  // node_modules/kuromoji/src/dict/builder/ConnectionCostsBuilder.js
  var require_ConnectionCostsBuilder = __commonJS({
    "node_modules/kuromoji/src/dict/builder/ConnectionCostsBuilder.js"(exports, module) {
      "use strict";
      var ConnectionCosts = require_ConnectionCosts();
      function ConnectionCostsBuilder() {
        this.lines = 0;
        this.connection_cost = null;
      }
      ConnectionCostsBuilder.prototype.putLine = function(line) {
        if (this.lines === 0) {
          var dimensions = line.split(" ");
          var forward_dimension = dimensions[0];
          var backward_dimension = dimensions[1];
          if (forward_dimension < 0 || backward_dimension < 0) {
            throw "Parse error of matrix.def";
          }
          this.connection_cost = new ConnectionCosts(forward_dimension, backward_dimension);
          this.lines++;
          return this;
        }
        var costs = line.split(" ");
        if (costs.length !== 3) {
          return this;
        }
        var forward_id = parseInt(costs[0]);
        var backward_id = parseInt(costs[1]);
        var cost = parseInt(costs[2]);
        if (forward_id < 0 || backward_id < 0 || !isFinite(forward_id) || !isFinite(backward_id) || this.connection_cost.forward_dimension <= forward_id || this.connection_cost.backward_dimension <= backward_id) {
          throw "Parse error of matrix.def";
        }
        this.connection_cost.put(forward_id, backward_id, cost);
        this.lines++;
        return this;
      };
      ConnectionCostsBuilder.prototype.build = function() {
        return this.connection_cost;
      };
      module.exports = ConnectionCostsBuilder;
    }
  });

  // node_modules/kuromoji/src/dict/builder/CharacterDefinitionBuilder.js
  var require_CharacterDefinitionBuilder = __commonJS({
    "node_modules/kuromoji/src/dict/builder/CharacterDefinitionBuilder.js"(exports, module) {
      "use strict";
      var CharacterDefinition = require_CharacterDefinition();
      var InvokeDefinitionMap = require_InvokeDefinitionMap();
      var CATEGORY_DEF_PATTERN = /^(\w+)\s+(\d)\s+(\d)\s+(\d)/;
      var CATEGORY_MAPPING_PATTERN = /^(0x[0-9A-F]{4})(?:\s+([^#\s]+))(?:\s+([^#\s]+))*/;
      var RANGE_CATEGORY_MAPPING_PATTERN = /^(0x[0-9A-F]{4})\.\.(0x[0-9A-F]{4})(?:\s+([^#\s]+))(?:\s+([^#\s]+))*/;
      function CharacterDefinitionBuilder() {
        this.char_def = new CharacterDefinition();
        this.char_def.invoke_definition_map = new InvokeDefinitionMap();
        this.character_category_definition = [];
        this.category_mapping = [];
      }
      CharacterDefinitionBuilder.prototype.putLine = function(line) {
        var parsed_category_def = CATEGORY_DEF_PATTERN.exec(line);
        if (parsed_category_def != null) {
          var class_id = this.character_category_definition.length;
          var char_class = CharacterDefinition.parseCharCategory(class_id, parsed_category_def);
          if (char_class == null) {
            return;
          }
          this.character_category_definition.push(char_class);
          return;
        }
        var parsed_category_mapping = CATEGORY_MAPPING_PATTERN.exec(line);
        if (parsed_category_mapping != null) {
          var mapping = CharacterDefinition.parseCategoryMapping(parsed_category_mapping);
          this.category_mapping.push(mapping);
        }
        var parsed_range_category_mapping = RANGE_CATEGORY_MAPPING_PATTERN.exec(line);
        if (parsed_range_category_mapping != null) {
          var range_mapping = CharacterDefinition.parseRangeCategoryMapping(parsed_range_category_mapping);
          this.category_mapping.push(range_mapping);
        }
      };
      CharacterDefinitionBuilder.prototype.build = function() {
        this.char_def.invoke_definition_map.init(this.character_category_definition);
        this.char_def.initCategoryMappings(this.category_mapping);
        return this.char_def;
      };
      module.exports = CharacterDefinitionBuilder;
    }
  });

  // node_modules/kuromoji/src/dict/builder/DictionaryBuilder.js
  var require_DictionaryBuilder = __commonJS({
    "node_modules/kuromoji/src/dict/builder/DictionaryBuilder.js"(exports, module) {
      "use strict";
      var doublearray = require_doublearray();
      var DynamicDictionaries = require_DynamicDictionaries();
      var TokenInfoDictionary = require_TokenInfoDictionary();
      var ConnectionCostsBuilder = require_ConnectionCostsBuilder();
      var CharacterDefinitionBuilder = require_CharacterDefinitionBuilder();
      var UnknownDictionary = require_UnknownDictionary();
      function DictionaryBuilder() {
        this.tid_entries = [];
        this.unk_entries = [];
        this.cc_builder = new ConnectionCostsBuilder();
        this.cd_builder = new CharacterDefinitionBuilder();
      }
      DictionaryBuilder.prototype.addTokenInfoDictionary = function(line) {
        var new_entry = line.split(",");
        this.tid_entries.push(new_entry);
        return this;
      };
      DictionaryBuilder.prototype.putCostMatrixLine = function(line) {
        this.cc_builder.putLine(line);
        return this;
      };
      DictionaryBuilder.prototype.putCharDefLine = function(line) {
        this.cd_builder.putLine(line);
        return this;
      };
      DictionaryBuilder.prototype.putUnkDefLine = function(line) {
        this.unk_entries.push(line.split(","));
        return this;
      };
      DictionaryBuilder.prototype.build = function() {
        var dictionaries = this.buildTokenInfoDictionary();
        var unknown_dictionary = this.buildUnknownDictionary();
        return new DynamicDictionaries(dictionaries.trie, dictionaries.token_info_dictionary, this.cc_builder.build(), unknown_dictionary);
      };
      DictionaryBuilder.prototype.buildTokenInfoDictionary = function() {
        var token_info_dictionary = new TokenInfoDictionary();
        var dictionary_entries = token_info_dictionary.buildDictionary(this.tid_entries);
        var trie = this.buildDoubleArray();
        for (var token_info_id in dictionary_entries) {
          var surface_form = dictionary_entries[token_info_id];
          var trie_id = trie.lookup(surface_form);
          token_info_dictionary.addMapping(trie_id, token_info_id);
        }
        return {
          trie,
          token_info_dictionary
        };
      };
      DictionaryBuilder.prototype.buildUnknownDictionary = function() {
        var unk_dictionary = new UnknownDictionary();
        var dictionary_entries = unk_dictionary.buildDictionary(this.unk_entries);
        var char_def = this.cd_builder.build();
        unk_dictionary.characterDefinition(char_def);
        for (var token_info_id in dictionary_entries) {
          var class_name = dictionary_entries[token_info_id];
          var class_id = char_def.invoke_definition_map.lookup(class_name);
          unk_dictionary.addMapping(class_id, token_info_id);
        }
        return unk_dictionary;
      };
      DictionaryBuilder.prototype.buildDoubleArray = function() {
        var trie_id = 0;
        var words = this.tid_entries.map(function(entry) {
          var surface_form = entry[0];
          return { k: surface_form, v: trie_id++ };
        });
        var builder = doublearray.builder(1024 * 1024);
        return builder.build(words);
      };
      module.exports = DictionaryBuilder;
    }
  });

  // node_modules/kuromoji/src/kuromoji.js
  var require_kuromoji = __commonJS({
    "node_modules/kuromoji/src/kuromoji.js"(exports, module) {
      "use strict";
      var TokenizerBuilder = require_TokenizerBuilder();
      var DictionaryBuilder = require_DictionaryBuilder();
      var kuromoji2 = {
        builder: function(option) {
          return new TokenizerBuilder(option);
        },
        dictionaryBuilder: function() {
          return new DictionaryBuilder();
        }
      };
      module.exports = kuromoji2;
    }
  });

  // src/content.js
  var import_kuromoji = __toESM(require_kuromoji(), 1);

  // src/person-name-readings.mjs
  var VERIFIED_AT = "2026-08-20";
  var PERSON_NAME_SOURCES = Object.freeze({
    "mofa-heads-2026-08-20": Object.freeze({
      url: "https://www.mofa.go.jp/mofaj/ms/po/page22_001297.html",
      note: "Japanese Ministry of Foreign Affairs list of current heads of state and ministers"
    }),
    "mofa-north-korea-2022-04-21": Object.freeze({
      url: "https://www.mofa.go.jp/mofaj/area/n_korea/data.html",
      note: "Japanese Ministry of Foreign Affairs North Korea country data"
    }),
    "mofa-vietnam-country-data": Object.freeze({
      url: "https://www.mofa.go.jp/mofaj/area/vietnam/data.html",
      note: "Japanese Ministry of Foreign Affairs Vietnam country data and official katakana spellings"
    }),
    "mofa-korea-official-pages": Object.freeze({
      url: "https://www.mofa.go.jp/mofaj/a_o/na/kr/pageit_000001_02236.html",
      note: "Japanese Ministry of Foreign Affairs Korean leader spellings"
    })
  });
  var PERSON_COUNTRY_HINTS = Object.freeze({
    china: Object.freeze(["\u4E2D\u56FD", "\u4E2D\u83EF\u4EBA\u6C11\u5171\u548C\u56FD", "\u4E2D\u56FD\u5171\u7523\u515A", "\u5317\u4EAC"]),
    korea: Object.freeze(["\u97D3\u56FD", "\u5927\u97D3\u6C11\u56FD", "\u30BD\u30A6\u30EB"]),
    northKorea: Object.freeze(["\u5317\u671D\u9BAE", "\u671D\u9BAE\u6C11\u4E3B\u4E3B\u7FA9\u4EBA\u6C11\u5171\u548C\u56FD", "\u671D\u9BAE\u52B4\u50CD\u515A", "\u5E73\u58CC"]),
    vietnam: Object.freeze([
      "\u30D9\u30C8\u30CA\u30E0\u793E\u4F1A\u4E3B\u7FA9\u5171\u548C\u56FD",
      "\u30D9\u30C8\u30CA\u30E0\u5171\u7523\u515A",
      "\u30D9\u30C8\u30CA\u30E0",
      "\u8D8A\u5357",
      "\u30CF\u30CE\u30A4"
    ])
  });
  var PERSON_ROLE_HINTS = Object.freeze([
    "\u6C0F",
    "\u3055\u3093",
    "\u5927\u7D71\u9818",
    "\u56FD\u5BB6\u4E3B\u5E2D",
    "\u4E3B\u5E2D",
    "\u9996\u76F8",
    "\u7DCF\u7406",
    "\u5916\u76F8",
    "\u5916\u52D9\u5927\u81E3",
    "\u5916\u4EA4\u90E8\u9577",
    "\u7DCF\u66F8\u8A18",
    "\u66F8\u8A18\u9577",
    "\u56FD\u52D9\u59D4\u54E1\u9577",
    "\u6700\u9AD8\u6307\u5C0E\u8005",
    "\u526F\u9996\u76F8",
    "\u9577\u5B98",
    "\u5143\u66F8\u8A18\u9577",
    "\u5143\u56FD\u5BB6\u4E3B\u5E2D",
    "\u5143\u5927\u7D71\u9818",
    "\u5143\u9996\u76F8",
    "\u524D\u5927\u7D71\u9818",
    "\u524D\u9996\u76F8",
    "\u524D\u4E3B\u5E2D",
    "\u524D\u5916\u76F8",
    "\u8B70\u9577",
    "\u8B70\u54E1",
    "\u5019\u88DC",
    "\u4EE3\u8868",
    "\u4F1A\u9577",
    "\u76E3\u7763",
    "\u9078\u624B",
    "\u6559\u6388",
    "\u535A\u58EB",
    "\u653F\u6A29"
  ]);
  function defineName(definition) {
    const {
      surfaces,
      components: rawComponents,
      blockedSuffixes = [],
      roleHints = [],
      ...metadata
    } = definition;
    const components = rawComponents.map((component) => Object.freeze({ ...component }));
    const componentReading = components.map((component) => component.reading).join("");
    if (componentReading !== definition.reading) {
      throw new Error(`Foreign person name components do not reconstruct ${definition.id}`);
    }
    return Object.freeze({
      verifiedAt: VERIFIED_AT,
      confidence: "unique",
      ...metadata,
      surfaces: Object.freeze([...surfaces]),
      components: Object.freeze(components),
      blockedSuffixes: Object.freeze([...blockedSuffixes]),
      roleHints: Object.freeze([...roleHints])
    });
  }
  var FOREIGN_PERSON_NAMES = Object.freeze([
    defineName({
      id: "xi-jinping",
      country: "china",
      locale: "zh-CN",
      surfaces: ["\u7FD2\u8FD1\u5E73", "\u4E60\u8FD1\u5E73"],
      reading: "\u30B7\u30FC\u30B8\u30F3\u30D4\u30F3",
      components: [{ length: 1, reading: "\u30B7\u30FC" }, { length: 1, reading: "\u30B8\u30F3" }, { length: 1, reading: "\u30D4\u30F3" }],
      sourceId: "mofa-heads-2026-08-20"
    }),
    defineName({
      id: "li-qiang",
      country: "china",
      locale: "zh-CN",
      confidence: "contextual",
      surfaces: ["\u674E\u5F37", "\u674E\u5F3A"],
      reading: "\u30EA\u30FC\u30FB\u30C1\u30A2\u30F3",
      components: [{ length: 1, reading: "\u30EA\u30FC\u30FB" }, { length: 1, reading: "\u30C1\u30A2\u30F3" }],
      roleHints: ["\u9996\u76F8", "\u7DCF\u7406", "\u56FD\u52D9\u9662\u7DCF\u7406"],
      sourceId: "mofa-heads-2026-08-20"
    }),
    defineName({
      id: "wang-yi",
      country: "china",
      locale: "zh-CN",
      confidence: "contextual",
      surfaces: ["\u738B\u6BC5"],
      reading: "\u30EF\u30F3\u30FB\u30A4\u30FC",
      components: [{ length: 1, reading: "\u30EF\u30F3\u30FB" }, { length: 1, reading: "\u30A4\u30FC" }],
      roleHints: ["\u5916\u76F8", "\u5916\u52D9\u5927\u81E3", "\u5916\u4EA4\u90E8\u9577", "\u653F\u6CBB\u5C40\u54E1"],
      sourceId: "mofa-heads-2026-08-20"
    }),
    defineName({
      id: "kim-jong-un",
      country: "northKorea",
      locale: "ko-KP",
      surfaces: ["\u91D1\u6B63\u6069"],
      reading: "\u30AD\u30E0\u30FB\u30B8\u30E7\u30F3\u30A6\u30F3",
      components: [{ length: 1, reading: "\u30AD\u30E0\u30FB" }, { length: 1, reading: "\u30B8\u30E7\u30F3" }, { length: 1, reading: "\u30A6\u30F3" }],
      sourceId: "mofa-north-korea-2022-04-21"
    }),
    defineName({
      id: "kim-yo-jong",
      country: "northKorea",
      locale: "ko-KP",
      surfaces: ["\u91D1\u4E0E\u6B63", "\u91D1\u8207\u6B63"],
      reading: "\u30AD\u30E0\u30FB\u30E8\u30B8\u30E7\u30F3",
      components: [{ length: 1, reading: "\u30AD\u30E0\u30FB" }, { length: 1, reading: "\u30E8" }, { length: 1, reading: "\u30B8\u30E7\u30F3" }],
      sourceId: "mofa-north-korea-2022-04-21"
    }),
    defineName({
      id: "kim-il-sung",
      country: "northKorea",
      locale: "ko-KP",
      surfaces: ["\u91D1\u65E5\u6210"],
      reading: "\u30AD\u30E0\u30FB\u30A4\u30EB\u30BD\u30F3",
      components: [{ length: 1, reading: "\u30AD\u30E0\u30FB" }, { length: 1, reading: "\u30A4\u30EB" }, { length: 1, reading: "\u30BD\u30F3" }],
      sourceId: "mofa-north-korea-2022-04-21"
    }),
    defineName({
      id: "kim-jong-il",
      country: "northKorea",
      locale: "ko-KP",
      surfaces: ["\u91D1\u6B63\u65E5"],
      reading: "\u30AD\u30E0\u30FB\u30B8\u30E7\u30F3\u30A4\u30EB",
      components: [{ length: 1, reading: "\u30AD\u30E0\u30FB" }, { length: 1, reading: "\u30B8\u30E7\u30F3" }, { length: 1, reading: "\u30A4\u30EB" }],
      sourceId: "mofa-north-korea-2022-04-21"
    }),
    defineName({
      id: "choe-ryong-hae",
      country: "northKorea",
      locale: "ko-KP",
      surfaces: ["\u5D14\u7ADC\u6D77", "\u5D14\u9F8D\u6D77"],
      reading: "\u30C1\u30A7\u30FB\u30EA\u30E7\u30F3\u30D8",
      components: [{ length: 1, reading: "\u30C1\u30A7\u30FB" }, { length: 1, reading: "\u30EA\u30E7\u30F3" }, { length: 1, reading: "\u30D8" }],
      sourceId: "mofa-north-korea-2022-04-21"
    }),
    defineName({
      id: "jo-yong-won",
      country: "northKorea",
      locale: "ko-KP",
      surfaces: ["\u8D99\u752C\u5143"],
      reading: "\u30C1\u30E7\u30FB\u30E8\u30F3\u30A6\u30A9\u30F3",
      components: [{ length: 1, reading: "\u30C1\u30E7\u30FB" }, { length: 1, reading: "\u30E8\u30F3" }, { length: 1, reading: "\u30A6\u30A9\u30F3" }],
      sourceId: "mofa-north-korea-2022-04-21"
    }),
    defineName({
      id: "pak-jong-chon",
      country: "northKorea",
      locale: "ko-KP",
      surfaces: ["\u6734\u6B63\u5929"],
      reading: "\u30D1\u30AF\u30FB\u30B8\u30E7\u30F3\u30C1\u30E7\u30F3",
      components: [{ length: 1, reading: "\u30D1\u30AF\u30FB" }, { length: 1, reading: "\u30B8\u30E7\u30F3" }, { length: 1, reading: "\u30C1\u30E7\u30F3" }],
      sourceId: "mofa-north-korea-2022-04-21"
    }),
    defineName({
      id: "kim-tok-hun",
      country: "northKorea",
      locale: "ko-KP",
      surfaces: ["\u91D1\u5FB3\u8A13"],
      reading: "\u30AD\u30E0\u30FB\u30C9\u30C3\u30AF\u30F3",
      components: [{ length: 1, reading: "\u30AD\u30E0\u30FB" }, { length: 1, reading: "\u30C9\u30C3" }, { length: 1, reading: "\u30AF\u30F3" }],
      sourceId: "mofa-north-korea-2022-04-21"
    }),
    defineName({
      id: "ri-son-gwon",
      country: "northKorea",
      locale: "ko-KP",
      surfaces: ["\u674E\u5584\u6A29", "\u674E\u5584\u6B0A"],
      reading: "\u30EA\u30FB\u30BD\u30F3\u30B0\u30A9\u30F3",
      components: [{ length: 1, reading: "\u30EA\u30FB" }, { length: 1, reading: "\u30BD\u30F3" }, { length: 1, reading: "\u30B0\u30A9\u30F3" }],
      sourceId: "mofa-north-korea-2022-04-21"
    }),
    defineName({
      id: "lee-jae-myung",
      country: "korea",
      locale: "ko-KR",
      surfaces: ["\u674E\u5728\u660E"],
      reading: "\u30A4\u30FB\u30B8\u30A7\u30DF\u30E7\u30F3",
      components: [{ length: 1, reading: "\u30A4\u30FB" }, { length: 1, reading: "\u30B8\u30A7" }, { length: 1, reading: "\u30DF\u30E7\u30F3" }],
      sourceId: "mofa-heads-2026-08-20"
    }),
    defineName({
      id: "yoon-suk-yeol",
      country: "korea",
      locale: "ko-KR",
      surfaces: ["\u5C39\u932B\u60A6"],
      reading: "\u30E6\u30F3\u30FB\u30BD\u30F3\u30CB\u30E7\u30EB",
      components: [{ length: 1, reading: "\u30E6\u30F3\u30FB" }, { length: 1, reading: "\u30BD\u30F3" }, { length: 1, reading: "\u30CB\u30E7\u30EB" }],
      sourceId: "mofa-korea-official-pages"
    }),
    defineName({
      id: "moon-jae-in",
      country: "korea",
      locale: "ko-KR",
      surfaces: ["\u6587\u5728\u5BC5"],
      reading: "\u30E0\u30F3\u30FB\u30B8\u30A7\u30A4\u30F3",
      components: [{ length: 1, reading: "\u30E0\u30F3\u30FB" }, { length: 1, reading: "\u30B8\u30A7" }, { length: 1, reading: "\u30A4\u30F3" }],
      sourceId: "mofa-korea-official-pages"
    }),
    defineName({
      id: "park-geun-hye",
      country: "korea",
      locale: "ko-KR",
      surfaces: ["\u6734\u69FF\u6075", "\u6734\u69FF\u60E0"],
      reading: "\u30D1\u30AF\u30FB\u30AF\u30CD",
      components: [{ length: 1, reading: "\u30D1\u30AF\u30FB" }, { length: 1, reading: "\u30AF" }, { length: 1, reading: "\u30CD" }],
      sourceId: "mofa-korea-official-pages"
    }),
    defineName({
      id: "lee-myung-bak",
      country: "korea",
      locale: "ko-KR",
      surfaces: ["\u674E\u660E\u535A"],
      reading: "\u30A4\u30FB\u30DF\u30E7\u30F3\u30D0\u30AF",
      components: [{ length: 1, reading: "\u30A4\u30FB" }, { length: 1, reading: "\u30DF\u30E7\u30F3" }, { length: 1, reading: "\u30D0\u30AF" }],
      sourceId: "mofa-korea-official-pages"
    }),
    defineName({
      id: "roh-moo-hyun",
      country: "korea",
      locale: "ko-KR",
      surfaces: ["\u76E7\u6B66\u9249"],
      reading: "\u30CE\u30FB\u30E0\u30D2\u30E7\u30F3",
      components: [{ length: 1, reading: "\u30CE\u30FB" }, { length: 1, reading: "\u30E0" }, { length: 1, reading: "\u30D2\u30E7\u30F3" }],
      sourceId: "mofa-korea-official-pages"
    }),
    defineName({
      id: "kim-dae-jung",
      country: "korea",
      locale: "ko-KR",
      surfaces: ["\u91D1\u5927\u4E2D"],
      reading: "\u30AD\u30E0\u30FB\u30C7\u30B8\u30E5\u30F3",
      components: [{ length: 1, reading: "\u30AD\u30E0\u30FB" }, { length: 1, reading: "\u30C7" }, { length: 1, reading: "\u30B8\u30E5\u30F3" }],
      sourceId: "mofa-korea-official-pages"
    }),
    defineName({
      id: "kim-young-sam",
      country: "korea",
      locale: "ko-KR",
      surfaces: ["\u91D1\u6CF3\u4E09"],
      reading: "\u30AD\u30E0\u30FB\u30E8\u30F3\u30B5\u30E0",
      components: [{ length: 1, reading: "\u30AD\u30E0\u30FB" }, { length: 1, reading: "\u30E8\u30F3" }, { length: 1, reading: "\u30B5\u30E0" }],
      sourceId: "mofa-korea-official-pages"
    }),
    defineName({
      id: "chun-doo-hwan",
      country: "korea",
      locale: "ko-KR",
      surfaces: ["\u5168\u6597\u7165"],
      reading: "\u30C1\u30E7\u30F3\u30FB\u30C9\u30A5\u30D5\u30A1\u30F3",
      components: [{ length: 1, reading: "\u30C1\u30E7\u30F3\u30FB" }, { length: 1, reading: "\u30C9\u30A5" }, { length: 1, reading: "\u30D5\u30A1\u30F3" }],
      sourceId: "mofa-korea-official-pages"
    }),
    defineName({
      id: "nguyen-phu-trong",
      country: "vietnam",
      locale: "vi",
      surfaces: ["\u962E\u5BCC\u4EF2"],
      reading: "\u30B0\u30A8\u30F3\u30FB\u30D5\u30FC\u30FB\u30C1\u30E7\u30F3",
      components: [{ length: 1, reading: "\u30B0\u30A8\u30F3\u30FB" }, { length: 1, reading: "\u30D5\u30FC\u30FB" }, { length: 1, reading: "\u30C1\u30E7\u30F3" }],
      sourceId: "mofa-vietnam-country-data"
    }),
    defineName({
      id: "nguyen-xuan-phuc",
      country: "vietnam",
      locale: "vi",
      surfaces: ["\u962E\u6625\u798F"],
      reading: "\u30B0\u30A8\u30F3\u30FB\u30B9\u30A2\u30F3\u30FB\u30D5\u30C3\u30AF",
      components: [{ length: 1, reading: "\u30B0\u30A8\u30F3\u30FB" }, { length: 1, reading: "\u30B9\u30A2\u30F3\u30FB" }, { length: 1, reading: "\u30D5\u30C3\u30AF" }],
      sourceId: "mofa-vietnam-country-data"
    }),
    defineName({
      id: "vo-nguyen-giap",
      country: "vietnam",
      locale: "vi",
      surfaces: ["\u6B66\u5143\u7532"],
      reading: "\u30F4\u30A9\u30FC\u30FB\u30B0\u30A8\u30F3\u30FB\u30B6\u30C3\u30D7",
      components: [{ length: 1, reading: "\u30F4\u30A9\u30FC\u30FB" }, { length: 1, reading: "\u30B0\u30A8\u30F3\u30FB" }, { length: 1, reading: "\u30B6\u30C3\u30D7" }],
      sourceId: "mofa-vietnam-country-data"
    }),
    defineName({
      id: "vo-van-thuong",
      country: "vietnam",
      locale: "vi",
      surfaces: ["\u6B66\u6587\u8CDE"],
      reading: "\u30F4\u30A9\u30FC\u30FB\u30F4\u30A1\u30F3\u30FB\u30C8\u30A5\u30AA\u30F3",
      components: [{ length: 1, reading: "\u30F4\u30A9\u30FC\u30FB" }, { length: 1, reading: "\u30F4\u30A1\u30F3\u30FB" }, { length: 1, reading: "\u30C8\u30A5\u30AA\u30F3" }],
      sourceId: "mofa-vietnam-country-data"
    }),
    defineName({
      id: "to-lam",
      country: "vietnam",
      locale: "vi",
      confidence: "contextual",
      surfaces: ["\u8607\u6797"],
      reading: "\u30C8\u30FC\u30FB\u30E9\u30E0",
      components: [{ length: 1, reading: "\u30C8\u30FC\u30FB" }, { length: 1, reading: "\u30E9\u30E0" }],
      roleHints: ["\u66F8\u8A18\u9577", "\u7DCF\u66F8\u8A18", "\u56FD\u5BB6\u4E3B\u5E2D", "\u4E3B\u5E2D"],
      sourceId: "mofa-vietnam-country-data"
    }),
    defineName({
      id: "luong-cuong",
      country: "vietnam",
      locale: "vi",
      confidence: "contextual",
      surfaces: ["\u6881\u5F37", "\u6881\u5F3A"],
      reading: "\u30EB\u30AA\u30F3\u30FB\u30AF\u30AA\u30F3",
      components: [{ length: 1, reading: "\u30EB\u30AA\u30F3\u30FB" }, { length: 1, reading: "\u30AF\u30AA\u30F3" }],
      roleHints: ["\u56FD\u5BB6\u4E3B\u5E2D", "\u4E3B\u5E2D"],
      sourceId: "mofa-heads-2026-08-20"
    }),
    defineName({
      id: "pham-minh-chinh",
      country: "vietnam",
      locale: "vi",
      confidence: "contextual",
      surfaces: ["\u8303\u660E\u653F"],
      reading: "\u30D5\u30A1\u30E0\u30FB\u30DF\u30F3\u30FB\u30C1\u30F3",
      components: [{ length: 1, reading: "\u30D5\u30A1\u30E0\u30FB" }, { length: 1, reading: "\u30DF\u30F3\u30FB" }, { length: 1, reading: "\u30C1\u30F3" }],
      roleHints: ["\u9996\u76F8"],
      sourceId: "mofa-heads-2026-08-20"
    }),
    defineName({
      id: "bui-thanh-son",
      country: "vietnam",
      locale: "vi",
      confidence: "contextual",
      surfaces: ["\u88F4\u9752\u5C71"],
      reading: "\u30D6\u30A4\u30FB\u30BF\u30A4\u30F3\u30FB\u30BD\u30F3",
      components: [{ length: 1, reading: "\u30D6\u30A4\u30FB" }, { length: 1, reading: "\u30BF\u30A4\u30F3\u30FB" }, { length: 1, reading: "\u30BD\u30F3" }],
      roleHints: ["\u5916\u76F8", "\u5916\u52D9\u5927\u81E3", "\u526F\u9996\u76F8"],
      sourceId: "mofa-heads-2026-08-20"
    }),
    defineName({
      id: "tran-thanh-man",
      country: "vietnam",
      locale: "vi",
      surfaces: ["\u9673\u9752\u654F"],
      reading: "\u30C1\u30E3\u30F3\u30FB\u30BF\u30A4\u30F3\u30FB\u30DE\u30F3",
      components: [{ length: 1, reading: "\u30C1\u30E3\u30F3\u30FB" }, { length: 1, reading: "\u30BF\u30A4\u30F3\u30FB" }, { length: 1, reading: "\u30DE\u30F3" }],
      sourceId: "mofa-vietnam-country-data"
    }),
    defineName({
      id: "ho-chi-minh",
      country: "vietnam",
      locale: "vi",
      confidence: "contextual",
      surfaces: ["\u80E1\u5FD7\u660E"],
      reading: "\u30DB\u30FC\u30FB\u30C1\u30FB\u30DF\u30F3",
      components: [{ length: 1, reading: "\u30DB\u30FC\u30FB" }, { length: 1, reading: "\u30C1\u30FB" }, { length: 1, reading: "\u30DF\u30F3" }],
      roleHints: ["\u4E3B\u5E2D", "\u9769\u547D\u5BB6", "\u5EFA\u56FD\u306E\u7236"],
      blockedSuffixes: ["\u5E02", "\u7A7A\u6E2F", "\u99C5", "\u5E02\u5185", "\u901A\u308A", "\u5EDF"],
      sourceId: "mofa-vietnam-country-data"
    })
  ]);
  function getForeignPersonNameParts(entry, surface) {
    const parts = [];
    let start = 0;
    for (let first = 0; first < entry.components.length; first += 1) {
      let length = 0;
      let reading = "";
      for (let last = first; last < entry.components.length; last += 1) {
        length += entry.components[last].length;
        reading += entry.components[last].reading;
        parts.push(Object.freeze({
          surface: surface.slice(start, start + length),
          start,
          reading: reading.replace(/・$/u, "")
        }));
      }
      start += entry.components[first].length;
    }
    return parts;
  }

  // src/core.mjs
  var KANJI_PATTERN = /[\p{Script=Han}々〆ヶ]/u;
  var SINGLE_KANJI_PATTERN = /^[\p{Script=Han}々〆ヶ]$/u;
  var HORIZONTAL_SPACE = "[\\p{Zs}\\t]*";
  var WEEKDAY_ABBREVIATION_READINGS = Object.freeze({
    \u65E5: "\u306B\u3061",
    \u6708: "\u3052\u3064",
    \u706B: "\u304B",
    \u6C34: "\u3059\u3044",
    \u6728: "\u3082\u304F",
    \u91D1: "\u304D\u3093",
    \u571F: "\u3069"
  });
  var CLOSING_PARENTHESIS = Object.freeze({
    "(": ")",
    "\uFF08": "\uFF09"
  });
  var SPECIAL_DAY_READINGS = Object.freeze({
    1: "\u3064\u3044\u305F\u3061",
    2: "\u3075\u3064\u304B",
    3: "\u307F\u3063\u304B",
    4: "\u3088\u3063\u304B",
    5: "\u3044\u3064\u304B",
    6: "\u3080\u3044\u304B",
    7: "\u306A\u306E\u304B",
    8: "\u3088\u3046\u304B",
    9: "\u3053\u3053\u306E\u304B",
    10: "\u3068\u304A\u304B",
    14: "\u3058\u3085\u3046\u3088\u3063\u304B",
    20: "\u306F\u3064\u304B",
    24: "\u306B\u3058\u3085\u3046\u3088\u3063\u304B"
  });
  var PEOPLE_COUNTER_READINGS = Object.freeze({
    "1": "\u3072\u3068\u308A",
    "\uFF11": "\u3072\u3068\u308A",
    \u4E00: "\u3072\u3068\u308A",
    "2": "\u3075\u305F\u308A",
    "\uFF12": "\u3075\u305F\u308A",
    \u4E8C: "\u3075\u305F\u308A"
  });
  var EXACT_PHRASE_READINGS = Object.freeze([
    ["\u598A\u5A20\u9AD8\u8840\u5727\u814E\u75C7", "\u306B\u3093\u3057\u3093\u3053\u3046\u3051\u3064\u3042\u3064\u3058\u3093\u3057\u3087\u3046"],
    ["\u535A\u58EB\u8AB2\u7A0B", "\u306F\u304F\u3057\u304B\u3066\u3044"],
    ["\u65E5\u672C\u7814\u7A76", "\u306B\u307B\u3093\u3051\u3093\u304D\u3085\u3046"],
    ["\u65E5\u672C\u521D", "\u306B\u307B\u3093\u306F\u3064"],
    ["\u982D\u9838\u90E8", "\u3068\u3046\u3051\u3044\u3076"],
    ["\u5E79\u7D30\u80DE", "\u304B\u3093\u3055\u3044\u307C\u3046"],
    ["\u6D78\u900F\u5727", "\u3057\u3093\u3068\u3046\u3042\u3064"],
    ["\u30C8\u30D4\u4E3B\u69D8", "\u3068\u3074\u306C\u3057\u3055\u307E"],
    ["\u30B9\u30EC\u4E3B\u69D8", "\u3059\u308C\u306C\u3057\u3055\u307E"],
    ["\u30C8\u30D4\u7ACB\u3066", "\u3068\u3074\u305F\u3066"],
    ["\u30B9\u30EC\u7ACB\u3066", "\u3059\u308C\u305F\u3066"],
    ["\u30C8\u30D4\u4E3B", "\u3068\u3074\u306C\u3057"],
    ["\u30B9\u30EC\u4E3B", "\u3059\u308C\u306C\u3057"],
    ["\u76F8\u8EE2\u79FB", "\u305D\u3046\u3066\u3093\u3044"],
    ["\u5E73\u5747\u5834", "\u3078\u3044\u304D\u3093\u3070"],
    ["\u9AA8\u9AC4", "\u3053\u3064\u305A\u3044"],
    ["\u5354\u50CD", "\u304D\u3087\u3046\u3069\u3046"],
    ["\u81EA\u6CBB\u53A8", "\u3058\u3061\u3061\u3085\u3046"],
    ["\u65E2\u8AAD", "\u304D\u3069\u304F"],
    ["\u516C\u9332", "\u3053\u3046\u308D\u304F"],
    ["\u58F2\u308A\u6642", "\u3046\u308A\u3069\u304D"],
    ["\u6628\u590F", "\u3055\u3063\u304B"],
    ["\u4E00\u4EBA\u4E00\u4EBA", "\u3072\u3068\u308A\u3072\u3068\u308A"],
    ["\u4E8C\u4EBA\u7D44", "\u3075\u305F\u308A\u3050\u307F"],
    ["\u81B5", "\u3059\u3044"]
  ].sort(([left], [right]) => right.length - left.length));
  var ROUND_COUNTER_READINGS = Object.freeze({
    \u4E00: "\u3044\u3063\u304B\u3044",
    \u516D: "\u308D\u3063\u304B\u3044",
    \u516B: "\u306F\u3063\u304B\u3044",
    \u5341: "\u3058\u3085\u3063\u304B\u3044",
    \u767E: "\u3072\u3083\u3063\u304B\u3044"
  });
  var SPLIT_COMPOUND_READINGS = Object.freeze([
    {
      surface: "\u598A\u5A20\u9AD8\u8840\u5727\u814E\u75C7",
      parts: [
        ["\u598A", 0, "\u306B\u3093"],
        ["\u5A20", 1, "\u3057\u3093"],
        ["\u9AD8", 2, "\u3053\u3046"],
        ["\u8840", 3, "\u3051\u3064"],
        ["\u5727", 4, "\u3042\u3064"],
        ["\u814E", 5, "\u3058\u3093"],
        ["\u75C7", 6, "\u3057\u3087\u3046"],
        ["\u598A\u5A20", 0, "\u306B\u3093\u3057\u3093"],
        ["\u8840\u5727", 3, "\u3051\u3064\u3042\u3064"],
        ["\u814E\u75C7", 5, "\u3058\u3093\u3057\u3087\u3046"]
      ]
    },
    {
      surface: "\u535A\u58EB\u8AB2\u7A0B",
      parts: [
        ["\u535A", 0, "\u306F\u304F"],
        ["\u58EB", 1, "\u3057"],
        ["\u8AB2", 2, "\u304B"],
        ["\u7A0B", 3, "\u3066\u3044"],
        ["\u535A\u58EB", 0, "\u306F\u304F\u3057"],
        ["\u8AB2\u7A0B", 2, "\u304B\u3066\u3044"]
      ]
    },
    {
      surface: "\u65E5\u672C\u7814\u7A76",
      parts: [
        ["\u65E5", 0, "\u306B"],
        ["\u672C", 1, "\u307B\u3093"],
        ["\u7814", 2, "\u3051\u3093"],
        ["\u7A76", 3, "\u304D\u3085\u3046"],
        ["\u65E5\u672C", 0, "\u306B\u307B\u3093"],
        ["\u7814\u7A76", 2, "\u3051\u3093\u304D\u3085\u3046"]
      ]
    },
    {
      surface: "\u5E79\u7D30\u80DE",
      parts: [
        ["\u5E79", 0, "\u304B\u3093"],
        ["\u7D30", 1, "\u3055\u3044"],
        ["\u80DE", 2, "\u307C\u3046"],
        ["\u7D30\u80DE", 1, "\u3055\u3044\u307C\u3046"]
      ]
    },
    {
      surface: "\u982D\u9838\u90E8",
      parts: [["\u982D", 0, "\u3068\u3046"], ["\u9838", 1, "\u3051\u3044"], ["\u90E8", 2, "\u3076"]]
    },
    {
      surface: "\u6D78\u900F\u5727",
      parts: [
        ["\u6D78", 0, "\u3057\u3093"],
        ["\u900F", 1, "\u3068\u3046"],
        ["\u5727", 2, "\u3042\u3064"],
        ["\u6D78\u900F", 0, "\u3057\u3093\u3068\u3046"]
      ]
    },
    {
      surface: "\u65E5\u672C\u521D",
      parts: [
        ["\u65E5", 0, "\u306B"],
        ["\u672C", 1, "\u307B\u3093"],
        ["\u521D", 2, "\u306F\u3064"],
        ["\u65E5\u672C", 0, "\u306B\u307B\u3093"],
        ["\u672C\u521D", 1, "\u307B\u3093\u306F\u3064"]
      ]
    },
    {
      surface: "\u76F8\u8EE2\u79FB",
      parts: [
        ["\u76F8", 0, "\u305D\u3046"],
        ["\u8EE2", 1, "\u3066\u3093"],
        ["\u79FB", 2, "\u3044"],
        ["\u8EE2\u79FB", 1, "\u3066\u3093\u3044"]
      ]
    },
    {
      surface: "\u5E73\u5747\u5834",
      parts: [
        ["\u5E73", 0, "\u3078\u3044"],
        ["\u5747", 1, "\u304D\u3093"],
        ["\u5834", 2, "\u3070"],
        ["\u5E73\u5747", 0, "\u3078\u3044\u304D\u3093"]
      ]
    },
    {
      surface: "\u81EA\u6CBB\u53A8",
      parts: [
        ["\u81EA", 0, "\u3058"],
        ["\u6CBB", 1, "\u3061"],
        ["\u53A8", 2, "\u3061\u3085\u3046"],
        ["\u81EA\u6CBB", 0, "\u3058\u3061"]
      ]
    },
    {
      surface: "\u58F2\u308A\u6642",
      parts: [["\u58F2\u308A", 0, "\u3046\u308A"], ["\u6642", 2, "\u3069\u304D"]]
    },
    {
      surface: "\u9AA8\u9AC4",
      parts: [["\u9AA8", 0, "\u3053\u3064"], ["\u9AC4", 1, "\u305A\u3044"]]
    },
    {
      surface: "\u5354\u50CD",
      parts: [["\u5354", 0, "\u304D\u3087\u3046"], ["\u50CD", 1, "\u3069\u3046"]]
    },
    {
      surface: "\u65E2\u8AAD",
      parts: [["\u65E2", 0, "\u304D"], ["\u8AAD", 1, "\u3069\u304F"]]
    },
    {
      surface: "\u516C\u9332",
      parts: [["\u516C", 0, "\u3053\u3046"], ["\u9332", 1, "\u308D\u304F"]]
    },
    {
      surface: "\u6628\u590F",
      parts: [["\u6628", 0, "\u3055\u3063"], ["\u590F", 1, "\u304B"]]
    },
    {
      surface: "\u4E2D\u65E5",
      parts: [["\u4E2D", 0, "\u3061\u3085\u3046"], ["\u65E5", 1, "\u306B\u3061"]]
    },
    {
      surface: "\u5DE8\u4EBA",
      parts: [["\u5DE8", 0, "\u304D\u3087"], ["\u4EBA", 1, "\u3058\u3093"]]
    },
    {
      surface: "\u975E\u5E38",
      parts: [["\u975E", 0, "\u3072"], ["\u5E38", 1, "\u3058\u3087\u3046"]]
    }
  ]);
  var FOREIGN_PERSON_SURFACES = Object.freeze(FOREIGN_PERSON_NAMES.flatMap(
    (entry) => entry.surfaces.map((surface) => Object.freeze({
      entry,
      surface,
      parts: Object.freeze(getForeignPersonNameParts(entry, surface))
    }))
  ).sort((left, right) => right.surface.length - left.surface.length));
  var ALL_PERSON_COUNTRY_HINTS = Object.freeze(Object.values(PERSON_COUNTRY_HINTS).flat());
  var PROVIDED_READING_PATTERN = /^([\p{Script=Han}々〆ヶ]{2,6})[\p{Zs}\t]*([\(（])[\p{Zs}\t]*([\p{Script=Hiragana}\p{Script=Katakana}ー・･\p{Zs}\t]{2,48})[\p{Zs}\t]*([\)）])/u;
  function containsKanji(value) {
    return KANJI_PATTERN.test(value);
  }
  function katakanaToHiragana(value) {
    return Array.from(value, (character) => {
      const codePoint = character.codePointAt(0);
      if (codePoint >= 12449 && codePoint <= 12534) {
        return String.fromCodePoint(codePoint - 96);
      }
      return character;
    }).join("");
  }
  function parseJapaneseNumber(value) {
    return Number(value.replace(
      /[０-９]/g,
      (digit) => String.fromCodePoint(digit.codePointAt(0) - 65248)
    ));
  }
  function normalizeContext(context) {
    return {
      prefix: typeof context?.prefix === "string" ? context.prefix : "",
      suffix: typeof context?.suffix === "string" ? context.suffix : ""
    };
  }
  function startsWithAny(value, candidates) {
    return candidates.some((candidate) => value.startsWith(candidate));
  }
  function endsWithAny(value, candidates) {
    return candidates.some((candidate) => value.endsWith(candidate));
  }
  function normalizeProvidedReading(value) {
    return value.trim().replace(/[\p{Zs}\t]+/gu, "\u30FB").replaceAll("\uFF65", "\u30FB");
  }
  function personRoleImmediatelyFollows(textAfter, roleHints = PERSON_ROLE_HINTS) {
    const withoutHorizontalSpace = textAfter.replace(/^[\p{Zs}\t]+/u, "");
    return startsWithAny(withoutHorizontalSpace, roleHints);
  }
  function personRoleImmediatelyPrecedes(textBefore, roleHints = PERSON_ROLE_HINTS) {
    const withoutHorizontalSpace = textBefore.replace(/[\p{Zs}\t]+$/u, "");
    return roleHints.some(
      (role) => withoutHorizontalSpace.endsWith(role) || withoutHorizontalSpace.endsWith(`${role}\u306E`)
    );
  }
  var COUNTRY_AFFILIATION_PATTERN = /^[\p{Zs}\t]*(?:(?:の|・|、|政府(?:の)?|共産党(?:の)?|国家(?:主席)?(?:の)?|政権(?:の)?|代表(?:の)?|首脳(?:の)?|大統領府(?:の)?)[\p{Zs}\t]*)?$/u;
  function hasCountryHint(entry, contextualText, start, end) {
    const hints = entry ? PERSON_COUNTRY_HINTS[entry.country] : ALL_PERSON_COUNTRY_HINTS;
    const before = contextualText.slice(Math.max(0, start - 36), start);
    const after = contextualText.slice(end, Math.min(contextualText.length, end + 36));
    const lastBoundary = Math.max(
      before.lastIndexOf("\u3002"),
      before.lastIndexOf("\uFF01"),
      before.lastIndexOf("\uFF1F"),
      before.lastIndexOf("!"),
      before.lastIndexOf("?"),
      before.lastIndexOf("\uFF1B"),
      before.lastIndexOf(";"),
      before.lastIndexOf("\n"),
      before.lastIndexOf("\r")
    );
    const sameSentenceBefore = before.slice(lastBoundary + 1);
    const afterBoundary = after.search(/[。！？!?；;\r\n]/u);
    const sameSentenceAfter = afterBoundary === -1 ? after : after.slice(0, afterBoundary);
    return hints.some((hint) => {
      const hintStart = sameSentenceBefore.lastIndexOf(hint);
      if (hintStart !== -1) {
        const between = sameSentenceBefore.slice(hintStart + hint.length);
        if (COUNTRY_AFFILIATION_PATTERN.test(between)) {
          return true;
        }
      }
      const afterName = sameSentenceAfter.replace(/^[\p{Zs}\t、・]+/u, "");
      if (!afterName.startsWith(hint)) {
        return false;
      }
      return personRoleImmediatelyFollows(
        afterName.slice(hint.length),
        entry?.roleHints || PERSON_ROLE_HINTS
      );
    });
  }
  function hasRequiredPersonContext(entry, contextualText, start, end) {
    if (entry.confidence !== "contextual") {
      return true;
    }
    const textBefore = contextualText.slice(0, start);
    const textAfter = contextualText.slice(end);
    return hasCountryHint(entry, contextualText, start, end) || personRoleImmediatelyFollows(textAfter, entry.roleHints) || personRoleImmediatelyPrecedes(textBefore, entry.roleHints);
  }
  function hasPersonNameBoundary(contextualText, start, end, entry = null) {
    const textBefore = contextualText.slice(0, start);
    const textAfter = contextualText.slice(end);
    const boundaryAfter = textAfter.replace(/^[\p{Zs}\t]+/u, "");
    if (entry && startsWithAny(boundaryAfter, entry.blockedSuffixes)) {
      return false;
    }
    const previousCharacter = Array.from(textBefore).at(-1) || "";
    if (SINGLE_KANJI_PATTERN.test(previousCharacter)) {
      const countryHints = entry ? PERSON_COUNTRY_HINTS[entry.country] : ALL_PERSON_COUNTRY_HINTS;
      if (!endsWithAny(textBefore, countryHints)) {
        return false;
      }
    }
    const nextCharacter = Array.from(boundaryAfter)[0] || "";
    if (SINGLE_KANJI_PATTERN.test(nextCharacter)) {
      const allowedSuffixes = entry ? [...PERSON_ROLE_HINTS, ...entry.roleHints] : PERSON_ROLE_HINTS;
      if (!startsWithAny(boundaryAfter, allowedSuffixes)) {
        return false;
      }
    }
    return true;
  }
  function findForeignPersonSurface(surface) {
    return FOREIGN_PERSON_SURFACES.find((candidate) => candidate.surface === surface) || null;
  }
  function findPageProvidedPersonName(text, start, contextualText, contextualOffset) {
    const match = text.slice(start).match(PROVIDED_READING_PATTERN);
    if (!match || CLOSING_PARENTHESIS[match[2]] !== match[4]) {
      return null;
    }
    const surface = match[1];
    const reading = normalizeProvidedReading(match[3]);
    if (!/[\p{Script=Hiragana}\p{Script=Katakana}]/u.test(reading)) {
      return null;
    }
    const known = findForeignPersonSurface(surface);
    const contextualStart = contextualOffset + start;
    const contextualEnd = contextualStart + surface.length;
    if (!hasPersonNameBoundary(contextualText, contextualStart, contextualEnd, known?.entry || null)) {
      return null;
    }
    if (!known) {
      const parentheticalEnd = contextualOffset + start + match[0].length;
      const afterParenthetical = contextualText.slice(parentheticalEnd);
      if (!hasCountryHint(null, contextualText, contextualStart, contextualEnd) || !personRoleImmediatelyFollows(afterParenthetical)) {
        return null;
      }
    }
    return {
      start,
      end: start + surface.length,
      surface,
      reading,
      priority: 3,
      source: "page"
    };
  }
  function findKnownPersonName(text, start, contextualText, contextualOffset) {
    for (const candidate of FOREIGN_PERSON_SURFACES) {
      if (!text.startsWith(candidate.surface, start)) {
        continue;
      }
      const contextualStart = contextualOffset + start;
      const contextualEnd = contextualStart + candidate.surface.length;
      if (hasPersonNameBoundary(contextualText, contextualStart, contextualEnd, candidate.entry) && hasRequiredPersonContext(candidate.entry, contextualText, contextualStart, contextualEnd)) {
        return {
          start,
          end: start + candidate.surface.length,
          surface: candidate.surface,
          reading: candidate.entry.reading,
          priority: 2,
          source: candidate.entry.id
        };
      }
    }
    return null;
  }
  function findCrossBoundaryPersonParts(text, contextualText, contextualOffset) {
    const currentStart = contextualOffset;
    const currentEnd = contextualOffset + text.length;
    const matches = [];
    for (const candidate of FOREIGN_PERSON_SURFACES) {
      let nameStart = contextualText.indexOf(
        candidate.surface,
        Math.max(0, currentStart - candidate.surface.length + 1)
      );
      while (nameStart !== -1 && nameStart < currentEnd) {
        const nameEnd = nameStart + candidate.surface.length;
        const crossesBoundary = nameStart < currentStart || nameEnd > currentEnd;
        if (crossesBoundary && nameEnd > currentStart && hasPersonNameBoundary(contextualText, nameStart, nameEnd, candidate.entry) && hasRequiredPersonContext(candidate.entry, contextualText, nameStart, nameEnd)) {
          const overlapStart = Math.max(nameStart, currentStart);
          const overlapEnd = Math.min(nameEnd, currentEnd);
          const relativeStart = overlapStart - nameStart;
          const overlapSurface = contextualText.slice(overlapStart, overlapEnd);
          const part = candidate.parts.find(
            (item) => item.start === relativeStart && item.surface === overlapSurface
          );
          if (part) {
            matches.push({
              start: overlapStart - currentStart,
              end: overlapEnd - currentStart,
              surface: overlapSurface,
              reading: part.reading,
              priority: 1,
              source: candidate.entry.id
            });
          }
        }
        nameStart = contextualText.indexOf(candidate.surface, nameStart + 1);
      }
    }
    return matches;
  }
  function findForeignPersonNameMatches(text, context) {
    const normalizedContext = normalizeContext(context);
    const contextualText = `${normalizedContext.prefix}${text}${normalizedContext.suffix}`;
    const contextualOffset = normalizedContext.prefix.length;
    const candidates = [];
    for (let start = 0; start < text.length; start += 1) {
      const pageProvided = findPageProvidedPersonName(text, start, contextualText, contextualOffset);
      const known = findKnownPersonName(text, start, contextualText, contextualOffset);
      if (pageProvided) {
        candidates.push(pageProvided);
      } else if (known) {
        candidates.push(known);
      }
    }
    candidates.push(...findCrossBoundaryPersonParts(text, contextualText, contextualOffset));
    candidates.sort(
      (left, right) => left.start - right.start || right.priority - left.priority || right.end - right.start - (left.end - left.start)
    );
    const matches = [];
    let consumedUntil = 0;
    for (const candidate of candidates) {
      if (candidate.start < consumedUntil) {
        continue;
      }
      matches.push(candidate);
      consumedUntil = candidate.end;
    }
    return matches;
  }
  function getSplitCompoundReading(contextualText, contextualStart, surface, currentTextStart, currentTextEnd) {
    const tokenEnd = contextualStart + surface.length;
    for (const compound of SPLIT_COMPOUND_READINGS) {
      let compoundStart = contextualText.indexOf(
        compound.surface,
        Math.max(0, contextualStart - compound.surface.length + 1)
      );
      while (compoundStart !== -1 && compoundStart <= contextualStart) {
        const compoundEnd = compoundStart + compound.surface.length;
        if (tokenEnd <= compoundEnd) {
          const crossesTextBoundary = compoundStart < currentTextStart || compoundEnd > currentTextEnd;
          if (crossesTextBoundary) {
            const relativeStart = contextualStart - compoundStart;
            const matchingPart = compound.parts.find(
              ([partSurface, partStart]) => partStart === relativeStart && partSurface === surface
            );
            if (matchingPart) {
              return matchingPart[2];
            }
          }
        }
        compoundStart = contextualText.indexOf(compound.surface, compoundStart + 1);
      }
    }
    return null;
  }
  function getPairedWeekdayContext(textBefore, textAfter) {
    const closingMatch = textAfter.match(new RegExp(`^${HORIZONTAL_SPACE}([\\)\uFF09])`, "u"));
    if (!closingMatch) {
      return null;
    }
    const japaneseDateMatch = textBefore.match(new RegExp(
      `(?:^|[^0-9\uFF10-\uFF19])([0-9\uFF10-\uFF19]{1,2})\u65E5${HORIZONTAL_SPACE}([\\(\uFF08])${HORIZONTAL_SPACE}$`,
      "u"
    ));
    if (japaneseDateMatch) {
      const dayNumber2 = parseJapaneseNumber(japaneseDateMatch[1]);
      if (dayNumber2 >= 1 && dayNumber2 <= 31 && CLOSING_PARENTHESIS[japaneseDateMatch[2]] === closingMatch[1]) {
        return true;
      }
    }
    const bareDayMatch = textBefore.match(new RegExp(
      `(?:^|[^\\p{Letter}\\p{Number}.\uFF0E/\uFF0F-])([0-9\uFF10-\uFF19]{1,2})${HORIZONTAL_SPACE}([\\(\uFF08])${HORIZONTAL_SPACE}$`,
      "u"
    ));
    if (bareDayMatch) {
      const dayNumber2 = parseJapaneseNumber(bareDayMatch[1]);
      if (dayNumber2 >= 1 && dayNumber2 <= 31 && CLOSING_PARENTHESIS[bareDayMatch[2]] === closingMatch[1]) {
        return true;
      }
    }
    const dottedDateMatch = textBefore.match(new RegExp(
      `(?:^|[^0-9\uFF10-\uFF19])([0-9\uFF10-\uFF19]{1,2})[.\uFF0E/\uFF0F-]([0-9\uFF10-\uFF19]{1,2})${HORIZONTAL_SPACE}([\\(\uFF08])${HORIZONTAL_SPACE}$`,
      "u"
    ));
    if (!dottedDateMatch) {
      return null;
    }
    const monthNumber = parseJapaneseNumber(dottedDateMatch[1]);
    const dayNumber = parseJapaneseNumber(dottedDateMatch[2]);
    return monthNumber >= 1 && monthNumber <= 12 && dayNumber >= 1 && dayNumber <= 31 && CLOSING_PARENTHESIS[dottedDateMatch[3]] === closingMatch[1];
  }
  function getContextualReading(text, tokenStart, surface, context = {}) {
    const normalizedContext = normalizeContext(context);
    const contextualText = `${normalizedContext.prefix}${text}${normalizedContext.suffix}`;
    const contextualStart = normalizedContext.prefix.length + tokenStart;
    const textBefore = contextualText.slice(0, contextualStart);
    const textAfter = contextualText.slice(contextualStart + surface.length);
    const splitCompoundReading = getSplitCompoundReading(
      contextualText,
      contextualStart,
      surface,
      normalizedContext.prefix.length,
      normalizedContext.prefix.length + text.length
    );
    if (splitCompoundReading) {
      return splitCompoundReading;
    }
    if (surface === "\u96E8") {
      const followsHardBoundary = /(?:^|[/／:：|｜、，,（(【「『])[\p{Zs}\t]*$/u.test(textBefore);
      const startsWeatherPair = /^[\p{Zs}\t]*・/u.test(textAfter);
      if (followsHardBoundary && startsWeatherPair) {
        return "\u3042\u3081";
      }
    }
    if (surface === "\u6708") {
      const monthMatch = textBefore.match(/(?:^|[^0-9０-９])([0-9０-９]{1,2})$/u);
      if (monthMatch) {
        const monthNumber = parseJapaneseNumber(monthMatch[1]);
        if (monthNumber >= 1 && monthNumber <= 12) {
          return "\u304C\u3064";
        }
      }
    }
    if (surface === "\u7B11" || surface === "\u6CE3") {
      const openingMatch = textBefore.match(/([\(（])[\p{Zs}\t]*$/u);
      const closingMatch = textAfter.match(/^[\p{Zs}\t]*([\)）])/u);
      if (openingMatch && closingMatch && CLOSING_PARENTHESIS[openingMatch[1]] === closingMatch[1]) {
        return surface === "\u7B11" ? "\u308F\u3089\u3044" : "\u306A\u304D";
      }
    }
    if (surface === "\u8F9B\u3044" && /^[\p{Zs}\t]*(?:焼きそば|料理|食べ物|食品|ラーメン|カレー|味)/u.test(textAfter)) {
      return "\u304B\u3089\u3044";
    }
    if (surface === "\u5F8C" && /^から/u.test(textAfter) && /(?:^|[。．.!！?？、，,（(【「『])[\p{Zs}\t]*$/u.test(textBefore)) {
      return "\u3042\u3068";
    }
    if (surface === "\u7ACB\u3066" && /(?:トピ|スレ)$/u.test(textBefore)) {
      return "\u305F\u3066";
    }
    if (surface === "\u4E3B" && /(?:トピ|スレ)$/u.test(textBefore) && /^(?:さん|様)/u.test(textAfter)) {
      return "\u306C\u3057";
    }
    const weekdayReading = WEEKDAY_ABBREVIATION_READINGS[surface];
    if (!weekdayReading || surface.length !== 1) {
      return null;
    }
    return getPairedWeekdayContext(textBefore, textAfter) ? weekdayReading : null;
  }
  function createTokenEntries(tokens) {
    let start = 0;
    return tokens.map((token) => {
      const entry = {
        token,
        start,
        end: start + token.surface_form.length
      };
      start = entry.end;
      return entry;
    });
  }
  function findExactPhrase(text, start, tokenIndexByStart) {
    for (const [surface, reading] of EXACT_PHRASE_READINGS) {
      if (!text.startsWith(surface, start)) {
        continue;
      }
      const nextTokenIndex = tokenIndexByStart.get(start + surface.length);
      if (nextTokenIndex !== void 0) {
        return { surface, reading, nextTokenIndex };
      }
    }
    return null;
  }
  function followsValidCalendarMonth(textBefore) {
    const match = textBefore.match(/(?:^|[^0-9０-９])([0-9０-９]{1,2})月[\p{Zs}\t]*$/u);
    if (!match) {
      return false;
    }
    const monthNumber = parseJapaneseNumber(match[1]);
    return monthNumber >= 1 && monthNumber <= 12;
  }
  function startsPairedWeekday(textAfter) {
    const match = textAfter.match(/^[\p{Zs}\t]*([\(（])[\p{Zs}\t]*[日月火水木金土][\p{Zs}\t]*([\)）])/u);
    return Boolean(match && CLOSING_PARENTHESIS[match[1]] === match[2]);
  }
  function findSpecialDay(text, start, tokenIndexByStart, context) {
    const match = text.slice(start).match(/^([0-9０-９]{1,2})日(間)?/u);
    if (!match) {
      return null;
    }
    const dayNumber = parseJapaneseNumber(match[1]);
    const ordinaryReading = SPECIAL_DAY_READINGS[dayNumber];
    if (!ordinaryReading) {
      return null;
    }
    const surface = match[0];
    const nextTokenIndex = tokenIndexByStart.get(start + surface.length);
    if (nextTokenIndex === void 0) {
      return null;
    }
    const normalizedContext = normalizeContext(context);
    const textBefore = `${normalizedContext.prefix}${text.slice(0, start)}`;
    const textAfter = `${text.slice(start + surface.length)}${normalizedContext.suffix}`;
    if (!match[2] && textAfter.startsWith("\u672C")) {
      return null;
    }
    if (match[2]) {
      const dayReading = dayNumber === 1 ? "\u3044\u3061\u306B\u3061" : ordinaryReading;
      return { surface, reading: `${dayReading}\u304B\u3093`, nextTokenIndex };
    }
    if (dayNumber === 1) {
      if (followsValidCalendarMonth(textBefore) || startsPairedWeekday(textAfter)) {
        return { surface, reading: ordinaryReading, nextTokenIndex };
      }
      if (/^(?:目|後|前|以内|以上|以下|未満|程度)/u.test(textAfter)) {
        return { surface, reading: "\u3044\u3061\u306B\u3061", nextTokenIndex };
      }
      return null;
    }
    return { surface, reading: ordinaryReading, nextTokenIndex };
  }
  function findPeopleCounter(text, start, tokenIndexByStart, context) {
    const match = text.slice(start).match(/^([12１２一二])人/u);
    if (!match) {
      return null;
    }
    const surface = match[0];
    const nextTokenIndex = tokenIndexByStart.get(start + surface.length);
    if (nextTokenIndex === void 0) {
      return null;
    }
    const normalizedContext = normalizeContext(context);
    const textAfter = `${text.slice(start + surface.length)}${normalizedContext.suffix}`;
    if (/^[称前月日年者物]/u.test(textAfter)) {
      return null;
    }
    return {
      surface,
      reading: PEOPLE_COUNTER_READINGS[match[1]],
      nextTokenIndex
    };
  }
  function findRoundCounter(text, start, tokenIndexByStart, context) {
    const match = text.slice(start).match(/^([一六八十百])回/u);
    if (!match) {
      return null;
    }
    const normalizedContext = normalizeContext(context);
    const previousCharacter = Array.from(`${normalizedContext.prefix}${text.slice(0, start)}`).at(-1) ?? "";
    if (/[一二三四五六七八九十百千万兆]/u.test(previousCharacter)) {
      return null;
    }
    const surface = match[0];
    const nextTokenIndex = tokenIndexByStart.get(start + surface.length);
    if (nextTokenIndex === void 0) {
      return null;
    }
    return {
      surface,
      reading: ROUND_COUNTER_READINGS[match[1]],
      nextTokenIndex
    };
  }
  function buildBaseAnnotationSegments(text, tokenizer, context = {}) {
    if (!containsKanji(text)) {
      return [{ text, reading: null }];
    }
    const tokens = tokenizer.tokenize(text);
    if (tokens.map((token) => token.surface_form).join("") !== text) {
      return [{ text, reading: null }];
    }
    const entries = createTokenEntries(tokens);
    const tokenIndexByStart = new Map(entries.map((entry, index2) => [entry.start, index2]));
    tokenIndexByStart.set(text.length, entries.length);
    const segments = [];
    let index = 0;
    while (index < entries.length) {
      const entry = entries[index];
      const phrase = findExactPhrase(text, entry.start, tokenIndexByStart) ?? findSpecialDay(text, entry.start, tokenIndexByStart, context) ?? findPeopleCounter(text, entry.start, tokenIndexByStart, context) ?? findRoundCounter(text, entry.start, tokenIndexByStart, context);
      if (phrase) {
        segments.push({ text: phrase.surface, reading: phrase.reading });
        index = phrase.nextTokenIndex;
        continue;
      }
      const dictionaryReading = entry.token.reading && entry.token.reading !== "*" ? katakanaToHiragana(entry.token.reading) : null;
      const reading = getContextualReading(text, entry.start, entry.token.surface_form, context) ?? dictionaryReading;
      segments.push({
        text: entry.token.surface_form,
        reading: containsKanji(entry.token.surface_form) ? reading : null
      });
      index += 1;
    }
    return segments;
  }
  function buildAnnotationSegments(text, tokenizer, context = {}) {
    if (!containsKanji(text)) {
      return [{ text, reading: null }];
    }
    const matches = findForeignPersonNameMatches(text, context);
    if (matches.length === 0) {
      return buildBaseAnnotationSegments(text, tokenizer, context);
    }
    const normalizedContext = normalizeContext(context);
    const segments = [];
    let cursor = 0;
    for (const match of matches) {
      if (match.start > cursor) {
        segments.push(...buildBaseAnnotationSegments(
          text.slice(cursor, match.start),
          tokenizer,
          {
            prefix: `${normalizedContext.prefix}${text.slice(0, cursor)}`,
            suffix: `${text.slice(match.start)}${normalizedContext.suffix}`
          }
        ));
      }
      segments.push({ text: match.surface, reading: match.reading });
      cursor = match.end;
    }
    if (cursor < text.length) {
      segments.push(...buildBaseAnnotationSegments(
        text.slice(cursor),
        tokenizer,
        {
          prefix: `${normalizedContext.prefix}${text.slice(0, cursor)}`,
          suffix: normalizedContext.suffix
        }
      ));
    }
    return segments;
  }

  // src/content.js
  var CONTROLLER_KEY = "__japaneseFuriganaAiController__";
  var RUBY_ATTRIBUTE = "data-jp-furigana";
  var FOREIGN_PERSON_RUBY_ATTRIBUTE = "data-jp-foreign-person";
  var STYLE_ID = "jp-furigana-ai-style";
  var TOAST_ID = "jp-furigana-ai-toast";
  var TRANSLATION_CONTROLLER_KEY = "__japaneseSelectionTranslationController__";
  var TRANSLATION_UI_ATTRIBUTE = "data-jp-translation-ui";
  var TRANSLATION_CONTROLLER_ATTRIBUTE = "data-jp-translation-controller";
  var CONTENT_BUILD_VERSION = "2.3.0";
  var MAX_TRANSLATION_CHARACTERS = 12e3;
  var SKIPPED_SELECTOR = [
    "script",
    "style",
    "noscript",
    "textarea",
    "input",
    "select",
    "option",
    "button",
    "code",
    "pre",
    "kbd",
    "samp",
    "ruby",
    "rt",
    "rp",
    "svg",
    "math",
    `[${TRANSLATION_UI_ATTRIBUTE}]`,
    "[hidden]",
    "[aria-hidden='true']",
    "[contenteditable]:not([contenteditable='false'])"
  ].join(",");
  var CONTEXT_CANDIDATE_PATTERN = /[日月火水木金土雨笑泣辛後立主人妊娠高血圧腎症博士課程本研究幹細胞頭頸部浸透初相転移平均場自治厨売時骨髄協働既読公録昨夏中巨非常]/u;
  var CONTEXT_MUTATION_PATTERN = /[()（）0-9０-９日月火水木金土]/u;
  var escapeRegularExpression = (value) => value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  var foreignPersonNameCharacters = [...new Set(
    FOREIGN_PERSON_NAMES.flatMap((entry) => entry.surfaces.flatMap((surface) => Array.from(surface)))
  )];
  var foreignPersonMutationTerms = [.../* @__PURE__ */ new Set([
    ...FOREIGN_PERSON_NAMES.flatMap((entry) => [
      ...entry.surfaces,
      ...entry.roleHints,
      ...entry.blockedSuffixes
    ]),
    ...Object.values(PERSON_COUNTRY_HINTS).flat(),
    ...PERSON_ROLE_HINTS
  ])].filter(Boolean).sort((left, right) => right.length - left.length);
  var FOREIGN_PERSON_CONTEXT_PATTERN = new RegExp(
    foreignPersonNameCharacters.map(escapeRegularExpression).join("|"),
    "u"
  );
  var FOREIGN_PERSON_MUTATION_PATTERN = new RegExp(
    foreignPersonMutationTerms.map(escapeRegularExpression).join("|"),
    "u"
  );
  var FOREIGN_PERSON_SURFACE_PATTERN = new RegExp(
    FOREIGN_PERSON_NAMES.flatMap((entry) => entry.surfaces).sort((left, right) => right.length - left.length).map(escapeRegularExpression).join("|"),
    "u"
  );
  var foreignPersonAnnotationSignatures = new Set(
    FOREIGN_PERSON_NAMES.flatMap((entry) => entry.surfaces.flatMap(
      (surface) => getForeignPersonNameParts(entry, surface).map((part) => `${part.surface}\0${part.reading}`)
    ))
  );
  var CONTEXT_CHARACTER_LIMIT = 48;
  var CONTEXT_NODE_LIMIT = 64;
  var INLINE_DISPLAYS = /* @__PURE__ */ new Set(["inline", "inline-block", "inline-flex", "inline-grid", "contents"]);
  var SEMANTIC_INLINE_TAGS = /* @__PURE__ */ new Set([
    "A",
    "ABBR",
    "B",
    "BDI",
    "BDO",
    "CITE",
    "EM",
    "I",
    "LABEL",
    "MARK",
    "Q",
    "S",
    "SMALL",
    "SPAN",
    "STRONG",
    "SUB",
    "SUP",
    "TIME",
    "U"
  ]);
  var HARD_BOUNDARY_TAGS = /* @__PURE__ */ new Set([
    "BR",
    "HR",
    "IMG",
    "PICTURE",
    "VIDEO",
    "AUDIO",
    "CANVAS",
    "IFRAME",
    "OBJECT",
    "EMBED"
  ]);
  var TRANSLATION_BLOCK_TAGS = /* @__PURE__ */ new Set([
    "ADDRESS",
    "ARTICLE",
    "ASIDE",
    "BLOCKQUOTE",
    "DD",
    "DIV",
    "DL",
    "DT",
    "FIGCAPTION",
    "FIGURE",
    "FOOTER",
    "H1",
    "H2",
    "H3",
    "H4",
    "H5",
    "H6",
    "HEADER",
    "LI",
    "MAIN",
    "NAV",
    "OL",
    "P",
    "SECTION",
    "TABLE",
    "TD",
    "TH",
    "TR",
    "UL"
  ]);
  function containsContextCandidate(value) {
    return CONTEXT_CANDIDATE_PATTERN.test(value) || FOREIGN_PERSON_CONTEXT_PATTERN.test(value);
  }
  function containsContextMutation(value) {
    return CONTEXT_MUTATION_PATTERN.test(value) || FOREIGN_PERSON_MUTATION_PATTERN.test(value);
  }
  function appendSelectionFragmentText(node, chunks) {
    if (node.nodeType === Node.TEXT_NODE) {
      chunks.push(node.nodeValue || "");
      return;
    }
    if (node.nodeType !== Node.ELEMENT_NODE) {
      Array.from(node.childNodes || []).forEach((child) => appendSelectionFragmentText(child, chunks));
      return;
    }
    const element = node;
    if (element.matches(`rt, rp, [${TRANSLATION_UI_ATTRIBUTE}]`) || element.closest(`[${TRANSLATION_UI_ATTRIBUTE}]`)) {
      return;
    }
    if (element.tagName === "BR") {
      chunks.push("\n");
      return;
    }
    Array.from(element.childNodes).forEach((child) => appendSelectionFragmentText(child, chunks));
    if (TRANSLATION_BLOCK_TAGS.has(element.tagName) && !chunks.at(-1)?.endsWith("\n")) {
      chunks.push("\n");
    }
  }
  function getSelectedSourceText(selection, range) {
    const fragment = range.cloneContents();
    if (!fragment.querySelector?.("rt, rp")) {
      return selection.toString().trim();
    }
    const chunks = [];
    Array.from(fragment.childNodes).forEach((node) => appendSelectionFragmentText(node, chunks));
    return chunks.join("").trim();
  }
  function classifySelection(text) {
    const sentenceEndCount = (text.match(/(?:。|[！？!?]+)/gu) || []).length;
    if (/\r|\n/u.test(text) || sentenceEndCount >= 2 || text.length >= 180) {
      return "paragraph";
    }
    if (sentenceEndCount === 1 || /\s/u.test(text) || text.length >= 24) {
      return "sentence";
    }
    return "word";
  }
  function selectionTypeLabel(selectionType) {
    if (selectionType === "paragraph") {
      return "\u6BB5\u843D";
    }
    if (selectionType === "sentence") {
      return "\u53E5\u5B50";
    }
    return "\u8BCD\u8BED";
  }
  function getUsableRangeRect(range) {
    const rects = Array.from(range.getClientRects());
    const rect = [...rects].reverse().find((item) => item.width > 0 || item.height > 0) || range.getBoundingClientRect();
    if (!rect || !rect.width && !rect.height) {
      return null;
    }
    return {
      top: rect.top,
      right: rect.right,
      bottom: rect.bottom,
      left: rect.left,
      width: rect.width,
      height: rect.height
    };
  }
  function sendRuntimeMessage(message) {
    return new Promise((resolve, reject) => {
      let settled = false;
      const finish = (callback, value) => {
        if (settled) {
          return;
        }
        settled = true;
        callback(value);
      };
      try {
        const possiblePromise = chrome.runtime.sendMessage(message, (response) => {
          const runtimeError = chrome.runtime.lastError;
          if (runtimeError) {
            finish(reject, new Error(runtimeError.message));
            return;
          }
          finish(resolve, response);
        });
        if (possiblePromise?.then) {
          possiblePromise.then(
            (response) => finish(resolve, response),
            (error) => finish(reject, error)
          );
        }
      } catch (error) {
        finish(reject, error);
      }
    });
  }
  function normalizeTokenUsage(payload) {
    const usage = payload?.usage || payload?.tokenUsage || payload?.tokens || {};
    const inputTokens = Number(usage.inputTokens ?? usage.input_tokens ?? usage.promptTokens ?? usage.prompt_tokens);
    const outputTokens = Number(usage.outputTokens ?? usage.output_tokens ?? usage.completionTokens ?? usage.completion_tokens);
    const explicitTotal = Number(usage.totalTokens ?? usage.total_tokens ?? usage.total);
    const hasInput = Number.isFinite(inputTokens);
    const hasOutput = Number.isFinite(outputTokens);
    const totalTokens = Number.isFinite(explicitTotal) ? explicitTotal : hasInput || hasOutput ? (hasInput ? inputTokens : 0) + (hasOutput ? outputTokens : 0) : null;
    return {
      inputTokens: hasInput ? inputTokens : null,
      outputTokens: hasOutput ? outputTokens : null,
      totalTokens
    };
  }
  function getTranslationPayload(response) {
    const payload = response?.data || response?.result || response;
    const responseErrorCode = response?.error?.code || response?.code || payload?.error?.code || payload?.code;
    if (!response || response.ok === false || response.success === false || payload?.ok === false || response?.error || /CONFIG_REQUIRED|HOST_PERMISSION_REQUIRED/u.test(String(responseErrorCode || "").toUpperCase())) {
      const errorValue = response?.error || payload?.error || response;
      const error = new Error(
        typeof errorValue === "string" ? errorValue : errorValue?.message || response?.message || "\u7FFB\u8BD1\u670D\u52A1\u6CA1\u6709\u8FD4\u56DE\u6709\u6548\u7ED3\u679C\u3002"
      );
      error.code = errorValue?.code || response?.code || payload?.code || "TRANSLATION_FAILED";
      throw error;
    }
    const translation = payload?.translation ?? payload?.translatedText ?? payload?.translated_text ?? payload?.text ?? payload?.content;
    if (typeof translation !== "string" || !translation.trim()) {
      const error = new Error("\u7FFB\u8BD1\u670D\u52A1\u6CA1\u6709\u8FD4\u56DE\u8BD1\u6587\uFF0C\u8BF7\u91CD\u8BD5\u3002");
      error.code = "EMPTY_TRANSLATION";
      throw error;
    }
    return {
      translation: translation.trim(),
      targetLanguage: payload?.targetLanguage ?? payload?.target_language ?? payload?.target ?? response?.targetLanguage ?? "\u76EE\u6807\u8BED\u8A00",
      selectionType: payload?.selectionType,
      usage: normalizeTokenUsage(payload)
    };
  }
  function sanitizeTranslationErrorMessage(value) {
    return String(value || "").replace(/\b(?:sk|key)-[A-Za-z0-9_-]{8,}\b/giu, "[\u5DF2\u9690\u85CF]").replace(/Bearer\s+[A-Za-z0-9._~+\/-]{8,}/giu, "Bearer [\u5DF2\u9690\u85CF]").slice(0, 240);
  }
  function describeTranslationError(error) {
    const code = String(error?.code || "").toUpperCase();
    const message = sanitizeTranslationErrorMessage(error?.message || error);
    if (/CONFIG_REQUIRED|API_KEY_MISSING|API_KEY_(?:NOT_)?CONFIGURED|NOT_CONFIGURED/u.test(code + message.toUpperCase())) {
      return {
        message: "\u5C1A\u672A\u914D\u7F6E\u7FFB\u8BD1 API\u3002\u8BF7\u6253\u5F00\u7BA1\u7406\u9762\u677F\u586B\u5199 OpenAI \u517C\u5BB9 API Key\u3001BaseURL \u548C\u6A21\u578B\u3002",
        showOptions: true
      };
    }
    if (/HOST_PERMISSION_REQUIRED|HOST_PERMISSION|PERMISSION_DENIED/u.test(code + message.toUpperCase())) {
      return {
        message: "\u5F53\u524D API BaseURL \u5C1A\u672A\u83B7\u5F97\u8BBF\u95EE\u6743\u9650\u3002\u8BF7\u6253\u5F00\u7BA1\u7406\u9762\u677F\u68C0\u67E5\u5730\u5740\u5E76\u5B8C\u6210\u6388\u6743\u3002",
        showOptions: true
      };
    }
    if (/AUTHENTICATION_FAILED|API_ACCESS_DENIED|UNAUTHORIZED|FORBIDDEN|\b401\b|\b403\b/u.test(code + message.toUpperCase())) {
      return {
        message: "API \u9274\u6743\u5931\u8D25\u3002\u8BF7\u6253\u5F00\u7BA1\u7406\u9762\u677F\u68C0\u67E5 API Key\u3001BaseURL \u548C\u670D\u52A1\u6743\u9650\u3002",
        showOptions: true
      };
    }
    if (/EXTENSION CONTEXT INVALIDATED|RECEIVING END DOES NOT EXIST/u.test(message.toUpperCase())) {
      return {
        message: "\u6269\u5C55\u521A\u521A\u66F4\u65B0\uFF0C\u8BF7\u5237\u65B0\u5F53\u524D\u7F51\u9875\u540E\u518D\u8BD5\u3002",
        showOptions: false
      };
    }
    return {
      message: message ? `\u7FFB\u8BD1\u5931\u8D25\uFF1A${message}` : "\u7FFB\u8BD1\u5931\u8D25\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5\u3002",
      showOptions: false
    };
  }
  var SelectionTranslationController = class {
    constructor() {
      this.buildVersion = CONTENT_BUILD_VERSION;
      this.host = null;
      this.shadowRoot = null;
      this.actionButton = null;
      this.card = null;
      this.cardTitle = null;
      this.typeBadge = null;
      this.status = null;
      this.targetRow = null;
      this.targetValue = null;
      this.translation = null;
      this.usage = null;
      this.copyButton = null;
      this.retryButton = null;
      this.optionsButton = null;
      this.lastSelection = null;
      this.lastRequest = null;
      this.lastTranslation = "";
      this.anchorRect = null;
      this.selectionTimer = null;
      this.requestId = 0;
      this.install();
    }
    install() {
      this.ensureUi();
      document.addEventListener("mouseup", (event) => this.handleSelectionEvent(event), true);
      document.addEventListener("keyup", (event) => this.handleSelectionEvent(event), true);
      window.addEventListener("resize", () => this.keepUiInViewport(), { passive: true });
    }
    ensureUi() {
      if (!this.host) {
        this.createUi();
      }
      if (!this.host.isConnected) {
        (document.documentElement || document).append(this.host);
      }
      document.querySelectorAll(
        `[${TRANSLATION_UI_ATTRIBUTE}][aria-live="polite"]:not([role])`
      ).forEach((element) => {
        if (element !== this.host) {
          element.remove();
        }
      });
    }
    createUi() {
      const host = document.createElement("div");
      host.setAttribute(TRANSLATION_UI_ATTRIBUTE, "");
      host.setAttribute(TRANSLATION_CONTROLLER_ATTRIBUTE, "active");
      host.setAttribute("aria-live", "polite");
      for (const [property, value] of Object.entries({
        all: "initial",
        position: "fixed",
        inset: "0 auto auto 0",
        width: "0",
        height: "0",
        overflow: "visible",
        pointerEvents: "none",
        zIndex: "2147483647"
      })) {
        host.style.setProperty(property.replace(/[A-Z]/g, (match) => `-${match.toLowerCase()}`), value, "important");
      }
      const shadowRoot = host.attachShadow({ mode: "closed" });
      const style = document.createElement("style");
      style.textContent = `
      :host { all: initial !important; }
      *, *::before, *::after { box-sizing: border-box; }
      button { font: inherit; }
      [hidden] { display: none !important; }
      .action {
        position: fixed;
        z-index: 2147483647;
        min-height: 36px;
        padding: 8px 13px;
        border: 1px solid rgba(255,255,255,.28);
        border-radius: 999px;
        color: #fff;
        background: #175cd3;
        box-shadow: 0 8px 24px rgba(16,24,40,.28);
        cursor: pointer;
        pointer-events: auto;
        font: 600 13px/1.2 system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
        white-space: nowrap;
      }
      .action:hover { background: #1849a9; }
      .action:focus-visible, .control:focus-visible {
        outline: 3px solid rgba(83,177,253,.55);
        outline-offset: 2px;
      }
      .card {
        position: fixed;
        z-index: 2147483647;
        width: min(390px, calc(100vw - 16px));
        max-height: min(520px, calc(100vh - 16px));
        overflow: auto;
        padding: 15px;
        border: 1px solid #d0d5dd;
        border-radius: 14px;
        color: #101828;
        background: #fff;
        box-shadow: 0 16px 48px rgba(16,24,40,.28);
        pointer-events: auto;
        font: 14px/1.55 system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
        text-align: left;
        word-break: break-word;
      }
      .header { display: flex; align-items: center; gap: 8px; margin-bottom: 12px; }
      .title { flex: 1; margin: 0; color: #101828; font-size: 15px; line-height: 1.3; font-weight: 700; }
      .badge {
        padding: 2px 8px;
        border-radius: 999px;
        color: #1849a9;
        background: #eff8ff;
        font-size: 12px;
        font-weight: 600;
      }
      .close {
        width: 30px;
        height: 30px;
        padding: 0;
        border: 0;
        border-radius: 8px;
        color: #475467;
        background: transparent;
        cursor: pointer;
        font-size: 20px;
        line-height: 1;
      }
      .close:hover { background: #f2f4f7; }
      .status { margin: 0; color: #475467; }
      .status.error { color: #b42318; }
      .target { display: flex; gap: 6px; margin-bottom: 8px; color: #667085; font-size: 12px; }
      .target strong { color: #344054; font-weight: 600; }
      .translation {
        min-height: 44px;
        max-height: 300px;
        overflow: auto;
        padding: 12px;
        border-radius: 10px;
        color: #101828;
        background: #f9fafb;
        white-space: pre-wrap;
        user-select: text;
      }
      .usage { margin-top: 8px; color: #667085; font-size: 12px; }
      .controls { display: flex; flex-wrap: wrap; gap: 8px; margin-top: 13px; }
      .control {
        min-height: 34px;
        padding: 7px 11px;
        border: 1px solid #d0d5dd;
        border-radius: 8px;
        color: #344054;
        background: #fff;
        cursor: pointer;
        font-size: 13px;
        font-weight: 600;
      }
      .control:hover { background: #f9fafb; }
      .control.primary { border-color: #175cd3; color: #fff; background: #175cd3; }
      .control.primary:hover { background: #1849a9; }
      .control:disabled { opacity: .5; cursor: default; }
      .spinner::before {
        content: "";
        display: inline-block;
        width: 12px;
        height: 12px;
        margin-right: 7px;
        border: 2px solid #b2ccff;
        border-top-color: #175cd3;
        border-radius: 50%;
        vertical-align: -2px;
        animation: spin .8s linear infinite;
      }
      @keyframes spin { to { transform: rotate(360deg); } }
    `;
      const actionButton = document.createElement("button");
      actionButton.type = "button";
      actionButton.className = "action";
      actionButton.hidden = true;
      actionButton.textContent = "\u7FFB\u8BD1";
      actionButton.addEventListener("click", () => void this.translateLastSelection());
      const card = document.createElement("section");
      card.className = "card";
      card.hidden = true;
      card.setAttribute("role", "dialog");
      card.setAttribute("aria-label", "\u5212\u8BCD\u7FFB\u8BD1\u7ED3\u679C");
      const header = document.createElement("div");
      header.className = "header";
      const cardTitle = document.createElement("h2");
      cardTitle.className = "title";
      cardTitle.textContent = "\u5212\u8BCD\u7FFB\u8BD1";
      const typeBadge = document.createElement("span");
      typeBadge.className = "badge";
      typeBadge.textContent = "\u8BCD\u8BED";
      const closeButton = document.createElement("button");
      closeButton.type = "button";
      closeButton.className = "close";
      closeButton.setAttribute("aria-label", "\u5173\u95ED\u7FFB\u8BD1\u7ED3\u679C");
      closeButton.textContent = "\xD7";
      closeButton.addEventListener("click", () => this.hideAll());
      header.append(cardTitle, typeBadge, closeButton);
      const status = document.createElement("p");
      status.className = "status";
      status.hidden = true;
      const targetRow = document.createElement("div");
      targetRow.className = "target";
      targetRow.hidden = true;
      const targetLabel = document.createElement("span");
      targetLabel.textContent = "\u76EE\u6807\u8BED\u8A00\uFF1A";
      const targetValue = document.createElement("strong");
      targetRow.append(targetLabel, targetValue);
      const translation = document.createElement("div");
      translation.className = "translation";
      translation.hidden = true;
      translation.setAttribute("role", "document");
      const usage = document.createElement("div");
      usage.className = "usage";
      usage.hidden = true;
      const controls = document.createElement("div");
      controls.className = "controls";
      const copyButton = document.createElement("button");
      copyButton.type = "button";
      copyButton.className = "control primary";
      copyButton.textContent = "\u590D\u5236\u8BD1\u6587";
      copyButton.hidden = true;
      copyButton.addEventListener("click", () => void this.copyTranslation());
      const retryButton = document.createElement("button");
      retryButton.type = "button";
      retryButton.className = "control";
      retryButton.textContent = "\u91CD\u8BD5";
      retryButton.hidden = true;
      retryButton.addEventListener("click", () => void this.retry());
      const optionsButton = document.createElement("button");
      optionsButton.type = "button";
      optionsButton.className = "control";
      optionsButton.textContent = "\u6253\u5F00\u7BA1\u7406\u9762\u677F";
      optionsButton.hidden = true;
      optionsButton.addEventListener("click", () => void this.openOptions());
      controls.append(copyButton, retryButton, optionsButton);
      card.append(header, status, targetRow, translation, usage, controls);
      const protectUiInteraction = (event) => {
        event.stopPropagation();
        if (event.type === "mousedown") {
          event.preventDefault();
        }
      };
      ["pointerdown", "mousedown", "mouseup", "click", "dblclick", "keydown", "keyup"].forEach((type) => {
        shadowRoot.addEventListener(type, protectUiInteraction);
      });
      shadowRoot.append(style, actionButton, card);
      this.host = host;
      this.shadowRoot = shadowRoot;
      this.actionButton = actionButton;
      this.card = card;
      this.cardTitle = cardTitle;
      this.typeBadge = typeBadge;
      this.status = status;
      this.targetRow = targetRow;
      this.targetValue = targetValue;
      this.translation = translation;
      this.usage = usage;
      this.copyButton = copyButton;
      this.retryButton = retryButton;
      this.optionsButton = optionsButton;
    }
    isUiEvent(event) {
      return event.composedPath?.().includes(this.host) || event.target === this.host;
    }
    handleSelectionEvent(event) {
      if (this.isUiEvent(event)) {
        return;
      }
      if (event.type === "keyup" && ["Shift", "Control", "Alt", "Meta"].includes(event.key)) {
        return;
      }
      clearTimeout(this.selectionTimer);
      this.selectionTimer = setTimeout(() => this.updateSelection(), 16);
    }
    updateSelection() {
      this.ensureUi();
      const selection = window.getSelection();
      if (!selection || selection.isCollapsed || selection.rangeCount === 0) {
        this.actionButton.hidden = true;
        return;
      }
      const range = selection.getRangeAt(0);
      const ancestor = range.commonAncestorContainer.nodeType === Node.ELEMENT_NODE ? range.commonAncestorContainer : range.commonAncestorContainer.parentElement;
      if (ancestor?.closest?.(`[${TRANSLATION_UI_ATTRIBUTE}]`)) {
        return;
      }
      const text = getSelectedSourceText(selection, range);
      if (!text) {
        this.actionButton.hidden = true;
        return;
      }
      const anchorRect = getUsableRangeRect(range);
      if (!anchorRect) {
        this.actionButton.hidden = true;
        return;
      }
      const selectionType = classifySelection(text);
      this.lastSelection = { text, selectionType };
      this.anchorRect = anchorRect;
      this.actionButton.textContent = `\u7FFB\u8BD1${selectionTypeLabel(selectionType)}`;
      this.card.hidden = true;
      this.actionButton.hidden = false;
      this.positionElement(this.actionButton, anchorRect);
    }
    positionElement(element, anchorRect = this.anchorRect) {
      if (!anchorRect || element.hidden) {
        return;
      }
      element.style.visibility = "hidden";
      element.style.left = "8px";
      element.style.top = "8px";
      const measured = element.getBoundingClientRect();
      const width = measured.width || (element === this.card ? Math.min(390, window.innerWidth - 16) : 110);
      const height = measured.height || (element === this.card ? 180 : 36);
      const margin = 8;
      const centeredLeft = anchorRect.left + anchorRect.width / 2 - width / 2;
      const left = Math.max(margin, Math.min(centeredLeft, window.innerWidth - width - margin));
      const roomBelow = window.innerHeight - anchorRect.bottom;
      const preferredTop = roomBelow >= height + 12 ? anchorRect.bottom + 8 : anchorRect.top - height - 8;
      const top = Math.max(margin, Math.min(preferredTop, window.innerHeight - height - margin));
      element.style.left = `${Math.round(left)}px`;
      element.style.top = `${Math.round(top)}px`;
      element.style.visibility = "visible";
    }
    keepUiInViewport() {
      if (!this.actionButton?.hidden) {
        this.positionElement(this.actionButton);
      }
      if (!this.card?.hidden) {
        this.positionElement(this.card);
      }
    }
    async translateLastSelection() {
      const selected = this.lastSelection;
      if (!selected?.text.trim()) {
        return;
      }
      this.actionButton.hidden = true;
      this.lastRequest = {
        type: "TRANSLATE_TEXT",
        text: selected.text,
        selectionType: selected.selectionType,
        pageUrl: location.href,
        pageTitle: document.title
      };
      this.typeBadge.textContent = selectionTypeLabel(selected.selectionType);
      this.cardTitle.textContent = "\u5212\u8BCD\u7FFB\u8BD1";
      this.card.hidden = false;
      this.positionElement(this.card);
      if (selected.text.length > MAX_TRANSLATION_CHARACTERS) {
        this.showError(
          `\u9009\u4E2D\u6587\u672C\u5171 ${selected.text.length.toLocaleString()} \u4E2A\u5B57\u7B26\uFF0C\u5355\u6B21\u6700\u591A\u7FFB\u8BD1 ${MAX_TRANSLATION_CHARACTERS.toLocaleString()} \u4E2A\u5B57\u7B26\u3002`,
          false
        );
        return;
      }
      await this.runTranslation(this.lastRequest);
    }
    async runTranslation(request) {
      const currentRequestId = ++this.requestId;
      this.showLoading();
      try {
        const response = await sendRuntimeMessage(request);
        if (currentRequestId !== this.requestId) {
          return;
        }
        const result = getTranslationPayload(response);
        this.showResult(result);
      } catch (error) {
        if (currentRequestId !== this.requestId) {
          return;
        }
        const description = describeTranslationError(error);
        this.showError(description.message, description.showOptions);
      }
    }
    showLoading() {
      this.status.hidden = false;
      this.status.className = "status spinner";
      this.status.textContent = "\u6B63\u5728\u7FFB\u8BD1\u2026";
      this.targetRow.hidden = true;
      this.translation.hidden = true;
      this.translation.textContent = "";
      this.usage.hidden = true;
      this.usage.textContent = "";
      this.copyButton.hidden = true;
      this.retryButton.hidden = true;
      this.optionsButton.hidden = true;
      this.positionElement(this.card);
    }
    showResult(result) {
      this.lastTranslation = result.translation;
      this.status.hidden = true;
      this.status.className = "status";
      this.targetValue.textContent = String(result.targetLanguage || "\u76EE\u6807\u8BED\u8A00");
      this.targetRow.hidden = false;
      this.translation.textContent = result.translation;
      this.translation.hidden = false;
      const usageParts = [];
      if (result.usage.inputTokens !== null) {
        usageParts.push(`\u8F93\u5165 ${result.usage.inputTokens.toLocaleString()}`);
      }
      if (result.usage.outputTokens !== null) {
        usageParts.push(`\u8F93\u51FA ${result.usage.outputTokens.toLocaleString()}`);
      }
      if (result.usage.totalTokens !== null) {
        usageParts.push(`\u5408\u8BA1 ${result.usage.totalTokens.toLocaleString()}`);
      }
      this.usage.textContent = usageParts.length ? `Token\uFF1A${usageParts.join(" \xB7 ")}` : "Token\uFF1A\u670D\u52A1\u672A\u8FD4\u56DE\u6D88\u8017\u6570\u636E";
      this.usage.hidden = false;
      this.copyButton.hidden = false;
      this.copyButton.disabled = false;
      this.copyButton.textContent = "\u590D\u5236\u8BD1\u6587";
      this.retryButton.hidden = false;
      this.optionsButton.hidden = true;
      this.positionElement(this.card);
    }
    showError(message, showOptions) {
      this.lastTranslation = "";
      this.status.hidden = false;
      this.status.className = "status error";
      this.status.textContent = message;
      this.targetRow.hidden = true;
      this.translation.hidden = true;
      this.translation.textContent = "";
      this.usage.hidden = true;
      this.copyButton.hidden = true;
      this.retryButton.hidden = false;
      this.optionsButton.hidden = !showOptions;
      this.positionElement(this.card);
    }
    async retry() {
      if (!this.lastRequest || this.lastRequest.text.length > MAX_TRANSLATION_CHARACTERS) {
        return;
      }
      await this.runTranslation(this.lastRequest);
    }
    async copyTranslation() {
      if (!this.lastTranslation) {
        return;
      }
      let copied = false;
      try {
        await navigator.clipboard.writeText(this.lastTranslation);
        copied = true;
      } catch (_error) {
        const fallback = document.createElement("textarea");
        fallback.value = this.lastTranslation;
        fallback.setAttribute("aria-hidden", "true");
        Object.assign(fallback.style, {
          position: "fixed",
          left: "-9999px",
          width: "1px",
          height: "1px",
          opacity: "0"
        });
        this.shadowRoot.append(fallback);
        fallback.select();
        try {
          copied = document.execCommand("copy");
        } finally {
          fallback.remove();
        }
      }
      if (copied) {
        this.copyButton.textContent = "\u5DF2\u590D\u5236";
        setTimeout(() => {
          if (this.copyButton) {
            this.copyButton.textContent = "\u590D\u5236\u8BD1\u6587";
          }
        }, 1600);
      } else {
        this.copyButton.textContent = "\u590D\u5236\u5931\u8D25";
      }
    }
    async openOptions() {
      this.optionsButton.disabled = true;
      this.optionsButton.textContent = "\u6B63\u5728\u6253\u5F00\u2026";
      try {
        await sendRuntimeMessage({ type: "OPEN_TRANSLATION_OPTIONS" });
        this.optionsButton.textContent = "\u5DF2\u6253\u5F00\u7BA1\u7406\u9762\u677F";
      } catch (error) {
        this.status.hidden = false;
        this.status.className = "status error";
        this.status.textContent = describeTranslationError(error).message;
        this.optionsButton.textContent = "\u6253\u5F00\u7BA1\u7406\u9762\u677F";
      } finally {
        this.optionsButton.disabled = false;
      }
    }
    hideAll() {
      this.requestId += 1;
      this.actionButton.hidden = true;
      this.card.hidden = true;
    }
  };
  function getDisplay(element, displayCache) {
    if (!displayCache.has(element)) {
      displayCache.set(element, getComputedStyle(element).display);
    }
    return displayCache.get(element);
  }
  function findInlineContextBoundaryFromElement(element, displayCache) {
    let current = element;
    let boundary = current;
    while (current && current !== document.body && current !== document.documentElement) {
      boundary = current;
      if (!SEMANTIC_INLINE_TAGS.has(current.tagName) && !INLINE_DISPLAYS.has(getDisplay(current, displayCache))) {
        break;
      }
      current = current.parentElement;
    }
    return boundary;
  }
  function findInlineContextBoundary(node, displayCache) {
    return findInlineContextBoundaryFromElement(node.parentElement, displayCache);
  }
  function getContextRefreshRoot(target, displayCache) {
    let element = target.nodeType === Node.TEXT_NODE ? target.parentElement : target;
    if (!(element instanceof Element)) {
      return null;
    }
    const pluginRuby = element.closest(`ruby[${RUBY_ATTRIBUTE}]`);
    if (pluginRuby) {
      pluginRuby.dataset.jpOriginal = pluginRuby.firstChild?.textContent || pluginRuby.dataset.jpOriginal || "";
      element = pluginRuby.parentElement;
    }
    const boundary = findInlineContextBoundaryFromElement(element, displayCache);
    if (!boundary || ["HTML", "BODY", "MAIN", "ARTICLE", "SECTION", "UL", "OL", "TABLE"].includes(boundary.tagName) || (boundary.textContent?.length || 0) > 512) {
      return null;
    }
    return boundary;
  }
  function collectMutationSourceText(node, limit = 512) {
    if (!node || limit <= 0) {
      return "";
    }
    if (node.nodeType === Node.TEXT_NODE) {
      return (node.nodeValue || "").slice(0, limit);
    }
    if (node.nodeType !== Node.ELEMENT_NODE) {
      return "";
    }
    if (node.matches(`ruby[${RUBY_ATTRIBUTE}]`)) {
      return (node.dataset.jpOriginal || node.firstChild?.textContent || "").slice(0, limit);
    }
    if (node.matches("rt, rp")) {
      return "";
    }
    let result = "";
    for (const child of node.childNodes) {
      result += collectMutationSourceText(child, limit - result.length);
      if (result.length >= limit) {
        break;
      }
    }
    return result;
  }
  function mutationNodesContainContext(nodeList) {
    return Array.from(nodeList).some(
      (node) => containsContextMutation(collectMutationSourceText(node))
    );
  }
  function mutationNodesContainForeignNameCharacter(nodeList) {
    return Array.from(nodeList).some(
      (node) => FOREIGN_PERSON_CONTEXT_PATTERN.test(collectMutationSourceText(node))
    );
  }
  function contextualRootContainsForeignPerson(root) {
    return FOREIGN_PERSON_SURFACE_PATTERN.test(collectMutationSourceText(root));
  }
  function getElementDisposition(element, boundary, displayCache) {
    if (element.matches(`ruby[${RUBY_ATTRIBUTE}]`)) {
      return "plugin-ruby";
    }
    if (element.matches(SKIPPED_SELECTOR) || HARD_BOUNDARY_TAGS.has(element.tagName)) {
      return "barrier";
    }
    if (element === boundary || SEMANTIC_INLINE_TAGS.has(element.tagName) || INLINE_DISPLAYS.has(getDisplay(element, displayCache))) {
      return "inline";
    }
    return "barrier";
  }
  function normalizeAdjacentText(value) {
    return value.replace(/[\r\n\f]+/g, " ");
  }
  function nextNodeAfter(node, boundary) {
    let current = node;
    while (current && current !== boundary) {
      if (current.nextSibling) {
        return current.nextSibling;
      }
      current = current.parentNode;
    }
    return null;
  }
  function previousNodeBefore(node, boundary) {
    let current = node;
    while (current && current !== boundary) {
      if (current.previousSibling) {
        return current.previousSibling;
      }
      current = current.parentNode;
    }
    return null;
  }
  function collectFollowingContext(node, boundary, displayCache) {
    let current = nextNodeAfter(node, boundary);
    let result = "";
    let visitedNodes = 0;
    while (current && visitedNodes < CONTEXT_NODE_LIMIT && result.length < CONTEXT_CHARACTER_LIMIT) {
      visitedNodes += 1;
      if (current.nodeType === Node.TEXT_NODE) {
        result += normalizeAdjacentText(current.nodeValue || "");
        current = nextNodeAfter(current, boundary);
        continue;
      }
      if (current.nodeType !== Node.ELEMENT_NODE) {
        current = nextNodeAfter(current, boundary);
        continue;
      }
      const disposition = getElementDisposition(current, boundary, displayCache);
      if (disposition === "barrier") {
        break;
      }
      if (disposition === "plugin-ruby") {
        result += normalizeAdjacentText(current.dataset.jpOriginal || "");
        current = nextNodeAfter(current, boundary);
        continue;
      }
      current = current.firstChild || nextNodeAfter(current, boundary);
    }
    return result.slice(0, CONTEXT_CHARACTER_LIMIT);
  }
  function collectPrecedingContext(node, boundary, displayCache) {
    let current = previousNodeBefore(node, boundary);
    let result = "";
    let visitedNodes = 0;
    while (current && visitedNodes < CONTEXT_NODE_LIMIT && result.length < CONTEXT_CHARACTER_LIMIT) {
      visitedNodes += 1;
      if (current.nodeType === Node.TEXT_NODE) {
        result = `${normalizeAdjacentText(current.nodeValue || "")}${result}`;
        current = previousNodeBefore(current, boundary);
        continue;
      }
      if (current.nodeType !== Node.ELEMENT_NODE) {
        current = previousNodeBefore(current, boundary);
        continue;
      }
      const disposition = getElementDisposition(current, boundary, displayCache);
      if (disposition === "barrier") {
        break;
      }
      if (disposition === "plugin-ruby") {
        result = `${normalizeAdjacentText(current.dataset.jpOriginal || "")}${result}`;
        current = previousNodeBefore(current, boundary);
        continue;
      }
      current = current.lastChild || previousNodeBefore(current, boundary);
    }
    return result.slice(-CONTEXT_CHARACTER_LIMIT);
  }
  function collectAdjacentInlineContext(node, displayCache) {
    if (!containsContextCandidate(node.nodeValue || "")) {
      return { prefix: "", suffix: "" };
    }
    const boundary = findInlineContextBoundary(node, displayCache);
    if (!boundary) {
      return { prefix: "", suffix: "" };
    }
    return {
      prefix: collectPrecedingContext(node, boundary, displayCache),
      suffix: collectFollowingContext(node, boundary, displayCache)
    };
  }
  var FuriganaController = class {
    constructor() {
      this.buildVersion = CONTENT_BUILD_VERSION;
      this.phase = "idle";
      this.count = 0;
      this.errorMessage = "";
      this.tokenizer = null;
      this.tokenizerPromise = null;
      this.observer = null;
      this.pendingRoots = /* @__PURE__ */ new Set();
      this.pendingContextRefreshRoots = /* @__PURE__ */ new Set();
      this.flushTimer = null;
      this.runId = 0;
    }
    getStatus() {
      if (this.phase === "enabled") {
        this.syncCount();
      }
      return {
        phase: this.phase,
        enabled: this.phase === "enabled",
        count: this.count,
        message: this.errorMessage
      };
    }
    async toggle() {
      if (this.phase === "enabled" || this.phase === "loading") {
        this.disable();
        return this.getStatus();
      }
      await this.enable();
      return this.getStatus();
    }
    async enable() {
      if (this.phase === "enabled" || this.phase === "loading") {
        return;
      }
      const currentRun = ++this.runId;
      this.phase = "loading";
      this.errorMessage = "";
      this.showToast("\u6B63\u5728\u672C\u5730\u5206\u6790\u65E5\u8BED\u8BFB\u97F3\u2026", "loading", 0);
      this.installStyle();
      try {
        const tokenizer = await this.getTokenizer();
        if (currentRun !== this.runId) {
          return;
        }
        this.count = 0;
        this.processRoot(document.body || document.documentElement, tokenizer);
        this.startObserver();
        this.phase = "enabled";
        this.showToast(`\u5DF2\u6807\u6CE8 ${this.count} \u5904\u6C49\u5B57\u8BFB\u97F3`, "success");
      } catch (error) {
        if (currentRun !== this.runId) {
          return;
        }
        this.phase = "error";
        this.tokenizerPromise = null;
        this.errorMessage = error instanceof Error ? error.message : String(error);
        this.removeStyle();
        this.showToast(`\u6807\u6CE8\u5931\u8D25\uFF1A${this.errorMessage}`, "error", 6e3);
        console.error("[\u65E5\u8BED\u6C49\u5B57 AI \u8BFB\u97F3\u52A9\u624B]", error);
      }
    }
    disable() {
      this.runId += 1;
      this.observer?.disconnect();
      this.observer = null;
      this.pendingRoots.clear();
      this.pendingContextRefreshRoots.clear();
      if (this.flushTimer !== null) {
        clearTimeout(this.flushTimer);
        this.flushTimer = null;
      }
      const changedParents = /* @__PURE__ */ new Set();
      document.querySelectorAll(`ruby[${RUBY_ATTRIBUTE}]`).forEach((ruby) => {
        if (ruby.parentNode) {
          changedParents.add(ruby.parentNode);
        }
        ruby.replaceWith(document.createTextNode(ruby.dataset.jpOriginal || ruby.firstChild?.textContent || ""));
      });
      changedParents.forEach((parent) => parent.normalize());
      this.removeStyle();
      this.count = 0;
      this.phase = "idle";
      this.errorMessage = "";
      this.showToast("\u5DF2\u79FB\u9664\u8BFB\u97F3\u6807\u6CE8", "success");
    }
    getTokenizer() {
      if (this.tokenizer) {
        return Promise.resolve(this.tokenizer);
      }
      if (!this.tokenizerPromise) {
        const dictionaryPath = chrome.runtime.getURL("dict/");
        this.tokenizerPromise = new Promise((resolve, reject) => {
          import_kuromoji.default.builder({ dicPath: dictionaryPath }).build((error, tokenizer) => {
            if (error) {
              reject(error);
              return;
            }
            this.tokenizer = tokenizer;
            resolve(tokenizer);
          });
        });
      }
      return this.tokenizerPromise;
    }
    processRoot(root, tokenizer = this.tokenizer) {
      if (!root || !tokenizer) {
        return;
      }
      if (root.nodeType === Node.TEXT_NODE) {
        if (!this.isEligibleTextNode(root)) {
          return;
        }
        this.processTextNode(root, tokenizer, collectAdjacentInlineContext(root, /* @__PURE__ */ new WeakMap()));
        return;
      }
      if (!(root instanceof Element || root instanceof Document || root instanceof DocumentFragment)) {
        return;
      }
      if (root instanceof Element && root.matches(SKIPPED_SELECTOR)) {
        return;
      }
      const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
        acceptNode: (node) => this.isEligibleTextNode(node) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT
      });
      const nodes = [];
      while (walker.nextNode()) {
        nodes.push(walker.currentNode);
      }
      const displayCache = /* @__PURE__ */ new WeakMap();
      const jobs = nodes.map((node) => ({
        node,
        context: collectAdjacentInlineContext(node, displayCache)
      }));
      jobs.forEach(({ node, context }) => this.processTextNode(node, tokenizer, context));
    }
    isEligibleTextNode(node) {
      if (!node.nodeValue || !containsKanji(node.nodeValue)) {
        return false;
      }
      const parent = node.parentElement;
      return Boolean(parent && !parent.closest(SKIPPED_SELECTOR));
    }
    processTextNode(node, tokenizer, context = {}) {
      if (!node.isConnected || !this.isEligibleTextNode(node)) {
        return;
      }
      const originalText = node.nodeValue;
      const segments = buildAnnotationSegments(originalText, tokenizer, context);
      if (!segments.some((segment) => segment.reading)) {
        return;
      }
      const fragment = document.createDocumentFragment();
      for (const segment of segments) {
        if (!segment.reading) {
          fragment.append(document.createTextNode(segment.text));
          continue;
        }
        const ruby = document.createElement("ruby");
        ruby.setAttribute(RUBY_ATTRIBUTE, "");
        if (foreignPersonAnnotationSignatures.has(`${segment.text}\0${segment.reading}`)) {
          ruby.setAttribute(FOREIGN_PERSON_RUBY_ATTRIBUTE, "");
        }
        ruby.dataset.jpOriginal = segment.text;
        ruby.append(document.createTextNode(segment.text));
        const rt = document.createElement("rt");
        rt.textContent = segment.reading;
        ruby.append(rt);
        fragment.append(ruby);
        this.count += 1;
      }
      node.replaceWith(fragment);
    }
    syncCount() {
      this.count = document.querySelectorAll(`ruby[${RUBY_ATTRIBUTE}]`).length;
    }
    refreshContextualRoot(root, tokenizer = this.tokenizer) {
      if (!root?.isConnected || !tokenizer || !(root instanceof Element)) {
        return;
      }
      const changedParents = /* @__PURE__ */ new Set();
      root.querySelectorAll(`ruby[${RUBY_ATTRIBUTE}]`).forEach((ruby) => {
        const original = ruby.dataset.jpOriginal || ruby.firstChild?.textContent || "";
        if (!containsContextCandidate(original)) {
          return;
        }
        if (ruby.parentNode) {
          changedParents.add(ruby.parentNode);
        }
        ruby.replaceWith(document.createTextNode(original));
      });
      if (changedParents.size === 0) {
        return;
      }
      changedParents.forEach((parent) => parent.normalize());
      this.processRoot(root, tokenizer);
    }
    observeDocumentChanges() {
      this.observer?.observe(document.body || document.documentElement, {
        childList: true,
        subtree: true,
        characterData: true,
        characterDataOldValue: true
      });
    }
    startObserver() {
      this.observer?.disconnect();
      this.observer = new MutationObserver((mutations) => {
        const displayCache = /* @__PURE__ */ new WeakMap();
        for (const mutation of mutations) {
          if (mutation.type === "characterData") {
            this.pendingRoots.add(mutation.target);
            const currentValue = mutation.target.nodeValue || "";
            const oldValue = mutation.oldValue || "";
            const directContextChange2 = containsContextMutation(currentValue) || containsContextMutation(oldValue);
            const personCharacterChange2 = FOREIGN_PERSON_CONTEXT_PATTERN.test(currentValue) || FOREIGN_PERSON_CONTEXT_PATTERN.test(oldValue);
            if (directContextChange2 || personCharacterChange2) {
              const refreshRoot = getContextRefreshRoot(mutation.target, displayCache);
              if (refreshRoot && (directContextChange2 || contextualRootContainsForeignPerson(refreshRoot) || FOREIGN_PERSON_CONTEXT_PATTERN.test(oldValue) && Boolean(refreshRoot.querySelector(
                `ruby[${RUBY_ATTRIBUTE}][${FOREIGN_PERSON_RUBY_ATTRIBUTE}]`
              )))) {
                this.pendingContextRefreshRoots.add(refreshRoot);
              }
            }
            continue;
          }
          mutation.addedNodes.forEach((node) => this.pendingRoots.add(node));
          const directContextChange = mutationNodesContainContext(mutation.addedNodes) || mutationNodesContainContext(mutation.removedNodes);
          const personCharacterChange = mutationNodesContainForeignNameCharacter(mutation.addedNodes) || mutationNodesContainForeignNameCharacter(mutation.removedNodes);
          if (directContextChange || personCharacterChange) {
            const refreshRoot = getContextRefreshRoot(mutation.target, displayCache);
            if (refreshRoot && (directContextChange || contextualRootContainsForeignPerson(refreshRoot) || mutationNodesContainForeignNameCharacter(mutation.removedNodes) && Boolean(refreshRoot.querySelector(
              `ruby[${RUBY_ATTRIBUTE}][${FOREIGN_PERSON_RUBY_ATTRIBUTE}]`
            )))) {
              this.pendingContextRefreshRoots.add(refreshRoot);
            }
          }
        }
        this.scheduleFlush();
      });
      this.observeDocumentChanges();
    }
    scheduleFlush() {
      if (this.flushTimer !== null || this.phase !== "enabled") {
        return;
      }
      this.flushTimer = setTimeout(() => {
        this.flushTimer = null;
        const roots = Array.from(this.pendingRoots);
        const refreshRoots = Array.from(this.pendingContextRefreshRoots);
        this.pendingRoots.clear();
        this.pendingContextRefreshRoots.clear();
        this.observer?.disconnect();
        try {
          refreshRoots.forEach((root) => this.refreshContextualRoot(root));
          roots.forEach((root) => this.processRoot(root));
          this.syncCount();
        } finally {
          if (this.phase === "enabled") {
            this.observeDocumentChanges();
          }
        }
      }, 60);
    }
    installStyle() {
      if (document.getElementById(STYLE_ID)) {
        return;
      }
      const style = document.createElement("style");
      style.id = STYLE_ID;
      style.textContent = `
      ruby[${RUBY_ATTRIBUTE}] { ruby-position: over; }
      ruby[${RUBY_ATTRIBUTE}] > rt {
        font-size: 0.55em;
        line-height: 1;
        color: #b42318;
        font-weight: 600;
        user-select: none;
      }
    `;
      (document.head || document.documentElement).append(style);
    }
    removeStyle() {
      document.getElementById(STYLE_ID)?.remove();
    }
    showToast(message, kind = "success", duration = 2600) {
      let toast = document.getElementById(TOAST_ID);
      if (!toast) {
        toast = document.createElement("div");
        toast.id = TOAST_ID;
        toast.setAttribute(TRANSLATION_UI_ATTRIBUTE, "");
        toast.setAttribute("role", "status");
        Object.assign(toast.style, {
          position: "fixed",
          zIndex: "2147483647",
          top: "18px",
          right: "18px",
          maxWidth: "340px",
          padding: "12px 16px",
          borderRadius: "10px",
          color: "#fff",
          font: "600 14px/1.45 system-ui, sans-serif",
          boxShadow: "0 8px 28px rgba(0, 0, 0, .24)",
          transition: "opacity .2s ease",
          pointerEvents: "none"
        });
        document.documentElement.append(toast);
      }
      toast.style.background = kind === "error" ? "#b42318" : kind === "loading" ? "#344054" : "#067647";
      toast.style.opacity = "1";
      toast.textContent = message;
      clearTimeout(toast.__jpFuriganaTimer);
      if (duration > 0) {
        toast.__jpFuriganaTimer = setTimeout(() => {
          toast.style.opacity = "0";
          setTimeout(() => toast.remove(), 220);
        }, duration);
      }
    }
  };
  if (globalThis[TRANSLATION_CONTROLLER_KEY]?.buildVersion !== CONTENT_BUILD_VERSION) {
    globalThis[TRANSLATION_CONTROLLER_KEY] = new SelectionTranslationController();
  }
  if (globalThis[CONTROLLER_KEY]?.buildVersion !== CONTENT_BUILD_VERSION) {
    const controller = new FuriganaController();
    globalThis[CONTROLLER_KEY] = controller;
    chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
      if (message?.type === "GET_FURIGANA_STATUS") {
        sendResponse(controller.getStatus());
        return false;
      }
      if (message?.type === "TOGGLE_FURIGANA") {
        controller.toggle().then(sendResponse);
        return true;
      }
      return false;
    });
    void controller.enable();
  }
})();
