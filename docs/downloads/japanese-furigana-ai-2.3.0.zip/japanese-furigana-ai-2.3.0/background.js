"use strict";
(() => {
  // src/translation-core.mjs
  var DEFAULT_TRANSLATION_SETTINGS = Object.freeze({
    baseUrl: "https://api.openai.com/v1",
    model: "gpt-4o-mini",
    targetLanguage: "zh-CN",
    uiLanguage: "zh-CN"
  });
  var MAX_TRANSLATION_TEXT_LENGTH = 12e3;
  var MAX_TRANSLATION_OUTPUT_LENGTH = 48e3;
  var MAX_API_RESPONSE_BYTES = 2 * 1024 * 1024;
  var MAX_BASE_URL_LENGTH = 2048;
  var MAX_API_KEY_LENGTH = 4096;
  var MAX_TRANSLATION_HISTORY = 500;
  var MAX_TOKEN_USAGE_RECORDS = 1e3;
  var MAX_TRANSLATION_HISTORY_BYTES = 4 * 1024 * 1024;
  var MAX_TOKEN_USAGE_BYTES = 512 * 1024;
  var TRANSLATION_REQUEST_TIMEOUT_MS = 45e3;
  var SELECTION_TYPES = /* @__PURE__ */ new Set(["word", "sentence", "paragraph", "selection"]);
  var SUPPORTED_UI_LANGUAGES = Object.freeze(["zh-CN", "en", "ja", "ko"]);
  var SUPPORTED_UI_LANGUAGE_SET = new Set(SUPPORTED_UI_LANGUAGES);
  var TARGET_LANGUAGE_NAMES = Object.freeze({
    "zh-CN": "Simplified Chinese",
    "zh-TW": "Traditional Chinese",
    en: "English",
    ko: "Korean",
    ja: "Japanese",
    fr: "French",
    de: "German",
    es: "Spanish",
    it: "Italian",
    pt: "Portuguese",
    ru: "Russian",
    th: "Thai",
    vi: "Vietnamese",
    id: "Indonesian"
  });
  var TranslationError = class extends Error {
    constructor(code, message) {
      super(message);
      this.name = "TranslationError";
      this.code = code;
    }
  };
  function cleanString(value, maximumLength = Number.POSITIVE_INFINITY) {
    return typeof value === "string" ? value.trim().slice(0, maximumLength) : "";
  }
  function finiteTokenCount(value) {
    const number = Number(value);
    return Number.isFinite(number) && number > 0 ? Math.floor(number) : 0;
  }
  function validateBaseUrl(value) {
    const input = cleanString(value || DEFAULT_TRANSLATION_SETTINGS.baseUrl);
    if (input.length > MAX_BASE_URL_LENGTH || /[\u0000-\u001f\u007f]/u.test(input)) {
      throw new TranslationError("INVALID_BASE_URL", "BaseURL \u957F\u5EA6\u6216\u5B57\u7B26\u65E0\u6548");
    }
    let url;
    try {
      url = new URL(input);
    } catch {
      throw new TranslationError("INVALID_BASE_URL", "BaseURL \u4E0D\u662F\u6709\u6548\u7684\u7F51\u5740");
    }
    if (url.username || url.password || url.search || url.hash) {
      throw new TranslationError(
        "INVALID_BASE_URL",
        "BaseURL \u4E0D\u80FD\u5305\u542B\u8D26\u53F7\u3001\u5BC6\u7801\u3001\u67E5\u8BE2\u53C2\u6570\u6216\u7247\u6BB5"
      );
    }
    const hostname = url.hostname.toLowerCase();
    if (hostname.startsWith("[") || hostname.includes(":")) {
      throw new TranslationError("INVALID_BASE_URL", "\u6682\u4E0D\u652F\u6301 IPv6 BaseURL");
    }
    const localHttp = url.protocol === "http:" && (hostname === "localhost" || hostname === "127.0.0.1");
    if (url.protocol !== "https:" && !localHttp) {
      throw new TranslationError(
        "INSECURE_BASE_URL",
        "BaseURL \u5FC5\u987B\u4F7F\u7528 HTTPS\uFF1B\u4EC5 localhost \u6216 127.0.0.1 \u53EF\u4F7F\u7528 HTTP"
      );
    }
    const normalizedPath = url.pathname.replace(/\/+$/u, "");
    url.pathname = normalizedPath || "/";
    return url.toString().replace(/\/$/u, "");
  }
  function buildChatCompletionsUrl(baseUrl) {
    const normalized = validateBaseUrl(baseUrl);
    if (/\/chat\/completions$/u.test(new URL(normalized).pathname)) {
      return normalized;
    }
    return `${normalized}/chat/completions`;
  }
  function getApiOriginPattern(baseUrl) {
    const url = new URL(validateBaseUrl(baseUrl));
    return `${url.protocol}//${url.hostname}/*`;
  }
  function validateModel(value) {
    const model = cleanString(value || DEFAULT_TRANSLATION_SETTINGS.model);
    if (!model || model.length > 160 || /[\u0000-\u001f\u007f]/u.test(model)) {
      throw new TranslationError("INVALID_MODEL", "\u6A21\u578B\u540D\u79F0\u65E0\u6548");
    }
    return model;
  }
  function validateApiKey(value) {
    const apiKey = cleanString(value);
    if (apiKey.length > MAX_API_KEY_LENGTH || /[\u0000-\u001f\u007f]/u.test(apiKey)) {
      throw new TranslationError("INVALID_API_KEY", "API Key \u957F\u5EA6\u6216\u5B57\u7B26\u65E0\u6548");
    }
    return apiKey;
  }
  function validateTargetLanguage(value) {
    const targetLanguage = cleanString(value || DEFAULT_TRANSLATION_SETTINGS.targetLanguage);
    if (!/^[A-Za-z]{2,3}(?:-[A-Za-z0-9]{2,8})*$/u.test(targetLanguage)) {
      throw new TranslationError("INVALID_TARGET_LANGUAGE", "\u76EE\u6807\u8BED\u8A00\u4EE3\u7801\u65E0\u6548");
    }
    return targetLanguage;
  }
  function validateUiLanguage(value) {
    const uiLanguage = cleanString(value || DEFAULT_TRANSLATION_SETTINGS.uiLanguage);
    if (!SUPPORTED_UI_LANGUAGE_SET.has(uiLanguage)) {
      throw new TranslationError("INVALID_UI_LANGUAGE", "\u7BA1\u7406\u9762\u677F\u754C\u9762\u8BED\u8A00\u65E0\u6548");
    }
    return uiLanguage;
  }
  function normalizeStoredSettings(value = {}) {
    const source = value && typeof value === "object" ? value : {};
    const storedUiLanguage = cleanString(source.uiLanguage);
    return {
      baseUrl: cleanString(source.baseUrl) || DEFAULT_TRANSLATION_SETTINGS.baseUrl,
      model: cleanString(source.model) || DEFAULT_TRANSLATION_SETTINGS.model,
      targetLanguage: cleanString(source.targetLanguage) || DEFAULT_TRANSLATION_SETTINGS.targetLanguage,
      uiLanguage: SUPPORTED_UI_LANGUAGE_SET.has(storedUiLanguage) ? storedUiLanguage : DEFAULT_TRANSLATION_SETTINGS.uiLanguage,
      apiKey: cleanString(source.apiKey)
    };
  }
  function mergeTranslationSettings(current = {}, changes = {}) {
    const existing = normalizeStoredSettings(current);
    const input = changes && typeof changes === "object" ? changes : {};
    const clearingApiKey = input.clearApiKey === true || input.apiKeyAction === "clear";
    let apiKey;
    if (clearingApiKey) {
      apiKey = "";
    } else if (typeof input.apiKey === "string" && input.apiKey.trim()) {
      apiKey = validateApiKey(input.apiKey);
    } else {
      apiKey = validateApiKey(existing.apiKey);
    }
    let baseUrl = validateBaseUrl(input.baseUrl ?? existing.baseUrl);
    let model = validateModel(input.model ?? existing.model);
    if (clearingApiKey) {
      if (existing.apiKey && baseUrl.includes(existing.apiKey)) {
        baseUrl = DEFAULT_TRANSLATION_SETTINGS.baseUrl;
      }
      if (existing.apiKey && model.includes(existing.apiKey)) {
        model = DEFAULT_TRANSLATION_SETTINGS.model;
      }
    } else {
      const configuredSecrets = [...new Set([existing.apiKey, apiKey].filter(Boolean))];
      if (configuredSecrets.some((secret) => baseUrl.includes(secret) || model.includes(secret))) {
        throw new TranslationError(
          "SENSITIVE_SETTING_REJECTED",
          "BaseURL \u6216\u6A21\u578B\u540D\u79F0\u4E0D\u80FD\u5305\u542B\u5F53\u524D\u6216\u4E4B\u524D\u7684 API Key"
        );
      }
    }
    return {
      baseUrl,
      model,
      targetLanguage: validateTargetLanguage(input.targetLanguage ?? existing.targetLanguage),
      uiLanguage: validateUiLanguage(input.uiLanguage ?? existing.uiLanguage),
      apiKey
    };
  }
  function sanitizeSettingsForClient(settings) {
    const normalized = normalizeStoredSettings(settings);
    const hasApiKey = Boolean(normalized.apiKey);
    return {
      baseUrl: redactSecrets(normalized.baseUrl, hasApiKey ? [normalized.apiKey] : []),
      model: redactSecrets(normalized.model, hasApiKey ? [normalized.apiKey] : []),
      targetLanguage: redactSecrets(
        normalized.targetLanguage,
        hasApiKey ? [normalized.apiKey] : []
      ),
      uiLanguage: normalized.uiLanguage,
      hasApiKey,
      apiKeyHint: hasApiKey ? normalized.apiKey.length > 4 ? `\u2022\u2022\u2022\u2022${normalized.apiKey.slice(-4)}` : "\u5DF2\u914D\u7F6E" : ""
    };
  }
  function validateTranslationInput(payload = {}) {
    if (!payload || typeof payload !== "object") {
      throw new TranslationError("INVALID_REQUEST", "\u7FFB\u8BD1\u8BF7\u6C42\u683C\u5F0F\u65E0\u6548");
    }
    if (typeof payload.text !== "string" || !payload.text.trim()) {
      throw new TranslationError("INVALID_TEXT", "\u8BF7\u9009\u62E9\u9700\u8981\u7FFB\u8BD1\u7684\u6587\u5B57");
    }
    const text = payload.text.trim();
    if (text.length > MAX_TRANSLATION_TEXT_LENGTH) {
      throw new TranslationError(
        "TEXT_TOO_LONG",
        `\u5355\u6B21\u7FFB\u8BD1\u6700\u591A\u652F\u6301 ${MAX_TRANSLATION_TEXT_LENGTH} \u4E2A\u5B57\u7B26`
      );
    }
    const selectionType = cleanString(payload.selectionType || "selection").toLowerCase();
    if (!SELECTION_TYPES.has(selectionType)) {
      throw new TranslationError("INVALID_SELECTION_TYPE", "\u5212\u8BCD\u7C7B\u578B\u65E0\u6548");
    }
    return {
      text,
      selectionType,
      targetLanguage: validateTargetLanguage(
        payload.targetLanguage || DEFAULT_TRANSLATION_SETTINGS.targetLanguage
      )
    };
  }
  function buildChatCompletionRequest({ text, targetLanguage, selectionType, model }) {
    const validated = validateTranslationInput({ text, targetLanguage, selectionType });
    const safeModel = validateModel(model);
    const languageName = TARGET_LANGUAGE_NAMES[validated.targetLanguage] || `the language identified by BCP 47 code ${validated.targetLanguage}`;
    const unit = validated.selectionType === "word" ? "selected Japanese word or short phrase" : "selected Japanese text";
    return {
      model: safeModel,
      messages: [
        {
          role: "system",
          content: `You are a precise translation engine. Translate the ${unit} into ${languageName}. Preserve meaning, names, numbers, tone, and formatting. Return only the translation, with no explanation, labels, or quotation marks.`
        },
        { role: "user", content: validated.text }
      ],
      temperature: 0.2
    };
  }
  function normalizeTokenUsage(usage = {}) {
    const source = usage && typeof usage === "object" ? usage : {};
    const inputTokens = finiteTokenCount(source.prompt_tokens ?? source.input_tokens ?? source.inputTokens);
    const outputTokens = finiteTokenCount(
      source.completion_tokens ?? source.output_tokens ?? source.outputTokens
    );
    const reportedTotal = finiteTokenCount(source.total_tokens ?? source.totalTokens);
    return {
      inputTokens,
      outputTokens,
      totalTokens: Math.max(reportedTotal, inputTokens + outputTokens)
    };
  }
  function contentPartToText(part) {
    if (typeof part === "string") {
      return part;
    }
    if (!part || typeof part !== "object") {
      return "";
    }
    if (typeof part.text === "string") {
      return part.text;
    }
    if (part.text && typeof part.text.value === "string") {
      return part.text.value;
    }
    return "";
  }
  function parseChatCompletionResponse(payload) {
    const choice = payload?.choices?.[0];
    const content = choice?.message?.content ?? choice?.text;
    const translation = Array.isArray(content) ? content.map(contentPartToText).join("").trim() : cleanString(content);
    if (!translation) {
      throw new TranslationError("INVALID_API_RESPONSE", "\u7FFB\u8BD1\u63A5\u53E3\u6CA1\u6709\u8FD4\u56DE\u6709\u6548\u6587\u672C");
    }
    if (translation.length > MAX_TRANSLATION_OUTPUT_LENGTH) {
      throw new TranslationError(
        "TRANSLATION_OUTPUT_TOO_LONG",
        `\u7FFB\u8BD1\u63A5\u53E3\u8FD4\u56DE\u5185\u5BB9\u8D85\u8FC7 ${MAX_TRANSLATION_OUTPUT_LENGTH} \u4E2A\u5B57\u7B26`
      );
    }
    return {
      translation,
      model: cleanString(payload?.model),
      usage: normalizeTokenUsage(payload?.usage)
    };
  }
  function parseApiResponseText(text) {
    if (typeof text !== "string") {
      throw new TranslationError("INVALID_API_RESPONSE", "\u7FFB\u8BD1\u63A5\u53E3\u8FD4\u56DE\u4E86\u65E0\u6CD5\u89E3\u6790\u7684\u6570\u636E");
    }
    if (utf8ByteLength(text) > MAX_API_RESPONSE_BYTES) {
      throw new TranslationError("API_RESPONSE_TOO_LARGE", "\u7FFB\u8BD1\u63A5\u53E3\u54CD\u5E94\u4F53\u8FC7\u5927");
    }
    try {
      return JSON.parse(text);
    } catch {
      throw new TranslationError("INVALID_API_RESPONSE", "\u7FFB\u8BD1\u63A5\u53E3\u8FD4\u56DE\u4E86\u65E0\u6CD5\u89E3\u6790\u7684\u6570\u636E");
    }
  }
  function prependBounded(record, records, maximum) {
    const existing = Array.isArray(records) ? records : [];
    const safeMaximum = Math.max(0, Math.floor(Number(maximum) || 0));
    return [record, ...existing].slice(0, safeMaximum);
  }
  function utf8ByteLength(value) {
    return new TextEncoder().encode(String(value)).byteLength;
  }
  function limitRecordsByUtf8Bytes(records, maximumCount, maximumBytes) {
    const list = Array.isArray(records) ? records : [];
    const countLimit = Math.max(0, Math.floor(Number(maximumCount) || 0));
    const byteLimit = Math.max(2, Math.floor(Number(maximumBytes) || 0));
    const result = [];
    let bytes = 2;
    for (const record of list.slice(0, countLimit)) {
      let encoded;
      try {
        encoded = utf8ByteLength(JSON.stringify(record));
      } catch {
        break;
      }
      const separator = result.length ? 1 : 0;
      if (bytes + separator + encoded > byteLimit) {
        break;
      }
      result.push(record);
      bytes += separator + encoded;
    }
    return result;
  }
  function summarizeTokenUsage(records) {
    const list = Array.isArray(records) ? records : [];
    return list.reduce(
      (summary, record) => {
        const usage = normalizeTokenUsage(record?.usage || record);
        summary.requests += 1;
        summary.inputTokens += usage.inputTokens;
        summary.outputTokens += usage.outputTokens;
        summary.totalTokens += usage.totalTokens;
        return summary;
      },
      { requests: 0, inputTokens: 0, outputTokens: 0, totalTokens: 0 }
    );
  }
  function createRecordId(prefix = "record", now = Date.now(), random = Math.random()) {
    const randomPart = Math.floor(Math.abs(random) * 4294967296).toString(36);
    return `${prefix}-${Math.floor(now).toString(36)}-${randomPart}`;
  }
  function sanitizePageMetadata(payload = {}, sender = {}) {
    return {
      pageUrl: cleanString(sender?.tab?.url || payload.pageUrl, 2048),
      pageTitle: cleanString(sender?.tab?.title || payload.pageTitle, 500)
    };
  }
  function redactSecrets(value, secrets = []) {
    let message = typeof value === "string" ? value : String(value || "");
    for (const secret of secrets) {
      if (typeof secret === "string" && secret) {
        message = message.split(secret).join("[REDACTED]");
      }
    }
    return message.replace(/Bearer\s+[^\s"']+/giu, "Bearer [REDACTED]").replace(/\bsk-[A-Za-z0-9_-]{8,}\b/gu, "[REDACTED]");
  }
  function toSafeError(error, secrets = []) {
    if (error instanceof TranslationError) {
      return { code: error.code, message: redactSecrets(error.message, secrets) };
    }
    return { code: "TRANSLATION_ERROR", message: "\u7FFB\u8BD1\u670D\u52A1\u6682\u65F6\u4E0D\u53EF\u7528\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5" };
  }

  // src/background.js
  var STORAGE_KEYS = Object.freeze({
    settings: "translationSettings",
    history: "translationHistory",
    usage: "translationTokenUsage"
  });
  var SUPPORTED_MESSAGES = /* @__PURE__ */ new Set([
    "GET_TRANSLATION_DASHBOARD",
    "SAVE_TRANSLATION_SETTINGS",
    "TRANSLATE_TEXT",
    "TEST_TRANSLATION_CONNECTION",
    "DELETE_TRANSLATION_HISTORY_ITEM",
    "CLEAR_TRANSLATION_HISTORY",
    "CLEAR_TOKEN_USAGE",
    "OPEN_TRANSLATION_OPTIONS"
  ]);
  var CONTENT_SCRIPT_MESSAGES = /* @__PURE__ */ new Set(["TRANSLATE_TEXT", "OPEN_TRANSLATION_OPTIONS"]);
  var storageMutationQueue = Promise.resolve();
  function enqueueStorageMutation(operation) {
    const task = storageMutationQueue.then(operation, operation);
    storageMutationQueue = task.catch(() => void 0);
    return task;
  }
  async function protectLocalStorage() {
    if (typeof chrome.storage?.local?.setAccessLevel !== "function") {
      throw new TranslationError(
        "STORAGE_SECURITY_UNAVAILABLE",
        "\u5F53\u524D\u6D4F\u89C8\u5668\u65E0\u6CD5\u5B89\u5168\u4FDD\u62A4\u672C\u5730\u7FFB\u8BD1\u8BBE\u7F6E"
      );
    }
    try {
      await chrome.storage.local.setAccessLevel({ accessLevel: "TRUSTED_CONTEXTS" });
    } catch {
      throw new TranslationError(
        "STORAGE_SECURITY_UNAVAILABLE",
        "\u65E0\u6CD5\u542F\u7528\u672C\u5730\u7FFB\u8BD1\u8BBE\u7F6E\u5B89\u5168\u4FDD\u62A4"
      );
    }
  }
  async function initializeBackground() {
    await protectLocalStorage();
  }
  var backgroundReady = null;
  function ensureBackgroundReady() {
    if (!backgroundReady) {
      const attempt = initializeBackground();
      backgroundReady = attempt;
      attempt.catch(() => {
        if (backgroundReady === attempt) {
          backgroundReady = null;
        }
      });
    }
    return backgroundReady;
  }
  ensureBackgroundReady().catch(() => void 0);
  chrome.runtime.onInstalled.addListener(() => {
    ensureBackgroundReady().catch(() => void 0);
  });
  chrome.runtime.onStartup?.addListener(() => {
    ensureBackgroundReady().catch(() => void 0);
  });
  function safeStoredText(value, apiKey = "") {
    return redactSecrets(String(value || ""), apiKey ? [apiKey] : []);
  }
  function sanitizedHistory(value, apiKey = "") {
    if (!Array.isArray(value)) {
      return [];
    }
    const records = value.slice(0, MAX_TRANSLATION_HISTORY).map((entry) => ({
      id: safeStoredText(entry?.id, apiKey),
      timestamp: safeStoredText(entry?.timestamp, apiKey),
      sourceText: safeStoredText(entry?.sourceText, apiKey),
      translatedText: safeStoredText(entry?.translatedText, apiKey),
      pageUrl: safeStoredText(entry?.pageUrl, apiKey),
      pageTitle: safeStoredText(entry?.pageTitle, apiKey),
      selectionType: safeStoredText(entry?.selectionType || "selection", apiKey),
      model: safeStoredText(entry?.model, apiKey),
      targetLanguage: safeStoredText(entry?.targetLanguage, apiKey),
      usage: normalizeTokenUsage(entry?.usage)
    }));
    return limitRecordsByUtf8Bytes(
      records,
      MAX_TRANSLATION_HISTORY,
      MAX_TRANSLATION_HISTORY_BYTES
    );
  }
  function sanitizedUsageRecords(value, apiKey = "") {
    if (!Array.isArray(value)) {
      return [];
    }
    const records = value.slice(0, MAX_TOKEN_USAGE_RECORDS).map((entry) => ({
      id: safeStoredText(entry?.id, apiKey),
      timestamp: safeStoredText(entry?.timestamp, apiKey),
      operation: entry?.operation === "connection-test" ? "connection-test" : "translation",
      pageUrl: safeStoredText(entry?.pageUrl, apiKey),
      pageTitle: safeStoredText(entry?.pageTitle, apiKey),
      selectionType: safeStoredText(entry?.selectionType || "selection", apiKey),
      model: safeStoredText(entry?.model, apiKey),
      targetLanguage: safeStoredText(entry?.targetLanguage, apiKey),
      usage: normalizeTokenUsage(entry?.usage)
    }));
    return limitRecordsByUtf8Bytes(records, MAX_TOKEN_USAGE_RECORDS, MAX_TOKEN_USAGE_BYTES);
  }
  async function getDashboard() {
    const stored = await chrome.storage.local.get(Object.values(STORAGE_KEYS));
    const configuredApiKey = normalizeStoredSettings(stored[STORAGE_KEYS.settings]).apiKey;
    const history = sanitizedHistory(stored[STORAGE_KEYS.history], configuredApiKey);
    const usageRecords = sanitizedUsageRecords(stored[STORAGE_KEYS.usage], configuredApiKey);
    const usageSummary = summarizeTokenUsage(usageRecords);
    return {
      settings: sanitizeSettingsForClient(stored[STORAGE_KEYS.settings]),
      history,
      usageRecords,
      usageSummary,
      summary: usageSummary
    };
  }
  function saveSettings(message) {
    return enqueueStorageMutation(async () => {
      const stored = await chrome.storage.local.get(STORAGE_KEYS.settings);
      const previousSettings = normalizeStoredSettings(stored[STORAGE_KEYS.settings]);
      const changes = {
        ...message.payload && typeof message.payload === "object" ? message.payload : {},
        ...message.settings && typeof message.settings === "object" ? message.settings : {}
      };
      if (!message.payload && !message.settings) {
        Object.assign(changes, message);
      }
      if (message.clearApiKey === true) {
        changes.clearApiKey = true;
      }
      if (message.apiKeyAction === "clear") {
        changes.apiKeyAction = "clear";
      }
      const settings = mergeTranslationSettings(
        previousSettings,
        changes
      );
      const updates = { [STORAGE_KEYS.settings]: settings };
      if (previousSettings.apiKey && !settings.apiKey) {
        const records = await chrome.storage.local.get([STORAGE_KEYS.history, STORAGE_KEYS.usage]);
        updates[STORAGE_KEYS.history] = sanitizedHistory(
          records[STORAGE_KEYS.history],
          previousSettings.apiKey
        );
        updates[STORAGE_KEYS.usage] = sanitizedUsageRecords(
          records[STORAGE_KEYS.usage],
          previousSettings.apiKey
        );
      }
      await chrome.storage.local.set(updates);
      return getDashboard();
    });
  }
  async function requireHostPermission(baseUrl) {
    if (typeof chrome.permissions?.contains !== "function") {
      throw new TranslationError("HOST_PERMISSION_REQUIRED", "\u6269\u5C55\u7F3A\u5C11\u7FFB\u8BD1\u63A5\u53E3\u8BBF\u95EE\u6743\u9650");
    }
    const origin = getApiOriginPattern(baseUrl);
    const granted = await chrome.permissions.contains({ origins: [origin] });
    if (!granted) {
      throw new TranslationError(
        "HOST_PERMISSION_REQUIRED",
        "\u5C1A\u672A\u6388\u6743\u8BBF\u95EE\u8BE5 BaseURL\uFF0C\u8BF7\u4FDD\u5B58\u8BBE\u7F6E\u5E76\u5141\u8BB8\u4E3B\u673A\u8BBF\u95EE\u6743\u9650"
      );
    }
  }
  async function readResponseTextWithLimit(response) {
    const contentLength = Number(response.headers?.get?.("content-length"));
    if (Number.isFinite(contentLength) && contentLength > MAX_API_RESPONSE_BYTES) {
      throw new TranslationError("API_RESPONSE_TOO_LARGE", "\u7FFB\u8BD1\u63A5\u53E3\u54CD\u5E94\u4F53\u8FC7\u5927");
    }
    const reader = response.body?.getReader?.();
    if (!reader) {
      return response.text();
    }
    const decoder = new TextDecoder();
    const parts = [];
    let receivedBytes = 0;
    while (true) {
      const { done, value } = await reader.read();
      if (done) {
        parts.push(decoder.decode());
        return parts.join("");
      }
      receivedBytes += value?.byteLength || 0;
      if (receivedBytes > MAX_API_RESPONSE_BYTES) {
        await reader.cancel().catch(() => void 0);
        throw new TranslationError("API_RESPONSE_TOO_LARGE", "\u7FFB\u8BD1\u63A5\u53E3\u54CD\u5E94\u4F53\u8FC7\u5927");
      }
      parts.push(decoder.decode(value, { stream: true }));
    }
  }
  async function requestTranslation(settings, input) {
    if (!settings.apiKey) {
      throw new TranslationError("API_KEY_MISSING", "\u8BF7\u5148\u5728\u7BA1\u7406\u9762\u677F\u914D\u7F6E API Key");
    }
    if (input.text.includes(settings.apiKey)) {
      throw new TranslationError(
        "SENSITIVE_TEXT_REJECTED",
        "\u6240\u9009\u6587\u672C\u5305\u542B\u5F53\u524D\u914D\u7F6E\u7684 API Key\uFF0C\u5DF2\u963B\u6B62\u53D1\u9001\u548C\u8BB0\u5F55"
      );
    }
    await requireHostPermission(settings.baseUrl);
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), TRANSLATION_REQUEST_TIMEOUT_MS);
    try {
      let response;
      try {
        response = await fetch(buildChatCompletionsUrl(settings.baseUrl), {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${settings.apiKey}`
          },
          body: JSON.stringify(buildChatCompletionRequest({
            ...input,
            model: settings.model
          })),
          cache: "no-store",
          credentials: "omit",
          signal: controller.signal
        });
      } catch (error) {
        if (controller.signal.aborted || error?.name === "AbortError") {
          throw new TranslationError("REQUEST_TIMEOUT", "\u7FFB\u8BD1\u8BF7\u6C42\u8D85\u65F6\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5");
        }
        throw new TranslationError("NETWORK_ERROR", "\u65E0\u6CD5\u8FDE\u63A5\u7FFB\u8BD1\u63A5\u53E3\uFF0C\u8BF7\u68C0\u67E5 BaseURL \u548C\u7F51\u7EDC");
      }
      if (!response.ok) {
        const code = response.status === 401 ? "AUTHENTICATION_FAILED" : response.status === 403 ? "API_ACCESS_DENIED" : response.status === 429 ? "RATE_LIMITED" : `HTTP_${response.status}`;
        const message = response.status === 401 ? "API Key \u65E0\u6548\u6216\u5DF2\u5931\u6548" : response.status === 403 ? "\u7FFB\u8BD1\u63A5\u53E3\u62D2\u7EDD\u8BBF\u95EE\uFF0C\u8BF7\u68C0\u67E5\u8D26\u53F7\u6216\u6A21\u578B\u6743\u9650" : response.status === 429 ? "\u7FFB\u8BD1\u63A5\u53E3\u8BF7\u6C42\u8FC7\u4E8E\u9891\u7E41\u6216\u989D\u5EA6\u4E0D\u8DB3" : `\u7FFB\u8BD1\u63A5\u53E3\u8BF7\u6C42\u5931\u8D25\uFF08HTTP ${response.status}\uFF09`;
        throw new TranslationError(code, message);
      }
      let responseText;
      try {
        responseText = await readResponseTextWithLimit(response);
      } catch (error) {
        if (error instanceof TranslationError) {
          throw error;
        }
        if (controller.signal.aborted || error?.name === "AbortError") {
          throw new TranslationError("REQUEST_TIMEOUT", "\u7FFB\u8BD1\u8BF7\u6C42\u8D85\u65F6\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5");
        }
        throw new TranslationError("INVALID_API_RESPONSE", "\u7FFB\u8BD1\u63A5\u53E3\u8FD4\u56DE\u4E86\u65E0\u6CD5\u89E3\u6790\u7684\u6570\u636E");
      }
      const payload = parseApiResponseText(responseText);
      const result = parseChatCompletionResponse(payload);
      if (result.translation.includes(settings.apiKey) || result.model && result.model.includes(settings.apiKey)) {
        throw new TranslationError("INVALID_API_RESPONSE", "\u7FFB\u8BD1\u63A5\u53E3\u8FD4\u56DE\u4E86\u4E0D\u5B89\u5168\u7684\u6570\u636E");
      }
      return result;
    } finally {
      clearTimeout(timeout);
    }
  }
  function buildUsageRecord({ operation, timestamp, page, input, settings, usage }) {
    const apiKey = settings.apiKey || "";
    return {
      id: createRecordId("usage"),
      timestamp,
      operation,
      pageUrl: safeStoredText(page.pageUrl, apiKey),
      pageTitle: safeStoredText(page.pageTitle, apiKey),
      selectionType: input.selectionType,
      model: safeStoredText(settings.model, apiKey),
      targetLanguage: input.targetLanguage,
      usage
    };
  }
  async function recordTranslation({ page, input, settings, result }) {
    const timestamp = (/* @__PURE__ */ new Date()).toISOString();
    const apiKey = settings.apiKey || "";
    const historyEntry = {
      id: createRecordId("translation"),
      timestamp,
      sourceText: safeStoredText(input.text, apiKey),
      translatedText: safeStoredText(result.translation, apiKey),
      pageUrl: safeStoredText(page.pageUrl, apiKey),
      pageTitle: safeStoredText(page.pageTitle, apiKey),
      selectionType: input.selectionType,
      model: safeStoredText(result.model || settings.model, apiKey),
      targetLanguage: input.targetLanguage,
      usage: result.usage
    };
    const usageRecord = buildUsageRecord({
      operation: "translation",
      timestamp,
      page,
      input,
      settings: { ...settings, model: historyEntry.model },
      usage: result.usage
    });
    const saved = await enqueueStorageMutation(async () => {
      try {
        const stored = await chrome.storage.local.get([STORAGE_KEYS.history, STORAGE_KEYS.usage]);
        const history = limitRecordsByUtf8Bytes(
          prependBounded(historyEntry, stored[STORAGE_KEYS.history], MAX_TRANSLATION_HISTORY),
          MAX_TRANSLATION_HISTORY,
          MAX_TRANSLATION_HISTORY_BYTES
        );
        const usageRecords = limitRecordsByUtf8Bytes(
          prependBounded(usageRecord, stored[STORAGE_KEYS.usage], MAX_TOKEN_USAGE_RECORDS),
          MAX_TOKEN_USAGE_RECORDS,
          MAX_TOKEN_USAGE_BYTES
        );
        try {
          await chrome.storage.local.set({
            [STORAGE_KEYS.history]: history,
            [STORAGE_KEYS.usage]: usageRecords
          });
          return { historySaved: true, usageSaved: true };
        } catch {
          try {
            await chrome.storage.local.set({ [STORAGE_KEYS.usage]: usageRecords });
            return { historySaved: false, usageSaved: true };
          } catch {
            return { historySaved: false, usageSaved: false };
          }
        }
      } catch {
        return { historySaved: false, usageSaved: false };
      }
    });
    return { historyEntry, ...saved };
  }
  async function recordConnectionUsage({ input, settings, result }) {
    const timestamp = (/* @__PURE__ */ new Date()).toISOString();
    const record = buildUsageRecord({
      operation: "connection-test",
      timestamp,
      page: { pageUrl: "", pageTitle: "" },
      input,
      settings: { ...settings, model: result.model || settings.model },
      usage: result.usage
    });
    return enqueueStorageMutation(async () => {
      try {
        const stored = await chrome.storage.local.get(STORAGE_KEYS.usage);
        const usageRecords = limitRecordsByUtf8Bytes(
          prependBounded(record, stored[STORAGE_KEYS.usage], MAX_TOKEN_USAGE_RECORDS),
          MAX_TOKEN_USAGE_RECORDS,
          MAX_TOKEN_USAGE_BYTES
        );
        await chrome.storage.local.set({ [STORAGE_KEYS.usage]: usageRecords });
        return true;
      } catch {
        return false;
      }
    });
  }
  async function translateText(message, sender) {
    const stored = await chrome.storage.local.get(STORAGE_KEYS.settings);
    const settings = mergeTranslationSettings(stored[STORAGE_KEYS.settings], {});
    const input = validateTranslationInput({
      text: message.text ?? message.payload?.text,
      selectionType: message.selectionType ?? message.payload?.selectionType,
      targetLanguage: message.targetLanguage ?? message.payload?.targetLanguage ?? settings.targetLanguage
    });
    const page = sanitizePageMetadata(message.payload || message, sender);
    const result = await requestTranslation(settings, input);
    const saved = await recordTranslation({ page, input, settings, result });
    return {
      translation: result.translation,
      targetLanguage: input.targetLanguage,
      selectionType: input.selectionType,
      usage: result.usage,
      historyEntry: saved.historyEntry,
      historySaved: saved.historySaved,
      usageSaved: saved.usageSaved
    };
  }
  async function testConnection(message) {
    const stored = await chrome.storage.local.get(STORAGE_KEYS.settings);
    const settings = mergeTranslationSettings(
      stored[STORAGE_KEYS.settings],
      message.settings || message.payload || {}
    );
    const input = validateTranslationInput({
      text: "\u3053\u3093\u306B\u3061\u306F",
      selectionType: "sentence",
      targetLanguage: settings.targetLanguage
    });
    const result = await requestTranslation(settings, input);
    const usageSaved = await recordConnectionUsage({ input, settings, result });
    return {
      translation: result.translation,
      targetLanguage: input.targetLanguage,
      selectionType: input.selectionType,
      model: result.model || settings.model,
      usage: result.usage,
      usageSaved
    };
  }
  async function deleteHistoryItem(message) {
    const id = String(message.id || message.historyId || message.payload?.id || "").trim();
    if (!id) {
      throw new TranslationError("INVALID_HISTORY_ID", "\u7F3A\u5C11\u9700\u8981\u5220\u9664\u7684\u5386\u53F2\u8BB0\u5F55 ID");
    }
    await enqueueStorageMutation(async () => {
      const stored = await chrome.storage.local.get(STORAGE_KEYS.history);
      const history = Array.isArray(stored[STORAGE_KEYS.history]) ? stored[STORAGE_KEYS.history].filter((entry) => entry?.id !== id) : [];
      await chrome.storage.local.set({ [STORAGE_KEYS.history]: history });
    });
    return getDashboard();
  }
  async function clearStorageList(key) {
    await enqueueStorageMutation(() => chrome.storage.local.set({ [key]: [] }));
    return getDashboard();
  }
  async function dispatchMessage(message, sender) {
    let trustedExtensionPage = false;
    if (typeof chrome.runtime?.getURL === "function") {
      const extensionRoot = chrome.runtime.getURL("");
      const extensionOrigin = extensionRoot.replace(/\/$/u, "");
      trustedExtensionPage = typeof sender?.url === "string" && sender.url.startsWith(extensionRoot) || sender?.origin === extensionOrigin;
    }
    if (!CONTENT_SCRIPT_MESSAGES.has(message.type) && !trustedExtensionPage) {
      throw new TranslationError(
        "PRIVILEGED_MESSAGE_FORBIDDEN",
        "\u8BE5\u64CD\u4F5C\u53EA\u80FD\u4ECE\u6269\u5C55\u7BA1\u7406\u9875\u9762\u6267\u884C"
      );
    }
    switch (message.type) {
      case "GET_TRANSLATION_DASHBOARD":
        return getDashboard();
      case "SAVE_TRANSLATION_SETTINGS":
        return saveSettings(message);
      case "TRANSLATE_TEXT":
        return translateText(message, sender);
      case "TEST_TRANSLATION_CONNECTION":
        return testConnection(message);
      case "DELETE_TRANSLATION_HISTORY_ITEM":
        return deleteHistoryItem(message);
      case "CLEAR_TRANSLATION_HISTORY":
        return clearStorageList(STORAGE_KEYS.history);
      case "CLEAR_TOKEN_USAGE":
        return clearStorageList(STORAGE_KEYS.usage);
      case "OPEN_TRANSLATION_OPTIONS":
        await chrome.runtime.openOptionsPage();
        return { opened: true };
      default:
        throw new TranslationError("UNKNOWN_MESSAGE", "\u4E0D\u652F\u6301\u7684\u540E\u53F0\u6D88\u606F");
    }
  }
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (!message || !SUPPORTED_MESSAGES.has(message.type)) {
      return void 0;
    }
    ensureBackgroundReady().then(() => dispatchMessage(message, sender)).then((data) => sendResponse({ ok: true, ...data })).catch((error) => {
      const safe = toSafeError(error);
      sendResponse({ ok: false, code: safe.code, error: safe.message });
    });
    return true;
  });
})();
